"""
Gate Entry Management System - Flask Backend
Run: python app.py
Access: http://localhost:5000
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, Response
import sqlite3
try:
    from flask_cors import CORS
    _cors_available = True
except ImportError:
    _cors_available = False
import hashlib
import os
import json
import csv
import io
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, date
from functools import wraps
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
if _cors_available:
    CORS(app, supports_credentials=True)

DB_PATH = os.path.join(os.path.dirname(__file__), 'gate_management.db')

# ──────────────────────────────────────────────
# DATABASE HELPERS
# ──────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript(open(os.path.join(os.path.dirname(__file__), 'sql', 'schema.sql')).read())
    print("✅ Database initialized.")

# ──────────────────────────────────────────────
# AUTH DECORATORS
# ──────────────────────────────────────────────
def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user_id' not in session:
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({'error': 'Unauthorized', 'redirect': '/'}), 401
                return redirect('/')
            if role and session.get('role') != role:
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({'error': 'Forbidden'}), 403
                return redirect('/')
            return f(*args, **kwargs)
        return decorated
    return decorator

# ──────────────────────────────────────────────
# EMAIL HELPER
# ──────────────────────────────────────────────
def send_email(to_email, subject, body, settings):
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From']    = f"{settings.get('smtp_from_name','Gate System')} <{settings.get('smtp_email','')}>"
        msg['To']      = to_email
        msg.attach(MIMEText(body, 'plain'))
        msg.attach(MIMEText(body.replace('\n','<br>'), 'html'))

        host = settings.get('smtp_host', 'smtp.gmail.com')
        port = int(settings.get('smtp_port', 587))
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.ehlo()
            server.starttls()
            server.login(settings.get('smtp_email',''), settings.get('smtp_password',''))
            server.sendmail(msg['From'], to_email, msg.as_string())
        return {'success': True, 'message': 'Email sent'}
    except Exception as e:
        return {'success': False, 'message': str(e)}

def get_settings():
    try:
        with get_db() as conn:
            rows = conn.execute("SELECT setting_key, setting_value FROM settings").fetchall()
            return {r['setting_key']: r['setting_value'] for r in rows}
    except:
        return {}

# ──────────────────────────────────────────────
# PAGE ROUTES (serve HTML pages)
# ──────────────────────────────────────────────
@app.route('/')
def index():
    return redirect('/visitor/register')

@app.route('/admin/login')
def admin_login_page():
    if session.get('role') == 'admin':
        return redirect('/admin/dashboard')
    return render_template('admin/login.html')

@app.route('/admin/dashboard')
@login_required(role='admin')
def admin_dashboard():
    return render_template('admin/dashboard.html', user=session)

@app.route('/admin/employees/tml')
@login_required(role='admin')
def tml_page():
    return render_template('admin/tml.html', user=session)

@app.route('/admin/employees/non-tml')
@login_required(role='admin')
def non_tml_page():
    return render_template('admin/non_tml.html', user=session)

@app.route('/admin/reports/visitors')
@login_required(role='admin')
def visitors_report_page():
    return render_template('admin/report_visitors.html', user=session)

@app.route('/admin/reports/tml')
@login_required(role='admin')
def tml_report_page():
    return render_template('admin/report_tml.html', user=session)

@app.route('/admin/reports/non-tml')
@login_required(role='admin')
def non_tml_report_page():
    return render_template('admin/report_non_tml.html', user=session)

@app.route('/admin/settings')
@login_required(role='admin')
def settings_page():
    return render_template('admin/settings.html', user=session)

@app.route('/admin/settings/approvers')
@login_required(role='admin')
def approvers_page():
    return render_template('admin/approvers.html', user=session)

@app.route('/visitor/register')
def visitor_register_page():
    return render_template('visitor/register.html')

# ──────────────────────────────────────────────
# AUTH API
# ──────────────────────────────────────────────
@app.route('/api/auth/login', methods=['POST'])
def api_login():
    data     = request.get_json()
    username = (data.get('username') or '').strip()
    password = (data.get('password') or '').strip()
    role     = data.get('role', 'admin')

    with get_db() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE username=? AND role=? AND is_active=1",
            (username, role)
        ).fetchone()

    if not user:
        return jsonify({'error': 'Invalid username or password'}), 401

    import hashlib
    pwd_hash = hashlib.sha256(password.encode()).hexdigest()
    if user['password'] != pwd_hash:
        return jsonify({'error': 'Invalid username or password'}), 401

    session['user_id']   = user['id']
    session['username']  = user['username']
    session['full_name'] = user['full_name']
    session['role']      = user['role']
    session.permanent    = True

    redirect_url = '/admin/dashboard' if role == 'admin' else '/visitor/register'
    return jsonify({'success': True, 'redirect': redirect_url})

@app.route('/api/auth/logout', methods=['POST'])
def api_logout():
    role = session.get('role','admin')
    session.clear()
    redirect_url = '/admin/login' if role == 'admin' else '/visitor/register'
    return jsonify({'success': True, 'redirect': redirect_url})

@app.route('/api/auth/me')
def api_me():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    return jsonify({
        'user_id':   session['user_id'],
        'username':  session['username'],
        'full_name': session['full_name'],
        'role':      session['role'],
    })

# ──────────────────────────────────────────────
# DASHBOARD API
# ──────────────────────────────────────────────
@app.route('/api/dashboard/stats')
@login_required(role='admin')
def api_dashboard_stats():
    with get_db() as conn:
        today = date.today().isoformat()
        stats = {
            'visitor_count':   conn.execute("SELECT COUNT(*) FROM visitor_entries").fetchone()[0],
            'today_visitors':  conn.execute("SELECT COUNT(*) FROM visitor_entries WHERE DATE(created_at)=?", (today,)).fetchone()[0],
            'tml_count':       conn.execute("SELECT COUNT(*) FROM tml_employee_entries").fetchone()[0],
            'non_tml_count':   conn.execute("SELECT COUNT(*) FROM non_tml_employee_entries").fetchone()[0],
            'email_sent':      conn.execute("SELECT COUNT(*) FROM tml_employee_entries WHERE email_status='sent'").fetchone()[0]
                             + conn.execute("SELECT COUNT(*) FROM non_tml_employee_entries WHERE email_status='sent'").fetchone()[0],
            'email_failed':    conn.execute("SELECT COUNT(*) FROM tml_employee_entries WHERE email_status='failed'").fetchone()[0]
                             + conn.execute("SELECT COUNT(*) FROM non_tml_employee_entries WHERE email_status='failed'").fetchone()[0],
        }
        recent_visitors = [dict(r) for r in conn.execute(
            "SELECT * FROM visitor_entries ORDER BY created_at DESC LIMIT 8").fetchall()]
        recent_tml = [dict(r) for r in conn.execute(
            "SELECT * FROM tml_employee_entries ORDER BY created_at DESC LIMIT 5").fetchall()]
    return jsonify({'stats': stats, 'recent_visitors': recent_visitors, 'recent_tml': recent_tml})

# ──────────────────────────────────────────────
# VISITOR ENTRIES API
# ──────────────────────────────────────────────
@app.route('/api/visitors', methods=['GET'])
@login_required(role='admin')
def api_visitors_list():
    search  = request.args.get('search', '').strip()
    status  = request.args.get('status', '')
    d_from  = request.args.get('date_from', '')
    d_to    = request.args.get('date_to', '')

    sql    = "SELECT * FROM visitor_entries WHERE 1=1"
    params = []
    if search:
        sql += " AND (visitor_name LIKE ? OR vendor_name LIKE ? OR mobile_no LIKE ? OR person_to_meet LIKE ?)"
        s = f'%{search}%'
        params += [s,s,s,s]
    if status:
        sql += " AND status=?"; params.append(status)
    if d_from:
        sql += " AND DATE(scheduled_date)>=?"; params.append(d_from)
    if d_to:
        sql += " AND DATE(scheduled_date)<=?"; params.append(d_to)
    sql += " ORDER BY created_at DESC"

    with get_db() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    return jsonify({'data': rows})

@app.route('/api/visitors', methods=['POST'])
@login_required(role='visitor_panel')
def api_visitor_create():
    d = request.get_json()
    required = ['visitor_name','mobile_no','purpose_of_visit','person_to_meet','scheduled_date']
    errors = [f for f in required if not (d.get(f) or '').strip()]
    if errors:
        return jsonify({'error': f"Required: {', '.join(errors)}"}), 400
    if not d.get('no_non_compliance'):
        return jsonify({'error': 'You must confirm the Non-Compliance declaration.'}), 400

    # calc expected out
    validity_from = d.get('validity_from','')
    validity_hrs  = float(d.get('validity_period_hrs', 2))
    expected_out  = ''
    if validity_from:
        try:
            t = datetime.strptime(validity_from, '%H:%M')
            mins = t.hour*60 + t.minute + int(validity_hrs*60)
            expected_out = f"{(mins//60)%24:02d}:{mins%60:02d}"
        except: pass

    with get_db() as conn:
        cur = conn.execute("""
            INSERT INTO visitor_entries
            (visitor_name, vendor_name, gender, email, venue_of_meeting, mobile_no, nationality,
             purpose_of_visit, requesting_division, person_to_meet, department,
             scheduled_date, validity_from, validity_period_hrs, expected_out_time, employee_mobile_no,
             has_hard_drive, has_ipad_tablet, has_laptop_other, laptop_serial_other,
             no_non_compliance, remarks)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, (
            d.get('visitor_name',''), d.get('vendor_name',''), d.get('gender','Male'),
            d.get('email',''), d.get('venue_of_meeting',''), d.get('mobile_no',''), d.get('nationality',''),
            d.get('purpose_of_visit',''), d.get('requesting_division',''), d.get('person_to_meet',''),
            d.get('department',''), d.get('scheduled_date',''), validity_from, validity_hrs,
            expected_out, d.get('employee_mobile_no',''),
            1 if d.get('has_hard_drive') else 0,
            1 if d.get('has_ipad_tablet') else 0,
            1 if d.get('has_laptop_other') else 0,
            d.get('laptop_serial_other',''),
            1 if d.get('no_non_compliance') else 0,
            d.get('remarks','')
        ))
        conn.commit()
        new_id = cur.lastrowid
    return jsonify({'success': True, 'id': new_id})

@app.route('/api/visitors/<int:vid>', methods=['PUT'])
@login_required(role='admin')
def api_visitor_update(vid):
    d = request.get_json()
    with get_db() as conn:
        conn.execute("UPDATE visitor_entries SET status=? WHERE id=?", (d.get('status','pending'), vid))
        conn.commit()
    return jsonify({'success': True})

@app.route('/api/visitors/<int:vid>', methods=['DELETE'])
@login_required(role='admin')
def api_visitor_delete(vid):
    with get_db() as conn:
        conn.execute("DELETE FROM visitor_entries WHERE id=?", (vid,))
        conn.commit()
    return jsonify({'success': True})

@app.route('/api/visitors/export')
@login_required(role='admin')
def api_visitors_export():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM visitor_entries ORDER BY created_at DESC").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID','Visitor Name','Vendor','Gender','Email','Mobile','Nationality',
                     'Purpose','Requesting Div','Person to Meet','Dept','Scheduled Date',
                     'Validity From','Validity Hrs','Expected Out','Emp Mobile',
                     'Hard Drive','iPad','Laptop','Laptop Serial','No Non-Compliance','Remarks','Status','Created'])
    for r in rows:
        writer.writerow([r['id'],r['visitor_name'],r['vendor_name'],r['gender'],r['email'],
                         r['mobile_no'],r['nationality'],r['purpose_of_visit'],r['requesting_division'],
                         r['person_to_meet'],r['department'],r['scheduled_date'],r['validity_from'],
                         r['validity_period_hrs'],r['expected_out_time'],r['employee_mobile_no'],
                         'Yes' if r['has_hard_drive'] else 'No',
                         'Yes' if r['has_ipad_tablet'] else 'No',
                         'Yes' if r['has_laptop_other'] else 'No',
                         r['laptop_serial_other'],
                         'Yes' if r['no_non_compliance'] else 'No',
                         r['remarks'],r['status'],r['created_at']])
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=visitors_{date.today()}.csv'})

# ──────────────────────────────────────────────
# TML ENTRIES API
# ──────────────────────────────────────────────
@app.route('/api/tml', methods=['GET'])
@login_required(role='admin')
def api_tml_list():
    search = request.args.get('search','').strip()
    status = request.args.get('status','')
    sql    = "SELECT * FROM tml_employee_entries WHERE 1=1"
    params = []
    if search:
        sql += " AND (employee_name LIKE ?)"; params.append(f'%{search}%')
    if status:
        sql += " AND email_status=?"; params.append(status)
    sql += " ORDER BY created_at DESC"
    with get_db() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    return jsonify({'data': rows})

@app.route('/api/tml', methods=['POST'])
@login_required(role='admin')
def api_tml_create():
    d = request.get_json()
    sender_name = (d.get('sender_name') or '').strip()
    subject     = (d.get('subject') or '').strip()
    body        = (d.get('body_message') or '').strip()

    if not sender_name: return jsonify({'error': 'Sender Name is required'}), 400
    if not subject:     return jsonify({'error': 'Subject is required'}), 400
    if not body:        return jsonify({'error': 'Message body is required'}), 400

    settings  = get_settings()
    settings['smtp_from_name'] = sender_name
    with get_db() as conn:
        approvers = conn.execute("SELECT email FROM approver_emails WHERE is_active=1").fetchall()

    if not approvers:
        approvers = [{'email': settings.get('smtp_email','')}]

    sent = 0; last_error = ''
    for ap in approvers:
        if not ap['email']: continue
        result = send_email(ap['email'], subject, body, settings)
        if result['success']: sent += 1
        else: last_error = result['message']

    email_status = 'sent' if sent > 0 else 'failed'
    now = datetime.now().isoformat() if sent > 0 else None
    with get_db() as conn:
        conn.execute("""INSERT INTO tml_employee_entries
            (employee_name, subject, body_message, email_status, email_sent_at)
            VALUES (?,?,?,?,?)""", (sender_name, subject, body, email_status, now))
        conn.commit()

    if sent > 0:
        return jsonify({'success': True, 'message': f'Email sent to {sent} approver(s)!'})
    return jsonify({'success': False, 'message': f'Saved but email failed: {last_error}'}), 207

@app.route('/api/tml/<int:tid>', methods=['DELETE'])
@login_required(role='admin')
def api_tml_delete(tid):
    with get_db() as conn:
        conn.execute("DELETE FROM tml_employee_entries WHERE id=?", (tid,))
        conn.commit()
    return jsonify({'success': True})

@app.route('/api/tml/export')
@login_required(role='admin')
def api_tml_export():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM tml_employee_entries ORDER BY created_at DESC").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID','Sender Name','Subject','Email Status','Email Sent At','Created'])
    for r in rows:
        writer.writerow([r['id'],r['employee_name'],r['subject'],r['email_status'],r['email_sent_at'],r['created_at']])
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=tml_report_{date.today()}.csv'})

# ──────────────────────────────────────────────
# NON-TML ENTRIES API
# ──────────────────────────────────────────────
@app.route('/api/non-tml', methods=['GET'])
@login_required(role='admin')
def api_non_tml_list():
    search = request.args.get('search','').strip()
    status = request.args.get('status','')
    sql    = "SELECT * FROM non_tml_employee_entries WHERE 1=1"
    params = []
    if search:
        sql += " AND (employee_name LIKE ?)"; params.append(f'%{search}%')
    if status:
        sql += " AND email_status=?"; params.append(status)
    sql += " ORDER BY created_at DESC"
    with get_db() as conn:
        rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    return jsonify({'data': rows})

@app.route('/api/non-tml', methods=['POST'])
@login_required(role='admin')
def api_non_tml_create():
    d = request.get_json()
    sender_name = (d.get('sender_name') or '').strip()
    subject     = (d.get('subject') or '').strip()
    body        = (d.get('body_message') or '').strip()

    if not sender_name: return jsonify({'error': 'Sender Name is required'}), 400
    if not subject:     return jsonify({'error': 'Subject is required'}), 400
    if not body:        return jsonify({'error': 'Message body is required'}), 400

    tagged_subject = f'[Non-TML Employee] {subject}'
    tagged_body    = f'[NON-TML EMPLOYEE]\n\n{body}'

    settings  = get_settings()
    settings['smtp_from_name'] = sender_name
    with get_db() as conn:
        approvers = conn.execute("SELECT email FROM approver_emails WHERE is_active=1").fetchall()
    if not approvers:
        approvers = [{'email': settings.get('smtp_email','')}]

    sent = 0; last_error = ''
    for ap in approvers:
        if not ap['email']: continue
        result = send_email(ap['email'], tagged_subject, tagged_body, settings)
        if result['success']: sent += 1
        else: last_error = result['message']

    email_status = 'sent' if sent > 0 else 'failed'
    now = datetime.now().isoformat() if sent > 0 else None
    with get_db() as conn:
        conn.execute("""INSERT INTO non_tml_employee_entries
            (employee_name, subject, body_message, email_status, email_sent_at)
            VALUES (?,?,?,?,?)""", (sender_name, tagged_subject, tagged_body, email_status, now))
        conn.commit()

    if sent > 0:
        return jsonify({'success': True, 'message': f'Non-TML email sent to {sent} approver(s)!'})
    return jsonify({'success': False, 'message': f'Saved but email failed: {last_error}'}), 207

@app.route('/api/non-tml/<int:nid>', methods=['DELETE'])
@login_required(role='admin')
def api_non_tml_delete(nid):
    with get_db() as conn:
        conn.execute("DELETE FROM non_tml_employee_entries WHERE id=?", (nid,))
        conn.commit()
    return jsonify({'success': True})

@app.route('/api/non-tml/export')
@login_required(role='admin')
def api_non_tml_export():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM non_tml_employee_entries ORDER BY created_at DESC").fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID','Sender Name','Subject','Email Status','Email Sent At','Created'])
    for r in rows:
        writer.writerow([r['id'],r['employee_name'],r['subject'],r['email_status'],r['email_sent_at'],r['created_at']])
    return Response(output.getvalue(), mimetype='text/csv',
                    headers={'Content-Disposition': f'attachment; filename=non_tml_report_{date.today()}.csv'})

# ──────────────────────────────────────────────
# APPROVERS API
# ──────────────────────────────────────────────
@app.route('/api/approvers', methods=['GET'])
@login_required(role='admin')
def api_approvers_list():
    with get_db() as conn:
        rows = [dict(r) for r in conn.execute("SELECT * FROM approver_emails ORDER BY name").fetchall()]
    return jsonify({'data': rows})

@app.route('/api/approvers', methods=['POST'])
@login_required(role='admin')
def api_approver_create():
    d    = request.get_json()
    name = (d.get('name') or '').strip()
    email= (d.get('email') or '').strip()
    dept = (d.get('department') or '').strip()
    if not name or not email:
        return jsonify({'error': 'Name and email are required'}), 400
    try:
        with get_db() as conn:
            conn.execute("INSERT INTO approver_emails (name, email, department) VALUES (?,?,?)", (name, email, dept))
            conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': 'Email already exists'}), 400

@app.route('/api/approvers/<int:aid>', methods=['PUT'])
@login_required(role='admin')
def api_approver_update(aid):
    d = request.get_json()
    action = d.get('action')
    if action == 'toggle':
        with get_db() as conn:
            conn.execute("UPDATE approver_emails SET is_active = 1 - is_active WHERE id=?", (aid,))
            conn.commit()
    else:
        with get_db() as conn:
            conn.execute("UPDATE approver_emails SET name=?, email=?, department=? WHERE id=?",
                         (d.get('name',''), d.get('email',''), d.get('department',''), aid))
            conn.commit()
    return jsonify({'success': True})

@app.route('/api/approvers/<int:aid>', methods=['DELETE'])
@login_required(role='admin')
def api_approver_delete(aid):
    with get_db() as conn:
        conn.execute("DELETE FROM approver_emails WHERE id=?", (aid,))
        conn.commit()
    return jsonify({'success': True})

# ──────────────────────────────────────────────
# SETTINGS API
# ──────────────────────────────────────────────
@app.route('/api/settings', methods=['GET'])
@login_required(role='admin')
def api_settings_get():
    s = get_settings()
    # never expose password
    if 'smtp_password' in s:
        s['smtp_password'] = '••••••••••••••••' if s['smtp_password'] else ''
    return jsonify({'data': s})

@app.route('/api/settings', methods=['POST'])
@login_required(role='admin')
def api_settings_save():
    d = request.get_json()
    keys = ['smtp_host','smtp_port','smtp_email','smtp_password','smtp_from_name','company_name','company_address']
    with get_db() as conn:
        for k in keys:
            if k in d:
                val = d[k]
                if k == 'smtp_password' and val.startswith('••'):
                    continue  # don't overwrite with masked value
                conn.execute("INSERT INTO settings (setting_key, setting_value) VALUES (?,?) "
                             "ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value",
                             (k, val))
        conn.commit()
    return jsonify({'success': True})

# ──────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────
if __name__ == '__main__':
    if not os.path.exists(DB_PATH):
        init_db()
    else:
        init_db()
    print("🚀 Gate Management System running at http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=8004)



