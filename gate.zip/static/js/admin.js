/* gate_mgmt_python/static/js/admin.js - shared utilities */

// ── TOAST NOTIFICATIONS ──────────────────────────
function showToast(msg, type='success') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const colors = {success:'#198754', error:'#dc3545', warning:'#ffc107', info:'#0dcaf0'};
  const icons  = {success:'check-circle-fill', error:'x-circle-fill', warning:'exclamation-triangle-fill', info:'info-circle-fill'};
  const toast  = document.createElement('div');
  toast.style.cssText = `
    background:#fff; border-radius:10px; padding:.85rem 1.1rem;
    box-shadow:0 4px 20px rgba(0,0,0,.15); display:flex; align-items:center; gap:.75rem;
    min-width:280px; max-width:360px; margin-bottom:.5rem;
    border-left:4px solid ${colors[type]||colors.info};
    animation: slideIn .3s ease;
  `;
  toast.innerHTML = `
    <i class="bi bi-${icons[type]||icons.info}" style="color:${colors[type]};font-size:1.1rem;flex-shrink:0;"></i>
    <span style="font-size:.875rem;flex:1;">${msg}</span>
    <button onclick="this.parentElement.remove()" style="border:none;background:none;font-size:1rem;color:#6b7280;cursor:pointer;">×</button>
  `;
  container.appendChild(toast);
  setTimeout(() => toast.style.animation='slideOut .3s ease forwards', 3800);
  setTimeout(() => toast.remove(), 4100);
}

const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn  { from{transform:translateX(120%);opacity:0} to{transform:translateX(0);opacity:1} }
  @keyframes slideOut { from{transform:translateX(0);opacity:1} to{transform:translateX(120%);opacity:0} }
`;
document.head.appendChild(style);

// ── API HELPER ────────────────────────────────────
async function api(method, url, data=null) {
  const opts = {
    method,
    credentials: 'same-origin',
    headers: {'Content-Type':'application/json'}
  };
  if (data) opts.body = JSON.stringify(data);
  const res = await fetch(url, opts);
  if (res.status === 401) { window.location.href='/admin/login'; return null; }
  return res.json();
}

// ── SIDEBAR TOGGLE ────────────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('show');
  document.getElementById('sidebarOverlay')?.classList.toggle('show');
}

// ── LOGOUT ────────────────────────────────────────
async function doLogout() {
  const r = await api('POST', '/api/auth/logout');
  if (r) window.location.href = r.redirect || '/admin/login';
}

// ── MODAL HELPERS ─────────────────────────────────
function openModal(id)  { new bootstrap.Modal(document.getElementById(id)).show(); }
function closeModal(id) { bootstrap.Modal.getInstance(document.getElementById(id))?.hide(); }

// ── CONFIRM DELETE ────────────────────────────────
function confirmDelete(msg) { return confirm(msg || 'Are you sure you want to delete this record?'); }

// ── DATATABLE INIT ────────────────────────────────
function initDataTable(id, extraOpts={}) {
  if ($.fn.DataTable && document.getElementById(id)) {
    $(`#${id}`).DataTable({
      responsive: true, pageLength: 25, order: [[0,'desc']],
      language: { search:'', searchPlaceholder:'Search records...' },
      ...extraOpts
    });
  }
}

// ── BADGE COLOR ───────────────────────────────────
function statusBadge(status) {
  const map = {
    approved:'bg-success', rejected:'bg-danger', completed:'bg-secondary',
    pending:'bg-warning text-dark', sent:'bg-success', failed:'bg-danger'
  };
  return `<span class="badge ${map[status]||'bg-secondary'} status-badge">${capitalize(status)}</span>`;
}
function capitalize(s) { return s ? s.charAt(0).toUpperCase()+s.slice(1) : ''; }

// ── DATE FORMATTING ───────────────────────────────
function fmtDate(s) {
  if (!s) return '—';
  const d = new Date(s);
  return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
}
function fmtTime(s) {
  if (!s) return '—';
  const [h,m] = s.split(':').map(Number);
  const ampm = h>=12?'PM':'AM';
  return `${(h%12)||12}:${String(m).padStart(2,'0')} ${ampm}`;
}
function fmtDateTime(s) {
  if (!s) return '—';
  return new Date(s).toLocaleString('en-IN',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
}
