#!/usr/bin/env python3
"""
Simple HTTP server to serve admin.html on port 8010
Accessible from the network at http://<your_ip>:8010
"""

import http.server
import socketserver
import os
import webbrowser
import time
from pathlib import Path

PORT = 8011
DIRECTORY = str(Path(__file__).parent)

class MyHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)
    
    def do_GET(self):
        if self.path == '/':
            self.send_response(302)
            self.send_header('Location', '/admin.html')
            self.end_headers()
        else:
            super().do_GET()
    
    def end_headers(self):
        # Add headers to prevent caching and allow cross-origin access
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        super().end_headers()

if __name__ == '__main__':
    # Bind to 0.0.0.0 to accept connections from any network interface
    handler = MyHTTPRequestHandler
    with socketserver.TCPServer(("0.0.0.0", PORT), handler) as httpd:
        print(f"🚀 Server running on:")
        print(f"   Local: http://localhost:{PORT}")
        print(f"   Network: http://<your_ip>:{PORT}")
        print(f"   Serving from: {DIRECTORY}")
        print(f"\nPress Ctrl+C to stop the server")
        
        # Open the page in the default browser after a short delay
        time.sleep(0.5)
        webbrowser.open(f'http://localhost:{PORT}/admin.html')
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n✓ Server stopped")
