# Gate Entry Management System — Python + Flask

## Tech Stack
- **Backend:** Python 3.8+ with Flask
- **Database:** SQLite (auto-created, zero config)
- **Frontend:** HTML + CSS + JavaScript (Bootstrap 5)
- **Email:** Python smtplib (built-in, no extra install)

---

## Quick Start (3 Steps)

### Step 1 — Install Python dependencies
```bash
pip install flask flask-cors
```

### Step 2 — Run the server
```bash
cd gate_mgmt_python
python app.py
```

### Step 3 — Open in browser
```
http://localhost:5000
```

The SQLite database is created automatically on first run. No MySQL, no XAMPP needed!

---

## Login Credentials

| Panel | URL | Username | Password |
|-------|-----|----------|----------|
| 🔐 Admin | http://localhost:5000/admin/login | `admin` | `password` |
| 👤 Visitor | http://localhost:5000/visitor/login | `visitor` | `password` |

> ⚠️ Change default passwords after first login!

---

## Project Structure
```
gate_mgmt_python/
├── app.py                    ← Flask app + all API routes
├── requirements.txt          ← pip dependencies
├── gate_management.db        ← SQLite DB (auto-created)
├── sql/
│   └── schema.sql            ← DB schema + seed data
├── templates/
│   ├── admin/
│   │   ├── base.html         ← Shared admin layout (sidebar)
│   │   ├── login.html
│   │   ├── dashboard.html
│   │   ├── tml.html
│   │   ├── non_tml.html
│   │   ├── report_visitors.html
│   │   ├── report_tml.html
│   │   ├── report_non_tml.html
│   │   ├── settings.html
│   │   └── approvers.html
│   └── visitor/
│       ├── login.html
│       └── register.html
└── static/
    ├── css/admin.css         ← Shared admin styles
    └── js/admin.js           ← Shared JS utilities
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login |
| POST | `/api/auth/logout` | Logout |
| GET | `/api/auth/me` | Current user |
| GET | `/api/dashboard/stats` | Dashboard statistics |
| GET/POST | `/api/visitors` | Visitor entries |
| PUT/DELETE | `/api/visitors/<id>` | Update/Delete visitor |
| GET | `/api/visitors/export` | CSV export |
| GET/POST | `/api/tml` | TML entries |
| DELETE | `/api/tml/<id>` | Delete TML entry |
| GET | `/api/tml/export` | CSV export |
| GET/POST | `/api/non-tml` | Non-TML entries |
| DELETE | `/api/non-tml/<id>` | Delete Non-TML entry |
| GET | `/api/non-tml/export` | CSV export |
| GET/POST/PUT/DELETE | `/api/approvers` | Approver management |
| GET/POST | `/api/settings` | SMTP settings |

---

## SMTP Email Setup

1. Go to **Admin → Settings**
2. Enter your Gmail SMTP details:
   - Host: `smtp.gmail.com`
   - Port: `587`
   - Email: `your@gmail.com`
   - Password: 16-char App Password (Google Account → Security → App passwords)

---

## Changing Default Passwords

Passwords are stored as SHA-256 hashes. To change, use Python:
```python
import hashlib
print(hashlib.sha256("your_new_password".encode()).hexdigest())
```
Then update in the SQLite DB using DB Browser for SQLite or command line.
