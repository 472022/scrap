-- Gate Entry Management System - SQLite Schema
-- Auto-created on first run

CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    username   TEXT NOT NULL UNIQUE,
    password   TEXT NOT NULL,
    role       TEXT NOT NULL CHECK(role IN ('visitor_panel','admin')) DEFAULT 'admin',
    full_name  TEXT,
    email      TEXT,
    is_active  INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS visitor_entries (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    visitor_name         TEXT NOT NULL,
    vendor_name          TEXT,
    gender               TEXT DEFAULT 'Male',
    email                TEXT,
    venue_of_meeting     TEXT,
    mobile_no            TEXT,
    nationality          TEXT,
    purpose_of_visit     TEXT,
    requesting_division  TEXT,
    person_to_meet       TEXT,
    department           TEXT,
    scheduled_date       TEXT,
    validity_from        TEXT,
    validity_period_hrs  REAL DEFAULT 2.0,
    expected_out_time    TEXT,
    employee_mobile_no   TEXT,
    has_hard_drive       INTEGER DEFAULT 0,
    has_ipad_tablet      INTEGER DEFAULT 0,
    has_laptop_other     INTEGER DEFAULT 0,
    laptop_serial_other  TEXT,
    no_non_compliance    INTEGER DEFAULT 0,
    remarks              TEXT,
    status               TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','completed')),
    created_at           TEXT DEFAULT (datetime('now')),
    updated_at           TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tml_employee_entries (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_name  TEXT NOT NULL,
    subject        TEXT,
    body_message   TEXT,
    email_status   TEXT DEFAULT 'pending' CHECK(email_status IN ('sent','failed','pending')),
    email_sent_at  TEXT,
    created_at     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS non_tml_employee_entries (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_name  TEXT NOT NULL,
    subject        TEXT,
    body_message   TEXT,
    email_status   TEXT DEFAULT 'pending' CHECK(email_status IN ('sent','failed','pending')),
    email_sent_at  TEXT,
    created_at     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS approver_emails (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    email      TEXT NOT NULL UNIQUE,
    department TEXT,
    is_active  INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    setting_key   TEXT NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at    TEXT DEFAULT (datetime('now'))
);

-- Default admin user (password: password)
INSERT OR IGNORE INTO users (username, password, role, full_name, email)
VALUES ('admin', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'admin', 'System Administrator', 'admin@plant.com');

-- Default visitor user (password: password)
INSERT OR IGNORE INTO users (username, password, role, full_name, email)
VALUES ('visitor', '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', 'visitor_panel', 'Visitor Panel User', 'visitor@plant.com');

-- Default settings
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('smtp_host',      'smtp.gmail.com');
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('smtp_port',      '587');
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('smtp_email',     'your_email@gmail.com');
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('smtp_password',  '');
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('smtp_from_name', 'Gate Management System');
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('company_name',   'TML Plant');
INSERT OR IGNORE INTO settings (setting_key, setting_value) VALUES ('company_address','Plant Address Here');

-- Default approvers
INSERT OR IGNORE INTO approver_emails (name, email, department) VALUES ('HR Manager',    'hr.manager@plant.com',    'Human Resources');
INSERT OR IGNORE INTO approver_emails (name, email, department) VALUES ('Plant Manager', 'plant.manager@plant.com', 'Management');
INSERT OR IGNORE INTO approver_emails (name, email, department) VALUES ('Security Head', 'security@plant.com',      'Security');
