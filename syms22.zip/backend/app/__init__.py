from __future__ import annotations

import os
from datetime import datetime

from dotenv import load_dotenv
from flask import Flask, g, redirect, request, session
from werkzeug.exceptions import RequestEntityTooLarge

from app.config import load_settings
from app.db.engine import init_engine
from app.security.csrf import csrf_field_html, csrf_token, register_csrf_error_handlers
from app.utils.expiry import expiry_alert_summary
from app.utils.flash import flash_get, flash_set
from app.utils.app_logging import init_logging
from app.utils.rbac import can_view_report, current_user_role


def create_app() -> Flask:
    load_dotenv()
    init_logging()
    settings = load_settings()

    app = Flask(
        __name__,
        static_folder="static",
        static_url_path=f"{settings.base_path}",
        template_folder="templates",
    )

    try:
        max_content_mb = int(os.getenv("SYMS_MAX_CONTENT_MB") or "50")
    except Exception:
        max_content_mb = 50
    if max_content_mb < 1:
        max_content_mb = 50
    if max_content_mb > 250:
        max_content_mb = 250

    app.config.update(
        SECRET_KEY=settings.secret_key,
        SESSION_COOKIE_NAME="syms_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=bool(settings.session_cookie_secure),
        MAX_CONTENT_LENGTH=max_content_mb * 1024 * 1024,
    )

    init_engine(settings)
    register_csrf_error_handlers(app)

    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["csrf_field_html"] = csrf_field_html

    @app.before_request
    def _load_flash() -> None:
        g.flash = flash_get()

    @app.errorhandler(RequestEntityTooLarge)
    def _handle_request_too_large(e: Exception) -> object:
        flash_set("error", "Upload failed: file is too large.")
        return redirect(request.referrer or f"{settings.base_path}/dashboard")

    @app.context_processor
    def _inject_globals() -> dict[str, object]:
        flash = getattr(g, "flash", None)
        flash_class = ""
        if isinstance(flash, dict):
            t = str(flash.get("type") or "")
            flash_class = "alert-success" if t == "success" else ("alert-danger" if t == "error" else "alert-info")
        is_authed = bool(session.get("user_id"))
        role = current_user_role() if is_authed else ""

        expiry_menu_badge = 0
        if is_authed and (
            can_view_report("inventory") or can_view_report("dash_inventory") or can_view_report("expiry_alerts")
        ):
            summary = expiry_alert_summary()
            expiry_menu_badge = int((summary.get("near_lots") or 0) + (summary.get("expired_lots") or 0))

        def is_active(needle: str) -> bool:
            uri = str(request.path or "")
            return needle != "" and needle in uri

        return {
            "flash": flash,
            "flash_class": flash_class,
            "isAuthed": is_authed,
            "role": role,
            "expiryMenuBadge": expiry_menu_badge,
            "isActive": is_active,
            "current_year": datetime.now().year,
        }

    from app.modules.core.routes import bp as core_bp
    from app.modules.auth.routes import bp as auth_bp
    from app.modules.dashboard.routes import bp as dashboard_bp
    from app.modules.memo.routes import bp as memo_bp
    from app.modules.mutilation.routes import bp as mutilation_bp
    from app.modules.segregation.routes import bp as segregation_bp
    from app.modules.outward.routes import bp as outward_bp
    from app.modules.inventory.routes import bp as inventory_bp
    from app.modules.reports.routes import bp as reports_bp
    from app.modules.reports.api_trends import bp as reports_api_trends_bp
    from app.modules.reports.api_report_charts import bp as reports_api_charts_bp
    from app.modules.requests.routes import bp as requests_bp
    from app.modules.settings.routes import bp as settings_bp
    from app.modules.sqpdcme.routes import bp as sqpdcme_bp
    from app.modules.scrap_admin_auth.routes import bp as scrap_admin_auth_bp
    from app.modules.scrap_admin_requests.routes import bp as scrap_admin_requests_bp
    from app.modules.scrap_admin_settings.routes import bp as scrap_admin_settings_bp
    from app.modules.chatbot.routes import bp as chatbot_bp

    app.register_blueprint(core_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(memo_bp)
    app.register_blueprint(mutilation_bp)
    app.register_blueprint(segregation_bp)
    app.register_blueprint(outward_bp)
    app.register_blueprint(inventory_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(reports_api_trends_bp)
    app.register_blueprint(reports_api_charts_bp)
    app.register_blueprint(requests_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(sqpdcme_bp)
    app.register_blueprint(scrap_admin_auth_bp)
    app.register_blueprint(scrap_admin_requests_bp)
    app.register_blueprint(scrap_admin_settings_bp)
    app.register_blueprint(chatbot_bp)

    return app
