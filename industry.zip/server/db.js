import sqlite3 from 'sqlite3';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { DEFAULT_METRIC_DEFINITIONS } from './services/metricDefinitions.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '..');
const dataDir = path.join(projectRoot, 'data');

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'industrial_dashboard.db');

sqlite3.verbose();
const db = new sqlite3.Database(dbPath);

export function runSql(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

export function querySql(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

export function getSql(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

/**
 * Secure password hashing using PBKDF2
 */
export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

/**
 * Verify password against stored hash
 */
export function verifyPassword(password, storedHash) {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, originalHash] = storedHash.split(':');
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return hash === originalHash;
}

export async function initDatabase() {
  await runSql(`
    CREATE TABLE IF NOT EXISTS users (
      user_id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      full_name TEXT NOT NULL,
      role TEXT NOT NULL,
      department TEXT DEFAULT 'General',
      created_at TEXT NOT NULL,
      is_active INTEGER DEFAULT 1
    )
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS uploads (
      upload_id TEXT PRIMARY KEY,
      file_name TEXT NOT NULL,
      file_hash TEXT UNIQUE NOT NULL,
      file_format TEXT NOT NULL,
      upload_timestamp TEXT NOT NULL,
      stored_filename TEXT,
      reporting_period TEXT,
      total_rows INTEGER DEFAULT 0,
      valid_rows INTEGER DEFAULT 0,
      rejected_rows INTEGER DEFAULT 0,
      status TEXT NOT NULL,
      summary_json TEXT
    )
  `);

  // Add the stored-file pointer when upgrading databases created before it existed.
  const uploadColumns = await querySql('PRAGMA table_info(uploads)');
  if (!uploadColumns.some(column => column.name === 'stored_filename')) {
    await runSql('ALTER TABLE uploads ADD COLUMN stored_filename TEXT');
  }

  await runSql(`
    CREATE TABLE IF NOT EXISTS performance_data (
      record_id INTEGER PRIMARY KEY AUTOINCREMENT,
      upload_id TEXT,
      record_date TEXT NOT NULL,
      year INTEGER NOT NULL,
      month INTEGER NOT NULL,
      fiscal_year INTEGER NOT NULL,
      plant TEXT DEFAULT 'Dharwad',
      department TEXT DEFAULT 'General',
      module TEXT NOT NULL,
      category TEXT DEFAULT '',
      metric_id TEXT NOT NULL,
      target_value REAL DEFAULT 0,
      actual_value REAL DEFAULT 0,
      unit TEXT DEFAULT '',
      FOREIGN KEY(upload_id) REFERENCES uploads(upload_id) ON DELETE CASCADE
    )
  `);

  await runSql(`
    CREATE INDEX IF NOT EXISTS idx_perf_module_date ON performance_data(module, record_date);
  `);
  await runSql(`
    CREATE INDEX IF NOT EXISTS idx_perf_metric_fy ON performance_data(metric_id, fiscal_year, month);
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS metric_definitions (
      metric_id TEXT PRIMARY KEY,
      metric_name TEXT NOT NULL,
      module TEXT NOT NULL,
      unit TEXT DEFAULT '',
      aggregation_type TEXT DEFAULT 'sum',
      direction TEXT DEFAULT 'higher_better',
      section TEXT DEFAULT ''
    )
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS column_mappings (
      source_column TEXT PRIMARY KEY,
      target_metric_id TEXT NOT NULL,
      target_field TEXT DEFAULT 'actual'
    )
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS dashboard_config (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS processing_logs (
      log_id INTEGER PRIMARY KEY AUTOINCREMENT,
      upload_id TEXT,
      stage TEXT NOT NULL,
      status TEXT NOT NULL,
      message TEXT,
      timestamp TEXT NOT NULL
    )
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS kpi_snapshots (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      target REAL,
      actual REAL,
      unit TEXT,
      module TEXT,
      section TEXT,
      target_label TEXT,
      actual_label TEXT,
      measure TEXT
    )
  `);

  await runSql(`
    CREATE TABLE IF NOT EXISTS dashboard_snapshots (
      snapshot_id TEXT PRIMARY KEY,
      upload_id TEXT,
      reporting_date TEXT NOT NULL,
      state_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY(upload_id) REFERENCES uploads(upload_id) ON DELETE SET NULL
    )
  `);

  // Seed default 4 initial users if users table is empty
  const userCount = await getSql('SELECT COUNT(*) as cnt FROM users');
  if (!userCount || userCount.cnt === 0) {
    const initialUsers = [
      { id: 'usr_admin', username: 'admin', pass: 'admin123', name: 'System Administrator', role: 'Admin', dept: 'IT & Systems' },
      { id: 'usr_plant_mgr', username: 'plant_manager', pass: 'plant123', name: 'Plant Executive Manager', role: 'Executive', dept: 'Plant Operations' },
      { id: 'usr_quality', username: 'quality_officer', pass: 'quality123', name: 'Quality Operations Officer', role: 'Quality Lead', dept: 'Quality Assurance' },
      { id: 'usr_safety', username: 'safety_head', pass: 'safety123', name: 'Safety & Health Head', role: 'Safety Lead', dept: 'EHS & Safety' }
    ];

    const now = new Date().toISOString();
    for (const u of initialUsers) {
      const pHash = hashPassword(u.pass);
      await runSql(`
        INSERT INTO users (user_id, username, password_hash, full_name, role, department, created_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
      `, [u.id, u.username, pHash, u.name, u.role, u.dept, now]);
    }
    console.log('[SQLite] Seeded 4 default user accounts successfully.');
  }

  // Seed default metric definitions
  await runSql('BEGIN TRANSACTION');
  for (const m of DEFAULT_METRIC_DEFINITIONS) {
    await runSql(`
      INSERT OR REPLACE INTO metric_definitions (metric_id, metric_name, module, unit, aggregation_type, direction, section)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [m.metric_id, m.metric_name, m.module, m.unit || '', m.aggregation_type || 'sum', m.direction || 'higher_better', m.section || '']);
  }
  await runSql('COMMIT');

  // Seed default config
  await runSql("INSERT OR IGNORE INTO dashboard_config (key, value) VALUES ('fiscal_year_start_month', '4')");
  await runSql("INSERT OR IGNORE INTO dashboard_config (key, value) VALUES ('current_reporting_date', '2026-09-30')");
  await runSql("INSERT OR IGNORE INTO dashboard_config (key, value) VALUES ('current_module', 'overall')");

  console.log(`[SQLite] Database successfully initialized at: ${dbPath}`);
}

export default db;

