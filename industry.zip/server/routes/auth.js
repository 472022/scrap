import express from 'express';
import crypto from 'crypto';
import { getSql, querySql, runSql, verifyPassword, hashPassword } from '../db.js';

const router = express.Router();

// Active sessions memory map: token -> userObj
const activeSessions = new Map();

/**
 * Helper to generate a random session token
 */
function generateSessionToken(user) {
  const token = 'sess_' + Date.now() + '_' + crypto.randomBytes(16).toString('hex');
  activeSessions.set(token, {
    userId: user.user_id,
    username: user.username,
    fullName: user.full_name,
    role: user.role,
    department: user.department,
    createdAt: new Date().toISOString()
  });
  return token;
}

/**
 * Middleware to verify authorization token header
 */
export function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'Authentication token required.' });
  }

  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const session = activeSessions.get(token);

  if (!session) {
    return res.status(401).json({ error: 'Invalid or expired authentication session.' });
  }

  req.user = session;
  req.token = token;
  next();
}

export function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'Admin') return res.status(403).json({ error: 'Administrator access required.' });
    next();
  });
}

/**
 * POST /api/auth/login
 * User login authentication handler
 */
router.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password are required.' });
    }

    const cleanUsername = String(username).trim().toLowerCase();
    const user = await getSql('SELECT * FROM users WHERE LOWER(username) = ? AND is_active = 1', [cleanUsername]);

    if (!user) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const isValid = verifyPassword(password, user.password_hash);
    if (!isValid) {
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const token = generateSessionToken(user);

    return res.status(200).json({
      success: true,
      token,
      user: {
        userId: user.user_id,
        username: user.username,
        fullName: user.full_name,
        role: user.role,
        department: user.department
      }
    });
  } catch (err) {
    console.error('[Auth Login Error]', err);
    return res.status(500).json({ error: 'Login authentication failed.', details: err.message });
  }
});

/**
 * GET /api/auth/me
 * Validate current active session token
 */
router.get('/auth/me', (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: 'No active session token.' });
  }

  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const session = activeSessions.get(token);

  if (!session) {
    return res.status(401).json({ error: 'Session expired.' });
  }

  return res.status(200).json({ success: true, user: session });
});

/**
 * POST /api/auth/logout
 * Log out user session
 */
router.post('/auth/logout', (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.replace(/^Bearer\s+/i, '').trim();
    activeSessions.delete(token);
  }
  return res.status(200).json({ success: true, message: 'Successfully logged out.' });
});

/**
 * GET /api/users
 * List all users from SQLite backend database
 */
router.get('/users', requireAdmin, async (req, res) => {
  try {
    const users = await querySql('SELECT user_id, username, full_name, role, department, created_at, is_active FROM users ORDER BY created_at ASC');
    return res.status(200).json({ success: true, users });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch users.', details: err.message });
  }
});

/**
 * POST /api/users
 * Add a new user account to SQLite backend database
 */
router.post('/users', requireAdmin, async (req, res) => {
  try {
    const { username, password, full_name, role, department } = req.body;

    if (!username || !password || !full_name) {
      return res.status(400).json({ error: 'Username, password, and full_name are required.' });
    }

    const cleanUsername = String(username).trim().toLowerCase();
    const existing = await getSql('SELECT user_id FROM users WHERE LOWER(username) = ?', [cleanUsername]);
    if (existing) {
      return res.status(409).json({ error: 'Username already exists.' });
    }

    const userId = 'usr_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    const pHash = hashPassword(password);
    const now = new Date().toISOString();

    await runSql(`
      INSERT INTO users (user_id, username, password_hash, full_name, role, department, created_at, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    `, [userId, cleanUsername, pHash, full_name, role || 'User', department || 'General', now]);

    return res.status(201).json({
      success: true,
      message: 'User created successfully.',
      user: { userId, username: cleanUsername, fullName: full_name, role: role || 'User', department: department || 'General' }
    });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to create user.', details: err.message });
  }
});

/**
 * DELETE /api/users/:id
 * Delete a user from SQLite backend database
 */
router.delete('/users/:id', requireAdmin, async (req, res) => {
  try {
    const userId = req.params.id;
    const user = await getSql('SELECT user_id, username FROM users WHERE user_id = ?', [userId]);

    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    if (user.username === 'admin') {
      return res.status(403).json({ error: 'System administrator account cannot be deleted.' });
    }

    await runSql('DELETE FROM users WHERE user_id = ?', [userId]);
    return res.status(200).json({ success: true, message: `User '${user.username}' deleted successfully.` });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to delete user.', details: err.message });
  }
});

export default router;
