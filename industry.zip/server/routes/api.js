import express from 'express';
import { querySql, getSql, runSql } from '../db.js';
import { getMetricValuesForPeriod, calculateAchievement, calculateStatus, isLowerBetter } from '../services/calculationEngine.js';
import { getTopStrengths, getTopFocusAreas } from '../services/insightsService.js';
import { requireAuth } from './auth.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const router = express.Router();
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

router.get('/dashboard/state', requireAuth, async (_req, res) => {
  try {
    const snapshot = await getSql('SELECT state_json, reporting_date, created_at FROM dashboard_snapshots ORDER BY created_at DESC LIMIT 1');
    return res.json(snapshot ? { success: true, state: JSON.parse(snapshot.state_json), reportingDate: snapshot.reporting_date } : { success: true, state: null });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to load dashboard state.', details: err.message });
  }
});

router.put('/dashboard/state', requireAuth, async (req, res) => {
  try {
    const dashboardState = req.body?.state;
    if (!dashboardState || typeof dashboardState !== 'object' || !Array.isArray(dashboardState.kpis)) {
      return res.status(400).json({ error: 'A dashboard state with a KPI array is required.' });
    }
    const cfg = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
    const reportingDate = dashboardState.reportingDate || cfg?.value || new Date().toISOString().slice(0, 10);
    const upload = await getSql('SELECT upload_id FROM uploads ORDER BY upload_timestamp DESC LIMIT 1');
    await runSql('INSERT INTO dashboard_snapshots (snapshot_id, upload_id, reporting_date, state_json, created_at) VALUES (?, ?, ?, ?, ?)', [
      `snap_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, upload?.upload_id || null,
      reportingDate, JSON.stringify(dashboardState), new Date().toISOString()
    ]);
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to save dashboard state.', details: err.message });
  }
});

router.get('/uploads/latest/file', requireAuth, async (_req, res) => {
  const upload = await getSql('SELECT stored_filename, file_name FROM uploads ORDER BY upload_timestamp DESC LIMIT 1');
  if (!upload?.stored_filename) return res.status(404).json({ error: 'No stored workbook is available.' });
  const filePath = path.join(projectRoot, 'uploads', path.basename(upload.stored_filename));
  if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'The stored workbook file is missing.' });
  return res.download(filePath, upload.file_name);
});

const ALL_MODULES = [
  'safety', 'quality', 'productivity', 'delivery', 'cost', 'inventory', 'environment', 'hr', 'digital'
];

/**
 * GET /api/dashboard/summary
 * Returns overall plant score, 9 pillar scores, top 5 strengths, top 4 focus areas
 */
router.get('/dashboard/summary', async (req, res) => {
  try {
    const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
    const reportingDate = req.query.reportingDate || (reportingConfig ? reportingConfig.value : '2026-09-30');

    const moduleScores = {};
    let totalScoreSum = 0;
    let validModulesCount = 0;

    for (const mod of ALL_MODULES) {
      const metrics = await querySql(`
        SELECT DISTINCT d.metric_id FROM metric_definitions d
        JOIN performance_data p ON p.metric_id = d.metric_id
        WHERE d.module = ? AND p.target_value IS NOT NULL AND p.actual_value IS NOT NULL
      `, [mod]);
      if (!metrics || metrics.length === 0) {
        moduleScores[mod] = { score: null, achievement: null, status: 'No data', metricCount: 0 };
        continue;
      }

      let modAchievementSum = 0;
      let metricCount = 0;

      for (const m of metrics) {
        const val = await getMetricValuesForPeriod(m.metric_id, 'ftm', { reportingDate });
        modAchievementSum += val.achievement;
        metricCount++;
      }

      const avgScore = metricCount > 0 ? parseFloat((modAchievementSum / metricCount).toFixed(1)) : null;
      let status = 'Green';
      if (avgScore === null) status = 'No data';
      else if (avgScore < 80) status = 'Red';
      else if (avgScore < 95) status = 'Yellow';

      moduleScores[mod] = {
        score: avgScore,
        achievement: avgScore,
        status,
        metricCount
      };

      if (avgScore !== null) {
        totalScoreSum += avgScore;
        validModulesCount++;
      }
    }

    const overallScore = validModulesCount > 0 ? parseFloat((totalScoreSum / validModulesCount).toFixed(1)) : null;
    const strengths = await getTopStrengths(reportingDate, 5);
    const focusAreas = await getTopFocusAreas(reportingDate, 4);

    return res.status(200).json({
      success: true,
      overallScore,
      reportingDate,
      moduleScores,
      strengths,
      focusAreas
    });
  } catch (err) {
    console.error('[API Summary Error]', err);
    return res.status(500).json({ error: 'Failed to calculate summary data.', details: err.message });
  }
});

/**
 * GET /api/dashboard/module/:moduleName
 * Returns module-specific KPI cards, monthly trends, breakdown tables, and chart datasets
 */
router.get('/dashboard/module/:moduleName', async (req, res) => {
  try {
    const moduleName = req.params.moduleName.toLowerCase();
    const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
    const reportingDate = req.query.reportingDate || (reportingConfig ? reportingConfig.value : '2026-09-30');

    // Fetch all metric definitions for this module
    const metricDefs = await querySql('SELECT * FROM metric_definitions WHERE module = ? ORDER BY metric_id ASC', [moduleName]);

    const kpiDetails = [];
    const tableData = {};

    for (const def of metricDefs) {
      const ftm = await getMetricValuesForPeriod(def.metric_id, 'ftm', { reportingDate });
      const lastMonth = await getMetricValuesForPeriod(def.metric_id, 'last_month', { reportingDate });
      const ytd = await getMetricValuesForPeriod(def.metric_id, 'ytd', { reportingDate });

      const kpiObj = {
        metric_id: def.metric_id,
        metric_name: def.metric_name,
        unit: def.unit,
        section: def.section || 'general',
        direction: def.direction,
        aggregation_type: def.aggregation_type,
        ftm: {
          target: ftm.target,
          actual: ftm.actual,
          achievement: ftm.achievement,
          status: ftm.status
        },
        last_month: {
          target: lastMonth.target,
          actual: lastMonth.actual,
          achievement: lastMonth.achievement,
          status: lastMonth.status
        },
        ytd: {
          target: ytd.target,
          actual: ytd.actual,
          achievement: ytd.achievement,
          status: ytd.status
        }
      };

      kpiDetails.push(kpiObj);

      // Group into table section
      const sec = def.section || 'default';
      if (!tableData[sec]) tableData[sec] = [];
      tableData[sec].push(kpiObj);
    }

    // Generate 12-month historical trend for charts
    const monthlyTrends = {};
    const d = new Date(reportingDate);
    const months = [];
    for (let i = 11; i >= 0; i--) {
      const past = new Date(d.getFullYear(), d.getMonth() - i, 1);
      const yr = past.getFullYear();
      const mo = String(past.getMonth() + 1).padStart(2, '0');
      months.push(`${yr}-${mo}`);
    }

    for (const def of metricDefs) {
      const trendPoints = [];
      for (const mStr of months) {
        const row = await getSql(`
          SELECT actual_value FROM performance_data
          WHERE metric_id = ? AND record_date LIKE ?
        `, [def.metric_id, `${mStr}%`]);
        trendPoints.push({
          period: mStr,
          value: row ? row.actual_value : 0
        });
      }
      monthlyTrends[def.metric_id] = trendPoints;
    }

    return res.status(200).json({
      success: true,
      module: moduleName,
      reportingDate,
      metricsCount: metricDefs.length,
      kpis: kpiDetails,
      tables: tableData,
      trends: monthlyTrends,
      chartLabels: months
    });
  } catch (err) {
    console.error('[API Module Error]', err);
    return res.status(500).json({ error: `Failed to fetch module data for ${req.params.moduleName}.`, details: err.message });
  }
});

/**
 * POST /api/kpi/update
 * Updates a KPI target or actual value manually
 */
router.post('/kpi/update', requireAuth, async (req, res) => {
  try {
    const { metric_id, target_value, actual_value, period_date } = req.body;
    if (!metric_id) {
      return res.status(400).json({ error: 'metric_id is required.' });
    }

    const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
    const pDate = period_date || (reportingConfig ? reportingConfig.value : '2026-09-30');

    const dObj = new Date(pDate);
    const yr = dObj.getFullYear();
    const mo = dObj.getMonth() + 1;

    // Check if record exists
    const existing = await getSql('SELECT record_id FROM performance_data WHERE metric_id = ? AND year = ? AND month = ?', [metric_id, yr, mo]);

    if (existing) {
      await runSql(`
        UPDATE performance_data
        SET target_value = COALESCE(?, target_value), actual_value = COALESCE(?, actual_value)
        WHERE record_id = ?
      `, [target_value !== undefined ? target_value : null, actual_value !== undefined ? actual_value : null, existing.record_id]);
    } else {
      const def = await getSql('SELECT module FROM metric_definitions WHERE metric_id = ?', [metric_id]);
      await runSql(`
        INSERT INTO performance_data (record_date, year, month, fiscal_year, plant, department, module, metric_id, target_value, actual_value)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        pDate, yr, mo, yr + (mo >= 4 ? 1 : 0), 'Dharwad Plant', 'General', def ? def.module : 'general', metric_id,
        target_value || 0, actual_value || 0
      ]);
    }

    return res.status(200).json({ success: true, message: `KPI ${metric_id} successfully updated.` });
  } catch (err) {
    console.error('[API KPI Update Error]', err);
    return res.status(500).json({ error: 'Failed to update KPI record.', details: err.message });
  }
});

/**
 * GET /api/uploads/history
 * Returns file upload history
 */
router.get('/uploads/history', async (req, res) => {
  try {
    const uploads = await querySql('SELECT * FROM uploads ORDER BY upload_timestamp DESC LIMIT 50');
    return res.status(200).json({ success: true, uploads });
  } catch (err) {
    console.error('[API Upload History Error]', err);
    return res.status(500).json({ error: 'Failed to fetch upload history.', details: err.message });
  }
});

/**
 * GET /api/config
 */
router.get('/config', async (req, res) => {
  try {
    const rows = await querySql('SELECT * FROM dashboard_config');
    const config = {};
    rows.forEach(r => config[r.key] = r.value);
    return res.status(200).json({ success: true, config });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch config.', details: err.message });
  }
});

/**
 * POST /api/config
 */
router.post('/config', requireAuth, async (req, res) => {
  try {
    const { key, value } = req.body;
    if (!key || value === undefined) {
      return res.status(400).json({ error: 'key and value are required.' });
    }
    await runSql('INSERT OR REPLACE INTO dashboard_config (key, value) VALUES (?, ?)', [key, String(value)]);
    return res.status(200).json({ success: true, key, value });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to save config.', details: err.message });
  }
});

export default router;
