import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULT_METRIC_DEFINITIONS } from './services/metricDefinitions.js';
import { calculateFileHash, parseDatasetFile } from './services/parserService.js';
import { getFiscalYear } from './services/calculationEngine.js';
import { getSql, initDatabase, runSql } from './db.js';

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const datasetPath = path.join(projectRoot, 'Daily Report.xlsx');
const uploadDir = path.join(projectRoot, 'uploads');

function reportDateFromPeriod(period) {
  const [year, month] = period.split('-').map(Number);
  return `${period}-${new Date(year, month, 0).getDate()}`;
}

async function main() {
  if (!fs.existsSync(datasetPath)) {
    throw new Error(`Required source workbook not found: ${datasetPath}`);
  }

  await initDatabase();
  const buffer = fs.readFileSync(datasetPath);
  const parsed = parseDatasetFile(buffer, path.basename(datasetPath));
  if (!parsed.records.length) {
    throw new Error('The source workbook did not produce any valid performance records.');
  }

  const period = parsed.summary.latestReportingPeriod;
  const reportingDate = reportDateFromPeriod(period);
  const uploadId = `up_seed_${Date.now()}`;
  const storedFilename = `${uploadId}.xlsx`;
  const storedPath = path.join(uploadDir, storedFilename);
  const timestamp = new Date().toISOString();
  const fileHash = calculateFileHash(buffer);

  fs.mkdirSync(uploadDir, { recursive: true });
  fs.copyFileSync(datasetPath, storedPath);

  try {
    await runSql('BEGIN TRANSACTION');
    await runSql('DELETE FROM performance_data');
    await runSql('DELETE FROM processing_logs');
    await runSql('DELETE FROM dashboard_snapshots');
    await runSql('DELETE FROM kpi_snapshots');
    await runSql('DELETE FROM column_mappings');
    await runSql('DELETE FROM uploads');
    await runSql('DELETE FROM metric_definitions');
    await runSql('DELETE FROM dashboard_config');

    for (const def of DEFAULT_METRIC_DEFINITIONS) {
      await runSql(`
        INSERT INTO metric_definitions (metric_id, metric_name, module, unit, aggregation_type, direction, section)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `, [def.metric_id, def.metric_name, def.module, def.unit || '', def.aggregation_type || 'sum', def.direction || 'higher_better', def.section || '']);
    }

    await runSql(`
      INSERT INTO dashboard_config (key, value) VALUES
      ('fiscal_year_start_month', '4'),
      ('current_reporting_date', ?),
      ('current_module', 'overall')
    `, [reportingDate]);

    await runSql(`
      INSERT INTO uploads (upload_id, file_name, file_hash, file_format, upload_timestamp, stored_filename, reporting_period, total_rows, valid_rows, rejected_rows, status, summary_json)
      VALUES (?, ?, ?, 'xlsx', ?, ?, ?, ?, ?, ?, 'completed', ?)
    `, [
      uploadId,
      path.basename(datasetPath),
      fileHash,
      timestamp,
      storedFilename,
      period,
      parsed.summary.totalParsedRows,
      parsed.records.length,
      parsed.summary.rejected_rows || 0,
      JSON.stringify(parsed.summary)
    ]);

    for (const record of parsed.records) {
      const date = record.period_date.length === 7 ? `${record.period_date}-01` : record.period_date;
      const parsedDate = new Date(`${date}T00:00:00Z`);
      const year = parsedDate.getUTCFullYear();
      const month = parsedDate.getUTCMonth() + 1;
      await runSql(`
        INSERT INTO performance_data (upload_id, record_date, year, month, fiscal_year, plant, department, module, category, metric_id, target_value, actual_value, unit)
        VALUES (?, ?, ?, ?, ?, 'Dharwad Plant', ?, ?, ?, ?, ?, ?, ?)
      `, [
        uploadId,
        date,
        year,
        month,
        getFiscalYear(date, 4),
        record.department || 'Dharwad Plant',
        record.module,
        record.section || '',
        record.metric_id,
        record.target_value ?? null,
        record.actual_value ?? null,
        record.unit || ''
      ]);
    }

    await runSql(`INSERT INTO processing_logs (upload_id, stage, status, message, timestamp) VALUES (?, 'reset_and_import', 'success', ?, ?)`, [
      uploadId,
      `Fresh database loaded from ${path.basename(datasetPath)}: ${parsed.records.length} records, reporting month ${period}.`,
      timestamp
    ]);
    await runSql('COMMIT');
  } catch (error) {
    await runSql('ROLLBACK');
    fs.rmSync(storedPath, { force: true });
    throw error;
  }

  const files = fs.readdirSync(uploadDir).filter(file => file !== storedFilename);
  for (const file of files) fs.rmSync(path.join(uploadDir, file), { force: true, recursive: true });

  const row = await getSql('SELECT COUNT(*) AS count FROM performance_data');
  console.log(`Fresh import complete: ${row.count} performance records from ${path.basename(datasetPath)} for ${period}.`);
}

main().catch(error => {
  console.error('[Reset/import failed]', error);
  process.exitCode = 1;
});
