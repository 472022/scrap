import crypto from 'crypto';
import * as xlsxModule from 'xlsx';
import { DEFAULT_METRIC_DEFINITIONS } from './metricDefinitions.js';

const xlsx = xlsxModule.default || xlsxModule;

export function calculateFileHash(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function cleanStr(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

const ALIAS_MAP = {
  // Safety
  'safesession': 'safe_session', 'safesessions': 'safe_session',
  'visilens': 'visilens', 'visilenshealthycamera': 'visilens',
  'leadershiponfloor': 'floor_leadership', 'leadershiponfloor90mins': 'floor_leadership',
  'leadeshiponfloor': 'floor_leadership', 'leadeshiponfloor90mins': 'floor_leadership',
  'leadeshiponfloor90minssessions': 'floor_leadership',
  'safetytraining': 'safety_training',
  'smtcoverage': 'smt_coverage',
  'sdtcoverage': 'sdt_coverage',
  'sifderisking': 'sif_derisking',
  'bpmsstarrating': 'bpms_rating',
  'psii': 'psi_1', 'psi1': 'psi_1',
  'psiii': 'psi_2', 'psi2': 'psi_2',
  'fic': 'fic', 'bbt': 'bbt', 'plantsubcommittee': 'plant_subcommittee',
  'phase2': 'phase_2', 'phase3': 'phase_3',
  'redcornerstatus': 'red_corner', 'bluecornerstatus': 'blue_corner',
  'lti': 'lti', 'ltiftm': 'lti',
  'rwc': 'rwc', 'rwcftm': 'rwc',
  'mtc': 'mtc', 'mtcftm': 'mtc',
  'fac': 'fac', 'facftm': 'fac',
  'trcfr': 'trcfr',

  // Quality
  'drr1': 'drr_1', 'drr1line1': 'drr_1_l1', 'drr1line2': 'drr_1_l2', 'drr1line3': 'drr_1_l3',
  'drr2': 'drr_2', 'drr2line1': 'drr_2_l1', 'drr2line2': 'drr_2_l2', 'drr2line3': 'drr_2_l3',
  'drr3': 'drr_3', 'drr3line1': 'drr_3_l1', 'drr3line2': 'drr_3_l2', 'drr3line3': 'drr_3_l3',
  'drr4': 'drr_4', 'drr4line1': 'drr_4_l1', 'drr4line2': 'drr_4_l2', 'drr4line3': 'drr_4_l3',
  'l3control': 'l3_control',
  'warrantynetpayout': 'warranty_payout', 'warrantypayout': 'warranty_payout',
  'cpascore': 'cpa_score',
  'unscheduledvisit24mis': 'visit_24', 'unscheduledvisit12mis': 'visit_12',
  'compiptv': 'comp_iptv', '3misiptv': 'iptv_3',
  'layerauditcompliance': 'layer_audit', 'layerauditcompliancepercent': 'layer_audit',
  'vccharter': 'vc_charter', 'productcharter': 'product_charter',
  'launchqualityforproductslaunchedinlast12monthscompositeiptv369mis': 'launch_quality',
  'cimpleprojectofftrack': 'cimple_project',

  // Productivity
  'hpev3': 'hpev_3', 'hpev3ftm': 'hpev_3',
  'hpev4': 'hpev_4', 'hpev4ftm': 'hpev_4',
  'cpev': 'cpev', 'cpevftm': 'cpev',
  'lineavailabilityline2': 'line_avail_l2', 'lineavailabilityline3': 'line_avail_l3', 'lineavailabilitytotal': 'line_avail_tot',
  'minuteslostline2': 'min_lost_l2', 'minuteslostline3': 'min_lost_l3', 'minuteslosttotal': 'min_lost_tot',
  'vehicledayline2': 'veh_day_l2', 'vehicledayline3': 'veh_day_l3', 'vehicledaytotal': 'veh_day_tot',
  'headcountoptimization': 'headcount_opt',
  'lineefficiencyline2': 'line_eff_l2', 'lineefficiencyline3': 'line_eff_l3',
  'linespeed': 'line_speed',
  'lineformationratiopercent': 'line_form_ratio',
  'leanmfg': 'lean_mfg',
  'automation': 'automation',
  'lotus30': 'lotus_3',
  'structuralimprovements': 'structural_improvements',
  'kaizenandproductivityactions': 'kaizen_productivity',

  // Delivery
  'otifdomestic': 'otif_dom', 'otifib': 'otif_ib', 'otifspares': 'otif_spares', 'otifsparesinhouseparts': 'otif_spares',
  'spd': 'spd',
  '1mapedomesticilmcv': 'mape_dom_ilmcv', '1mapedomestichcv': 'mape_dom_hcv', '1mapedomesticcvp': 'mape_dom_cvp', '1mapeib': 'mape_ib',
  'productionline2': 'prod_l2', 'productionline3': 'prod_l3', 'productiontotal': 'prod_tot',
  'productiondomestic': 'prod_dom', 'productioninternational': 'prod_int',
  'dispatchtmbsl': 'disp_tmbsl', 'dispatchacgl': 'disp_acgl', 'dispatchimac': 'disp_imac',
  'dispatchjcbl': 'disp_jcbl', 'dispatchotherbb': 'disp_otherbb', 'dispatchdirectbilling': 'disp_direct',
  'dispatchevbustruck': 'disp_ev', 'dispatchtotal': 'disp_tot',
  'line2': 'prod_l2', 'line3': 'prod_l3', 'tmbsl': 'disp_tmbsl', 'acgl': 'disp_acgl', 'imac': 'disp_imac', 'jcbl': 'disp_jcbl', 'otherbb': 'disp_otherbb', 'directbilling': 'disp_direct', 'evbustruck': 'disp_ev',
  'domestic': 'prod_dom', 'international': 'prod_int',
  '4spcrnac': 'bus_4spcr_nac', 'busengine4spcrnac': 'bus_4spcr_nac', 'busenginedispatches4spcrnac': 'bus_4spcr_nac',
  '4spcrac': 'bus_4spcr_ac', 'busengine4spcrac': 'bus_4spcr_ac', 'busenginedispatches4spcrac': 'bus_4spcr_ac',
  'maxicabnac': 'bus_maxicab_nac', 'busenginemaxicabnac': 'bus_maxicab_nac', 'busenginedispatchesmaxicabnac': 'bus_maxicab_nac',
  'cx2nac': 'bus_cx2_nac', 'busenginecx2nac': 'bus_cx2_nac', 'busenginedispatchescx2nac': 'bus_cx2_nac',
  '1024sp': 'bus_10_2_4sp', 'busengine1024sp': 'bus_10_2_4sp', 'busenginedispatches1024sp': 'bus_10_2_4sp',
  '33lnac': 'bus_3_3l_nac', 'busengine33lnac': 'bus_3_3l_nac', 'busenginedispatches33lnac': 'bus_3_3l_nac',
  '33lac': 'bus_3_3l_ac', 'busengine33lac': 'bus_3_3l_ac', 'busenginedispatches33lac': 'bus_3_3l_ac',
  'ib912bs3140113': 'bus_ib912_bs3', 'ib912bs3': 'bus_ib912_bs3', 'busengineib912bs3140113': 'bus_ib912_bs3', 'busenginedispatchesib912bs3140113': 'bus_ib912_bs3',
  'ib712bs3': 'bus_ib712_bs3', 'busengineib712bs3': 'bus_ib712_bs3', 'busenginedispatchesib712bs3': 'bus_ib712_bs3',
  'ib712bs4': 'bus_ib712_bs4', 'busengineib712bs4': 'bus_ib712_bs4', 'busenginedispatchesib712bs4': 'bus_ib712_bs4',

  // Inventory
  'tml': 'inv_tml', 'inventorytml': 'inv_tml',
  'tmbsl': 'inv_tmbsl', 'inventorytmbsl': 'inv_tmbsl',
  'inventory': 'inv_overall', 'inventorytotal': 'inv_overall',
  'inventorynoofdays': 'inv_no_of_days', 'noofdays': 'inv_no_of_days',
  '91to120days': 'ageing_gt_90', '121to150days': 'ageing_gt_90', '151to180days': 'ageing_gt_90',
  '181to365days': 'ageing_gt_180',
  'gt180': 'ageing_gt_180', 'gt180days': 'ageing_gt_180', '180days': 'ageing_gt_180',
  'gt90': 'ageing_gt_90', 'gt90days': 'ageing_gt_90', '90days': 'ageing_gt_90',
  'machineryspares': 'machinery_spares', 'toolsidm': 'tools_idm', 'toolsandidm': 'tools_idm',
  'ageinginventorytotal': 'ageing_tot', 'ageingtotal': 'ageing_tot',
  'operationsinventorynoofdays': 'ops_inv_days',
  'inventoryinrscrswoiflt': 'inv_rs_crs_wo', 'inventoryinrscrswithoutiflt': 'inv_rs_crs_wo',
  'inventoryinrscrswithiflt': 'inv_rs_crs_w',

  // Environment
  'fueluniteu': 'fuel_unit', 'fuelunit': 'fuel_unit', 'fuel': 'fuel_unit',
  'powerkwheu': 'power_kwh', 'powerkwh': 'power_kwh', 'power': 'power_kwh',
  'zerowastetolandfill': 'zero_waste', 'zerowaste': 'zero_waste',
  're100': 're_100', 're100percent': 're_100',
  'waterpositiveratio': 'env_water_ratio', 'waterpositive': 'env_water_ratio', 'netwaterratio': 'env_water_ratio',

  // HR
  'pcvh': 'hr_pcvh',
  'ivdp': 'hr_lives_ivdp', 'ivdplivestouched': 'hr_lives_ivdp',
  'numberoflivestouched': 'hr_lives_tot', 'nooflivestouched': 'hr_lives_tot', 'livestouched': 'hr_lives_tot',
  'hrenvironment': 'hr_lives_env', 'nooflivestouchedenvironment': 'hr_lives_env',
  'hrhealth': 'hr_lives_health', 'nooflivestouchedhealth': 'hr_lives_health',
  'hreducation': 'hr_lives_edu', 'nooflivestouchededucation': 'hr_lives_edu',
  'hremployability': 'hr_lives_emp', 'nooflivestouchedemployability': 'hr_lives_emp',
  'absenteeismline2': 'hr_absenteeism_l2', 'absenteeismline3': 'hr_absenteeism_l3',
  'absenteeismline230thjuly': 'hr_absenteeism_l2', 'absenteeismline330thjuly': 'hr_absenteeism_l3',
  'skiplevelmeetingforstaff': 'hr_skip_level', 'skiplevelmeeting': 'hr_skip_level',
  'erindex': 'hr_er_index',
  'legatrix': 'hr_legatrix',
  'energymeterfunctioning': 'dig_energy_meter',
  'watermeterfunctioning': 'dig_water_meter',
  'andonreportupdation': 'dig_andon_updation',
  'cmdbupdation': 'dig_project_cmdb',
  'scriptrunningonwin10andabovesystems': 'dig_project_win10_script',
  'windowsupgradation': 'dig_project_windows_upgrade',
  'lightguidedassemblybatterycutoffswitch': 'dig_project_lga_battery',
  'lightguidedassemblyegp': 'dig_project_lga_egp',
  'lightguidedassemblycarddelassembly': 'dig_project_lga_carddel',
  'lb2materialstoredingangway': 'dig_project_lb2_gangway',
  'lb2navigationformaterialstoragearea': 'dig_project_lb2_navigation',
  'lb2smartdisplayprojector': 'dig_project_lb2_smart_display',
  'ghg': 'ghg',
  'drr1line2': 'drr_1_l2', 'drr1line3': 'drr_1_l3',
  'drr2line2': 'drr_2_l2', 'drr2line3': 'drr_2_l3',
  'drr3line2': 'drr_3_l2', 'drr3line3': 'drr_3_l3',
  'drr4line2': 'drr_4_l2', 'drr4line3': 'drr_4_l3',
};

export function findMetricDefinition(inputStr, sectionContext = '', moduleContext = '') {
  if (!inputStr) return null;
  const c = cleanStr(inputStr);

  if (moduleContext) {
    const modClean = cleanStr(`${moduleContext} ${inputStr}`);
    if (ALIAS_MAP[modClean]) {
      const match = DEFAULT_METRIC_DEFINITIONS.find(m => m.metric_id === ALIAS_MAP[modClean]);
      if (match && match.module === moduleContext) return match;
    }
  }

  if (sectionContext) {
    const combined = cleanStr(`${sectionContext} ${inputStr}`);
    if (ALIAS_MAP[combined]) {
      const match = DEFAULT_METRIC_DEFINITIONS.find(m => m.metric_id === ALIAS_MAP[combined]);
      if (match && (!moduleContext || match.module === moduleContext)) return match;
    }
  }

  if (ALIAS_MAP[c]) {
    const targetId = ALIAS_MAP[c];
    const match = DEFAULT_METRIC_DEFINITIONS.find(m => m.metric_id === targetId);
    if (match && (!moduleContext || match.module === moduleContext)) return match;
  }

  for (const def of DEFAULT_METRIC_DEFINITIONS) {
    if (moduleContext && def.module !== moduleContext) continue;
    if (def.metric_id === c || cleanStr(def.metric_name) === c) {
      return def;
    }
  }

  // Resolve ambiguous HR category labels only with their explicit parent row.
  if (moduleContext === 'hr' && sectionContext) {
    const parent = cleanStr(sectionContext);
    const hrCategoryIds = {
      environment: 'hr_lives_env', health: 'hr_lives_health',
      education: 'hr_lives_edu', employability: 'hr_lives_emp'
    };
    if (hrCategoryIds[c] && ['numberoflivestouched', 'nooflivestouched', 'livestouched'].includes(parent)) {
      return DEFAULT_METRIC_DEFINITIONS.find(m => m.metric_id === hrCategoryIds[c]);
    }
  }

  // Avoid matching single generic words (e.g., 'domestic') against unrelated long metric names
  const genericWords = ['domestic', 'international', 'total', 'line2', 'line3', 'plan', 'actual'];
  for (const def of DEFAULT_METRIC_DEFINITIONS) {
    if (moduleContext && def.module !== moduleContext) continue;
    const defClean = cleanStr(def.metric_name);
    if (defClean.length > 3 && c.includes(defClean) && !genericWords.includes(c)) {
      return def;
    }
  }

  return null;
}

export function parsePeriodDate(val) {
  if (!val) return null;
  const s = String(val).trim();
  const matchIso = s.match(/^(\d{4})[-/](\d{1,2})(?:[-/]\d{1,2})?$/);
  if (matchIso) {
    const year = Number(matchIso[1]);
    const month = Number(matchIso[2]);
    if (year < 2000 || year > 2100 || month < 1 || month > 12) return null;
    return `${year}-${String(month).padStart(2, '0')}-01`;
  }

  // Accept month labels with an explicit year only. Bare month names and prose
  // such as "Phase started in June 26" are not reporting-period evidence.
  const matchMonth = s.match(/^(?:(?:FTM|MTD)\s+)?(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[\s'’\-_/]*(\d{2}|\d{4})$/i);
  if (matchMonth) {
    const monthNames = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    const monthIndex = monthNames.findIndex(name => matchMonth[1].toLowerCase().startsWith(name));
    let year = Number(matchMonth[2]);
    if (year < 100) year += 2000;
    if (year < 2000 || year > 2100) return null;
    return `${year}-${String(monthIndex + 1).padStart(2, '0')}-01`;
  }

  const matchYearFirstMonth = s.match(/^(\d{2}|\d{4})[\s'’\-_/]+(Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)$/i);
  if (matchYearFirstMonth) {
    const monthNames = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    const monthIndex = monthNames.findIndex(name => matchYearFirstMonth[2].toLowerCase().startsWith(name));
    let year = Number(matchYearFirstMonth[1]);
    if (year < 100) year += 2000;
    if (year < 2000 || year > 2100) return null;
    return `${year}-${String(monthIndex + 1).padStart(2, '0')}-01`;
  }
  return null;
}

function getMonthHeaders(row) {
  const headers = [];
  (row || []).forEach((cell, colIdx) => {
    const raw = String(cell ?? '').trim();
    if (!raw || /^YTD\b/i.test(raw)) return;
    const periodDate = parsePeriodDate(raw);
    if (periodDate) headers.push({ colIdx, periodDate });
  });
  return headers;
}

function getModuleNameFromSheet(sName) {
  const c = sName.toLowerCase().replace(/[^a-z]/g, '');
  if (c.includes('safety')) return 'safety';
  if (c.includes('quality') || c.includes('qulality')) return 'quality';
  if (c.includes('productivity') || c.includes('productiv')) return 'productivity';
  if (c.includes('delivery')) return 'delivery';
  if (c.includes('cost')) return 'cost';
  if (c.includes('inventory')) return 'inventory';
  if (c.includes('environment') || c.includes('envirnoment')) return 'environment';
  if (c.includes('hr')) return 'hr';
  if (c.includes('digital')) return 'digital';
  return 'general';
}

export function parseDatasetFile(buffer, filename) {
  const workbook = xlsx.read(buffer, { type: 'buffer', cellDates: true, raw: false });
  const records = [];
  let totalParsedRows = 0;
  const unmappedMetricNames = new Set();

  const modulePeriodCoverage = new Map();
  const detailedModuleNames = new Set();

  workbook.SheetNames.forEach(sheetName => {
    const mod = getModuleNameFromSheet(sheetName);
    const ws = workbook.Sheets[sheetName];
    if (mod === 'general' || sheetName.toLowerCase().includes('summary')) return;
    detailedModuleNames.add(mod);
    const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
    for (const row of rows || []) {
      const headers = getMonthHeaders(row);
      // True history headers repeat across a row. This filters dates embedded
      // in notes and single future dates in planning/forecast sections.
      if (headers.length < 4) continue;
      for (const { periodDate } of headers) {
        const modules = modulePeriodCoverage.get(periodDate) || new Set();
        modules.add(mod);
        modulePeriodCoverage.set(periodDate, modules);
      }
    }
  });

  const coverageThreshold = Math.max(1, Math.ceil(detailedModuleNames.size / 2));
  const eligiblePeriods = [...modulePeriodCoverage.entries()]
    .filter(([, modules]) => modules.size >= coverageThreshold)
    .map(([period]) => period)
    .sort();
  const latestDetectedPeriod = eligiblePeriods.at(-1) || '2026-07-01';

  // 1. Parse Summary Sheets (*Summary*)
  const summarySheets = workbook.SheetNames.filter(s => s.toLowerCase().includes('summary'));
  summarySheets.forEach(sheetName => {
    const mod = getModuleNameFromSheet(sheetName);
    const summaryPeriodDate = latestDetectedPeriod;
    const ws = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
    if (!rows || rows.length < 2) return;

    let headerIdx = -1;
    for (let i = 0; i < Math.min(rows.length, 5); i++) {
      const row = (rows[i] || []).map(c => String(c).toLowerCase().trim());
      if (row.includes('target') && row.includes('actual')) {
        headerIdx = i;
        break;
      }
    }
    if (headerIdx === -1) headerIdx = 0;

    const headers = (rows[headerIdx] || []).map(c => String(c).toLowerCase().trim());
    const targetCol = headers.findIndex(h => h.includes('target'));
    const actualCol = headers.findIndex(h => h.includes('actual'));
    const unitCol = headers.findIndex(h => h.includes('uom') || h.includes('unit'));

    let currentSection = '';

    for (let r = headerIdx + 1; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.length === 0) continue;
      totalParsedRows++;

      let metricName = '';
      if (row[1] && String(row[1]).trim()) metricName = String(row[1]).trim();
      else if (row[0] && typeof row[0] === 'string' && row[0].trim()) metricName = row[0].trim();

      if (!metricName || metricName.toLowerCase() === 'total' || metricName.toLowerCase() === 'sl.no') continue;

      const parseCellNumber = value => {
        if (value === undefined || value === null || value === '' || String(value).trim() === '-') return null;
        const parsed = Number(String(value).replace(/,/g, '').replace(/%/g, '').trim());
        return Number.isFinite(parsed) ? parsed : null;
      };
      const targetVal = targetCol !== -1 ? parseCellNumber(row[targetCol]) : null;
      const actualVal = actualCol !== -1 ? parseCellNumber(row[actualCol]) : null;

      if (actualVal === null && targetVal === null) {
        currentSection = metricName;
        continue;
      }

      const def = findMetricDefinition(metricName, currentSection, mod) || findMetricDefinition(metricName, '', mod);
      if (mod === 'quality' && /^drr\s*[1-4]$/i.test(metricName)) currentSection = metricName;
      if (!def) {
        unmappedMetricNames.add(`${mod}: ${metricName}`);
        continue;
      }
      const metric_id = def.metric_id;
      const module = def.module;

      let unitVal = unitCol !== -1 ? String(row[unitCol] || '').trim() : (def ? def.unit : '');

      if (unitVal.toLowerCase().includes('paercentage') || unitVal.toLowerCase().includes('percent')) unitVal = '%';

      if (actualVal !== null || targetVal !== null) {
        const hasExplicitPercent = [row[targetCol], row[actualCol]].some(value => String(value ?? '').includes('%'));
        const isPercent = unitVal === '%' || (def && def.unit === '%');
        const normalizePercent = value => value !== null && isPercent && !hasExplicitPercent && value > 0 && value <= 1
          ? parseFloat((value * 100).toFixed(2))
          : value;
        records.push({
          period_date: summaryPeriodDate,
          module,
          metric_id,
          metric_name: def ? def.metric_name : metricName,
          actual_value: normalizePercent(actualVal),
          target_value: normalizePercent(targetVal),
          unit: unitVal,
          department: 'Dharwad Plant',
          section: def ? def.section : ''
        });
      }
    }
  });

  // 2. Parse Detailed Monthly Sheets
  const detailedSheets = workbook.SheetNames.filter(s => !s.toLowerCase().includes('summary') && s !== 'IGNITER Projects');
  detailedSheets.forEach(sheetName => {
    const mod = getModuleNameFromSheet(sheetName);
    const ws = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
    if (!rows || rows.length === 0) return;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row) continue;

      const monthCols = getMonthHeaders(row);

      if (monthCols.length >= 2) {
        let currentParentMetric = '';
        if (i > 0 && rows[i - 1]) {
          const prevCell0 = String(rows[i - 1][0] || '').trim();
          const prevCell1 = String(rows[i - 1][1] || '').trim();
          const prevCandidate = (prevCell0.toLowerCase().includes('dharwad') || !prevCell0) ? prevCell1 : prevCell0;
          if (prevCandidate && !prevCandidate.toLowerCase().includes('month')) {
            currentParentMetric = prevCandidate;
          }
        }

        const subHeaderRow = rows[i + 1] || [];
        const isSubHeaderTargetActual = monthCols.some(mCol => {
          const tCell = String(subHeaderRow[mCol.colIdx] || '').toLowerCase();
          const aCell = String(subHeaderRow[mCol.colIdx + 1] || '').toLowerCase();
          return (tCell.includes('target') || tCell.includes('plan')) && (aCell.includes('actual') || aCell.includes('act'));
        });

        if (isSubHeaderTargetActual) {
          for (let r = i + 2; r < Math.min(i + 30, rows.length); r++) {
            const nextRow = rows[r];
            if (!nextRow || nextRow.length === 0) continue;

            let cell0 = String(nextRow[0] || '').trim();
            let cell1 = String(nextRow[1] || '').trim();
            if (!cell0 && !cell1) continue;

            const label = (cell0 && !cell0.toLowerCase().includes('dharwad') && cell0.toLowerCase() !== 'sl.no' && cell0.toLowerCase() !== 'sl. no.') ? cell0 : cell1;
            if (!label || label.toLowerCase() === 'total' || label.toLowerCase().includes('target') || label.toLowerCase().includes('actual') || /^\d+$/.test(label)) continue;

            totalParsedRows++;
            const def = findMetricDefinition(label, currentParentMetric, mod) || findMetricDefinition(label, '', mod);
            if (!def) {
              unmappedMetricNames.add(`${mod}: ${currentParentMetric ? `${currentParentMetric} / ` : ''}${label}`);
              continue;
            }
            const metric_id = def.metric_id;
            const module = def.module;

            monthCols.forEach(mCol => {
              const tgtVal = parseFloat(nextRow[mCol.colIdx]);
              const actVal = parseFloat(nextRow[mCol.colIdx + 1]);
              if (!isNaN(tgtVal) || !isNaN(actVal)) {
                let existing = records.find(rec => rec.metric_id === metric_id && rec.period_date === mCol.periodDate);
                if (!existing) {
                  existing = {
                    period_date: mCol.periodDate,
                    module,
                    metric_id,
                    metric_name: def ? def.metric_name : (currentParentMetric ? `${currentParentMetric} - ${label}` : label),
                    actual_value: null,
                    target_value: null,
                    unit: def ? def.unit : 'Nos',
                    department: 'Dharwad Plant',
                    section: def ? def.section : ''
                  };
                  records.push(existing);
                }
                if (!isNaN(tgtVal)) existing.target_value = tgtVal;
                if (!isNaN(actVal)) existing.actual_value = actVal;
              }
            });
          }
        } else {
          for (let r = i + 1; r < Math.min(i + 30, rows.length); r++) {
            const nextRow = rows[r];
            if (!nextRow || nextRow.length === 0) continue;
            totalParsedRows++;

            let cell0 = String(nextRow[0] || '').trim();
            let cell1 = String(nextRow[1] || '').trim();

            const candidateParent = (cell0.toLowerCase().includes('dharwad') || cell0.toLowerCase() === 'kpi' || !cell0) ? cell1 : cell0;

            if (candidateParent && !candidateParent.toLowerCase().includes('plan') && !candidateParent.toLowerCase().includes('actual') && !candidateParent.toLowerCase().includes('target') && !candidateParent.toLowerCase().includes('month') && !candidateParent.includes('%')) {
              currentParentMetric = candidateParent;
            }

            const combinedText = `${cell0} ${cell1}`.toLowerCase();
            const isPlan = combinedText.includes('plan') || combinedText.includes('target');
            const isActual = combinedText.includes('actual') || combinedText.includes('act');
            const label = (cell0 && !cell0.toLowerCase().includes('dharwad')) ? cell0 : cell1;

            if (isPlan || isActual) {
              const def = findMetricDefinition(currentParentMetric, '', mod) || findMetricDefinition(label, currentParentMetric, mod) || findMetricDefinition(label, '', mod);
              if (!def) {
                unmappedMetricNames.add(`${mod}: ${currentParentMetric || label}`);
                continue;
              }
              const metric_id = def.metric_id;
              const module = def.module;

              monthCols.forEach(mCol => {
                const val = parseFloat(nextRow[mCol.colIdx]);
                if (!isNaN(val)) {
                  let existing = records.find(rec => rec.metric_id === metric_id && rec.period_date === mCol.periodDate);
                  if (!existing) {
                    existing = {
                      period_date: mCol.periodDate,
                      module,
                      metric_id,
                      metric_name: def ? def.metric_name : (currentParentMetric || label),
                      actual_value: null,
                      target_value: null,
                      unit: def ? def.unit : '',
                      department: 'Dharwad Plant',
                      section: def ? def.section : ''
                    };
                    records.push(existing);
                  }

                  let normVal = val;
                  if ((def && def.unit === '%') || metric_id.startsWith('otif_') || metric_id.startsWith('mape_') || metric_id === 'spd') {
                    if (normVal > 0 && normVal <= 1.0) normVal = parseFloat((normVal * 100).toFixed(2));
                  }

                  if (isPlan) existing.target_value = normVal;
                  if (isActual) existing.actual_value = normVal;
                }
              });
            }
          }
        }
      }
    }
  });

  // Step 3: Compute totals for composite metrics
  const uniquePeriods = [...new Set(records.map(r => r.period_date))];

  uniquePeriods.forEach(pDate => {
    const getRec = id => records.find(r => r.metric_id === id && r.period_date === pDate);

    // Delivery totals
    const l2 = getRec('prod_l2');
    const l3 = getRec('prod_l3');
    let prodTot = getRec('prod_tot');
    if (l2 && l3) {
      const totTgt = (l2.target_value || 0) + (l3.target_value || 0);
      const totAct = (l2.actual_value || 0) + (l3.actual_value || 0);
      if (!prodTot) {
        prodTot = {
          period_date: pDate, module: 'delivery', metric_id: 'prod_tot', metric_name: 'Production - Total',
          target_value: totTgt, actual_value: totAct, unit: 'Nos', department: 'Dharwad Plant', section: ''
        };
        records.push(prodTot);
      } else {
        prodTot.target_value = totTgt;
        prodTot.actual_value = totAct;
      }
    }

    // Dispatch total
    const dispItems = ['disp_tmbsl', 'disp_acgl', 'disp_imac', 'disp_jcbl', 'disp_otherbb', 'disp_direct', 'disp_ev'];
    const dispRecs = dispItems.map(id => getRec(id)).filter(Boolean);
    if (dispRecs.length > 0) {
      const totTgt = dispRecs.reduce((a, r) => a + (r.target_value || 0), 0);
      const totAct = dispRecs.reduce((a, r) => a + (r.actual_value || 0), 0);
      let dispTot = getRec('disp_tot');
      if (!dispTot) {
        dispTot = {
          period_date: pDate, module: 'delivery', metric_id: 'disp_tot', metric_name: 'Dispatch - Total',
          target_value: totTgt, actual_value: totAct, unit: 'Nos', department: 'Dharwad Plant', section: ''
        };
        records.push(dispTot);
      } else {
        dispTot.target_value = totTgt;
        dispTot.actual_value = totAct;
      }
    }

    // Bus Engine Total
    const busItems = [
      'bus_4spcr_nac', 'bus_4spcr_ac', 'bus_maxicab_nac', 'bus_cx2_nac',
      'bus_10_2_4sp', 'bus_3_3l_nac', 'bus_3_3l_ac', 'bus_ib912_bs3',
      'bus_ib712_bs3', 'bus_ib712_bs4'
    ];
    const busRecs = busItems.map(id => getRec(id)).filter(Boolean);
    if (busRecs.length > 0) {
      const totTgt = busRecs.reduce((a, r) => a + (r.target_value || 0), 0);
      const totAct = busRecs.reduce((a, r) => a + (r.actual_value || 0), 0);
      let busTot = getRec('bus_tot');
      if (!busTot) {
        busTot = {
          period_date: pDate, module: 'delivery', metric_id: 'bus_tot', metric_name: 'Bus Engine - Total',
          target_value: totTgt, actual_value: totAct, unit: 'Nos', department: 'Dharwad Plant', section: ''
        };
        records.push(busTot);
      } else {
        busTot.target_value = totTgt;
        busTot.actual_value = totAct;
      }
    }

    // Inventory dynamic syncing from uploaded dataset
    const rsWo = getRec('inv_rs_crs_wo');
    const rsW = getRec('inv_rs_crs_w');
    const opsDays = getRec('ops_inv_days');

    let tmlRec = getRec('inv_tml');
    let tmbslRec = getRec('inv_tmbsl');
    let invTot = getRec('inv_overall');
    let invDays = getRec('inv_no_of_days');

    // Sync from uploaded Excel dataset metrics if parsed
    if (rsWo && (!tmlRec || tmlRec.actual_value === 0)) {
      if (!tmlRec) {
        tmlRec = { period_date: pDate, module: 'inventory', metric_id: 'inv_tml', metric_name: 'TML', target_value: rsWo.target_value, actual_value: rsWo.actual_value, unit: 'Rs in Crs', department: 'Dharwad Plant', section: 'inventory_value' };
        records.push(tmlRec);
      } else {
        tmlRec.target_value = rsWo.target_value;
        tmlRec.actual_value = rsWo.actual_value;
      }
    }

    if (rsW && (!invTot || invTot.actual_value === 0)) {
      if (!invTot) {
        invTot = { period_date: pDate, module: 'inventory', metric_id: 'inv_overall', metric_name: 'Inventory', target_value: rsW.target_value, actual_value: rsW.actual_value, unit: 'Rs in Crs', department: 'Dharwad Plant', section: 'inventory_value' };
        records.push(invTot);
      } else {
        invTot.target_value = rsW.target_value;
        invTot.actual_value = rsW.actual_value;
      }
    }

    if (opsDays && (!invDays || invDays.actual_value === 0)) {
      if (!invDays) {
        invDays = { period_date: pDate, module: 'inventory', metric_id: 'inv_no_of_days', metric_name: 'Inventory - No of Days', target_value: opsDays.target_value, actual_value: opsDays.actual_value, unit: 'No of days', department: 'Dharwad Plant', section: 'inventory_value' };
        records.push(invDays);
      } else {
        invDays.target_value = opsDays.target_value;
        invDays.actual_value = opsDays.actual_value;
      }
    }

    if (invTot && tmlRec && (!tmbslRec || tmbslRec.actual_value === 0)) {
      const tmbslTgt = Math.max(0, parseFloat(((invTot.target_value || 0) - (tmlRec.target_value || 0)).toFixed(2)));
      const tmbslAct = Math.max(0, parseFloat(((invTot.actual_value || 0) - (tmlRec.actual_value || 0)).toFixed(2)));
      if (!tmbslRec) {
        tmbslRec = { period_date: pDate, module: 'inventory', metric_id: 'inv_tmbsl', metric_name: 'TMBSL', target_value: tmbslTgt, actual_value: tmbslAct, unit: 'Rs in Crs', department: 'Dharwad Plant', section: 'inventory_value' };
        records.push(tmbslRec);
      } else {
        tmbslRec.target_value = tmbslTgt;
        tmbslRec.actual_value = tmbslAct;
      }
    }

    // Compute Ageing Total (ageing_tot)
    const gt180 = getRec('ageing_gt_180');
    const gt90 = getRec('ageing_gt_90');
    const mach = getRec('machinery_spares');
    const tools = getRec('tools_idm');

    const totAgeingTarget = parseFloat(((gt180?.target_value || 0) + (gt90?.target_value || 0) + (mach?.target_value || 0) + (tools?.target_value || 0)).toFixed(2));
    const totAgeingActual = parseFloat(((gt180?.actual_value || 0) + (gt90?.actual_value || 0) + (mach?.actual_value || 0) + (tools?.actual_value || 0)).toFixed(2));

    let ageingTot = getRec('ageing_tot');
    if (!ageingTot && (gt180 || gt90 || mach || tools)) {
      ageingTot = {
        period_date: pDate, module: 'inventory', metric_id: 'ageing_tot', metric_name: 'Ageing Inventory Total',
        target_value: totAgeingTarget, actual_value: totAgeingActual, unit: 'Rs in Crs', department: 'Dharwad Plant', section: 'ageing_inventory'
      };
      records.push(ageingTot);
    }
  });


  return {
    records,
    summary: {
      totalParsedRows,
      extractedRecordsCount: records.length,
      latestReportingPeriod: latestDetectedPeriod.substring(0, 7),
      unmappedMetrics: [...unmappedMetricNames].sort()
    }
  };
}
