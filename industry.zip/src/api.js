// Client API Adapter for Industrial Dashboard V2 Express Backend

const API_BASE_URL = `${window.location.protocol}//${window.location.hostname}:3001/api`;
const authHeaders = (headers = {}) => ({
  ...headers,
  ...(localStorage.getItem('dashboard_auth_token') ? { Authorization: `Bearer ${localStorage.getItem('dashboard_auth_token')}` } : {})
});

/**
 * Health check to verify Express server status
 */
export async function checkServerHealth() {
  try {
    const res = await fetch(`${API_BASE_URL}/health`, { signal: AbortSignal.timeout(2000) });
    if (res.ok) {
      const data = await res.json();
      return data.status === 'ok';
    }
  } catch (e) {
    // Server offline
  }
  return false;
}

/**
 * Fetch overall summary dashboard data (Scores, Strengths, Focus Areas)
 */
export async function fetchSummaryFromApi(reportingDate) {
  try {
    const url = reportingDate ? `${API_BASE_URL}/dashboard/summary?reportingDate=${reportingDate}` : `${API_BASE_URL}/dashboard/summary`;
    const res = await fetch(url, { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn('[API Client] Failed to fetch summary from API:', e);
  }
  return null;
}

/**
 * Fetch module-specific metrics, tables, and monthly trends
 */
export async function fetchModuleFromApi(moduleName, reportingDate) {
  try {
    const url = reportingDate
      ? `${API_BASE_URL}/dashboard/module/${moduleName}?reportingDate=${reportingDate}`
      : `${API_BASE_URL}/dashboard/module/${moduleName}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      return await res.json();
    }
  } catch (e) {
    console.warn(`[API Client] Failed to fetch module '${moduleName}' from API:`, e);
  }
  return null;
}

/**
 * Upload dataset file (.csv, .xlsx, .xls) to backend parser
 */
export async function uploadDatasetFile(file, dashboardState = null, force = false) {
  try {
    const formData = new FormData();
    formData.append('dataset', file);
    formData.append('force', String(force));
    if (dashboardState) formData.append('dashboardState', JSON.stringify(dashboardState));

    const res = await fetch(`${API_BASE_URL}/upload`, {
      method: 'POST',
      headers: authHeaders(),
      body: formData
    });

    const data = await res.json();
    return { ok: res.ok, status: res.status, data };
  } catch (e) {
    console.error('[API Client] Dataset upload request failed:', e);
    return { ok: false, status: 500, error: e.message };
  }
}

/**
 * Update KPI target or actual value manually
 */
export async function updateKpiOnApi(metricId, targetValue, actualValue, periodDate) {
  try {
    const res = await fetch(`${API_BASE_URL}/kpi/update`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        metric_id: metricId,
        target_value: targetValue,
        actual_value: actualValue,
        period_date: periodDate
      }),
      signal: AbortSignal.timeout(4000)
    });
    return res.ok;
  } catch (e) {
    console.warn('[API Client] KPI override failed:', e);
    return false;
  }
}

/**
 * Fetch upload history list
 */
export async function fetchUploadHistory() {
  try {
    const res = await fetch(`${API_BASE_URL}/uploads/history`, { signal: AbortSignal.timeout(3000) });
    if (res.ok) {
      const data = await res.json();
      return data.uploads || [];
    }
  } catch (e) {
    console.warn('[API Client] Upload history fetch failed:', e);
  }
  return [];
}

// Compatibility functions for state.js
export async function fetchStateFromApi() {
  try {
    const res = await fetch(`${API_BASE_URL}/dashboard/state`, { headers: authHeaders(), signal: AbortSignal.timeout(4000) });
    if (res.ok) return await res.json();
  } catch (e) { console.warn('[API Client] Dashboard state fetch failed:', e); }
  return null;
}

export async function saveStateToApi(stateObj) {
  try {
    const safeState = { ...stateObj, authToken: null, currentUser: null };
    const res = await fetch(`${API_BASE_URL}/dashboard/state`, {
      method: 'PUT', headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ state: safeState }), signal: AbortSignal.timeout(5000)
    });
    return res.ok;
  } catch (e) { console.warn('[API Client] Dashboard state save failed:', e); return false; }
}

export async function fetchLatestDatasetFile() {
  try {
    const res = await fetch(`${API_BASE_URL}/uploads/latest/file`, { headers: authHeaders(), signal: AbortSignal.timeout(10000) });
    if (res.ok) return await res.blob();
  } catch (e) { console.warn('[API Client] Latest workbook fetch failed:', e); }
  return null;
}

export async function fetchHistoryLogsFromApi() {
  return fetchUploadHistory();
}

export async function saveHistoryLogToApi(log) {
  return true;
}

export async function deleteHistoryLogFromApi(id) {
  return true;
}

export async function resetDatabaseOnApi() {
  return true;
}

/**
 * Auth API: Login user with credentials
 */
export async function loginApi(username, password) {
  const cleanUser = String(username || '').trim().toLowerCase();
  const cleanPwd = String(password || '').trim();

  try {
    const res = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: cleanUser, password: cleanPwd }),
      signal: AbortSignal.timeout(3000)
    });
    const data = await res.json();
    if (res.ok) {
      return { ok: true, status: res.status, ...data };
    } else if (res.status === 401) {
      return { ok: false, error: data.error || 'Invalid username or password.' };
    }
    return { ok: res.ok, status: res.status, ...data };
  } catch (e) {
    console.warn('[API Client] Server authentication unavailable:', e);
    return { ok: false, error: 'Unable to reach the dashboard server. Please try again.' };
  }
}

/**
 * Auth API: Logout current session
 */
export async function logoutApi(token) {
  try {
    const res = await fetch(`${API_BASE_URL}/auth/logout`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    const data = await res.json();
    return res.ok;
  } catch (e) {
    console.warn('[API Client] Logout call error:', e);
    return false;
  }
}

/**
 * Auth API: Fetch current logged-in user profile from session token
 */
export async function fetchCurrentUserApi(token) {
  if (!token) return null;
  try {
    const res = await fetch(`${API_BASE_URL}/auth/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (res.ok) {
      const data = await res.json();
      return data.user;
    }
  } catch (e) {
    console.warn('[API Client] Failed to fetch current user profile:', e);
  }
  return null;
}

/**
 * User Admin API: List all users
 */
export async function fetchUsersApi(token) {
  try {
    const res = await fetch(`${API_BASE_URL}/users`, {
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    if (res.ok) {
      const data = await res.json();
      return data.users || [];
    }
  } catch (e) {
    console.warn('[API Client] Failed to list users:', e);
  }
  return [];
}

/**
 * User Admin API: Add new user account
 */
export async function addUserApi(userData, token) {
  try {
    const res = await fetch(`${API_BASE_URL}/users`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      body: JSON.stringify(userData)
    });
    const data = await res.json();
    return { ok: res.ok, status: res.status, ...data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

/**
 * User Admin API: Delete user account by ID
 */
export async function deleteUserApi(userId, token) {
  try {
    const res = await fetch(`${API_BASE_URL}/users/${userId}`, {
      method: 'DELETE',
      headers: token ? { 'Authorization': `Bearer ${token}` } : {}
    });
    const data = await res.json();
    return { ok: res.ok, status: res.status, ...data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}



