// Application State and Calculation Logic for All 7 Modules
import { fetchStateFromApi, saveStateToApi, fetchHistoryLogsFromApi, saveHistoryLogToApi, deleteHistoryLogFromApi, resetDatabaseOnApi, fetchCurrentUserApi, loginApi, logoutApi } from './api.js';

export const INITIAL_KPIS = [
  // ==================== 1. SAFETY MODULE ====================
  { id: 'safe_session', name: 'S.A.F.E. Session', target: 10, actual: 7, unit: 'sessions', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'visilens', name: 'Visilens [Healthy camera]', target: 107, actual: 90, unit: 'Nos', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'floor_leadership', name: 'Leadership on Floor (90 Mins)', target: 5, actual: 4, unit: 'sessions', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'safety_training', name: 'Safety Training', target: 2, actual: 0.62, unit: 'hours', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'smt_coverage', name: 'SMT Coverage', target: 1, actual: 0.99, unit: '%', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'sdt_coverage', name: 'SDT Coverage', target: 1, actual: 1, unit: '%', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'sif_derisking', name: 'SIF Derisking', target: 58, actual: 23, unit: 'No. Of Actions', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bpms_rating', name: 'BPMS Star Rating', target: 19, actual: 2, unit: '%', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'psi_1', name: 'PSI I', target: 95, actual: 0, unit: 'score', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'psi_2', name: 'PSI II', target: 100, actual: 0, unit: 'score', module: 'safety', section: 'safety_dashboard', targetLabel: 'Target', actualLabel: 'Actual' },

  { id: 'fic', name: 'FIC', target: 9, actual: 6, unit: 'meetings', module: 'safety', section: 'meeting_compliance', targetLabel: 'Planned', actualLabel: 'Actual' },
  { id: 'bbt', name: 'BBT', target: 21, actual: 11, unit: 'meetings', module: 'safety', section: 'meeting_compliance', targetLabel: 'Planned', actualLabel: 'Actual' },
  { id: 'plant_subcommittee', name: 'Plant Sub Committee', target: 19, actual: 17, unit: 'meetings', module: 'safety', section: 'meeting_compliance', targetLabel: 'Planned', actualLabel: 'Actual' },

  { id: 'phase_2', name: 'Phase 2', target: 197, actual: 195, unit: 'No. Of Actions', module: 'safety', section: 'horizontal_deployment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'phase_3', name: 'Phase 3', target: 58, actual: 23, unit: 'No. Of Actions', module: 'safety', section: 'horizontal_deployment', targetLabel: 'Target', actualLabel: 'Actual' },

  { id: 'red_corner', name: 'Red Corner Status', target: 28, actual: 24, unit: 'tags', module: 'safety', section: 'workplace_condition', targetLabel: 'Total', actualLabel: 'Actual' },
  { id: 'blue_corner', name: 'Blue Corner Status', target: 9, actual: 9, unit: 'tags', module: 'safety', section: 'workplace_condition', targetLabel: 'Total', actualLabel: 'Actual' },

  { id: 'lti', name: 'LTI (FTM)', target: 0, actual: 0, unit:'incidents', module: 'safety', section: 'safety_triangle', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'rwc', name: 'RWC (FTM)', target: 0, actual: 0, unit: 'incidents', module: 'safety', section: 'safety_triangle', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'mtc', name: 'MTC (FTM)', target: 0, actual: 0, unit: 'incidents', module: 'safety', section: 'safety_triangle', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'fac', name: 'FAC (FTM)', target: 0, actual: 2, unit: 'incidents', module: 'safety', section: 'safety_triangle', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'trcfr', name: 'TRCFR', target: 0.31, actual: 0, unit: 'rate', module: 'safety', section: 'safety_triangle', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'psi_2_ytd', name: 'PSI II (YTD)', target: 100, actual: 64.9, unit: 'score', module: 'safety', section: 'safety_triangle', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 2. QUALITY MODULE ====================
  { id: 'drr_1', name: 'DRR 1', target: 100, actual: 95, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_1_l1', name: 'DRR 1 - Line 1', target: 100, actual: 95, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_1_l2', name: 'DRR 1 - Line 2', target: 100, actual: 98, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_1_l3', name: 'DRR 1 - Line 3', target: 100, actual: 0, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  
  { id: 'drr_2', name: 'DRR 2', target: 95, actual: 90, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_2_l1', name: 'DRR 2 - Line 1', target: 95, actual: 90, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_2_l2', name: 'DRR 2 - Line 2', target: 95, actual: 85, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_2_l3', name: 'DRR 2 - Line 3', target: 95, actual: 0, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  
  { id: 'drr_3', name: 'DRR 3', target: 95, actual: 94, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_3_l1', name: 'DRR 3 - Line 1', target: 95, actual: 96, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_3_l2', name: 'DRR 3 - Line 2', target: 95, actual: 94, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_3_l3', name: 'DRR 3 - Line 3', target: 95, actual: 0, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  
  { id: 'drr_4', name: 'DRR 4', target: 82, actual: 81, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_4_l1', name: 'DRR 4 - Line 1', target: 82, actual: 81, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_4_l2', name: 'DRR 4 - Line 2', target: 82, actual: 81.5, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'drr_4_l3', name: 'DRR 4 - Line 3', target: 82, actual: 0, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },

  { id: 'l3_control', name: 'L3 Control', target: 406, actual: 406, unit: 'Nos', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'warranty_payout', name: 'Warranty Net Payout', target: 5.5, actual: 2.4, unit: 'Rs Crs', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'cpa_score', name: 'CPA Score', target: 80, actual: 66, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'visit_24', name: 'Unscheduled Visit 24 MIS', target: 0.78, actual: 0.69, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'visit_12', name: 'Unscheduled Visit 12 MIS', target: 0.23, actual: 0.18, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'comp_iptv', name: 'Comp IPTV', target: 235, actual: 197, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'iptv_3', name: '3 MIS IPTV', target: 40, actual: 39, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'layer_audit', name: 'Layer Audit Compliance (%)', target: 100, actual: 93.71, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'vc_charter', name: 'VC Charter ( C2)', target: 90, actual: 82, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'product_charter', name: 'Product Charter- C2', target: 95, actual: 79, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  
  // Composite Index Parent and Sub-metrics
  { id: 'composite_quality_index', name: 'Composite Quality Index', target: 0, actual: 0, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'comp_quality_iptv', name: 'a) Delta Composite IPTV (Index)', target: 232, actual: 197, unit: 'Index', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'comp_quality_epv', name: 'b) EPV (Expense per vehicle) ( Delta)', target: 4632, actual: 4361, unit: 'Rs./Vehicle', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'comp_quality_visits', name: 'c) Unscheduled visits per vehicle (24 MIS) - All Models', target: 0.8, actual: 0.69, unit: '12 MIS UVPV', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'comp_quality_notouch', name: 'd) No Touch DRR', target: 82, actual: 79.9, unit: '%', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'launch_quality', name: 'Launch Quality Composite IPTV - 3, 6, 9 MIS', target: 100, actual: 100, unit: '% Models with 50% Red.', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'launch_3mis', name: '3 MIS', target: 53, actual: 51, unit: 'Nos.', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'launch_3_6mis', name: '3-6 MIS', target: 99, actual: 93, unit: 'Nos.', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'launch_6_12mis', name: '6-12 MIS', target: 274, actual: 320, unit: 'Nos.', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'launch_uvpv', name: 'Launch UVPV', target: 0.42, actual: 0.42, unit: 'Launch UVPV', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'cimple_project', name: 'Cimple Project (On track )', target: 30, actual: 15, unit: 'Nos', module: 'quality', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 3. PRODUCTIVITY MODULE ====================
  { id: 'hpev_3', name: 'HPeV 3 (FTM)', target: 45, actual: 42.34, unit: 'Hours', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hpev_4', name: 'HPeV 4 (FTM)', target: 61.9, actual: 57.37, unit: 'Hours', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'cpev', name: 'CPeV (FTM)', target: 30710, actual: 25785, unit: 'Rs/ Eq Vehicle', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_avail_l2', name: 'Line Availability - Line 2', target: 0.85, actual: 0.89, unit: '%', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_avail_l3', name: 'Line Availability - Line 3', target: 0.85, actual: 0.87, unit: '%', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_avail_tot', name: 'Line Availability - Total', target: 0.85, actual: 0.88, unit: '%', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'min_lost_l2', name: 'Minutes Lost - Line 2', target: 0, actual: 50, unit: 'mins', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'min_lost_l3', name: 'Minutes Lost - Line 3', target: 0, actual: 59, unit: 'mins', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'min_lost_tot', name: 'Minutes Lost - Total', target: 0, actual: 55, unit: 'mins', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_speed', name: 'Line Speed % ', target: 0.1, actual: 0.09, unit: 'MPM', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_eff_l2', name: 'Line Efficiency - Line 2', target: 0.85, actual: 0.78, unit: '%', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_eff_l3', name: 'Line Efficiency - Line 3', target: 0.85, actual: 0.09, unit: '%', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'line_form_ratio', name: 'Line Formation ratio %', target: 0.85, actual: 0.69, unit: '%', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'veh_day_l2', name: 'Vehicle / Day - Line 2', target: 75, actual: 57, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'veh_day_l3', name: 'Vehicle / Day - Line 3', target: 30, actual: 22, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'veh_day_tot', name: 'Vehicle / Day - Total', target: 105, actual: 79, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  
  // Head Count parent and children
  { id: 'headcount_opt', name: 'Head Count Optimization', target: 139, actual: 2, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'lean_mfg', name: 'Lean Mfg.', target: 55, actual: 2, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'automation', name: 'Automation', target: 38, actual: 0, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'lotus_3', name: 'LOTUS 3.0', target: 46, actual: 0, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'structural_improvements', name: 'Structural Improvements', target: 0, actual: 0, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'kaizen_productivity', name: 'Kaizen and Productivity Actions', target: 7, actual: 1, unit: 'Nos', module: 'productivity', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 4. DELIVERY MODULE ====================
  { id: 'otif_dom', name: 'OTIF- Domestic', target: 98, actual: 100, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'otif_ib', name: 'OTIF- IB', target: 99, actual: 100, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'otif_spares', name: 'OTIF Spares (Inhouse Parts)', target: 100, actual: 100, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'spd', name: 'SPD', target: 100, actual: 100, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'mape_dom_ilmcv', name: '1-MAPE- Domestic ILMCV', target: 100, actual: 95, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'mape_dom_hcv', name: '1-MAPE- Domestic HCV', target: 100, actual: 95, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'mape_dom_cvp', name: '1-MAPE- Domestic CVP', target: 100, actual: 95, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'mape_ib', name: '1-MAPE - IB', target: 100, actual: 98, unit: 'percent', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'prod_l2', name: 'Production - Line 2', target: 1404, actual: 1422, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'prod_l3', name: 'Production - Line 3', target: 644, actual: 525, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'prod_tot', name: 'Production - Total', target: 2048, actual: 1947, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'prod_dom', name: 'Production - Domestic', target: 1814, actual: 1759, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'prod_int', name: 'Production - International', target: 234, actual: 188, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_tmbsl', name: 'Dispatch - TMBSL', target: 1061, actual: 854, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_acgl', name: 'Dispatch - ACGL', target: 1026, actual: 963, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_imac', name: 'Dispatch - IMAC', target: 33, actual: 28, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_jcbl', name: 'Dispatch - JCBL', target: 0, actual: 0, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_otherbb', name: 'Dispatch - Other BB', target: 28, actual: 27, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_direct', name: 'Dispatch - Direct Billing', target: 75, actual: 98, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_ev', name: 'Dispatch - EV Bus/truck', target: 6, actual: 6, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'disp_tot', name: 'Dispatch - Total', target: 2229, actual: 1976, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_4spcr_nac', name: 'Bus Engine - 4 SPCR NAC', target: 689, actual: 690, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_4spcr_ac', name: 'Bus Engine - 4 SPCR AC', target: 54, actual: 62, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_maxicab_nac', name: 'Bus Engine - Maxicab NAC', target: 249, actual: 252, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_cx2_nac', name: 'Bus Engine - CX2 NAC', target: 20, actual: 20, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_10_2_4sp', name: 'Bus Engine - 10.2 4SP', target: 14, actual: 13, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_3_3l_nac', name: 'Bus Engine - 3.3L NAC', target: 211, actual: 207, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_3_3l_ac', name: 'Bus Engine - 3.3L AC', target: 119, actual: 119, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_ib912_bs3', name: 'Bus Engine - IB-912 BS3 (140/113)', target: 32, actual: 25, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_ib712_bs3', name: 'Bus Engine - IB-712 BS3', target: 12, actual: 10, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_ib712_bs4', name: 'Bus Engine - IB-712 BS4', target: 32, actual: 7, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'bus_tot', name: 'Bus Engine - Total', target: 1432, actual: 1405, unit: 'Nos', module: 'delivery', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 5. INVENTORY MODULE ====================
  { id: 'inv_overall', name: 'Inventory', target: 165, actual: 204, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'inv_tml', name: 'TML', target: 139, actual: 165, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'inv_tmbsl', name: 'TMBSL', target: 26, actual: 39, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'inv_no_of_days', name: 'Inventory - No of Days', target: 9, actual: 22, unit: 'No of days', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'ageing_gt_180', name: '>180 Days', target: 35, actual: 35, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'ageing_gt_90', name: '>90  Days', target: 40, actual: 46, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'machinery_spares', name: 'Machinery spares', target: 4, actual: 3.58, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'tools_idm', name: 'Tools &IDM', target: 1.5, actual: 1.78, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'ageing_tot', name: 'Total', target: 80.5, actual: 86.36, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  
  // Total card KPIs
  { id: 'ops_inv_days', name: 'Operations Inventory No: of Days', target: 9, actual: 22, unit: 'No of days', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'inv_rs_crs_wo', name: 'Inventory in Rs Crs (W/o IFLT)', target: 194, actual: 169.61, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'inv_rs_crs_w', name: 'Inventory in Rs Crs (with IFLT)', target: 204, actual: 170, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'git', name: 'GIT', target: 0, actual: 0, unit: 'Rs in Crs', module: 'inventory', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 6. COST MODULE ====================
  { id: 'repro', name: 'Repro', target: 0, actual: 0, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dmc', name: 'DMC', target: 0, actual: 0, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'vcc', name: 'VCC', target: 0, actual: 0, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'ofe', name: 'OFE', target: 1.678, actual: 1.99, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'admin_ew', name: 'Admin & EW ', target: 0.245, actual: 0.253, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'maintenance_services', name: 'Maintenance & Services', target: 0.33, actual: 0.315, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'civil', name: 'Civil', target: 0.114, actual: 0.094, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'sustainability', name: 'Sustainability', target: 0.0282, actual: 0.001, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'production_contracts', name: 'Production Contracts', target: 1.076, actual: 1.01, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'utilities', name: 'Utilities', target: 0.58, actual: 0.46, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'vic_machinery', name: 'VIC & Machinery spares', target: 1.05, actual: 0.99, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'freight_logistic', name: 'Freight - Logistic', target: 2.96, actual: 2.96, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'cost_total', name: 'Cost Total', target: 6.389, actual: 6.10, unit: 'Rs Crs', module: 'cost', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 7. ENVIRONMENT MODULE ====================
  { id: 'fuel_unit', name: 'Fuel (Unit/EU)', target: 5.19, actual: 2.31, unit: 'Unit/EU', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'ghg', name: 'GHG', target: 0, actual: 0, unit: 'Nos', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'power_kwh', name: 'Power (KWh/EU)', target: 365, actual: 177, unit: 'KWh/EU', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'zero_waste', name: 'Zero Waste to Landfill', target: 100, actual: 100, unit: 'percent', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 're_100', name: 'RE 100%', target: 100, actual: 100, unit: 'percent', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'env_scope1', name: 'Scope 1 Decarbonisation', target: 0, actual: 0, unit: 'percent', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'env_water_ratio', name: 'Net Water Ratio', target: 1.84, actual: 1.84, unit: '%', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'env_circular', name: 'Circular Economy', target: 0, actual: 0, unit: 'percent', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'env_biodiversity', name: 'Biodiversity', target: 0, actual: 0, unit: 'percent', module: 'environment', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 8. HR MODULE ====================
  { id: 'hr_pcvh', name: 'PCVH', target: 48, actual: 20.38, unit: 'Per Capita', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_lives_ivdp', name: 'IVDP (Lives Touched)', target: 1000, actual: 1200, unit: 'Nos', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_lives_env', name: 'No. of Lives Touched - Environment', target: 1000, actual: 2400, unit: 'Nos', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_lives_health', name: 'No. of Lives Touched - Health', target: 2500, actual: 2858, unit: 'Nos', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_lives_edu', name: 'No. of Lives Touched - Education', target: 3400, actual: 3500, unit: 'Nos', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_lives_emp', name: 'No. of Lives Touched - Employability', target: 250, actual: 338, unit: 'Nos', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_absenteeism_l2', name: 'Absenteeism - Line 2', target: 5.0, actual: 0, unit: '%', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_absenteeism_l3', name: 'Absenteeism - Line 3', target: 5.0, actual: 0, unit: '%', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_skip_level', name: 'Skip Level Meeting for Staff', target: 100, actual: 100, unit: '%', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_er_index', name: 'ER Index', target: 97, actual: 92.02, unit: '%', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'hr_legatrix', name: 'Legatrix', target: 100, actual: 100, unit: '%', module: 'hr', targetLabel: 'Target', actualLabel: 'Actual' },

  // ==================== 9. DIGITAL MODULE ====================
  { id: 'dig_cctv', name: 'CCTV Camera functioning', target: 107, actual: 90, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_energy_meter', name: 'Energy meter functioning', target: 12, actual: 12, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_water_meter', name: 'Water meter functioning', target: 6, actual: 6, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_andon_updation', name: 'Andon report UPDATION', target: 3, actual: 3, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_qualix_compliance', name: 'Qualix process compliance adherence', target: 100, actual: 80, unit: '%', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_kitting_adherence', name: 'Kitting adherence', target: 100, actual: 90, unit: '%', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_cmdb', name: 'CMDB UPDATION', target: 418, actual: 418, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_win10_script', name: 'Script running on Win10 and above systems', target: 68, actual: 14, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_windows_upgrade', name: 'Windows upgradation', target: 8, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_lga_battery', name: 'Light guided assembly Battery cut off switch', target: 1, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_lga_egp', name: 'Light guided assembly EGP', target: 1, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_lga_carddel', name: 'Light guided assembly Carddel Assembly', target: 1, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_lb2_gangway', name: 'LB 2 : Material stored in Gangway', target: 1, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_lb2_navigation', name: 'LB2: Navigation for material storage area', target: 1, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
  { id: 'dig_project_lb2_smart_display', name: 'LB2 Smart display - Projector', target: 2, actual: 0, unit: 'Nos', module: 'digital', targetLabel: 'Target', actualLabel: 'Actual' },
];

export const INITIAL_HISTORY = {
  safety: [
    { month: 'Jan', overallScore: 68, lti: 0, rwc: 0, mtc: 1, fac: 3, nearMiss: 15, psi_1: 85, psi_2: 90 },
    { month: 'Feb', overallScore: 71, lti: 1, rwc: 0, mtc: 0, fac: 2, nearMiss: 18, psi_1: 88, psi_2: 92 },
    { month: 'Mar', overallScore: 74, lti: 0, rwc: 1, mtc: 0, fac: 1, nearMiss: 22, psi_1: 90, psi_2: 95 },
    { month: 'Apr', overallScore: 76, lti: 0, rwc: 0, mtc: 0, fac: 2, nearMiss: 24, psi_1: 92, psi_2: 98 }
  ],
  quality: [
    { month: 'Jan', overallScore: 88, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 89, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 90, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 91, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  productivity: [
    { month: 'Jan', overallScore: 82, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 84, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 85, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 87, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  delivery: [
    { month: 'Jan', overallScore: 79, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 81, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 83, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 84, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  inventory: [
    { month: 'Jan', overallScore: 92, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 93, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 94, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 95, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  cost: [
    { month: 'Jan', overallScore: 95, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 95, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 96, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 96, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  environment: [
    { month: 'Jan', overallScore: 80, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 85, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 90, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 95, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  hr: [
    { month: 'Jan', overallScore: 88, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 90, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 92, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 94, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ],
  digital: [
    { month: 'Jan', overallScore: 85, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Feb', overallScore: 88, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Mar', overallScore: 91, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 },
    { month: 'Apr', overallScore: 93, lti: 0, rwc: 0, mtc: 0, fac: 0, nearMiss: 0 }
  ]
};

export const INITIAL_FILTERS = {
  date: 'All Dates',
  plant: 'All Plants',
  department: 'All Departments',
  shift: 'All Shifts'
};

// State Object
export const state = {
  currentUser: null,
  authToken: localStorage.getItem('dashboard_auth_token') || null,
  kpis: JSON.parse(JSON.stringify(INITIAL_KPIS)),
  history: JSON.parse(JSON.stringify(INITIAL_HISTORY)),
  filters: { ...INITIAL_FILTERS },
  currentModule: 'overall',
  hasTml: true,
  ficWiseInjuries: [
    { name: 'Vehicle Factory', fac: 3, mtc: 0, rwc: 0, lti: 0 },
    { name: 'Technical Services', fac: 0, mtc: 0, rwc: 0, lti: 0 },
    { name: 'Office', fac: 0, mtc: 0, rwc: 0, lti: 0 },
    { name: 'Materials', fac: 0, mtc: 0, rwc: 0, lti: 0 },
    { name: 'Quality', fac: 0, mtc: 0, rwc: 0, lti: 0 },
    { name: 'FRM, BIW, APS & CM', fac: 1, mtc: 0, rwc: 0, lti: 0 },
    { name: 'TOTAL', fac: 4, mtc: 0, rwc: 0, lti: 0 }
  ],
  ficWiseInjuriesYtd: [
    { name: 'Vehicle Factory', fac: 8, mtc: 0, rwc: 1, lti: 0 },
    { name: 'Technical Services', fac: 1, mtc: 0, rwc: 0, lti: 0 },
    { name: 'Office', fac: 3, mtc: 0, rwc: 0, lti: 3 },
    { name: 'Materials', fac: 3, mtc: 0, rwc: 0, lti: 0 },
    { name: 'Quality', fac: 0, mtc: 0, rwc: 0, lti: 0 },
    { name: 'FRM, BIW, APS & CM', fac: 2, mtc: 0, rwc: 0, lti: 0 },
    { name: 'TOTAL', fac: 17, mtc: 0, rwc: 1, lti: 3 }
  ],
  baseFicWiseInjuries: null,
  baseFicWiseInjuriesYtd: null,
  baseKpis: null,
  baseSafetyMonthlyData: null,
  baseProductivityMonthlyData: null,
  baseDeliveryMonthlyData: null,
  baseCostMonthlyData: null,
  baseHrMonthlyData: null,
  baseQualityMonthlyData: null,
  baseEnvironmentMonthlyData: null,
  baseInventoryMonthlyData: null,
  baseDigitalMonthlyData: null,
  costLedgerBreakdown: [
    { name: "Admin & EW", fy27Tc: 320, fy27Sc: 282, mtdTarget: 0.43, mtdSc: 0.41, mtdActual: 0.32, ytdTarget: 1.58, ytdSc: 1.16, ytdActual: 1.0 },
    { name: "Maintenance & Services", fy27Tc: 425, fy27Sc: 375, mtdTarget: 0.45, mtdSc: 0.43, mtdActual: 0.42, ytdTarget: 1.5, ytdSc: 1.42, ytdActual: 1.39 },
    { name: "Civil", fy27Tc: 177, fy27Sc: 156, mtdTarget: 0.17, mtdSc: 0.16, mtdActual: 0.13, ytdTarget: 0.56, ytdSc: 0.46, ytdActual: 0.47 },
    { name: "Sustainability", fy27Tc: 16, fy27Sc: 14, mtdTarget: 0.03, mtdSc: 0.03, mtdActual: 0.01, ytdTarget: 0.11, ytdSc: 0.11, ytdActual: 0.01 },
    { name: "Production Contracts", fy27Tc: 943, fy27Sc: 835, mtdTarget: 1.11, mtdSc: 1.05, mtdActual: 1.16, ytdTarget: 4.22, ytdSc: 3.97, ytdActual: 4.08 },
    { name: "Utilities", fy27Tc: 458, fy27Sc: 435, mtdTarget: 0.9, mtdSc: 0.85, mtdActual: 0.48, ytdTarget: 2.55, ytdSc: 2.43, ytdActual: 1.83 },
    { name: "VIC & Machinery spares", fy27Tc: 725, fy27Sc: 689, mtdTarget: 1.09, mtdSc: 1.03, mtdActual: 1.02, ytdTarget: 3.96, ytdSc: 3.77, ytdActual: 3.68 },
    { name: "CLT", fy27Tc: 3064, fy27Sc: 2784, mtdTarget: 4.17, mtdSc: 3.96, mtdActual: 3.53, ytdTarget: 14.49, ytdSc: 13.31, ytdActual: 12.47 },
    { name: "Freight - Logistic", fy27Tc: 1554, fy27Sc: 1476, mtdTarget: 2.94, mtdSc: 2.8, mtdActual: 3.14, ytdTarget: 11.11, ytdSc: 10.56, ytdActual: 10.88 },
    { name: "Total", fy27Tc: 4618, fy27Sc: 4260, mtdTarget: 7.12, mtdSc: 6.76, mtdActual: 6.67, ytdTarget: 25.6, ytdSc: 23.87, ytdActual: 23.35 }
  ],
  baseCostLedgerBreakdown: null,
  costOfeBreakdown: [
    { name: 'Admin and EW', mtdTarget: 0.434, mtdSc: 0.412, mtdActual: 0.322, ytdTarget: 1.578, ytdSc: 1.157, ytdActual: 1.002 },
    { name: 'Civil R&M', mtdTarget: 0.171, mtdSc: 0.162, mtdActual: 0.126, ytdTarget: 0.558, ytdSc: 0.459, ytdActual: 0.469 },
    { name: 'Maintenance and Services', mtdTarget: 0.450, mtdSc: 0.427, mtdActual: 0.420, ytdTarget: 1.500, ytdSc: 1.418, ytdActual: 1.394 },
    { name: 'Prodn Related Contracts Exc Inhouse', mtdTarget: 0.449, mtdSc: 0.427, mtdActual: 0.440, ytdTarget: 1.527, ytdSc: 1.415, ytdActual: 1.409 },
    { name: 'Sustainability', mtdTarget: 0.028, mtdSc: 0.027, mtdActual: 0.006, ytdTarget: 0.113, ytdSc: 0.112, ytdActual: 0.009 },
    { name: 'CLT - OFC', mtdTarget: 1.533, mtdSc: 1.456, mtdActual: 1.315, ytdTarget: 5.277, ytdSc: 4.560, ytdActual: 4.283 },
    { name: 'Insurance', mtdTarget: 0.210, mtdSc: 0.199, mtdActual: 0.117, ytdTarget: 0.628, ytdSc: 0.588, ytdActual: 0.452 },
    { name: 'Treasury Exps', mtdTarget: 0.061, mtdSc: 0.058, mtdActual: 0.057, ytdTarget: 0.245, ytdSc: 0.242, ytdActual: 0.273 },
    { name: 'Insurance & Treasury', mtdTarget: 0.271, mtdSc: 0.257, mtdActual: 0.174, ytdTarget: 0.874, ytdSc: 0.830, ytdActual: 0.725 },
    { name: 'OFE excl IT', mtdTarget: 1.804, mtdSc: 1.713, mtdActual: 1.489, ytdTarget: 6.150, ytdSc: 5.390, ytdActual: 5.008 },
    { name: 'IT', mtdTarget: 0.763, mtdSc: 0.725, mtdActual: 0.632, ytdTarget: 2.476, ytdSc: 2.048, ytdActual: 2.753 },
    { name: 'Total OFC', mtdTarget: 2.567, mtdSc: 2.438, mtdActual: 2.120, ytdTarget: 8.627, ytdSc: 7.439, ytdActual: 7.761 }
  ],
  baseCostOfeBreakdown: null,
  costVccBreakdown: [
    { name: "Eq No", group: "", apr: { tc: 2341.6973393333324, sc: 2341.6973393333324, act: 1553 }, may: { tc: 2582.739365333334, sc: 2582.739365333334, act: 2053 }, jun: { tc: 2955.300458666668, sc: 2955.300458666668, act: 2230 }, jul: { tc: 2662.7936543333335, sc: 2662.7936543333335, act: 2103 }, ytdJuly27: { tc: 10542.53081766667, sc: 10542.53081766667, act: 7939 }, ytdMar27: { savingTc: 0, savingSc: 0 } },
    { name: "Rs/Eq Veh", group: "", apr: { tc: 0, sc: 0, act: 0 }, may: { tc: 0, sc: 0, act: 0 }, jun: { tc: 0, sc: 0, act: 0 }, jul: { tc: 0, sc: 0, act: 0 }, ytdJuly27: { tc: 0, sc: 0, act: 0 }, ytdMar27: { savingTc: 0, savingSc: 0 } },
    { name: "Power", group: "Utilities", apr: { tc: 2476.3601394529696, sc: 2352.542132480321, act: 1927.4196973599483 }, may: { tc: 2377.3060088690318, sc: 2258.44070842558, act: 2258.4407062834875 }, jun: { tc: 2241.96534037257, sc: 2129.8670733539416, act: 1777.895542600897 }, jul: { tc: 3757.245609320233, sc: 3569.3833288542214, act: 1958.9195102234903 }, ytdJuly27: { tc: 2709.9089603276398, sc: 2574.413512311258, act: 1979.3646995843305 }, ytdMar27: { savingTc: 730.5442607433092, savingSc: 595.0488127269273 } },
    { name: "Fuel", group: "Utilities", apr: { tc: 500, sc: 475, act: 319.1794204764971 }, may: { tc: 500, sc: 475, act: 364.7797467121285 }, jun: { tc: 500, sc: 475, act: 296.7116547085202 }, jul: { tc: 500, sc: 475, act: 321.0763005230623 }, ytdJuly27: { tc: 499.99999999999994, sc: 474.9999999999999, act: 325.16298148381406 }, ytdMar27: { savingTc: 174.83701851618588, savingSc: 149.83701851618582 } },
    { name: "IDM", group: "VIC & MS", apr: { tc: 710, sc: 674.5, act: 696.9254217643271 }, may: { tc: 720, sc: 684, act: 659.244242571846 }, jun: { tc: 720, sc: 684, act: 678.6129955156953 }, jul: { tc: 720, sc: 684, act: 719.9597432239658 }, ytdJuly27: { tc: 717.7788091115567, sc: 681.8898686559788, act: 688.1390515178235 }, ytdMar27: { savingTc: 29.63975759373318, savingSc: -6.249182861844702 } },
    { name: "Tools", group: "VIC & MS", apr: { tc: 90, sc: 85.5, act: 74.44858338699294 }, may: { tc: 95, sc: 90.25, act: 80.14953726254262 }, jun: { tc: 95, sc: 90.25, act: 81.29577130044844 }, jul: { tc: 95, sc: 90.25, act: 86.97739895387542 }, ytdJuly27: { tc: 93.88940455577836, sc: 89.19493432798944, act: 81.16496913969014 }, ytdMar27: { savingTc: 12.724435416088212, savingSc: 8.0299651882993 } },
    { name: "PTP", group: "VIC & MS", apr: { tc: 0, sc: 0, act: 0 }, may: { tc: 0, sc: 0, act: 0 }, jun: { tc: 0, sc: 0, act: 0 }, jul: { tc: 0, sc: 0, act: 0 }, ytdJuly27: { tc: 0, sc: 0, act: 0 }, ytdMar27: { savingTc: 0, savingSc: 0 } },
    { name: "Spares", group: "VIC & MS", apr: { tc: 2000, sc: 1900, act: 1992.9394526722474 }, may: { tc: 2100, sc: 1995, act: 1859.617749634681 }, jun: { tc: 2080, sc: 1976, act: 1951.206215246637 }, jul: { tc: 2300, sc: 2185, act: 1868.3720066571564 }, ytdJuly27: { tc: 2122.696920872075, sc: 2016.5620748284716, act: 1913.7430910694043 }, ytdMar27: { savingTc: 208.95382980267095, savingSc: 102.81898375906735 } },
    { name: "Freight- VIC", group: "VIC & MS", apr: { tc: 2059, sc: 1956.05, act: 2042.0084030907922 }, may: { tc: 2059, sc: 1956.05, act: 1891.018977106673 }, jun: { tc: 2059, sc: 1956.05, act: 1765.7821704035875 }, jul: { tc: 2059, sc: 1956.05, act: 2158.7351640513552 }, ytdJuly27: { tc: 2059, sc: 1956.05, act: 1956.2936515934 }, ytdMar27: { savingTc: 102.7063484066, savingSc: -0.24365159340004539 } },
    { name: "Freight- Logistics", group: "Logistics", apr: { tc: 14000, sc: 13300, act: 13992.692318094012 }, may: { tc: 14000, sc: 13300, act: 12646.573779834387 }, jun: { tc: 14000, sc: 13300, act: 13308.071103139015 }, jul: { tc: 14000, sc: 13300, act: 14953.585786970993 }, ytdJuly27: { tc: 13999.999999999996, sc: 13299.999999999998, act: 13706.821590880463 }, ytdMar27: { savingTc: 293.17840911953317, savingSc: -406.821590880465 } },
    { name: "Freight", group: "", apr: { tc: 16059, sc: 15256.05, act: 16034.700721184805 }, may: { tc: 16059, sc: 15256.05, act: 14537.59275694106 }, jun: { tc: 16059, sc: 15256.05, act: 15073.853273542602 }, jul: { tc: 16059, sc: 15256.05, act: 17112.320951022346 }, ytdJuly27: { tc: 16058.999999999996, sc: 15256.049999999997, act: 15663.115242473863 }, ytdMar27: { savingTc: 395.8847575261334, savingSc: -407.0652424738655 } },
    { name: "Total", group: "", apr: { tc: 21835.36013945297, sc: 20743.59213248032, act: 21045.613296844815 }, may: { tc: 21851.306008869033, sc: 20758.74070842558, act: 19759.824739405747 }, jun: { tc: 21695.965340372568, sc: 20611.167073353943, act: 19859.5754529148 }, jul: { tc: 23431.245609320235, sc: 22259.68332885422, act: 22067.6259106039 }, ytdJuly27: { tc: 22203.274094867047, sc: 21093.110390123697, act: 20650.690035268926 }, ytdMar27: { savingTc: 1552.5840595981208, savingSc: 442.42035485477027 } },
    { name: "Inhouse Contract", group: "Production Contracts", apr: { tc: 1411, sc: 1340.45, act: 1384.818622021893 }, may: { tc: 1853, sc: 1760.35, act: 1758.951646371164 }, jun: { tc: 1706, sc: 1620.6999999999998, act: 1410.3787847533633 }, jul: { tc: 1303, sc: 1237.85, act: 1277.5215359010938 }, ytdJuly27: { tc: 1630.125113159064, sc: 1548.6188575011108, act: 1460.3254225973044 }, ytdMar27: { savingTc: 169.7996905617597, savingSc: 88.29343490380643 } },
    { name: "Warehouse expenses", group: "Production Contracts", apr: { tc: 1818.8940776709796, sc: 1727.9493737874307, act: 1815.3696587250486 }, may: { tc: 1818.8940776709794, sc: 1727.9493737874304, act: 1652.0781100828056 }, jun: { tc: 1818.8940776709794, sc: 1727.9493737874304, act: 1989.0322017937217 }, jul: { tc: 1818.8940776709794, sc: 1727.9493737874304, act: 2130.842605801236 }, ytdJuly27: { tc: 1818.8940776709787, sc: 1727.9493737874297, act: 1905.4905214762566 }, ytdMar27: { savingTc: -86.59644380527789, savingSc: -177.54114768882687 } },
    { name: "Total", group: "", apr: { tc: 3229.8940776709796, sc: 3068.3993737874307, act: 3200.1882807469415 }, may: { tc: 3671.8940776709796, sc: 3488.2993737874303, act: 3411.0297564539696 }, jun: { tc: 3524.8940776709796, sc: 3348.6493737874302, act: 3399.410986547085 }, jul: { tc: 3121.8940776709796, sc: 2965.7993737874303, act: 3408.36414170233 }, ytdJuly27: { tc: 3449.019190830043, sc: 3276.5682312885406, act: 3365.815944073561 }, ytdMar27: { savingTc: 83.20324675648226, savingSc: -89.24771278502021 } },
    { name: "Grand Total", group: "", apr: { tc: 25065.254217123947, sc: 23811.99150626775, act: 24245.801577591756 }, may: { tc: 25523.20008654001, sc: 24247.04008221301, act: 23170.854495859716 }, jun: { tc: 25220.859418043547, sc: 23959.816447141373, act: 23258.986439461885 }, jul: { tc: 26553.139686991213, sc: 25225.48270264165, act: 25475.99005230623 }, ytdJuly27: { tc: 25652.29328569709, sc: 24369.678621412237, act: 24016.505979342488 }, ytdMar27: { savingTc: 1635.787306354603, savingSc: 353.1726420697487 } }
  ],
  baseCostVccBreakdown: null,
  costCltBreakdown: [
    { name: "Admin and EW", lead: "Anurag Chharia", mtdTarget: 0.434, mtdSc: 0.412, mtdActual: 0.322, mtdSavingTc: 0.112, mtdSavingSc: 0.090, ytdTarget: 1.578, ytdSc: 1.157, ytdActual: 1.002, ytdSavingTc: 0.576, ytdSavingSc: 0.155 },
    { name: "Maintenance and Services", lead: "Pradosh Mohanty", mtdTarget: 0.450, mtdSc: 0.427, mtdActual: 0.420, mtdSavingTc: 0.030, mtdSavingSc: 0.007, ytdTarget: 1.500, ytdSc: 1.418, ytdActual: 1.394, ytdSavingTc: 0.106, ytdSavingSc: 0.023 },
    { name: "Civil R&M", lead: "Ravi Kulkarni", mtdTarget: 0.171, mtdSc: 0.162, mtdActual: 0.126, mtdSavingTc: 0.045, mtdSavingSc: 0.036, ytdTarget: 0.558, ytdSc: 0.459, ytdActual: 0.469, ytdSavingTc: 0.089, ytdSavingSc: -0.010 },
    { name: "Sustainability", lead: "Ravi Kulkarni", mtdTarget: 0.028, mtdSc: 0.027, mtdActual: 0.006, mtdSavingTc: 0.023, mtdSavingSc: 0.021, ytdTarget: 0.113, ytdSc: 0.112, ytdActual: 0.009, ytdSavingTc: 0.104, ytdSavingSc: 0.103 },
    { name: "Prodn Related Contracts Exc Inhouse", lead: "Sunil Tiwari", mtdTarget: 1.106, mtdSc: 1.051, mtdActual: 1.157, mtdSavingTc: -0.051, mtdSavingSc: -0.107, ytdTarget: 4.225, ytdSc: 3.978, ytdActual: 4.081, ytdSavingTc: 0.144, ytdSavingSc: -0.103 },
    { name: "Utilities", lead: "Mahesh Suguru", mtdTarget: 0.895, mtdSc: 0.851, mtdActual: 0.479, mtdSavingTc: 0.416, mtdSavingSc: 0.371, ytdTarget: 2.560, ytdSc: 2.432, ytdActual: 1.830, ytdSavingTc: 0.730, ytdSavingSc: 0.602 },
    { name: "VIC & MS", lead: "Deepak Kumar", mtdTarget: 1.088, mtdSc: 1.034, mtdActual: 1.017, mtdSavingTc: 0.071, mtdSavingSc: 0.017, ytdTarget: 3.969, ytdSc: 3.770, ytdActual: 3.683, ytdSavingTc: 0.285, ytdSavingSc: 0.087 },
    { name: "Logistics", lead: "Umesh Tambolkar", mtdTarget: 2.944, mtdSc: 2.797, mtdActual: 3.145, mtdSavingTc: -0.201, mtdSavingSc: -0.348, ytdTarget: 11.115, ytdSc: 10.559, ytdActual: 10.882, ytdSavingTc: 0.233, ytdSavingSc: -0.323 },
    { name: "Total", lead: "", mtdTarget: 7.117, mtdSc: 6.761, mtdActual: 6.672, mtdSavingTc: 0.444, mtdSavingSc: 0.089, ytdTarget: 25.617, ytdSc: 23.884, ytdActual: 23.350, ytdSavingTc: 2.267, ytdSavingSc: 0.534 },
    { name: "Savings (Target vs Actual)", lead: "", mtdTarget: 0, mtdSc: 0.444, mtdActual: 0.089, mtdSavingTc: 0, mtdSavingSc: 0, ytdTarget: 0, ytdSc: 1.734, ytdActual: 2.267, ytdSavingTc: 0, ytdSavingSc: 0 }
  ],
  baseCostCltBreakdown: null,
  costPlantBreakdown: [
    { name: "Repairs & Renovation & Maintenance", mtdTarget: 76.65193248, mtdSc: 72.81933586, mtdActual: 69.4291765, ytdTarget: 971.0, ytdSc: 944.50221013, ytdActual: 222.8132904, ytdSavingTc: 748.1867096, ytdSavingSc: 721.68891973, mtdSavingTc: 7.22275598, mtdSavingSc: 3.39015936 },
    { name: "Employee Welfare,Recruitment etc", mtdTarget: 1.69, mtdSc: 1.6055, mtdActual: 2.1752, ytdTarget: 17.74, ytdSc: 17.5375, ytdActual: 5.7564738, ytdSavingTc: 11.9835262, ytdSavingSc: 11.7810262, mtdSavingTc: -0.4852, mtdSavingSc: -0.5697 },
    { name: "Municipal Chgs & Water Chgs", mtdTarget: 0.05, mtdSc: 0.0475, mtdActual: 0.353, ytdTarget: 11.999999999999998, ytdSc: 11.992499999999998, ytdActual: 0.365, ytdSavingTc: 11.635, ytdSavingSc: 11.6275, mtdSavingTc: -0.303, mtdSavingSc: -0.3055 },
    { name: "Others", mtdTarget: 9.0, mtdSc: 8.55, mtdActual: 3.19408, ytdTarget: 118.73, ytdSc: 111.2465, ytdActual: 23.6261638, ytdSavingTc: 95.1038362, ytdSavingSc: 87.6203362, mtdSavingTc: 5.80592, mtdSavingSc: 5.35592 },
    { name: "TOTAL  Controllable", mtdTarget: 153.27158852, mtdSc: 145.6080091, mtdActual: 131.4877019, ytdTarget: 527.65735409, ytdSc: 455.99377466, ytdActual: 428.3486059, ytdSavingTc: 99.30874819, ytdSavingSc: 27.64516876, mtdSavingTc: 21.78388662, mtdSavingSc: 14.1203072 },
    { name: "Treasury Exps", mtdTarget: 6.1373994, mtdSc: 5.83052943, mtdActual: 5.717505, ytdTarget: 24.5495976, ytdSc: 24.24272763, ytdActual: 27.2600948, ytdSavingTc: -2.7104972, ytdSavingSc: -3.01736717, mtdSavingTc: 0.4198944, mtdSavingSc: 0.11302443 },
    { name: "Insurance", mtdTarget: 20.9570505, mtdSc: 19.90919798, mtdActual: 11.65505, ytdTarget: 62.828202, ytdSc: 58.78034948, ytdActual: 45.19421, ytdSavingTc: 17.633992, ytdSavingSc: 13.58613947, mtdSavingTc: 9.3020005, mtdSavingSc: 8.25414798 },
    { name: "IT OPEX Exps", mtdTarget: 64.05217553, mtdSc: 60.84956675, mtdActual: 48.4619659, ytdTarget: 214.60870211, ytdSc: 172.40609333, ytdActual: 227.5825519, ytdSavingTc: -12.97384979, ytdSavingSc: -55.17645857, mtdSavingTc: 15.59020963, mtdSavingSc: 12.38760085 },
    { name: "IT DPDS Exps", mtdTarget: 12.26513928, mtdSc: 11.65188231, mtdActual: 14.7022211, ytdTarget: 33.04055711, ytdSc: 32.42730015, ytdActual: 47.6697439, ytdSavingTc: -14.62918679, ytdSavingSc: -15.24244375, mtdSavingTc: -2.43708182, mtdSavingSc: -3.05033879 },
    { name: "TOTAL Non Controllable", mtdTarget: 103.41176471, mtdSc: 98.24117647, mtdActual: 80.536742, ytdTarget: 335.02705882, ytdSc: 287.85647059, ytdActual: 347.7066006, ytdSavingTc: -12.67954178, ytdSavingSc: -59.85013001, mtdSavingTc: 22.87502271, mtdSavingSc: 17.70443447 },
    { name: "Grand Total (Controllable + Non Controllable)", mtdTarget: 256.68335323, mtdSc: 243.84918557, mtdActual: 212.0244439, ytdTarget: 862.68441291, ytdSc: 743.85024525, ytdActual: 776.0552065, ytdSavingTc: 86.62920641, ytdSavingSc: -32.20496125, mtdSavingTc: 44.65890933, mtdSavingSc: 31.82474167 },
    { name: "Grand Total (Controllable + Treasury + Insurance)", mtdTarget: 180.36603842, mtdSc: 171.3477365, mtdActual: 148.8602569, ytdTarget: 615.03515369, ytdSc: 539.01685177, ytdActual: 500.8029107, ytdSavingTc: 114.23224299, ytdSavingSc: 38.21394107, mtdSavingTc: 31.50578152, mtdSavingSc: 22.4874796 }
  ],
  baseCostPlantBreakdown: null,
  safetyMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
    fac: [3, 5, 2, 3, 4],
    lta: [0, 0, 0, 3, 0],
    mtc: [0, 0, 0, 0, 0],
    rwc: [0, 0, 1, 0, 0],
    psi1: [85, 88, 90, 92, 92],
    psi2: [90, 92, 95, 98, 98],
    trcfr: [0.26, 0, 2.89, 8.17, 8.17],
    safe_session: {
      targets: [10, 10, 10, 10, 10],
      actuals: [7, 7, 7, 7, 7],
      ytdTarget: 50,
      ytdActual: 35
    },
    floor_leadership: {
      targets: [5, 5, 5, 5, 5],
      actuals: [4, 4, 4, 4, 4],
      ytdTarget: 25,
      ytdActual: 20
    },
    safety_training: {
      targets: [2, 2, 2, 2, 2],
      actuals: [0.62, 0.62, 0.62, 0.62, 0.62],
      ytdTarget: 10,
      ytdActual: 3.1
    },
    smt_coverage: {
      targets: [1, 1, 1, 1, 1],
      actuals: [0.99, 0.99, 0.99, 0.99, 0.99],
      ytdTarget: 1,
      ytdActual: 0.99
    },
    sdt_coverage: {
      targets: [1, 1, 1, 1, 1],
      actuals: [1, 1, 1, 1, 1],
      ytdTarget: 1,
      ytdActual: 1
    },
    visilens: {
      targets: [107, 107, 107, 107, 107],
      actuals: [90, 90, 90, 90, 90],
      ytdTarget: 107,
      ytdActual: 90
    },
    bpms_rating: {
      target: 19,
      actual: 2,
      ytdTarget: 19,
      ytdActual: 2
    },
    meetings: {
      fic: { mtdTarget: 9, mtdActual: 6, ytdTarget: 45, ytdActual: 30 },
      bbt: { mtdTarget: 21, mtdActual: 11, ytdTarget: 105, ytdActual: 55 },
      plant_subcommittee: { mtdTarget: 19, mtdActual: 17, ytdTarget: 95, ytdActual: 85 }
    },
    fyData: {
      fac: { fy24: 19, fy25: 10, fy26: 12, ytd: 17 },
      lta: { fy24: 0, fy25: 0, fy26: 2, ytd: 3 },
      mtc: { fy24: 0, fy25: 0, fy26: 0, ytd: 0 },
      rwc: { fy24: 1, fy25: 0, fy26: 0, ytd: 1 },
      psi1: { fy24: 85, fy25: 90, fy26: 99, ytd: 97.5 },
      psi2: { fy24: 95.88, fy25: 98.94, fy26: 74.49, ytd: 64.9 },
      trcfr: { fy24: 0.26, fy25: 0, fy26: 0.63, ytd: 2.72 }
    }
  },
  productivityMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26"],
    hpev3: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [47, 46.33, 45.67, 45],
      actuals: [48.15, 46.08, 48.11, 42.34],
      fyData: { fy24: 48, fy25: 46.08, fy26: 48.11 }
    },
    hpev4: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [59.6, 59.1, 62.4, 61.9],
      actuals: [67.06, 62.75, 63.3, 57.37],
      fyData: { fy24: 67.06, fy25: 62.75, fy26: 63.3 }
    },
    cpev: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [30710, 30710, 30710, 30710],
      actuals: [31681, 27959, 25785, 28432],
      fyData: { fy24: 31681, fy25: 27959, fy26: 25785 }
    }
  },
  inventoryMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26"],
    opsDays: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [9, 9, 9, 9],
      actuals: [18, 17, 17, 17],
      fyData: { fy24: 0, fy25: 16, fy26: 12, ytd: 17 }
    },
    invWo: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [113, 121, 150, 194],
      actuals: [137.24, 160.66, 169.61, 169.61],
      fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 169.61 }
    },
    invWith: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [123, 131, 150, 204],
      actuals: [137.24, 160.66, 170, 170],
      fyData: { fy24: 0, fy25: 98, fy26: 121, ytd: 170.0 }
    },
    tml: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [113, 121, 124, 139],
      actuals: [137, 160, 135, 165],
      fyData: { fy24: 0, fy25: 0, fy26: 94, ytd: 165 }
    },
    tmbsl: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [27, 29, 26, 26],
      actuals: [35, 37, 35, 39],
      fyData: { fy24: 0, fy25: 0, fy26: 27, ytd: 39 }
    },
    gt180: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [35, 35, 35, 35],
      actuals: [31, 33, 35, 35]
    },
    gt90: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [40, 40, 40, 40],
      actuals: [38, 44, 46, 46]
    },
    mach: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [4, 4, 4, 4],
      actuals: [3.83, 3.71, 3.58, 3.58]
    },
    tools: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [1.5, 1.5, 1.5, 1.5],
      actuals: [2.78, 2.78, 1.78, 1.78]
    },
    invOverall: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [140, 150, 150, 165],
      actuals: [173, 191, 175, 204],
      fyData: { fy24: 0, fy25: 98, fy26: 121, ytd: 204 }
    },
    invNoOfDays: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [11, 11, 11, 11],
      actuals: [18, 19, 19, 22],
      fyData: { fy24: 0, fy25: 16, fy26: 12, ytd: 22 }
    }
  },
  digitalMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26"],
    budgetRfq: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [10, 25, 50, 75],
      actuals: [0, 13, 13, 13]
    },
    qualixIqms: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [0, 2, 2, 2],
      actuals: [0, 2, 2, 2]
    }
  },
  deliveryMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
    months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
    otif: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [100, 100, 100, 100, 100],
      actuals: [91, 99, 94, 100, 99],
      fyData: { fy24: 91, fy25: 95, fy26: 94 },
      ytdTarget: 100,
      ytdActual: 97.4
    },
    otif_dom: {
      targets: [98, 98, 98, 98, 98],
      actuals: [91, 99, 94, 99, 100],
      ytdTarget: 98,
      ytdActual: 97
    },
    otif_ib: {
      targets: [98, 98, 98, 98, 98],
      actuals: [100, 100, 94, 100, 100],
      ytdTarget: 99,
      ytdActual: 97
    },
    otif_spares: {
      targets: [100, 100, 100, 100, 100],
      actuals: [100, 100, 100, 100, 100],
      ytdTarget: 100,
      ytdActual: 100
    },
    spd: {
      targets: [100, 100, 100, 100, 100],
      actuals: [100, 100, 100, 100, 100],
      ytdTarget: 100,
      ytdActual: 100
    },
    mape_dom_ilmcv: {
      targets: [98, 98, 98, 98, 98],
      actuals: [76, 85, 93, 100, 100],
      ytdTarget: 100,
      ytdActual: 97
    },
    mape_dom_hcv: {
      targets: [98, 98, 98, 98, 98],
      actuals: [76, 85, 93, 100, 100],
      ytdTarget: 100,
      ytdActual: 97
    },
    mape_dom_cvp: {
      targets: [98, 98, 98, 98, 98],
      actuals: [76, 85, 93, 100, 100],
      ytdTarget: 100,
      ytdActual: 97
    },
    mape_ib: {
      targets: [98, 98, 98, 98, 98],
      actuals: [63, 100, 91, 100, 100],
      ytdTarget: 100,
      ytdActual: 97
    },
    line2: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [1891, 2288, 1914, 1404, 1404],
      actuals: [1449, 1599, 1587, 1422, 1422],
      ytdTarget: 8901,
      ytdActual: 7479
    },
    prod_l2: {
      targets: [1891, 2288, 1914, 1404, 1404],
      actuals: [1449, 1599, 1587, 1422, 1422],
      ytdTarget: 8901,
      ytdActual: 7479
    },
    line3: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [214, 501, 666, 644, 644],
      actuals: [152, 378, 438, 525, 525],
      ytdTarget: 2669,
      ytdActual: 2018
    },
    prod_l3: {
      targets: [214, 501, 666, 644, 644],
      actuals: [152, 378, 438, 525, 525],
      ytdTarget: 2669,
      ytdActual: 2018
    },
    prod_tot: {
      targets: [2105, 2789, 2580, 2048, 2048],
      actuals: [1601, 1977, 2025, 1947, 1947],
      ytdTarget: 11570,
      ytdActual: 9497
    },
    prod_dom: {
      targets: [1814, 1814, 1814, 1814, 1814],
      actuals: [1500, 1650, 1682, 1759, 1759],
      ytdTarget: 9070,
      ytdActual: 8350
    },
    prod_int: {
      targets: [234, 234, 234, 234, 234],
      actuals: [180, 200, 212, 188, 188],
      ytdTarget: 1170,
      ytdActual: 968
    },
    disp_tmbsl: {
      targets: [1061, 1061, 1061, 1061, 1061],
      actuals: [810, 840, 850, 854, 854],
      ytdTarget: 5305,
      ytdActual: 4208
    },
    disp_acgl: {
      targets: [1026, 1026, 1026, 1026, 1026],
      actuals: [910, 940, 950, 963, 963],
      ytdTarget: 5130,
      ytdActual: 4726
    },
    disp_imac: {
      targets: [33, 33, 33, 33, 33],
      actuals: [25, 27, 28, 28, 28],
      ytdTarget: 165,
      ytdActual: 136
    },
    disp_jcbl: {
      targets: [0, 0, 0, 0, 0],
      actuals: [0, 0, 0, 0, 0],
      ytdTarget: 0,
      ytdActual: 0
    },
    disp_otherbb: {
      targets: [28, 28, 28, 28, 28],
      actuals: [25, 26, 26, 27, 27],
      ytdTarget: 140,
      ytdActual: 131
    },
    disp_direct: {
      targets: [75, 75, 75, 75, 75],
      actuals: [85, 90, 92, 98, 98],
      ytdTarget: 375,
      ytdActual: 463
    },
    disp_ev: {
      targets: [6, 6, 6, 6, 6],
      actuals: [5, 5, 6, 6, 6],
      ytdTarget: 30,
      ytdActual: 28
    },
    disp_tot: {
      targets: [2229, 2229, 2229, 2229, 2229],
      actuals: [1860, 1928, 1952, 1976, 1976],
      ytdTarget: 11145,
      ytdActual: 9692
    },
    bus_4spcr_nac: {
      targets: [689, 689, 689, 689, 689],
      actuals: [670, 680, 685, 690, 690],
      ytdTarget: 3445,
      ytdActual: 3415
    },
    bus_4spcr_ac: {
      targets: [54, 54, 54, 54, 54],
      actuals: [55, 58, 60, 62, 62],
      ytdTarget: 270,
      ytdActual: 297
    },
    bus_maxicab_nac: {
      targets: [249, 249, 249, 249, 249],
      actuals: [245, 248, 250, 252, 252],
      ytdTarget: 1245,
      ytdActual: 1247
    },
    bus_cx2_nac: {
      targets: [20, 20, 20, 20, 20],
      actuals: [18, 19, 20, 20, 20],
      ytdTarget: 100,
      ytdActual: 97
    },
    bus_10_2_4sp: {
      targets: [14, 14, 14, 14, 14],
      actuals: [12, 12, 13, 13, 13],
      ytdTarget: 70,
      ytdActual: 63
    },
    bus_3_3l_nac: {
      targets: [211, 211, 211, 211, 211],
      actuals: [200, 204, 205, 207, 207],
      ytdTarget: 1055,
      ytdActual: 1023
    },
    bus_3_3l_ac: {
      targets: [119, 119, 119, 119, 119],
      actuals: [115, 116, 118, 119, 119],
      ytdTarget: 595,
      ytdActual: 587
    },
    bus_ib912_bs3: {
      targets: [32, 32, 32, 32, 32],
      actuals: [22, 24, 24, 25, 25],
      ytdTarget: 160,
      ytdActual: 120
    },
    bus_ib712_bs3: {
      targets: [12, 12, 12, 12, 12],
      actuals: [9, 10, 10, 10, 10],
      ytdTarget: 60,
      ytdActual: 49
    },
    bus_ib712_bs4: {
      targets: [32, 32, 32, 32, 32],
      actuals: [5, 6, 7, 7, 7],
      ytdTarget: 160,
      ytdActual: 32
    },
    bus_tot: {
      targets: [1432, 1432, 1432, 1432, 1432],
      actuals: [1351, 1377, 1392, 1405, 1405],
      ytdTarget: 7160,
      ytdActual: 6930
    }
  },
  costMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26"],
    dmc: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [1.6, 6.0, 4.5, 5.0],
      actuals: [1.74, 8.8, 4.5, 4.5]
    },
    repro: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [1.0, 1.0, 1.0, 1.0],
      actuals: [2.88, 0.47, 0.8, 0.8]
    },
    vcc: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [24246.0, 24246.85, 23959.82, 23959.82],
      actuals: [24246.0, 23169.0, 23250.91, 23250.91]
    },
    ofe: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [2.05, 2.05, 2.05, 2.05],
      actuals: [1.75, 1.80, 1.99, 2.12],
      fyData: { fy24: 24.5, fy25: 25.8, fy26: 26.2 }
    }
  },
  hrMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26"],
    csr: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [1910, 2040, 6800, 7150],
      actuals: [2322, 2350, 7240, 9096]
    },
    ivdp: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [0, 0, 0, 1000],
      actuals: [0, 0, 0, 1200]
    },
    environment: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [100, 100, 900, 1000],
      actuals: [300, 300, 1000, 2400]
    },
    health: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [1670, 1800, 2500, 2500],
      actuals: [1872, 1900, 2820, 2858]
    },
    education: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [0, 0, 3200, 3400],
      actuals: [0, 0, 3200, 3500]
    },
    employability: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [140, 140, 200, 250],
      actuals: [150, 150, 220, 338]
    }
  },
  qualityMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
    vc_charter: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [90, 90, 90, 90, 90],
      actuals: [82, 82, 82, 82, 82],
      ytdTarget: 90,
      ytdActual: 82,
      fyData: { fy24: 0, fy25: 0, fy26: 0 }
    },
    product_charter: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [90, 90, 95, 90, 90],
      actuals: [86, 79, 79, 79, 79],
      ytdTarget: 95,
      ytdActual: 79,
      fyData: { fy24: 0, fy25: 0, fy26: 0 }
    },
    comp_quality_iptv: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [347, 288, 235, 232, 232],
      actuals: [215, 200, 210, 197, 197],
      ytdTarget: 232,
      ytdActual: 197,
      fyData: { fy24: 0, fy25: 282, fy26: 243 }
    },
    comp_iptv: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [347, 288, 235, 235, 235],
      actuals: [215, 200, 210, 197, 197],
      ytdTarget: 235,
      ytdActual: 197
    },
    iptv_3: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [40, 40, 40, 40, 40],
      actuals: [39, 39, 39, 39, 39],
      ytdTarget: 40,
      ytdActual: 39
    },
    comp_quality_epv: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [6113, 5996, 5021, 4632, 4632],
      actuals: [6291, 5157, 4376, 4361, 4361],
      ytdTarget: 4632,
      ytdActual: 4361,
      fyData: { fy24: 0, fy25: 0, fy26: 0 }
    },
    comp_quality_visits: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [0.85, 0.84, 0.81, 0.8, 0.8],
      actuals: [0.83, 0.83, 0.69, 0.69, 0.69],
      ytdTarget: 0.8,
      ytdActual: 0.69,
      fyData: { fy24: 0, fy25: 0, fy26: 0.2 }
    },
    visit_24: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [0.78, 0.78, 0.78, 0.78, 0.78],
      actuals: [0.69, 0.69, 0.69, 0.69, 0.69],
      ytdTarget: 0.78,
      ytdActual: 0.69
    },
    visit_12: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [0.23, 0.23, 0.23, 0.23, 0.23],
      actuals: [0.18, 0.18, 0.18, 0.18, 0.18],
      ytdTarget: 0.23,
      ytdActual: 0.18
    },
    comp_quality_notouch: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [82, 82, 82, 82, 82],
      actuals: [81.2, 81.2, 83.0, 79.9, 79.9],
      ytdTarget: 82,
      ytdActual: 79.9,
      fyData: { fy24: 0, fy25: 0, fy26: 82 }
    },
    launch_quality: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [100, 100, 100, 100, 100],
      actuals: [100, 100, 100, 100, 100],
      ytdTarget: 100,
      ytdActual: 100,
      fyData: { fy24: 0, fy25: 0, fy26: 50 }
    },
    launch_uvpv: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [0.44, 0.43, 0.42, 0.42, 0.42],
      actuals: [0.44, 0.43, 0.42, 0.42, 0.42],
      ytdTarget: 0.42,
      ytdActual: 0.42,
      fyData: { fy24: 0, fy25: 0.85, fy26: 0 }
    },
    layer_audit: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [100, 100, 100, 100, 100],
      actuals: [100, 100, 100, 93.71, 93.71],
      ytdTarget: 100,
      ytdActual: 93.71,
      fyData: { fy24: 100, fy25: 100, fy26: 100 }
    },
    cimple_project: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [30, 30, 30, 30, 30],
      actuals: [0, 0, 3, 15, 15],
      ytdTarget: 30,
      ytdActual: 15,
      fyData: { fy24: 0, fy25: 0, fy26: 0 }
    },
    warranty_payout: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [5.5, 5.5, 5.5, 5.5, 5.5],
      actuals: [2.4, 2.4, 2.4, 2.4, 2.4],
      ytdTarget: 5.5,
      ytdActual: 2.4
    },
    l3_control: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [406, 406, 406, 406, 406],
      actuals: [406, 406, 406, 406, 406],
      ytdTarget: 406,
      ytdActual: 406
    },
    cpa_score: {
      months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"],
      targets: [80, 80, 80, 80, 80],
      actuals: [66, 66, 66, 66, 66],
      ytdTarget: 80,
      ytdActual: 66
    },
    launch_3mis: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [53, 53, 53, 53, 53], actuals: [51, 51, 51, 51, 51], ytdTarget: 53, ytdActual: 51 },
    launch_3_6mis: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [99, 99, 99, 99, 99], actuals: [93, 93, 93, 93, 93], ytdTarget: 99, ytdActual: 93 },
    launch_6_12mis: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [274, 274, 274, 274, 274], actuals: [320, 320, 320, 320, 320], ytdTarget: 274, ytdActual: 320 },
    drr_1_l1: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [90, 90, 90, 90, 90], actuals: [86.05, 85.46, 84.58, 83, 83], ytdTarget: 90, ytdActual: 84.77, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 84.77 } },
    drr_1_l2: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [90, 90, 90, 90, 90], actuals: [85.86, 84.77, 87.01, 85, 85], ytdTarget: 90, ytdActual: 85.66, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 85.66 } },
    drr_1_l3: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [90, 90, 90, 90, 90], actuals: [87.41, 89.17, 78.04, 78, 78], ytdTarget: 90, ytdActual: 83.16, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 83.16 } },
    drr_1: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [90, 90, 90, 90, 90], actuals: [86.05, 85.46, 84.58, 83, 83], ytdTarget: 90, ytdActual: 84.77, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 84.77 } },
    drr_2_l1: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [100, 100, 100, 100, 100], actuals: [100, 100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
    drr_2_l2: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [100, 100, 100, 100, 100], actuals: [100, 100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
    drr_2_l3: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [100, 100, 100, 100, 100], actuals: [100, 100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
    drr_2: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [100, 100, 100, 100, 100], actuals: [100, 100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
    drr_3_l1: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [95, 95, 95, 95, 95], actuals: [96, 96, 96, 96, 96], ytdTarget: 95, ytdActual: 96, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 96 } },
    drr_3_l2: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [95, 95, 95, 95, 95], actuals: [94, 94, 94, 94, 94], ytdTarget: 95, ytdActual: 94, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 94 } },
    drr_3_l3: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [95, 95, 95, 95, 95], actuals: [0, 0, 0, 0, 0], ytdTarget: 95, ytdActual: 0, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 0 } },
    drr_3: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [95, 95, 95, 95, 95], actuals: [94, 94, 94, 94, 94], ytdTarget: 95, ytdActual: 94, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 94 } },
    drr_4_l1: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [82, 82, 82, 82, 82], actuals: [93.59, 94.76, 96.41, 96, 96], ytdTarget: 82, ytdActual: 95.19, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 95.19 } },
    drr_4_l2: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [82, 82, 82, 82, 82], actuals: [92.99, 93.80, 95.26, 95, 95], ytdTarget: 82, ytdActual: 94.26, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 94.26 } },
    drr_4_l3: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [82, 82, 82, 82, 82], actuals: [99.30, 99.68, 99.31, 97, 97], ytdTarget: 82, ytdActual: 98.82, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 98.82 } },
    drr_4: { months: ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"], targets: [82, 82, 82, 82, 82], actuals: [93.59, 94.76, 96.41, 96, 96], ytdTarget: 82, ytdActual: 95.19, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 95.19 } }
  },
  environmentMonthlyData: {
    labels: ["Apr'26", "May'26", "June'26", "July'26"],
    power: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [238, 232, 222, 365],
      actuals: [193, 155, 145, 175]
    },
    fuel: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [5.25, 5.2, 5.25, 5.19],
      actuals: [2.7, 2.6, 2.1, 2.1]
    },
    ghg: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [5.13, 4.85, 10.35, 10.26],
      actuals: [4.56, 5.0, 9.48, 9.2]
    },
    water: {
      months: ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [1.75, 1.76, 1.84, 1.9],
      actuals: [1.8, 1.79, 1.84, 1.93]
    }
  },
  historyLogs: []
};

// Initialize base snapshots for filtering and resets
export function updateAllBaseSnapshots() {
  if (state.kpis) state.baseKpis = JSON.parse(JSON.stringify(state.kpis));
  if (state.deliveryMonthlyData) state.baseDeliveryMonthlyData = JSON.parse(JSON.stringify(state.deliveryMonthlyData));
  if (state.safetyMonthlyData) state.baseSafetyMonthlyData = JSON.parse(JSON.stringify(state.safetyMonthlyData));
  if (state.qualityMonthlyData) state.baseQualityMonthlyData = JSON.parse(JSON.stringify(state.qualityMonthlyData));
  if (state.productivityMonthlyData) state.baseProductivityMonthlyData = JSON.parse(JSON.stringify(state.productivityMonthlyData));
  if (state.costMonthlyData) state.baseCostMonthlyData = JSON.parse(JSON.stringify(state.costMonthlyData));
  if (state.hrMonthlyData) state.baseHrMonthlyData = JSON.parse(JSON.stringify(state.hrMonthlyData));
  if (state.environmentMonthlyData) state.baseEnvironmentMonthlyData = JSON.parse(JSON.stringify(state.environmentMonthlyData));
  if (state.inventoryMonthlyData) state.baseInventoryMonthlyData = JSON.parse(JSON.stringify(state.inventoryMonthlyData));
  if (state.digitalMonthlyData) state.baseDigitalMonthlyData = JSON.parse(JSON.stringify(state.digitalMonthlyData));
  if (state.costLedgerBreakdown) state.baseCostLedgerBreakdown = JSON.parse(JSON.stringify(state.costLedgerBreakdown));
  if (state.costOfeBreakdown) state.baseCostOfeBreakdown = JSON.parse(JSON.stringify(state.costOfeBreakdown));
  if (state.costVccBreakdown) state.baseCostVccBreakdown = JSON.parse(JSON.stringify(state.costVccBreakdown));
  if (state.costCltBreakdown) state.baseCostCltBreakdown = JSON.parse(JSON.stringify(state.costCltBreakdown));
  if (state.costPlantBreakdown) state.baseCostPlantBreakdown = JSON.parse(JSON.stringify(state.costPlantBreakdown));
  if (state.ficWiseInjuries) state.baseFicWiseInjuries = JSON.parse(JSON.stringify(state.ficWiseInjuries));
  if (state.ficWiseInjuriesYtd) state.baseFicWiseInjuriesYtd = JSON.parse(JSON.stringify(state.ficWiseInjuriesYtd));
}

export function syncKpiToMonthlyData(kpi) {
  if (!kpi || !kpi.module) return;
  const modProp = `${kpi.module}MonthlyData`;
  const modData = state[modProp];
  if (modData) {
    const key = kpi.id;
    const itemData = modData[key];
    if (itemData) {
      if (Array.isArray(itemData.targets) && itemData.targets.length > 0) {
        itemData.targets[itemData.targets.length - 1] = kpi.target;
      } else {
        itemData.targets = [kpi.target];
      }
      if (Array.isArray(itemData.actuals) && itemData.actuals.length > 0) {
        itemData.actuals[itemData.actuals.length - 1] = kpi.actual;
      } else {
        itemData.actuals = [kpi.actual];
      }
      itemData.ytdTarget = kpi.target;
      itemData.ytdActual = kpi.actual;
    } else {
      modData[key] = {
        targets: [kpi.target],
        actuals: [kpi.actual],
        ytdTarget: kpi.target,
        ytdActual: kpi.actual
      };
    }
  }
  updateAllBaseSnapshots();
}

updateAllBaseSnapshots();


// Helper to check if a KPI is a lower-is-better metric (money, usage, incidents, lost time)
export function isLowerBetter(kpi) {
  if (!kpi) return false;
  const { id = '', module = '' } = kpi;
  
  if (module === 'cost') {
    if (id === 'dmc') return false;
    return true;
  }
  if (module === 'inventory') return true;
  
  if (module === 'environment') {
    if (id === 'fuel_unit' || id === 'power_kwh' || id === 'env_water_ratio' || id === 'ghg' || id === 'zero_waste') return true;
  }
  
  if (module === 'productivity') {
    if (id === 'cpev' || id.startsWith('min_lost_')) return true;
  }
  
  if (module === 'quality') {
    if (id.includes('visit') || id.includes('iptv') || id.includes('epv') || id === 'launch_uvpv' || id.includes('warranty') || id === 'warranty_payout' || id.includes('notouch') || id === 'comp_quality_notouch') return true;
    return false;
  }

  if (module === 'hr') {
    if (id.includes('absenteeism')) return true;
  }

  if (module === 'safety') {
    if (id === 'trcfr' || id === 'lti' || id === 'rwc' || id === 'mtc' || id === 'fac') return true;
  }

  if (id.includes('gangway') && module !== 'digital') return true;

  return false;
}

// Dynamic helper to retrieve the latest reported value from a monthly series array
function getLatestVal(arr, fallback = 0) {
  if (!arr || !Array.isArray(arr) || arr.length === 0) return fallback;
  for (let i = arr.length - 1; i >= 0; i--) {
    const val = arr[i];
    if (val !== null && val !== undefined && !isNaN(val)) return val;
  }
  return fallback;
}

// Dynamic helper to calculate YTD sum across all reported months in dataset
function getYtdSum(arr, fallback = 0) {
  if (!arr || !Array.isArray(arr) || arr.length === 0) return fallback;
  let sum = 0;
  let count = 0;
  for (let i = 0; i < arr.length; i++) {
    const val = arr[i];
    if (val !== null && val !== undefined && !isNaN(val)) {
      sum += val;
      count++;
    }
  }
  return count > 0 ? sum : fallback;
}

export function getSafetyKpiForMode(kpi, mode) {
  if (kpi && kpi.module !== 'safety') {
    return { target: kpi ? kpi.target : 0, actual: kpi ? kpi.actual : 0 };
  }

  const smd = state.safetyMonthlyData || {};
  const fyData = smd.fyData || {};
  const labels = smd.labels || [];

  const monthCount = labels.length > 0 ? labels.length : (smd.fac && smd.fac.length > 0 ? smd.fac.length : 5);

  let target = kpi.target;
  let actual = kpi.actual;

  if (kpi.id === 'sif_derisking') {
    const p2Val = getSafetyKpiForMode({ id: 'phase_2', target: 197, actual: 197, module: 'safety' }, mode);
    const p3Val = getSafetyKpiForMode({ id: 'phase_3', target: 51, actual: 51, module: 'safety' }, mode);
    return {
      target: p2Val.target + p3Val.target,
      actual: p2Val.actual + p3Val.actual
    };
  }

  if (mode === 'monthly') {
    if (kpi.id === 'safe_session' || kpi.id === 'visilens' || kpi.id === 'floor_leadership' || kpi.id === 'safety_training' || kpi.id === 'smt_coverage' || kpi.id === 'sdt_coverage' || kpi.id === 'phase_2' || kpi.id === 'phase_3') {
      const field = kpi.id;
      if (smd[field]) {
        target = smd[field].targets ? getLatestVal(smd[field].targets, kpi.target) : (smd[field].target ?? kpi.target);
        actual = smd[field].actuals ? getLatestVal(smd[field].actuals, kpi.actual) : (smd[field].actual ?? kpi.actual);
      }
    } else if (kpi.id === 'bpms_rating') {
      target = smd.bpms_rating ? (smd.bpms_rating.target ?? kpi.target) : kpi.target;
      actual = smd.bpms_rating ? (smd.bpms_rating.actual ?? kpi.actual) : kpi.actual;
    } else if (kpi.id === 'psi_1') {
      target = smd.psi1Targets ? getLatestVal(smd.psi1Targets, kpi.target) : kpi.target;
      actual = smd.psi1 ? getLatestVal(smd.psi1, kpi.actual) : kpi.actual;
    } else if (kpi.id === 'psi_2') {
      target = smd.psi2Targets ? getLatestVal(smd.psi2Targets, kpi.target) : kpi.target;
      actual = smd.psi2 ? getLatestVal(smd.psi2, kpi.actual) : kpi.actual;
    } else if (kpi.id === 'trcfr') {
      target = smd.trcfrTargets ? getLatestVal(smd.trcfrTargets, kpi.target) : kpi.target;
      actual = smd.trcfr ? getLatestVal(smd.trcfr, kpi.actual) : kpi.actual;
    } else if (kpi.id === 'lti' || kpi.id === 'rwc' || kpi.id === 'mtc' || kpi.id === 'fac') {
      const fyKey = kpi.id === 'lti' ? 'lta' : kpi.id;
      target = 0;
      if (smd[fyKey + 'Obj'] && smd[fyKey + 'Obj'].ftm !== undefined) {
        actual = smd[fyKey + 'Obj'].ftm;
      } else {
        actual = smd[fyKey] ? getLatestVal(smd[fyKey], kpi.actual) : kpi.actual;
      }
    } else if (kpi.id === 'fic') {
      target = smd.meetings?.fic?.mtdTarget ?? kpi.target;
      actual = smd.meetings?.fic?.mtdActual ?? kpi.actual;
    } else if (kpi.id === 'bbt') {
      target = smd.meetings?.bbt?.mtdTarget ?? kpi.target;
      actual = smd.meetings?.bbt?.mtdActual ?? kpi.actual;
    } else if (kpi.id === 'plant_subcommittee') {
      target = smd.meetings?.plant_subcommittee?.mtdTarget ?? kpi.target;
      actual = smd.meetings?.plant_subcommittee?.mtdActual ?? kpi.actual;
    } else {
      target = kpi.target;
      actual = kpi.actual;
    }
  } else {
    // YTD mode
    if (kpi.id === 'safe_session' || kpi.id === 'safety_training' || kpi.id === 'floor_leadership' || kpi.id === 'visilens' || kpi.id === 'smt_coverage' || kpi.id === 'sdt_coverage' || kpi.id === 'phase_2' || kpi.id === 'phase_3') {
      const field = kpi.id;
      if (smd[field]) {
        target = smd[field].ytdTarget ?? (smd[field].targets ? getLatestVal(smd[field].targets, kpi.target) : kpi.target);
        actual = smd[field].ytdActual ?? (smd[field].actuals ? getLatestVal(smd[field].actuals, kpi.actual) : kpi.actual);
      } else {
        target = kpi.target;
        actual = kpi.actual;
      }
    } else if (kpi.id === 'psi_1' || kpi.id === 'psi_2' || kpi.id === 'trcfr') {
      const fyKey = kpi.id === 'psi_1' ? 'psi1' : (kpi.id === 'psi_2' ? 'psi2' : 'trcfr');
      const ytdProp = fyKey + 'Ytd';
      if (smd[ytdProp] !== undefined && smd[ytdProp] !== null) {
        actual = smd[ytdProp];
      } else if (fyData[fyKey] && fyData[fyKey].ytd !== undefined && fyData[fyKey].ytd !== null && fyData[fyKey].ytd !== 0) {
        actual = fyData[fyKey].ytd;
      } else {
        actual = smd[fyKey] ? getLatestVal(smd[fyKey], kpi.actual) : kpi.actual;
      }
      target = kpi.target;
    } else if (kpi.id === 'lti' || kpi.id === 'rwc' || kpi.id === 'mtc' || kpi.id === 'fac') {
      const fyKey = kpi.id === 'lti' ? 'lta' : kpi.id;
      target = 0;
      if (smd[fyKey + 'Obj'] && smd[fyKey + 'Obj'].ytd !== undefined) {
        actual = smd[fyKey + 'Obj'].ytd;
      } else if (fyData[fyKey] && fyData[fyKey].ytd !== undefined && fyData[fyKey].ytd !== null) {
        actual = fyData[fyKey].ytd;
      } else {
        actual = smd[fyKey] ? getYtdSum(smd[fyKey], kpi.actual) : kpi.actual;
      }
    } else if (kpi.id === 'fic' || kpi.id === 'bbt' || kpi.id === 'plant_subcommittee') {
      target = smd.meetings?.[kpi.id]?.ytdTarget ?? (kpi.target * monthCount);
      actual = smd.meetings?.[kpi.id]?.ytdActual ?? (kpi.actual * monthCount);
    } else {
      target = kpi.target;
      actual = kpi.actual;
    }
  }

  if (target === 0 && kpi.target !== 0 && !['fac', 'mtc', 'rwc', 'lti'].includes(kpi.id)) {
    target = kpi.target;
  }

  return { target, actual };
}

function getQualityMonthVal(kpiData, isTarget) {
  if (!kpiData) return null;
  const arr = isTarget ? kpiData.targets : kpiData.actuals;
  if (!arr || arr.length === 0) return null;
  return getLatestVal(arr, null);
}

function getQualityYtdVal(kpiData, isTarget) {
  if (!kpiData) return null;

  if (isTarget) {
    if (kpiData.ytdTarget !== undefined && kpiData.ytdTarget !== null && !isNaN(kpiData.ytdTarget) && kpiData.ytdTarget !== 0) {
      return kpiData.ytdTarget;
    }
    if (kpiData.fyData && kpiData.fyData.ytdTarget !== undefined && kpiData.fyData.ytdTarget !== null && !isNaN(kpiData.fyData.ytdTarget) && kpiData.fyData.ytdTarget !== 0) {
      return kpiData.fyData.ytdTarget;
    }
    if (kpiData.targets && kpiData.targets.length > 0) {
      const latestTgt = getLatestVal(kpiData.targets, null);
      if (latestTgt !== null && latestTgt !== undefined) return latestTgt;
    }
  } else {
    if (kpiData.ytdActual !== undefined && kpiData.ytdActual !== null && !isNaN(kpiData.ytdActual)) {
      return kpiData.ytdActual;
    }
    if (kpiData.fyData && kpiData.fyData.ytd !== undefined && kpiData.fyData.ytd !== null && !isNaN(kpiData.fyData.ytd) && kpiData.fyData.ytd !== 0) {
      return kpiData.fyData.ytd;
    }
    if (kpiData.actuals && kpiData.actuals.length > 0) {
      const validActuals = kpiData.actuals.filter(v => v !== null && v !== undefined && !isNaN(v));
      if (validActuals.length > 0) {
        return validActuals.reduce((a, b) => a + b, 0) / validActuals.length;
      }
    }
  }

  return null;
}

function getCostMonthVal(kpiData, isTarget) {
  if (!kpiData) return null;
  const arr = isTarget ? kpiData.targets : kpiData.actuals;
  if (!arr || arr.length === 0) return null;
  return getLatestVal(arr, null);
}

function getCostYtdVal(kpiData, isTarget, kpiId) {
  if (kpiData) {
    const fyData = kpiData.fyData || {};
    if (isTarget) {
      if (fyData.ytdTarget !== undefined && fyData.ytdTarget !== null && !isNaN(fyData.ytdTarget) && fyData.ytdTarget !== 0) {
        return fyData.ytdTarget;
      }
    } else {
      if (fyData.ytd !== undefined && fyData.ytd !== null && !isNaN(fyData.ytd) && fyData.ytd !== 0) {
        return fyData.ytd;
      }
      if (fyData.ytdActual !== undefined && fyData.ytdActual !== null && !isNaN(fyData.ytdActual) && fyData.ytdActual !== 0) {
        return fyData.ytdActual;
      }
    }

    const arr = isTarget ? kpiData.targets : kpiData.actuals;
    if (arr && arr.length > 0) {
      let sum = 0;
      let count = 0;
      for (let i = 0; i < arr.length; i++) {
        const val = arr[i];
        if (val !== null && val !== undefined && !isNaN(val)) {
          sum += val;
          count++;
        }
      }
      if (count > 0) {
        if (kpiId === 'vcc' && sum > 50000) {
          return sum / count;
        }
        return sum;
      }
    }
  }

  if (kpiId === 'ofe' && state.costOfeBreakdown) {
    const totalRow = state.costOfeBreakdown.find(r => r.name.toLowerCase().includes('total ofc') || r.name.toLowerCase().includes('ofe excl it'));
    if (totalRow) {
      return isTarget ? (totalRow.ytdTarget || totalRow.mtdTarget) : (totalRow.ytdActual || totalRow.mtdActual);
    }
  }

  if (kpiId === 'vcc' && state.costVccBreakdown) {
    const grandTotalRow = state.costVccBreakdown.find(r => r.name.toLowerCase().includes('grand total'));
    if (grandTotalRow) {
      if (grandTotalRow.ytdJuly27) {
        return isTarget ? (grandTotalRow.ytdJuly27.tc || grandTotalRow.jul.tc) : (grandTotalRow.ytdJuly27.act || grandTotalRow.jul.act);
      }
    }
  }

  return null;
}

function getGenericYtdVal(kpi, isTarget) {
  const module = kpi.module;
  const smd = state[`${module}MonthlyData`] || {};
  
  const idsToTry = [
    kpi.id,
    kpi.id.replace(/_/g, ''),
    kpi.id.replace('_l1', '').replace('_l2', '').replace('_l3', ''),
    kpi.id.replace('_l1', '').replace('_l2', '').replace('_l3', '').replace(/_/g, ''),
    kpi.id === 'fuel_unit' ? 'fuel' : null,
    kpi.id === 'power_kwh' ? 'power' : null,
    kpi.id === 'env_water_ratio' ? 'water' : null,
    kpi.id === 'inv_overall' ? 'invOverall' : null,
    kpi.id === 'inv_tml' ? 'tml' : null,
    kpi.id === 'inv_tmbsl' ? 'tmbsl' : null,
    kpi.id === 'inv_no_of_days' ? 'invNoOfDays' : null,
    kpi.id === 'ops_inv_days' ? 'opsDays' : null,
    kpi.id === 'inv_rs_crs_wo' ? 'invWo' : null,
    kpi.id === 'inv_rs_crs_w' ? 'invWith' : null,
    kpi.id === 'ageing_gt_180' ? 'gt180' : null,
    kpi.id === 'ageing_gt_90' ? 'gt90' : null,
    kpi.id === 'machinery_spares' ? 'mach' : null,
    kpi.id === 'tools_idm' ? 'tools' : null,
    kpi.id === 'hr_lives_ivdp' ? 'ivdp' : null,
    kpi.id === 'hr_lives_env' ? 'environment' : null,
    kpi.id === 'hr_lives_health' ? 'health' : null,
    kpi.id === 'hr_lives_edu' ? 'education' : null,
    kpi.id === 'hr_lives_emp' ? 'employability' : null,
    kpi.id === 'prod_l2' ? 'line2' : null,
    kpi.id === 'prod_l3' ? 'line3' : null
  ].filter(Boolean);

  let kpiData = null;
  for (const id of idsToTry) {
    if (smd[id]) {
      kpiData = smd[id];
      break;
    }
  }

  if (kpiData) {
    // 1. Check explicit YTD properties first
    if (isTarget) {
      if (kpiData.ytdTarget !== undefined && kpiData.ytdTarget !== null && !isNaN(kpiData.ytdTarget)) return kpiData.ytdTarget;
      if (kpiData.fyData && kpiData.fyData.ytdTarget !== undefined && kpiData.fyData.ytdTarget !== null && !isNaN(kpiData.fyData.ytdTarget)) return kpiData.fyData.ytdTarget;
    } else {
      if (kpiData.ytdActual !== undefined && kpiData.ytdActual !== null && !isNaN(kpiData.ytdActual)) return kpiData.ytdActual;
      if (kpiData.fyData && kpiData.fyData.ytd !== undefined && kpiData.fyData.ytd !== null && !isNaN(kpiData.fyData.ytd)) return kpiData.fyData.ytd;
      if (kpiData.fyData && kpiData.fyData.ytdActual !== undefined && kpiData.fyData.ytdActual !== null && !isNaN(kpiData.fyData.ytdActual)) return kpiData.fyData.ytdActual;
    }

    // 2. Sum or Average array values across all reported months in dataset
    const arr = isTarget ? kpiData.targets : (kpiData.actuals || (Array.isArray(kpiData) ? kpiData : null));
    if (arr && arr.length > 0) {
      const validVals = arr.filter(val => val !== null && val !== undefined && !isNaN(val));

      if (validVals.length > 0) {
        const isSumMetric = (
          kpi.id.startsWith('min_lost_') ||
          kpi.id.startsWith('prod_') ||
          kpi.id.startsWith('disp_') ||
          kpi.id.startsWith('bus_') ||
          kpi.id === 'line2' || kpi.id === 'line3' ||
          kpi.id.startsWith('hr_lives_') ||
          kpi.id === 'csr' || kpi.id === 'ivdp' || kpi.id === 'environment' || kpi.id === 'health' || kpi.id === 'education' || kpi.id === 'employability'
        );

        if (isSumMetric) {
          return validVals.reduce((a, b) => a + b, 0);
        } else {
          return validVals.reduce((a, b) => a + b, 0) / validVals.length;
        }
      }
    }
  }

  return isTarget ? kpi.target : kpi.actual;
}

export function getKpiForMode(kpi, mode) {
  if (!kpi) return { target: 0, actual: 0 };

  if (kpi.id === 'hr_pcvh') {
    const smd = state.hrMonthlyData || {};
    const pcvhData = smd.pcvh || smd.hr_pcvh;

    // Standard annual target is 48.0, standard default YTD actual is 20.38
    let annualTarget = 48.0;
    let ytdActual = 20.38;

    if (pcvhData) {
      if (pcvhData.annualTarget) {
        annualTarget = pcvhData.annualTarget;
      } else if (pcvhData.targets && pcvhData.targets.length > 0) {
        const sumT = pcvhData.targets.filter(v => v !== null && v !== undefined && !isNaN(v)).reduce((a, b) => a + b, 0);
        annualTarget = sumT > 12 ? sumT : (sumT * 3);
      }

      if (pcvhData.ytdActual) {
        ytdActual = pcvhData.ytdActual;
      } else if (pcvhData.actuals && pcvhData.actuals.length > 0) {
        const sumA = pcvhData.actuals.filter(v => v !== null && v !== undefined && !isNaN(v)).reduce((a, b) => a + b, 0);
        if (sumA > 0) ytdActual = sumA;
      }
    } else if (kpi) {
      if (kpi.annualTarget) annualTarget = kpi.annualTarget;
      else if (kpi.target && kpi.target > 12) annualTarget = kpi.target;
      
      if (kpi.ytdActual) ytdActual = kpi.ytdActual;
      else if (kpi.actual && kpi.actual > 12) ytdActual = kpi.actual;
    }

    const elapsedMonths = (pcvhData && pcvhData.actuals && pcvhData.actuals.length > 0)
      ? pcvhData.actuals.filter(v => v !== null && v !== undefined && !isNaN(v)).length
      : 4;

    const monthlyTarget = parseFloat((annualTarget / 12).toFixed(2));
    const monthlyActual = parseFloat((ytdActual / elapsedMonths).toFixed(2));
    const ytdTarget = parseFloat((annualTarget * (elapsedMonths / 12)).toFixed(2));

    if (mode === 'monthly' || mode === 'ftm') {
      return {
        target: monthlyTarget,
        actual: monthlyActual,
        annualTarget,
        ytdActual: parseFloat(ytdActual.toFixed(2)),
        ytdTarget
      };
    } else {
      return {
        target: ytdTarget,
        actual: parseFloat(ytdActual.toFixed(2)),
        annualTarget,
        ytdActual: parseFloat(ytdActual.toFixed(2)),
        ytdTarget
      };
    }
  }

  if (kpi.module === 'safety') {
    return getSafetyKpiForMode(kpi, mode);
  }


  if (kpi.module === 'quality') {
    const smd = state.qualityMonthlyData || {};
    const key = kpi.id;
    const kpiData = smd[key];
    if (mode === 'ytd') {
      const target = (kpiData ? getQualityYtdVal(kpiData, true) : null) ?? kpi.target;
      const actual = (kpiData ? getQualityYtdVal(kpiData, false) : null) ?? kpi.actual;
      return { target, actual };
    } else {
      const target = (kpiData ? getQualityMonthVal(kpiData, true) : null) ?? kpi.target;
      const actual = (kpiData ? getQualityMonthVal(kpiData, false) : null) ?? kpi.actual;
      return { target, actual };
    }
  }

  if (kpi.module === 'cost') {
    const smd = state.costMonthlyData || {};
    const key = kpi.id;
    const kpiData = smd[key];
    if (mode === 'ytd') {
      const target = getCostYtdVal(kpiData, true, key) ?? kpi.target;
      const actual = getCostYtdVal(kpiData, false, key) ?? kpi.actual;
      return { target, actual };
    } else {
      const target = getCostMonthVal(kpiData, true) ?? kpi.target;
      const actual = getCostMonthVal(kpiData, false) ?? kpi.actual;
      return { target, actual };
    }
  }

  if (kpi.module === 'delivery') {
    const key = kpi.id;

    // Prioritize active dataset values if available on KPI object
    if (mode === 'ytd') {
      if (kpi.ytdTarget !== undefined && kpi.ytdTarget !== null && kpi.ytdActual !== undefined && kpi.ytdActual !== null) {
        return { target: kpi.ytdTarget, actual: kpi.ytdActual };
      }
    } else {
      if (kpi.ftmTarget !== undefined && kpi.ftmTarget !== null && kpi.ftmActual !== undefined && kpi.ftmActual !== null) {
        return { target: kpi.ftmTarget, actual: kpi.ftmActual };
      }
    }

    if (key === 'prod_tot') {
      const l2 = getKpiForMode(state.kpis.find(k => k.id === 'prod_l2') || { id: 'prod_l2', module: 'delivery', target: 1404, actual: 1422 }, mode);
      const l3 = getKpiForMode(state.kpis.find(k => k.id === 'prod_l3') || { id: 'prod_l3', module: 'delivery', target: 644, actual: 525 }, mode);
      return { target: l2.target + l3.target, actual: l2.actual + l3.actual };
    }

    if (key === 'disp_tot') {
      const dispSubIds = ['disp_tmbsl', 'disp_acgl', 'disp_imac', 'disp_jcbl', 'disp_otherbb', 'disp_direct', 'disp_ev'];
      let targetSum = 0;
      let actualSum = 0;
      dispSubIds.forEach(subId => {
        const subKpi = state.kpis.find(k => k.id === subId);
        if (subKpi) {
          const v = getKpiForMode(subKpi, mode);
          targetSum += v.target;
          actualSum += v.actual;
        }
      });
      return { target: targetSum, actual: actualSum };
    }

    if (key === 'bus_tot') {
      const busSubIds = ['bus_4spcr_nac', 'bus_4spcr_ac', 'bus_maxicab_nac', 'bus_cx2_nac', 'bus_10_2_4sp', 'bus_3_3l_nac', 'bus_3_3l_ac', 'bus_ib912_bs3', 'bus_ib712_bs3', 'bus_ib712_bs4'];
      let targetSum = 0;
      let actualSum = 0;
      busSubIds.forEach(subId => {
        const subKpi = state.kpis.find(k => k.id === subId);
        if (subKpi) {
          const v = getKpiForMode(subKpi, mode);
          targetSum += v.target;
          actualSum += v.actual;
        }
      });
      return { target: targetSum, actual: actualSum };
    }

    if (kpi.target !== undefined && kpi.target !== null && kpi.actual !== undefined && kpi.actual !== null) {
      return { target: kpi.target, actual: kpi.actual };
    }

    const smd = state.deliveryMonthlyData || {};
    const kpiData = smd[key] || smd[key.replace('prod_l2', 'line2').replace('prod_l3', 'line3')];
    if (kpiData) {
      const isSumMetric = (
        key.startsWith('prod_') ||
        key.startsWith('disp_') ||
        key.startsWith('bus_') ||
        key === 'line2' || key === 'line3'
      );

      if (mode === 'ytd') {
        let target = kpiData.ytdTarget;
        let actual = kpiData.ytdActual;

        if (kpiData.fyData) {
          if (target === undefined || target === null) target = kpiData.fyData.ytdTarget;
          if (actual === undefined || actual === null) actual = kpiData.fyData.ytd ?? kpiData.fyData.ytdActual;
        }

        if (target === undefined || target === null) {
          const validTargets = kpiData.targets ? kpiData.targets.filter(v => v !== null && v !== undefined && !isNaN(v)) : [];
          if (validTargets.length > 0) {
            target = isSumMetric ? validTargets.reduce((a, b) => a + b, 0) : (validTargets.reduce((a, b) => a + b, 0) / validTargets.length);
          }
        }

        if (actual === undefined || actual === null) {
          const validActuals = kpiData.actuals ? kpiData.actuals.filter(v => v !== null && v !== undefined && !isNaN(v)) : [];
          if (validActuals.length > 0) {
            actual = isSumMetric ? validActuals.reduce((a, b) => a + b, 0) : (validActuals.reduce((a, b) => a + b, 0) / validActuals.length);
          }
        }

        if (!isSumMetric) {
          if (typeof target === 'number') target = parseFloat(target.toFixed(1));
          if (typeof actual === 'number') actual = parseFloat(actual.toFixed(1));
        }

        return { target: target ?? kpi.target, actual: actual ?? kpi.actual };
      } else {
        // Monthly (FTM / Previous month) mode
        const getLatestVal = (arr) => {
          if (!arr || !arr.length) return null;
          for (let i = arr.length - 1; i >= 0; i--) {
            if (arr[i] !== null && arr[i] !== undefined && !isNaN(arr[i])) return arr[i];
          }
          return null;
        };

        let target = getLatestVal(kpiData.targets);
        let actual = getLatestVal(kpiData.actuals);

        return { target: target ?? kpi.target, actual: actual ?? kpi.actual };
      }
    }
  }

  if (mode === 'ytd') {
    const target = getGenericYtdVal(kpi, true);
    const actual = getGenericYtdVal(kpi, false);
    return { target: target ?? kpi.target, actual: actual ?? kpi.actual };
  }

  // Monthly mode
  const smd = state[`${kpi.module}MonthlyData`] || {};
  let target = kpi.target;
  let actual = kpi.actual;

  const getLatestReportedVal = (arr) => {
    if (!arr || arr.length === 0) return null;
    for (let i = arr.length - 1; i >= 0; i--) {
      const val = arr[i];
      if (val !== null && val !== undefined && !isNaN(val)) return val;
    }
    return null;
  };

  const getMetricFromArray = (kpiData) => {
    if (!kpiData) return null;
    const t = kpiData.targets ? getLatestReportedVal(kpiData.targets) : null;
    const a = kpiData.actuals ? getLatestReportedVal(kpiData.actuals) : (Array.isArray(kpiData) ? getLatestReportedVal(kpiData) : null);
    return { target: t, actual: a };
  };

  let res = null;
  const idsToTry = [
    kpi.id,
    kpi.id.replace(/_/g, ''),
    kpi.id.replace('_l1', '').replace('_l2', '').replace('_l3', ''),
    kpi.id.replace('_l1', '').replace('_l2', '').replace('_l3', '').replace(/_/g, '')
  ];

  if (kpi.id === 'fuel_unit') idsToTry.push('fuel');
  if (kpi.id === 'power_kwh') idsToTry.push('power');
  if (kpi.id === 'env_water_ratio') idsToTry.push('water');

  for (const id of idsToTry) {
    if (smd[id]) {
      res = getMetricFromArray(smd[id]);
      break;
    }
  }

  if (res) {
    if (res.target !== null) target = res.target;
    if (res.actual !== null) actual = res.actual;
  }

  if (target === 0 && kpi.target !== 0) {
    target = kpi.target;
  }

  target = (target === null || target === undefined || isNaN(target)) ? (kpi.target || 0) : target;
  actual = (actual === null || actual === undefined || isNaN(actual)) ? (kpi.actual || 0) : actual;

  return { target, actual };
}

export function getAchievement(kpi, mode) {
  let target = kpi.target;
  let actual = kpi.actual;
  const { id, module } = kpi;

  if (mode) {
    const valObj = getKpiForMode(kpi, mode);
    target = valObj.target;
    actual = valObj.actual;
  }

  target = (target === null || target === undefined || isNaN(target)) ? (kpi.target || 0) : Number(target);
  actual = (actual === null || actual === undefined || isNaN(actual)) ? (kpi.actual || 0) : Number(actual);

  if (actual === target) return 100;

  if (isLowerBetter(kpi)) {
    if (target === 0) {
      return actual === 0 ? 100 : 0;
    }

    if (actual <= target) return 100;

    if (module === 'inventory' || id === 'ofe') {
      if (actual === 0) return 100;
      const res = parseFloat(((target / actual) * 100).toFixed(1));
      return isNaN(res) ? 0 : Math.min(100, Math.max(0, res));
    }

    const overflowPct = ((actual - target) / target) * 100;
    const res = Math.max(0, parseFloat((100 - overflowPct).toFixed(1)));
    return isNaN(res) ? 0 : Math.min(100, res);
  }

  if (target === 0) return actual === 0 ? 100 : 0;
  const achievement = (actual / target) * 100;
  const res = Math.min(100, Math.max(0, parseFloat(achievement.toFixed(1))));
  return isNaN(res) ? 0 : res;
}

export function getStatus(kpi, mode) {
  let target = kpi.target;
  let actual = kpi.actual;
  const { id, module } = kpi;

  if (mode) {
    const valObj = getKpiForMode(kpi, mode);
    target = valObj.target;
    actual = valObj.actual;
  }

  const tgtNum = (target === null || target === undefined || isNaN(target)) ? 0 : Number(target);
  const actNum = (actual === null || actual === undefined || isNaN(actual)) ? 0 : Number(actual);

  if (actNum === tgtNum) {
    return 'Green';
  }

  if (isLowerBetter(kpi)) {
    return actNum <= tgtNum ? 'Green' : 'Red';
  }

  const ach = getAchievement(kpi, mode);

  if (id === 'smt_coverage' && actNum < tgtNum) {
    return 'Yellow';
  }
  if (id === 'plant_subcommittee' && ach >= 90 && ach < 100) {
    return 'Yellow';
  }
  if (id === 'phase_2' && ach >= 95) {
    return 'Green';
  }

  if (ach >= 95) return 'Green';
  if (ach >= 80) return 'Yellow';
  return 'Red';
}

// Helper to render a small attractive speedometer-like gauge indicator for table status columns
export function renderMiniGauge(ach, status) {
  const val = Math.min(100, Math.max(0, ach || 0));
  
  // Choose beautiful, professional colors matching the status
  let color = '#10b981'; // Green
  if (status.toLowerCase() === 'yellow') {
    color = '#f59e0b'; // Yellow
  } else if (status.toLowerCase() === 'red') {
    color = '#ef4444'; // Red
  }

  // Semi-circle path length calculation:
  // Radius R = 19. Center of arc is at (25, 24).
  // Arc starts at (6, 24) and ends at (44, 24).
  // Total arc length = PI * R = 3.14159 * 19 = 59.69.
  const arcLength = 59.69;
  const strokeDashoffset = arcLength - (val / 100) * arcLength;

  return `
    <div class="mini-gauge-wrap" style="display: inline-flex; flex-direction: column; align-items: center; justify-content: center; position: relative; width: 64px; height: 38px;">
      <svg width="60" height="34" viewBox="0 0 50 28" style="overflow: visible;">
        <!-- Background Track Arc -->
        <path d="M 6 24 A 19 19 0 0 1 44 24" fill="none" stroke="#f1f5f9" stroke-width="4.5" stroke-linecap="round" />
        <!-- Active colored Gauge Arc -->
        <path d="M 6 24 A 19 19 0 0 1 44 24" fill="none" stroke="${color}" stroke-width="4.5" stroke-linecap="round"
              stroke-dasharray="59.69" stroke-dashoffset="${strokeDashoffset}"
              style="transition: stroke-dashoffset 0.6s ease-in-out;" />
      </svg>
      <!-- Percentage text positioned cleanly in the bottom center -->
      <span style="position: absolute; bottom: 0px; font-size: 10px; font-weight: 800; font-family: 'Outfit', 'Inter', sans-serif; color: #1e293b; line-height: 1;">${val}%</span>
    </div>
  `;
}

// Helper to render measurement direction badge (Lower Better vs Higher Better)
export function renderDirectionBadge(kpi) {
  const lower = isLowerBetter(kpi);
  if (lower) {
    return `<span style="display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 800; background-color: #e0f2fe; color: #0369a1; border: 1px solid #bae6fd; white-space: nowrap;">↓ Lower Better</span>`;
  }
  return `<span style="display: inline-block; padding: 3px 8px; border-radius: 4px; font-size: 11px; font-weight: 800; background-color: #f3e8ff; color: #7e22ce; border: 1px solid #e9d5ff; white-space: nowrap;">↑ Higher Better</span>`;
}



// Calculate the overall score dynamically for the active module
// Helper to identify if a KPI is a nested sub-group/sub-line and should be excluded from summary stats
function isKpiExcludedFromOverall(kpi) {
  const mod = kpi.module;
  const id = kpi.id;

  if (mod === 'safety') {
    return kpi.section === 'meeting_compliance' || kpi.section === 'horizontal_deployment';
  }

  if (mod === 'quality') {
    return (
      id.includes('_l1') ||
      id.includes('_l2') ||
      id.includes('_l3') ||
      id.includes('comp_quality_') ||
      id === 'launch_quality' ||
      id === 'launch_uvpv'
    );
  }

  if (mod === 'productivity') {
    return (
      id === 'lean_mfg' ||
      id === 'automation' ||
      id === 'lotus_3' ||
      id === 'structural_improvements' ||
      id.endsWith('_l2') ||
      id.endsWith('_l3')
    );
  }

  if (mod === 'delivery') {
    return (
      id === 'prod_l2' || id === 'prod_l3' || id === 'prod_dom' || id === 'prod_int' ||
      (id.startsWith('disp_') && id !== 'disp_tot') ||
      (id.startsWith('bus_') && id !== 'bus_tot')
    );
  }

  if (mod === 'cost') {
    return id === 'cost_total';
  }

  return false;
}

export function calculateOverallScore(mode) {
  let totalScore = 0;
  let count = 0;

  const activeKpis = state.kpis.filter(k => k.module === state.currentModule);

  activeKpis.forEach(kpi => {
    if (isKpiExcludedFromOverall(kpi)) return;

    totalScore += getAchievement(kpi, mode);
    count++;
  });

  if (count === 0) return 0;
  
  const avg = totalScore / count;
  return Math.min(100, Math.max(0, Math.round(avg)));
}

// Get the counts of Green, Yellow, and Red KPIs for the active module
export function getKpiStatusCounts(mode) {
  let green = 0;
  let yellow = 0;
  let red = 0;

  const activeKpis = state.kpis.filter(k => k.module === state.currentModule);

  activeKpis.forEach(kpi => {
    if (isKpiExcludedFromOverall(kpi)) return;

    const status = getStatus(kpi, mode);
    if (status === 'Green') green++;
    else if (status === 'Yellow') yellow++;
    else if (status === 'Red') red++;
  });

  return { green, yellow, red };
}

// Dynamically generate strengths for the active module based strictly on live dataset values
export function getStrengths(mode) {
  const strengthsList = [];
  const activeKpis = state.kpis.filter(k => k.module === state.currentModule);

  activeKpis.forEach(kpi => {
    // Exclude nested sub-lines / breakdowns
    if (kpi.id.includes('_l1') || kpi.id.includes('_l2') || kpi.id.includes('_l3')) return;
    if (kpi.id.includes('comp_quality_') || kpi.id === 'launch_quality' || kpi.id === 'launch_uvpv') return;
    if (kpi.id === 'lean_mfg' || kpi.id === 'automation' || kpi.id === 'lotus_3' || kpi.id === 'structural_improvements') return;

    let target = kpi.target;
    let actual = kpi.actual;
    if (mode) {
      const valObj = getKpiForMode(kpi, mode);
      target = valObj.target;
      actual = valObj.actual;
    }

    const status = getStatus(kpi, mode);
    const ach = getAchievement(kpi, mode);
    const lower = isLowerBetter(kpi);

    if (status === 'Green' || ach >= 95) {
      let desc = '';
      if (target === 0) {
        if (actual === 0) {
          desc = `${kpi.name} (Zero Incidents / Defect Free)`;
        } else {
          desc = `${kpi.name} Target Achieved (${actual} ${kpi.unit || ''})`;
        }
      } else if (lower) {
        desc = `${kpi.name} Target Achieved (${actual} ${kpi.unit || ''} vs ${target} target)`;
      } else {
        if (ach >= 100) {
          desc = `${kpi.name} Target Met (100%)`;
        } else {
          desc = `${kpi.name} (${ach}% achieved)`;
        }
      }
      strengthsList.push({ kpi, ach, desc });
    }
  });

  // Sort strengths by achievement score descending
  strengthsList.sort((a, b) => b.ach - a.ach);

  return strengthsList.slice(0, 5).map(s => s.desc);
}

// Dynamically generate Top Focus Areas for the active module based strictly on live data gaps
export function getFocusAreas(mode) {
  const deficits = [];
  const activeKpis = state.kpis.filter(k => k.module === state.currentModule);

  activeKpis.forEach(kpi => {
    // Exclude nested sub-lines / breakdowns
    if (kpi.id.includes('_l1') || kpi.id.includes('_l2') || kpi.id.includes('_l3')) return;
    if (kpi.id.includes('comp_quality_') || kpi.id === 'launch_quality' || kpi.id === 'launch_uvpv') return;
    if (kpi.id === 'lean_mfg' || kpi.id === 'automation' || kpi.id === 'lotus_3' || kpi.id === 'structural_improvements') return;

    let target = kpi.target;
    let actual = kpi.actual;
    if (mode) {
      const valObj = getKpiForMode(kpi, mode);
      target = valObj.target;
      actual = valObj.actual;
    }

    const status = getStatus(kpi, mode);
    const ach = getAchievement(kpi, mode);
    const lower = isLowerBetter(kpi);

    if (status === 'Red' || status === 'Yellow' || ach < 95) {
      let gap = 0;
      let desc = '';

      if (target === 0) {
        if (actual > 0) {
          gap = actual * 20;
          desc = `Reduce ${kpi.name} (${actual} ${kpi.unit || ''} recorded, target is 0)`;
        }
      } else if (lower) {
        if (actual > target) {
          gap = ((actual - target) / target) * 100;
          desc = `Reduce ${kpi.name} (${actual} ${kpi.unit || ''} vs ${target} target)`;
        } else {
          gap = 100 - ach;
          desc = `Improve ${kpi.name} (${actual} ${kpi.unit || ''} vs ${target} target)`;
        }
      } else {
        gap = 100 - ach;
        desc = `Improve ${kpi.name} (${ach}% achieved, ${actual} / ${target} ${kpi.unit || ''})`;
      }

      if (gap > 0 || status === 'Red' || status === 'Yellow') {
        deficits.push({ kpi, gap: Math.max(gap, status === 'Red' ? 50 : 20), desc });
      }
    }
  });

  // Sort by gap descending (largest gap / deficit first)
  deficits.sort((a, b) => b.gap - a.gap);

  return deficits.slice(0, 4).map(d => d.desc);
}

// Reset state
export function resetState() {
  if (state.baseKpis) {
    state.kpis = JSON.parse(JSON.stringify(state.baseKpis));
  } else {
    state.kpis = JSON.parse(JSON.stringify(INITIAL_KPIS));
  }

  state.history = JSON.parse(JSON.stringify(INITIAL_HISTORY));
  state.filters = { ...INITIAL_FILTERS };
  state.hasTml = true;

  if (state.baseSafetyMonthlyData) {
    state.safetyMonthlyData = JSON.parse(JSON.stringify(state.baseSafetyMonthlyData));
  } else {
    state.safetyMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      fac: [3, 5, 2, 2],
      lta: [0, 0, 0, 0],
      mtc: [0, 0, 0, 0],
      rwc: [0, 0, 0, 0],
      psi1: [85, 88, 90, 92],
      psi2: [90, 92, 95, 98],
      trcfr: [0.26, 0, 2.89, 8.17]
    };
  }

  if (state.baseProductivityMonthlyData) {
    state.productivityMonthlyData = JSON.parse(JSON.stringify(state.baseProductivityMonthlyData));
  } else {
    state.productivityMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      hpev3: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [47, 46.33, 45.67, 45],
        actuals: [48.15, 46.08, 48.11, 42.34]
      },
      hpev4: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [59.6, 59.1, 62.4, 61.9],
        actuals: [67.06, 62.75, 63.3, 57.37]
      },
      cpev: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [30710, 30710, 30710, 30710],
        actuals: [31681, 27959, 25785, 28432]
      }
    };
  }

  if (state.baseDeliveryMonthlyData) {
    state.deliveryMonthlyData = JSON.parse(JSON.stringify(state.baseDeliveryMonthlyData));
  }

  if (state.baseCostMonthlyData) {
    state.costMonthlyData = JSON.parse(JSON.stringify(state.baseCostMonthlyData));
  } else {
    state.costMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      dmc: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [1.6, 6.0, 4.5, 5.0],
        actuals: [1.74, 8.8, 4.5, 4.5]
      },
      repro: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [1.0, 1.0, 1.0, 1.0],
        actuals: [2.88, 0.47, 0.8, 0.8]
      },
      vcc: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [24246.0, 24246.85, 23959.82, 23959.82],
        actuals: [24246.0, 23169.0, 23250.91, 23250.91]
      }
    };
  }

  if (state.baseHrMonthlyData) {
    state.hrMonthlyData = JSON.parse(JSON.stringify(state.baseHrMonthlyData));
  } else {
    state.hrMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      csr: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [1910, 2040, 6800, 7150],
        actuals: [2322, 2350, 7240, 9096]
      },
      ivdp: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [0, 0, 0, 1000],
        actuals: [0, 0, 0, 1200]
      },
      environment: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [100, 100, 900, 1000],
        actuals: [300, 300, 1000, 2400]
      },
      health: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [1670, 1800, 2500, 2500],
        actuals: [1872, 1900, 2820, 2858]
      },
      education: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [0, 0, 3200, 3400],
        actuals: [0, 0, 3200, 3500]
      },
      employability: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [140, 140, 200, 250],
        actuals: [150, 150, 220, 338]
      }
    };
  }

  if (state.baseQualityMonthlyData) {
    state.qualityMonthlyData = JSON.parse(JSON.stringify(state.baseQualityMonthlyData));
  } else {
    state.qualityMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      vc_charter: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [90, 90, 90, 90],
        actuals: [82, 82, 82, 82],
        fyData: { fy24: 0, fy25: 0, fy26: 0 }
      },
      product_charter: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [90, 90, 95, 90],
        actuals: [86, 79, 79, 79],
        fyData: { fy24: 0, fy25: 0, fy26: 0 }
      },
      comp_quality_iptv: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [347, 288, 235, 232],
        actuals: [215, 200, 210, 197],
        fyData: { fy24: 0, fy25: 282, fy26: 243 }
      },
      comp_quality_epv: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [6113, 5996, 5021, 4632],
        actuals: [6291, 5157, 4376, 4361],
        fyData: { fy24: 0, fy25: 0, fy26: 0 }
      },
      comp_quality_visits: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [0.85, 0.84, 0.81, 0.8],
        actuals: [0.83, 0.83, 0.69, 0.69],
        fyData: { fy24: 0, fy25: 0, fy26: 0.2 }
      },
      comp_quality_notouch: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [82, 82, 82, 82],
        actuals: [81.2, 81.2, 83.0, 79.9],
        fyData: { fy24: 0, fy25: 0, fy26: 82 }
      },
      launch_quality: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [100, 100, 100, 100],
        actuals: [100, 100, 100, 100],
        fyData: { fy24: 0, fy25: 0, fy26: 50 }
      },
      launch_uvpv: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [0.44, 0.43, 0.42, 0.42],
        actuals: [0.44, 0.43, 0.42, 0.42],
        fyData: { fy24: 0, fy25: 0.85, fy26: 0 }
      },
      layer_audit: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [100, 100, 100, 100],
        actuals: [100, 100, 100, 93.71],
        fyData: { fy24: 100, fy25: 100, fy26: 100 }
      },
      cimple_project: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [30, 30, 30, 30],
        actuals: [0, 0, 3, 15],
        fyData: { fy24: 0, fy25: 0, fy26: 0 }
      },
      warranty: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [5.5, 5.5, 5.5, 5.5],
        actuals: [5.0, 4.0, 3.5, 2.4]
      },
      cpa: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [80, 80, 80, 80],
        actuals: [66, 68, 71, 75]
      },
      drr_1_l1: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [90, 90, 90, 90], actuals: [86.05, 85.46, 84.58, 83], ytdTarget: 90, ytdActual: 84.77, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 84.77 } },
      drr_1_l2: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [90, 90, 90, 90], actuals: [85.86, 84.77, 87.01, 85], ytdTarget: 90, ytdActual: 85.66, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 85.66 } },
      drr_1_l3: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [90, 90, 90, 90], actuals: [87.41, 89.17, 78.04, 78], ytdTarget: 90, ytdActual: 83.16, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 83.16 } },
      drr_1: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [90, 90, 90, 90], actuals: [86.05, 85.46, 84.58, 83], ytdTarget: 90, ytdActual: 84.77, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 84.77 } },
      drr_2_l1: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [100, 100, 100, 100], actuals: [100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
      drr_2_l2: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [100, 100, 100, 100], actuals: [100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
      drr_2_l3: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [100, 100, 100, 100], actuals: [100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
      drr_2: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [100, 100, 100, 100], actuals: [100, 100, 100, 100], ytdTarget: 100, ytdActual: 100, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 100 } },
      drr_4_l1: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [82, 82, 82, 82], actuals: [93.59, 94.76, 96.41, 96], ytdTarget: 82, ytdActual: 95.19, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 95.19 } },
      drr_4_l2: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [82, 82, 82, 82], actuals: [92.99, 93.80, 95.26, 95], ytdTarget: 82, ytdActual: 94.26, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 94.26 } },
      drr_4_l3: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [82, 82, 82, 82], actuals: [99.30, 99.68, 99.31, 97], ytdTarget: 82, ytdActual: 98.82, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 98.82 } },
      drr_4: { months: ["Apr'26", "May'26", "June'26", "July'26"], targets: [82, 82, 82, 82], actuals: [93.59, 94.76, 96.41, 96], ytdTarget: 82, ytdActual: 95.19, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 95.19 } }
    };
  }

  if (state.baseEnvironmentMonthlyData) {
    state.environmentMonthlyData = JSON.parse(JSON.stringify(state.baseEnvironmentMonthlyData));
  } else {
    state.environmentMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      power: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [238, 232, 222, 365],
        actuals: [193, 155, 145, 175]
      },
      fuel: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [5.25, 5.2, 5.25, 5.19],
        actuals: [2.7, 2.6, 2.1, 2.1]
      },
      ghg: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [5.13, 4.85, 10.35, 10.26],
        actuals: [4.56, 5.0, 9.48, 9.2]
      },
      water: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [1.75, 1.76, 1.84, 1.9],
        actuals: [1.8, 1.79, 1.84, 1.93]
      }
    };
  }

  if (state.baseInventoryMonthlyData) {
    state.inventoryMonthlyData = JSON.parse(JSON.stringify(state.baseInventoryMonthlyData));
  } else {
    state.inventoryMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      opsDays: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [9, 9, 9, 9],
        actuals: [18, 17, 17, 17],
        fyData: { fy24: 0, fy25: 16, fy26: 12, ytd: 17 }
      },
      invWo: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [113, 121, 150, 194],
        actuals: [137.24, 160.66, 169.61, 169.61],
        fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 169.61 }
      },
      invWith: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [123, 131, 150, 204],
        actuals: [137.24, 160.66, 170, 170],
        fyData: { fy24: 0, fy25: 98, fy26: 121, ytd: 170.0 }
      },
      tml: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [113, 121, 124, 139],
        actuals: [137, 160, 135, 165],
        fyData: { fy24: 0, fy25: 0, fy26: 94, ytd: 165 }
      },
      tmbsl: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [27, 29, 26, 26],
        actuals: [35, 37, 35, 39],
        fyData: { fy24: 0, fy25: 0, fy26: 27, ytd: 39 }
      },
      gt180: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [35, 35, 35, 35],
        actuals: [31, 33, 35, 35]
      },
      gt90: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [40, 40, 40, 40],
        actuals: [38, 44, 46, 46]
      },
      mach: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [4, 4, 4, 4],
        actuals: [3.83, 3.71, 3.58, 3.58]
      },
      tools: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [1.5, 1.5, 1.5, 1.5],
        actuals: [2.78, 2.78, 1.78, 1.78]
      },
      invOverall: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [140, 150, 150, 165],
        actuals: [173, 191, 175, 204]
      },
      invNoOfDays: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [11, 11, 11, 11],
        actuals: [18, 19, 19, 22]
      }
    };
  }

  if (state.baseDigitalMonthlyData) {
    state.digitalMonthlyData = JSON.parse(JSON.stringify(state.baseDigitalMonthlyData));
  } else {
    state.digitalMonthlyData = {
      labels: ["Apr'26", "May'26", "June'26", "July'26"],
      budgetRfq: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [10, 25, 50, 75],
        actuals: [0, 13, 13, 13]
      },
      qualixIqms: {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [0, 2, 2, 2],
        actuals: [0, 2, 2, 2]
      }
    };
  }

  if (state.baseFicWiseInjuries) {
    state.ficWiseInjuries = JSON.parse(JSON.stringify(state.baseFicWiseInjuries));
  } else {
    state.ficWiseInjuries = [
      { name: 'Vehicle Factory', fac: 3, mtc: 0, rwc: 0, lti: 0 },
      { name: 'Technical Services', fac: 0, mtc: 0, rwc: 0, lti: 0 },
      { name: 'Office', fac: 0, mtc: 0, rwc: 0, lti: 0 },
      { name: 'Materials', fac: 0, mtc: 0, rwc: 0, lti: 0 },
      { name: 'Quality', fac: 0, mtc: 0, rwc: 0, lti: 0 },
      { name: 'FRM, BIW, APS & CM', fac: 1, mtc: 0, rwc: 0, lti: 0 },
      { name: 'TOTAL', fac: 4, mtc: 0, rwc: 0, lti: 0 }
    ];
  }

  if (state.baseFicWiseInjuriesYtd) {
    state.ficWiseInjuriesYtd = JSON.parse(JSON.stringify(state.baseFicWiseInjuriesYtd));
  } else {
    state.ficWiseInjuriesYtd = [
      { name: 'Vehicle Factory', fac: 8, mtc: 0, rwc: 1, lti: 0 },
      { name: 'Technical Services', fac: 1, mtc: 0, rwc: 0, lti: 0 },
      { name: 'Office', fac: 3, mtc: 0, rwc: 0, lti: 3 },
      { name: 'Materials', fac: 3, mtc: 0, rwc: 0, lti: 0 },
      { name: 'Quality', fac: 0, mtc: 0, rwc: 0, lti: 0 },
      { name: 'FRM, BIW, APS & CM', fac: 2, mtc: 0, rwc: 0, lti: 0 },
      { name: 'TOTAL', fac: 17, mtc: 0, rwc: 1, lti: 3 }
    ];
  }

  if (state.baseCostOfeBreakdown) {
    state.costOfeBreakdown = JSON.parse(JSON.stringify(state.baseCostOfeBreakdown));
  } else {
    state.costOfeBreakdown = [
      { name: 'Admin and EW', mtdTarget: 0.434, mtdSc: 0.412, mtdActual: 0.322, ytdTarget: 1.578, ytdSc: 1.157, ytdActual: 1.002 },
      { name: 'Civil R&M', mtdTarget: 0.171, mtdSc: 0.162, mtdActual: 0.126, ytdTarget: 0.558, ytdSc: 0.459, ytdActual: 0.469 },
      { name: 'Maintenance and Services', mtdTarget: 0.450, mtdSc: 0.427, mtdActual: 0.420, ytdTarget: 1.500, ytdSc: 1.418, ytdActual: 1.394 },
      { name: 'Prodn Related Contracts Exc Inhouse', mtdTarget: 0.449, mtdSc: 0.427, mtdActual: 0.440, ytdTarget: 1.527, ytdSc: 1.415, ytdActual: 1.409 },
      { name: 'Sustainability', mtdTarget: 0.028, mtdSc: 0.027, mtdActual: 0.006, ytdTarget: 0.113, ytdSc: 0.112, ytdActual: 0.009 },
      { name: 'CLT - OFC', mtdTarget: 1.533, mtdSc: 1.456, mtdActual: 1.315, ytdTarget: 5.277, ytdSc: 4.560, ytdActual: 4.283 },
      { name: 'Insurance', mtdTarget: 0.210, mtdSc: 0.199, mtdActual: 0.117, ytdTarget: 0.628, ytdSc: 0.588, ytdActual: 0.452 },
      { name: 'Treasury Exps', mtdTarget: 0.061, mtdSc: 0.058, mtdActual: 0.057, ytdTarget: 0.245, ytdSc: 0.242, ytdActual: 0.273 },
      { name: 'Insurance & Treasury', mtdTarget: 0.271, mtdSc: 0.257, mtdActual: 0.174, ytdTarget: 0.874, ytdSc: 0.830, ytdActual: 0.725 },
      { name: 'OFE excl IT', mtdTarget: 1.804, mtdSc: 1.713, mtdActual: 1.489, ytdTarget: 6.150, ytdSc: 5.390, ytdActual: 5.008 },
      { name: 'IT', mtdTarget: 0.763, mtdSc: 0.725, mtdActual: 0.632, ytdTarget: 2.476, ytdSc: 2.048, ytdActual: 2.753 },
      { name: 'Total OFC', mtdTarget: 2.567, mtdSc: 2.438, mtdActual: 2.120, ytdTarget: 8.627, ytdSc: 7.439, ytdActual: 7.761 }
    ];
  }

  if (state.baseCostVccBreakdown) {
    state.costVccBreakdown = JSON.parse(JSON.stringify(state.baseCostVccBreakdown));
  } else {
    state.costVccBreakdown = [
    { name: "Eq No", group: "", apr: { tc: 2341.6973393333324, sc: 2341.6973393333324, act: 1553 }, may: { tc: 2582.739365333334, sc: 2582.739365333334, act: 2053 }, jun: { tc: 2955.300458666668, sc: 2955.300458666668, act: 2230 }, jul: { tc: 2662.7936543333335, sc: 2662.7936543333335, act: 2103 }, ytdJuly27: { tc: 10542.53081766667, sc: 10542.53081766667, act: 7939 }, ytdMar27: { savingTc: 0, savingSc: 0 } },
    { name: "Rs/Eq Veh", group: "", apr: { tc: 0, sc: 0, act: 0 }, may: { tc: 0, sc: 0, act: 0 }, jun: { tc: 0, sc: 0, act: 0 }, jul: { tc: 0, sc: 0, act: 0 }, ytdJuly27: { tc: 0, sc: 0, act: 0 }, ytdMar27: { savingTc: 0, savingSc: 0 } },
    { name: "Power", group: "Utilities", apr: { tc: 2476.3601394529696, sc: 2352.542132480321, act: 1927.4196973599483 }, may: { tc: 2377.3060088690318, sc: 2258.44070842558, act: 2258.4407062834875 }, jun: { tc: 2241.96534037257, sc: 2129.8670733539416, act: 1777.895542600897 }, jul: { tc: 3757.245609320233, sc: 3569.3833288542214, act: 1958.9195102234903 }, ytdJuly27: { tc: 2709.9089603276398, sc: 2574.413512311258, act: 1979.3646995843305 }, ytdMar27: { savingTc: 730.5442607433092, savingSc: 595.0488127269273 } },
    { name: "Fuel", group: "Utilities", apr: { tc: 500, sc: 475, act: 319.1794204764971 }, may: { tc: 500, sc: 475, act: 364.7797467121285 }, jun: { tc: 500, sc: 475, act: 296.7116547085202 }, jul: { tc: 500, sc: 475, act: 321.0763005230623 }, ytdJuly27: { tc: 499.99999999999994, sc: 474.9999999999999, act: 325.16298148381406 }, ytdMar27: { savingTc: 174.83701851618588, savingSc: 149.83701851618582 } },
    { name: "IDM", group: "VIC & MS", apr: { tc: 710, sc: 674.5, act: 696.9254217643271 }, may: { tc: 720, sc: 684, act: 659.244242571846 }, jun: { tc: 720, sc: 684, act: 678.6129955156953 }, jul: { tc: 720, sc: 684, act: 719.9597432239658 }, ytdJuly27: { tc: 717.7788091115567, sc: 681.8898686559788, act: 688.1390515178235 }, ytdMar27: { savingTc: 29.63975759373318, savingSc: -6.249182861844702 } },
    { name: "Tools", group: "VIC & MS", apr: { tc: 90, sc: 85.5, act: 74.44858338699294 }, may: { tc: 95, sc: 90.25, act: 80.14953726254262 }, jun: { tc: 95, sc: 90.25, act: 81.29577130044844 }, jul: { tc: 95, sc: 90.25, act: 86.97739895387542 }, ytdJuly27: { tc: 93.88940455577836, sc: 89.19493432798944, act: 81.16496913969014 }, ytdMar27: { savingTc: 12.724435416088212, savingSc: 8.0299651882993 } },
    { name: "PTP", group: "VIC & MS", apr: { tc: 0, sc: 0, act: 0 }, may: { tc: 0, sc: 0, act: 0 }, jun: { tc: 0, sc: 0, act: 0 }, jul: { tc: 0, sc: 0, act: 0 }, ytdJuly27: { tc: 0, sc: 0, act: 0 }, ytdMar27: { savingTc: 0, savingSc: 0 } },
    { name: "Spares", group: "VIC & MS", apr: { tc: 2000, sc: 1900, act: 1992.9394526722474 }, may: { tc: 2100, sc: 1995, act: 1859.617749634681 }, jun: { tc: 2080, sc: 1976, act: 1951.206215246637 }, jul: { tc: 2300, sc: 2185, act: 1868.3720066571564 }, ytdJuly27: { tc: 2122.696920872075, sc: 2016.5620748284716, act: 1913.7430910694043 }, ytdMar27: { savingTc: 208.95382980267095, savingSc: 102.81898375906735 } },
    { name: "Freight- VIC", group: "VIC & MS", apr: { tc: 2059, sc: 1956.05, act: 2042.0084030907922 }, may: { tc: 2059, sc: 1956.05, act: 1891.018977106673 }, jun: { tc: 2059, sc: 1956.05, act: 1765.7821704035875 }, jul: { tc: 2059, sc: 1956.05, act: 2158.7351640513552 }, ytdJuly27: { tc: 2059, sc: 1956.05, act: 1956.2936515934 }, ytdMar27: { savingTc: 102.7063484066, savingSc: -0.24365159340004539 } },
    { name: "Freight- Logistics", group: "Logistics", apr: { tc: 14000, sc: 13300, act: 13992.692318094012 }, may: { tc: 14000, sc: 13300, act: 12646.573779834387 }, jun: { tc: 14000, sc: 13300, act: 13308.071103139015 }, jul: { tc: 14000, sc: 13300, act: 14953.585786970993 }, ytdJuly27: { tc: 13999.999999999996, sc: 13299.999999999998, act: 13706.821590880463 }, ytdMar27: { savingTc: 293.17840911953317, savingSc: -406.821590880465 } },
    { name: "Freight", group: "", apr: { tc: 16059, sc: 15256.05, act: 16034.700721184805 }, may: { tc: 16059, sc: 15256.05, act: 14537.59275694106 }, jun: { tc: 16059, sc: 15256.05, act: 15073.853273542602 }, jul: { tc: 16059, sc: 15256.05, act: 17112.320951022346 }, ytdJuly27: { tc: 16058.999999999996, sc: 15256.049999999997, act: 15663.115242473863 }, ytdMar27: { savingTc: 395.8847575261334, savingSc: -407.0652424738655 } },
    { name: "Total", group: "", apr: { tc: 21835.36013945297, sc: 20743.59213248032, act: 21045.613296844815 }, may: { tc: 21851.306008869033, sc: 20758.74070842558, act: 19759.824739405747 }, jun: { tc: 21695.965340372568, sc: 20611.167073353943, act: 19859.5754529148 }, jul: { tc: 23431.245609320235, sc: 22259.68332885422, act: 22067.6259106039 }, ytdJuly27: { tc: 22203.274094867047, sc: 21093.110390123697, act: 20650.690035268926 }, ytdMar27: { savingTc: 1552.5840595981208, savingSc: 442.42035485477027 } },
    { name: "Inhouse Contract", group: "Production Contracts", apr: { tc: 1411, sc: 1340.45, act: 1384.818622021893 }, may: { tc: 1853, sc: 1760.35, act: 1758.951646371164 }, jun: { tc: 1706, sc: 1620.6999999999998, act: 1410.3787847533633 }, jul: { tc: 1303, sc: 1237.85, act: 1277.5215359010938 }, ytdJuly27: { tc: 1630.125113159064, sc: 1548.6188575011108, act: 1460.3254225973044 }, ytdMar27: { savingTc: 169.7996905617597, savingSc: 88.29343490380643 } },
    { name: "Warehouse expenses", group: "Production Contracts", apr: { tc: 1818.8940776709796, sc: 1727.9493737874307, act: 1815.3696587250486 }, may: { tc: 1818.8940776709794, sc: 1727.9493737874304, act: 1652.0781100828056 }, jun: { tc: 1818.8940776709794, sc: 1727.9493737874304, act: 1989.0322017937217 }, jul: { tc: 1818.8940776709794, sc: 1727.9493737874304, act: 2130.842605801236 }, ytdJuly27: { tc: 1818.8940776709787, sc: 1727.9493737874297, act: 1905.4905214762566 }, ytdMar27: { savingTc: -86.59644380527789, savingSc: -177.54114768882687 } },
    { name: "Total", group: "", apr: { tc: 3229.8940776709796, sc: 3068.3993737874307, act: 3200.1882807469415 }, may: { tc: 3671.8940776709796, sc: 3488.2993737874303, act: 3411.0297564539696 }, jun: { tc: 3524.8940776709796, sc: 3348.6493737874302, act: 3399.410986547085 }, jul: { tc: 3121.8940776709796, sc: 2965.7993737874303, act: 3408.36414170233 }, ytdJuly27: { tc: 3449.019190830043, sc: 3276.5682312885406, act: 3365.815944073561 }, ytdMar27: { savingTc: 83.20324675648226, savingSc: -89.24771278502021 } },
    { name: "Grand Total", group: "", apr: { tc: 25065.254217123947, sc: 23811.99150626775, act: 24245.801577591756 }, may: { tc: 25523.20008654001, sc: 24247.04008221301, act: 23170.854495859716 }, jun: { tc: 25220.859418043547, sc: 23959.816447141373, act: 23258.986439461885 }, jul: { tc: 26553.139686991213, sc: 25225.48270264165, act: 25475.99005230623 }, ytdJuly27: { tc: 25652.29328569709, sc: 24369.678621412237, act: 24016.505979342488 }, ytdMar27: { savingTc: 1635.787306354603, savingSc: 353.1726420697487 } }
    ];
  }

  if (state.baseCostPlantBreakdown) {
    state.costPlantBreakdown = JSON.parse(JSON.stringify(state.baseCostPlantBreakdown));
  } else {
    state.costPlantBreakdown = [
      { name: "Repairs & Renovation & Maintenance", mtdTarget: 76.65193248, mtdSc: 72.81933586, mtdActual: 69.4291765, ytdTarget: 971.0, ytdSc: 944.50221013, ytdActual: 222.8132904, ytdSavingTc: 748.1867096, ytdSavingSc: 721.68891973, mtdSavingTc: 7.22275598, mtdSavingSc: 3.39015936 },
      { name: "Employee Welfare,Recruitment etc", mtdTarget: 1.69, mtdSc: 1.6055, mtdActual: 2.1752, ytdTarget: 17.74, ytdSc: 17.5375, ytdActual: 5.7564738, ytdSavingTc: 11.9835262, ytdSavingSc: 11.7810262, mtdSavingTc: -0.4852, mtdSavingSc: -0.5697 },
      { name: "Municipal Chgs & Water Chgs", mtdTarget: 0.05, mtdSc: 0.0475, mtdActual: 0.353, ytdTarget: 11.999999999999998, ytdSc: 11.992499999999998, ytdActual: 0.365, ytdSavingTc: 11.635, ytdSavingSc: 11.6275, mtdSavingTc: -0.303, mtdSavingSc: -0.3055 },
      { name: "Others", mtdTarget: 9.0, mtdSc: 8.55, mtdActual: 3.19408, ytdTarget: 118.73, ytdSc: 111.2465, ytdActual: 23.6261638, ytdSavingTc: 95.1038362, ytdSavingSc: 87.6203362, mtdSavingTc: 5.80592, mtdSavingSc: 5.35592 },
      { name: "TOTAL  Controllable", mtdTarget: 153.27158852, mtdSc: 145.6080091, mtdActual: 131.4877019, ytdTarget: 527.65735409, ytdSc: 455.99377466, ytdActual: 428.3486059, ytdSavingTc: 99.30874819, ytdSavingSc: 27.64516876, mtdSavingTc: 21.78388662, mtdSavingSc: 14.1203072 },
      { name: "Treasury Exps", mtdTarget: 6.1373994, mtdSc: 5.83052943, mtdActual: 5.717505, ytdTarget: 24.5495976, ytdSc: 24.24272763, ytdActual: 27.2600948, ytdSavingTc: -2.7104972, ytdSavingSc: -3.01736717, mtdSavingTc: 0.4198944, mtdSavingSc: 0.11302443 },
      { name: "Insurance", mtdTarget: 20.9570505, mtdSc: 19.90919798, mtdActual: 11.65505, ytdTarget: 62.828202, ytdSc: 58.78034948, ytdActual: 45.19421, ytdSavingTc: 17.633992, ytdSavingSc: 13.58613947, mtdSavingTc: 9.3020005, mtdSavingSc: 8.25414798 },
      { name: "IT OPEX Exps", mtdTarget: 64.05217553, mtdSc: 60.84956675, mtdActual: 48.4619659, ytdTarget: 214.60870211, ytdSc: 172.40609333, ytdActual: 227.5825519, ytdSavingTc: -12.97384979, ytdSavingSc: -55.17645857, mtdSavingTc: 15.59020963, mtdSavingSc: 12.38760085 },
      { name: "IT DPDS Exps", mtdTarget: 12.26513928, mtdSc: 11.65188231, mtdActual: 14.7022211, ytdTarget: 33.04055711, ytdSc: 32.42730015, ytdActual: 47.6697439, ytdSavingTc: -14.62918679, ytdSavingSc: -15.24244375, mtdSavingTc: -2.43708182, mtdSavingSc: -3.05033879 },
      { name: "TOTAL Non Controllable", mtdTarget: 103.41176471, mtdSc: 98.24117647, mtdActual: 80.536742, ytdTarget: 335.02705882, ytdSc: 287.85647059, ytdActual: 347.7066006, ytdSavingTc: -12.67954178, ytdSavingSc: -59.85013001, mtdSavingTc: 22.87502271, mtdSavingSc: 17.70443447 },
      { name: "Grand Total (Controllable + Non Controllable)", mtdTarget: 256.68335323, mtdSc: 243.84918557, mtdActual: 212.0244439, ytdTarget: 862.68441291, ytdSc: 743.85024525, ytdActual: 776.0552065, ytdSavingTc: 86.62920641, ytdSavingSc: -32.20496125, mtdSavingTc: 44.65890933, mtdSavingSc: 31.82474167 },
      { name: "Grand Total (Controllable + Treasury + Insurance)", mtdTarget: 180.36603842, mtdSc: 171.3477365, mtdActual: 148.8602569, ytdTarget: 615.03515369, ytdSc: 539.01685177, ytdActual: 500.8029107, ytdSavingTc: 114.23224299, ytdSavingSc: 38.21394107, mtdSavingTc: 31.50578152, mtdSavingSc: 22.4874796 }
    ];
  }
  
  if (state.baseCostCltBreakdown) {
    state.costCltBreakdown = JSON.parse(JSON.stringify(state.baseCostCltBreakdown));
  } else {
    state.costCltBreakdown = [
      { name: "Admin and EW", lead: "Anurag Chharia", mtdTarget: 0.434, mtdSc: 0.412, mtdActual: 0.322, mtdSavingTc: 0.112, mtdSavingSc: 0.090, ytdTarget: 1.578, ytdSc: 1.157, ytdActual: 1.002, ytdSavingTc: 0.576, ytdSavingSc: 0.155 },
      { name: "Maintenance and Services", lead: "Pradosh Mohanty", mtdTarget: 0.450, mtdSc: 0.427, mtdActual: 0.420, mtdSavingTc: 0.030, mtdSavingSc: 0.007, ytdTarget: 1.500, ytdSc: 1.418, ytdActual: 1.394, ytdSavingTc: 0.106, ytdSavingSc: 0.023 },
      { name: "Civil R&M", lead: "Ravi Kulkarni", mtdTarget: 0.171, mtdSc: 0.162, mtdActual: 0.126, mtdSavingTc: 0.045, mtdSavingSc: 0.036, ytdTarget: 0.558, ytdSc: 0.459, ytdActual: 0.469, ytdSavingTc: 0.089, ytdSavingSc: -0.010 },
      { name: "Sustainability", lead: "Ravi Kulkarni", mtdTarget: 0.028, mtdSc: 0.027, mtdActual: 0.006, mtdSavingTc: 0.023, mtdSavingSc: 0.021, ytdTarget: 0.113, ytdSc: 0.112, ytdActual: 0.009, ytdSavingTc: 0.104, ytdSavingSc: 0.103 },
      { name: "Prodn Related Contracts Exc Inhouse", lead: "Sunil Tiwari", mtdTarget: 1.106, mtdSc: 1.051, mtdActual: 1.157, mtdSavingTc: -0.051, mtdSavingSc: -0.107, ytdTarget: 4.225, ytdSc: 3.978, ytdActual: 4.081, ytdSavingTc: 0.144, ytdSavingSc: -0.103 },
      { name: "Utilities", lead: "Mahesh Suguru", mtdTarget: 0.895, mtdSc: 0.851, mtdActual: 0.479, mtdSavingTc: 0.416, mtdSavingSc: 0.371, ytdTarget: 2.560, ytdSc: 2.432, ytdActual: 1.830, ytdSavingTc: 0.730, ytdSavingSc: 0.602 },
      { name: "VIC & MS", lead: "Deepak Kumar", mtdTarget: 1.088, mtdSc: 1.034, mtdActual: 1.017, mtdSavingTc: 0.071, mtdSavingSc: 0.017, ytdTarget: 3.969, ytdSc: 3.770, ytdActual: 3.683, ytdSavingTc: 0.285, ytdSavingSc: 0.087 },
      { name: "Logistics", lead: "Umesh Tambolkar", mtdTarget: 2.944, mtdSc: 2.797, mtdActual: 3.145, mtdSavingTc: -0.201, mtdSavingSc: -0.348, ytdTarget: 11.115, ytdSc: 10.559, ytdActual: 10.882, ytdSavingTc: 0.233, ytdSavingSc: -0.323 },
      { name: "Total", lead: "", mtdTarget: 7.117, mtdSc: 6.761, mtdActual: 6.672, mtdSavingTc: 0.444, mtdSavingSc: 0.089, ytdTarget: 25.617, ytdSc: 23.884, ytdActual: 23.350, ytdSavingTc: 2.267, ytdSavingSc: 0.534 },
      { name: "Savings (Target vs Actual)", lead: "", mtdTarget: 0, mtdSc: 0.444, mtdActual: 0.089, mtdSavingTc: 0, mtdSavingSc: 0, ytdTarget: 0, ytdSc: 1.734, ytdActual: 2.267, ytdSavingTc: 0, ytdSavingSc: 0 }
    ];
  }
}

/**
 * Normalize history log objects from local storage or backend SQLite
 */
export function normalizeLog(item) {
  if (!item) return null;
  const fileName = item.file_name || item.fileName || '';
  const title = item.title || (fileName ? `Dataset: ${fileName}` : 'Uploaded Dataset');
  const timestamp = item.timestamp || item.upload_timestamp || new Date().toLocaleString();
  const moduleName = item.module || 'overall';
  const id = String(item.id || item.upload_id || Date.now());
  const reportingPeriod = item.reporting_period || 'Active Dataset';
  const validRows = item.valid_rows || item.total_rows || 0;

  return {
    ...item,
    id,
    title,
    file_name: fileName || title,
    timestamp,
    upload_timestamp: timestamp,
    module: moduleName,
    reporting_period: reportingPeriod,
    valid_rows: validRows
  };
}

// Load all history logs from localStorage and SQLite backend
// Load all history logs from localStorage and SQLite backend
export function loadHistoryLogs() {
  let localLogs = [];
  try {
    const raw = localStorage.getItem('dashboard_history_logs');
    if (raw) {
      const parsed = JSON.parse(raw);
      localLogs = Array.isArray(parsed) ? parsed.map(normalizeLog) : [];
    }
  } catch (e) {
    console.error('Failed to load local history logs:', e);
  }

  // Preserve existing in-memory history logs if present
  if (!state.historyLogs || state.historyLogs.length === 0) {
    state.historyLogs = localLogs;
  } else {
    // Merge localLogs into state.historyLogs without overwriting API logs
    localLogs.forEach(localLog => {
      const exists = state.historyLogs.some(l => 
        String(l.id) === String(localLog.id) || 
        String(l.upload_id) === String(localLog.id) || 
        l.file_name === localLog.file_name || 
        l.title === localLog.title
      );
      if (!exists) {
        state.historyLogs.push(localLog);
      }
    });
  }

  fetchHistoryLogsFromApi().then(apiLogs => {
    if (apiLogs && Array.isArray(apiLogs) && apiLogs.length > 0) {
      const formattedApiLogs = apiLogs.map(normalizeLog);
      
      const merged = [...formattedApiLogs];
      localLogs.forEach(localLog => {
        const existingIdx = merged.findIndex(m => 
          String(m.id) === String(localLog.id) || 
          String(m.upload_id) === String(localLog.id) || 
          m.file_name === localLog.file_name || 
          m.title === localLog.title
        );
        if (existingIdx !== -1) {
          merged[existingIdx] = {
            ...localLog,
            ...merged[existingIdx],
            kpis: localLog.kpis || merged[existingIdx].kpis,
            safetyMonthlyData: localLog.safetyMonthlyData || merged[existingIdx].safetyMonthlyData,
            productivityMonthlyData: localLog.productivityMonthlyData || merged[existingIdx].productivityMonthlyData,
            deliveryMonthlyData: localLog.deliveryMonthlyData || merged[existingIdx].deliveryMonthlyData,
            costMonthlyData: localLog.costMonthlyData || merged[existingIdx].costMonthlyData,
            hrMonthlyData: localLog.hrMonthlyData || merged[existingIdx].hrMonthlyData,
            qualityMonthlyData: localLog.qualityMonthlyData || merged[existingIdx].qualityMonthlyData,
            environmentMonthlyData: localLog.environmentMonthlyData || merged[existingIdx].environmentMonthlyData,
            inventoryMonthlyData: localLog.inventoryMonthlyData || merged[existingIdx].inventoryMonthlyData,
            digitalMonthlyData: localLog.digitalMonthlyData || merged[existingIdx].digitalMonthlyData
          };
        } else {
          merged.push(localLog);
        }
      });
      state.historyLogs = merged;
      localStorage.setItem('dashboard_history_logs', JSON.stringify(state.historyLogs));
    }
  }).catch(() => {});

  return state.historyLogs;
}

// Save a new history log
export function saveHistoryLog(title, meta = {}) {
  loadHistoryLogs(); // Make sure we have latest

  const timestamp = new Date().toLocaleString();
  const id = Date.now().toString();

  const newLog = normalizeLog({
    id,
    timestamp,
    title,
    file_name: meta.file_name || title,
    upload_timestamp: timestamp,
    module: state.currentModule || 'overall',
    reporting_period: meta.reporting_period || 'Active Dataset',
    valid_rows: meta.valid_rows || (state.kpis ? state.kpis.length : 0),
    kpis: JSON.parse(JSON.stringify(state.kpis)),
    safetyMonthlyData: JSON.parse(JSON.stringify(state.safetyMonthlyData)),
    productivityMonthlyData: JSON.parse(JSON.stringify(state.productivityMonthlyData)),
    deliveryMonthlyData: JSON.parse(JSON.stringify(state.deliveryMonthlyData)),
    costMonthlyData: JSON.parse(JSON.stringify(state.costMonthlyData)),
    hrMonthlyData: JSON.parse(JSON.stringify(state.hrMonthlyData)),
    qualityMonthlyData: JSON.parse(JSON.stringify(state.qualityMonthlyData)),
    environmentMonthlyData: JSON.parse(JSON.stringify(state.environmentMonthlyData)),
    inventoryMonthlyData: JSON.parse(JSON.stringify(state.inventoryMonthlyData)),
    digitalMonthlyData: JSON.parse(JSON.stringify(state.digitalMonthlyData)),
    costLedgerBreakdown: JSON.parse(JSON.stringify(state.costLedgerBreakdown)),
    costOfeBreakdown: JSON.parse(JSON.stringify(state.costOfeBreakdown)),
    costVccBreakdown: JSON.parse(JSON.stringify(state.costVccBreakdown)),
    costCltBreakdown: JSON.parse(JSON.stringify(state.costCltBreakdown)),
    costPlantBreakdown: JSON.parse(JSON.stringify(state.costPlantBreakdown)),
    ficWiseInjuries: JSON.parse(JSON.stringify(state.ficWiseInjuries)),
    ficWiseInjuriesYtd: JSON.parse(JSON.stringify(state.ficWiseInjuriesYtd))
  });

  state.historyLogs.unshift(newLog); // Put new logs at the beginning
  
  if (state.historyLogs.length > 30) {
    state.historyLogs = state.historyLogs.slice(0, 30);
  }

  localStorage.setItem('dashboard_history_logs', JSON.stringify(state.historyLogs));
  saveHistoryLogToApi(newLog);
  syncStateToBackend();
  return state.historyLogs;
}

// Ensure all KPIs from INITIAL_KPIS exist in state.kpis
export function ensureAllKpisExist() {
  if (!state.kpis) {
    state.kpis = JSON.parse(JSON.stringify(INITIAL_KPIS));
    return;
  }
  INITIAL_KPIS.forEach(initKpi => {
    const exists = state.kpis.some(k => k.id === initKpi.id);
    if (!exists) {
      state.kpis.push(JSON.parse(JSON.stringify(initKpi)));
    }
  });
}

// Restore a history log by ID or upload_id
export async function restoreHistoryLog(id) {
  const targetId = String(id).trim();

  // 1. Search in current state.historyLogs memory
  let log = (state.historyLogs || []).find(l => 
    String(l.id) === targetId || 
    String(l.upload_id) === targetId ||
    String(l.file_name || '').trim() === targetId ||
    String(l.title || '').trim() === targetId
  );

  // 2. If not found in memory, query API upload history directly
  if (!log) {
    try {
      const apiLogs = await fetchHistoryLogsFromApi();
      if (apiLogs && Array.isArray(apiLogs) && apiLogs.length > 0) {
        const formattedApiLogs = apiLogs.map(normalizeLog);
        log = formattedApiLogs.find(l => 
          String(l.id) === targetId || 
          String(l.upload_id) === targetId ||
          String(l.file_name || '').trim() === targetId ||
          String(l.title || '').trim() === targetId
        );
        if (log) {
          if (!state.historyLogs.some(l => String(l.id) === String(log.id))) {
            state.historyLogs.unshift(log);
          }
        }
      }
    } catch (e) {
      console.warn('[Restore History] API lookup error:', e);
    }
  }

  // 3. Fallback to localStorage if still not found
  if (!log) {
    const rawLocal = localStorage.getItem('dashboard_history_logs');
    if (rawLocal) {
      try {
        const parsedLocal = JSON.parse(rawLocal);
        log = parsedLocal.map(normalizeLog).find(l => 
          String(l.id) === targetId || 
          String(l.upload_id) === targetId ||
          String(l.file_name || '').trim() === targetId ||
          String(l.title || '').trim() === targetId
        );
      } catch (e) {}
    }
  }

  if (!log) {
    console.warn('[Restore History] Log record not found for ID:', id);
    return false;
  }

  try {
    // A. Restore local snapshot state if available in history log item
    if (log.kpis && Array.isArray(log.kpis) && log.kpis.length > 0) {
      state.kpis = JSON.parse(JSON.stringify(log.kpis));
      ensureAllKpisExist();

      if (log.safetyMonthlyData) state.safetyMonthlyData = JSON.parse(JSON.stringify(log.safetyMonthlyData));
      if (log.productivityMonthlyData) state.productivityMonthlyData = JSON.parse(JSON.stringify(log.productivityMonthlyData));
      if (log.deliveryMonthlyData) state.deliveryMonthlyData = JSON.parse(JSON.stringify(log.deliveryMonthlyData));
      if (log.costMonthlyData) state.costMonthlyData = JSON.parse(JSON.stringify(log.costMonthlyData));
      if (log.hrMonthlyData) state.hrMonthlyData = JSON.parse(JSON.stringify(log.hrMonthlyData));
      if (log.qualityMonthlyData) state.qualityMonthlyData = JSON.parse(JSON.stringify(log.qualityMonthlyData));
      if (log.environmentMonthlyData) state.environmentMonthlyData = JSON.parse(JSON.stringify(log.environmentMonthlyData));
      if (log.inventoryMonthlyData) state.inventoryMonthlyData = JSON.parse(JSON.stringify(log.inventoryMonthlyData));
      if (log.digitalMonthlyData) state.digitalMonthlyData = JSON.parse(JSON.stringify(log.digitalMonthlyData));
      if (log.costLedgerBreakdown) state.costLedgerBreakdown = JSON.parse(JSON.stringify(log.costLedgerBreakdown));
      if (log.costOfeBreakdown) state.costOfeBreakdown = JSON.parse(JSON.stringify(log.costOfeBreakdown));
      if (log.costVccBreakdown) state.costVccBreakdown = JSON.parse(JSON.stringify(log.costVccBreakdown));
      if (log.costCltBreakdown) state.costCltBreakdown = JSON.parse(JSON.stringify(log.costCltBreakdown));
      if (log.costPlantBreakdown) state.costPlantBreakdown = JSON.parse(JSON.stringify(log.costPlantBreakdown));
      if (log.ficWiseInjuries) state.ficWiseInjuries = JSON.parse(JSON.stringify(log.ficWiseInjuries));
      if (log.ficWiseInjuriesYtd) state.ficWiseInjuriesYtd = JSON.parse(JSON.stringify(log.ficWiseInjuriesYtd));
    }

    // B. Fetch all 9 modules telemetry for the dataset reporting period from backend
    const period = log.reporting_period || log.period_date;
    if (period) {
      const allMods = ['safety', 'quality', 'productivity', 'delivery', 'cost', 'inventory', 'environment', 'hr', 'digital'];
      for (const modName of allMods) {
        try {
          await loadModuleDataFromApi(modName, period);
        } catch (e) {}
      }
    }

    if (log.module && log.module !== 'overall') {
      state.currentModule = log.module;
    }

    updateAllBaseSnapshots();
    return true;
  } catch (err) {
    console.error('[Restore History Exception]', err);
    return false;
  }
}

// Delete a history log by ID
export function deleteHistoryLog(id) {
  loadHistoryLogs();
  const targetId = String(id);
  state.historyLogs = state.historyLogs.filter(l => String(l.id) !== targetId && String(l.upload_id) !== targetId);
  localStorage.setItem('dashboard_history_logs', JSON.stringify(state.historyLogs));
  deleteHistoryLogFromApi(targetId);
  return state.historyLogs;
}

// Clear all history logs
export function clearHistoryLogs() {
  state.historyLogs = [];
  localStorage.removeItem('dashboard_history_logs');
  resetDatabaseOnApi();
  return [];
}

// Sync full state with SQLite backend
export async function syncStateWithBackend() {
  const data = await fetchStateFromApi();
  if (!data?.state) return false;
  const token = state.authToken;
  const user = state.currentUser;
  Object.assign(state, data.state);
  state.authToken = token;
  state.currentUser = user;
  ensureAllKpisExist();
  state.baseKpis = JSON.parse(JSON.stringify(state.kpis));
  return true;
}

export async function syncStateToBackend() {
  await saveStateToApi(state);
}

export async function loadModuleDataFromApi(moduleName, reportingDate) {
  if (!moduleName || moduleName === 'overall') return false;
  const modData = await fetchModuleFromApi(moduleName, reportingDate);
  if (modData && modData.kpis && modData.kpis.length > 0) {
    modData.kpis.forEach(item => {
      let match = state.kpis.find(k => k.id === item.metric_id);
      if (!match) {
        match = { id: item.metric_id, name: item.metric_name, unit: item.unit, module: moduleName, section: item.section || '' };
        state.kpis.push(match);
      }
      if (item.ftm) {
        match.target = item.ftm.target;
        match.actual = item.ftm.actual;
        match.ftmTarget = item.ftm.target;
        match.ftmActual = item.ftm.actual;
      }
      if (item.last_month) {
        match.lastMonthTarget = item.last_month.target;
        match.lastMonthActual = item.last_month.actual;
      }
      if (item.ytd) {
        match.ytdTarget = item.ytd.target;
        match.ytdActual = item.ytd.actual;
      }
      syncKpiToMonthlyData(match);
    });
    return true;
  }
  return false;
}

/**
 * Set current logged-in user & session token
 */
export function setAuthSession(user, token) {
  state.currentUser = user;
  state.authToken = token;
  if (token) {
    localStorage.setItem('dashboard_auth_token', token);
  } else {
    localStorage.removeItem('dashboard_auth_token');
  }
}

/**
 * Clear auth session (logout)
 */
export async function clearAuthSession() {
  if (state.authToken) {
    await logoutApi(state.authToken);
  }
  state.currentUser = null;
  state.authToken = null;
  localStorage.removeItem('dashboard_auth_token');
}

/**
 * Verify session token on startup and fetch user profile
 */
export async function initAuthSession() {
  const token = localStorage.getItem('dashboard_auth_token');
  if (!token) {
    state.currentUser = null;
    state.authToken = null;
    return null;
  }
  const user = await fetchCurrentUserApi(token);
  if (user) {
    state.currentUser = user;
    state.authToken = token;
    return user;
  } else {
    state.currentUser = null;
    state.authToken = null;
    localStorage.removeItem('dashboard_auth_token');
    return null;
  }
}



