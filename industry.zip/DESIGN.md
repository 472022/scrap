# Industrial Dashboard Design System

## 1. Atmosphere & Identity

An operational command center: dense, direct, and legible under frequent use. Its signature is the two-column monthly/YTD comparison, framed by a deep navy application bar and restrained module accents.

## 2. Color

### Palette

| Role | Token | Value | Usage |
|---|---|---|---|
| Workspace | `--bg-color` | `#eaedf2` | Page background |
| Surface | `--card-bg` | `#ffffff` | Cards and panels |
| Main text | `--text-dark` | `#1f2937` | Headings and values |
| Muted text | `--text-muted` | `#6b7280` | Supporting labels |
| Primary | `--primary-navy` | `#18223f` | Header, section headers |
| Primary hover | `--primary-navy-hover` | `#23315a` | Interactive navy states |
| Accent | `--accent-blue` | `#3b82f6` | Primary actions and focus |
| Success | `--green-bg` / `--green-text` | `#10b981` / `#047857` | On-target status |
| Warning | `--yellow-bg` / `--yellow-text` | `#eab308` / `#854d0e` | Near-target status |
| Error | `--red-bg` / `--red-text` | `#ef4444` / `#991b1b` | Off-target status |
| Secondary warning | `--orange-bg` / `--orange-text` | `#f97316` / `#c2410c` | Elevated attention |

Use the existing CSS custom properties for new states. Module accents may use the established per-module palette in `src/main.js`.

## 3. Typography

- Display and headings: Outfit, Inter, sans-serif (`--font-title`).
- Body and data: Inter, system sans-serif (`--font-body`).
- Existing dashboard scale ranges from 10px metadata to 30px page titles; preserve established local sizing for this data-dense UI.
- Values use strong weights; supporting labels use muted color and compact sizing.

## 4. Spacing & Layout

- Existing spacing is based on 4px increments, with 8px/12px/16px/20px/24px as common values.
- The header and action bar span the viewport. Module dashboards use two equal columns for monthly and YTD content, with a 20px gap.
- Cards and tables fill their column and use compact row spacing to keep related metrics visible together.
- At narrow widths, preserve content access and allow the dashboard columns to stack as defined by the existing responsive CSS.

## 5. Components

### Module tabs and actions
- **Structure**: semantic buttons inside the top navigation or action group.
- **Variants**: selected module, primary action, outlined action.
- **States**: default, hover, active, keyboard focus, disabled, loading where applicable.
- **Accessibility**: retain button semantics and visible focus; selected tabs expose their active state.
- **Motion**: existing short color/shadow transitions; no new decorative motion.

### Dashboard cards and KPI tables
- **Structure**: card header, body, and semantic table with labels, values, and status.
- **Variants**: module-specific cards, summary cards, chart cards, monthly/YTD views.
- **States**: populated, loading, empty, and error; status values use the established green/yellow/red classes.
- **Accessibility**: use table headers for column labels and do not communicate status by color alone.
- **Motion**: preserve existing chart and card transitions.

### Data status message
- **Structure**: concise text within an existing dashboard container, with optional retry action.
- **Variants**: loading, empty dataset, backend error, upload error.
- **States**: visible only while the corresponding condition applies; retry controls have focus and disabled states.
- **Accessibility**: announce async updates with an appropriate live region and keep the message readable without color.
- **Motion**: none required.

## 6. Motion & Interaction

- Preserve existing hover and active feedback on tabs, controls, and view switches.
- Existing durations are generally 0.2s; chart transitions may be longer when they communicate changing values.
- New loading/error behavior should not introduce decorative animation. Respect reduced-motion preferences for any motion added later.

## 7. Depth & Surface

The current UI uses a mixed surface strategy: white cards on a slate workspace, thin borders, and restrained layered shadows. New cards and status messages should use the same surface and elevation language rather than introducing a second visual style.
