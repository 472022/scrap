#!/bin/bash
# ============================================================
#  Tata Motors Canteen System — Startup Script
#  Port: 48000 (IT allocated)
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
PORT="${PORT:-48000}"
WORKERS="${WORKERS:-4}"

echo "======================================================"
echo "  TATA MOTORS CANTEEN ORDER MANAGEMENT SYSTEM"
echo "  Port: $PORT"
echo "======================================================"
echo ""

# Install dependencies
echo "Installing dependencies..."
pip install flask flask-cors mysql-connector-python pyodbc gunicorn --break-system-packages -q
echo "Dependencies ready."
echo ""

cd "$BACKEND_DIR"

# ── Choose run mode ─────────────────────────────────────────
if command -v gunicorn &>/dev/null; then
  echo "Starting with Gunicorn (production mode)..."
  echo "  Workers : $WORKERS"
  echo "  Port    : $PORT"
  echo ""
  exec gunicorn \
    --workers "$WORKERS" \
    --bind "0.0.0.0:$PORT" \
    --timeout 120 \
    --access-logfile - \
    --error-logfile - \
    wsgi:app
else
  echo "Gunicorn not found — starting with Flask dev server..."
  echo "  (Install gunicorn for production: pip install gunicorn)"
  echo ""
  PORT=$PORT python app.py
fi
