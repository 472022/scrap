from flask import Flask, request, jsonify, session
import os
import sys
import threading
import time
import hashlib
from datetime import datetime, timezone, timedelta

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(CURRENT_DIR)

if CURRENT_DIR not in sys.path:
    sys.path.insert(0, CURRENT_DIR)
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from database import get_db, init_db
from email_utils import (
    send_order_received,
    send_order_status_update,
    send_reviewer_pin_expiry_warning,
    CANTEEN_HEAD_EMAIL,
)
from canteen_app.app import canteen_app
from user_app.app import user_app

COMMON_STATIC = os.path.join(PROJECT_ROOT, 'canteen_app', 'static')
app = Flask(__name__, static_folder=COMMON_STATIC, static_url_path='/static')
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
REVIEWER_PIN_TTL_SECONDS = int(os.environ.get('CANTEEN_REVIEWER_PIN_TTL_SECONDS', '28800'))
REVIEWER_PIN_VALIDITY_DAYS = int(os.environ.get('CANTEEN_PIN_VALIDITY_DAYS', '90'))
REVIEWER_PIN_REMINDER_DAYS = int(os.environ.get('CANTEEN_PIN_REMINDER_DAYS', '5'))

app.register_blueprint(canteen_app, url_prefix='/canteen')
app.register_blueprint(user_app, url_prefix='/order')


def _reviewer_auth_remaining_seconds():
    expires_at = int(session.get('reviewer_auth_expires_at') or 0)
    remaining = expires_at - int(time.time())
    return max(0, remaining)


def _is_reviewer_authorized():
    return _is_canteen_session() and _reviewer_auth_remaining_seconds() > 0


def _is_canteen_session():
    return session.get('user_type') == 'canteen' and bool(session.get('user'))


def _reviewer_required_response():
    return (
        jsonify(
            {
                'success': False,
                'error': 'Reviewer PIN required for approve/reject actions',
                'code': 'REVIEWER_PIN_REQUIRED',
            }
        ),
        403,
    )


def _hash_pin(pin_value):
    return hashlib.sha256(str(pin_value).encode('utf-8')).hexdigest()


def _parse_ts_utc(raw_value):
    if not raw_value:
        return None
    try:
        dt = datetime.fromisoformat(str(raw_value).replace(' ', 'T'))
        return dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _format_ts_utc(dt_value):
    return dt_value.astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')


def _ensure_reviewer_policy_row(conn):
    row = conn.execute(
        'SELECT id, pin_hash, pin_changed_at, expires_at, reminder_sent_at FROM reviewer_pin_policy WHERE id=1'
    ).fetchone()
    if row:
        return dict(row)

    fallback_pin = os.environ.get('CANTEEN_REVIEWER_PIN', '2468')
    now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
    expiry_utc = now_utc + timedelta(days=REVIEWER_PIN_VALIDITY_DAYS)
    conn.execute(
        'INSERT INTO reviewer_pin_policy (id, pin_hash, pin_changed_at, expires_at, reminder_sent_at) VALUES (1, ?, ?, ?, NULL)',
        (_hash_pin(fallback_pin), _format_ts_utc(now_utc), _format_ts_utc(expiry_utc)),
    )
    conn.commit()
    row = conn.execute(
        'SELECT id, pin_hash, pin_changed_at, expires_at, reminder_sent_at FROM reviewer_pin_policy WHERE id=1'
    ).fetchone()
    return dict(row)


def _reviewer_pin_expiry_dt(policy_dict):
    return _parse_ts_utc(policy_dict.get('expires_at'))


def _reviewer_pin_days_left(policy_dict):
    expiry_dt = _reviewer_pin_expiry_dt(policy_dict)
    if not expiry_dt:
        return 0
    now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
    return max((expiry_dt - now_utc).days, 0)


def _reviewer_pin_is_expired(policy_dict):
    expiry_dt = _reviewer_pin_expiry_dt(policy_dict)
    if not expiry_dt:
        return True
    return datetime.utcnow().replace(tzinfo=timezone.utc) >= expiry_dt


def _maybe_send_pin_expiry_warning(conn, recipient_email):
    policy = _ensure_reviewer_policy_row(conn)
    if _reviewer_pin_is_expired(policy):
        return

    days_left = _reviewer_pin_days_left(policy)
    if days_left > REVIEWER_PIN_REMINDER_DAYS:
        return

    reminder_sent_at = _parse_ts_utc(policy.get('reminder_sent_at'))
    if reminder_sent_at:
        return

    expiry_dt = _reviewer_pin_expiry_dt(policy)
    target_email = recipient_email or CANTEEN_HEAD_EMAIL
    if not target_email:
        return

    if send_reviewer_pin_expiry_warning(target_email, expiry_dt, days_left):
        conn.execute(
            'UPDATE reviewer_pin_policy SET reminder_sent_at=? WHERE id=1',
            (_format_ts_utc(datetime.utcnow().replace(tzinfo=timezone.utc)),),
        )
        conn.commit()


def _parse_created_at(raw_value):
    if not raw_value:
        return None
    try:
        # SQLite CURRENT_TIMESTAMP is UTC; parse and mark as such.  fromisoformat
        # gives a naive datetime so we attach UTC zone.
        dt = datetime.fromisoformat(str(raw_value).replace(' ', 'T'))
        return dt.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _with_order_timing(order_dict):
    if order_dict.get('status') == 'Pending':
        created_at = _parse_created_at(order_dict.get('created_at'))
        if created_at:
            # compute interval in UTC to avoid local/UTC offset errors
            now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
            pending_minutes = max(int((now_utc - created_at).total_seconds() // 60), 0)
        else:
            pending_minutes = 0
    else:
        pending_minutes = 0

    order_dict['pending_minutes'] = pending_minutes
    order_dict['overdue'] = order_dict.get('status') == 'Pending' and pending_minutes >= 60
    return order_dict


def _get_items_for_orders(conn, order_ids):
    if not order_ids:
        return {}

    placeholders = ','.join('?' for _ in order_ids)
    rows = conn.execute(
        f'''SELECT id, order_id, item_name, quantity, unit, status, rejection_reason
            FROM order_items
            WHERE order_id IN ({placeholders})
            ORDER BY id''',
        order_ids,
    ).fetchall()

    grouped = {oid: [] for oid in order_ids}
    for row in rows:
        item = dict(row)
        grouped[item['order_id']].append(item)
    return grouped

def _get_order_by_id(conn, order_id):
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        return None

    order_dict = dict(order)
    items = conn.execute(
        '''SELECT id, order_id, item_name, quantity, unit, status, rejection_reason
           FROM order_items WHERE order_id=? ORDER BY id''',
        (order_id,),
    ).fetchall()
    order_dict['items'] = [dict(item) for item in items]
    return _with_order_timing(order_dict)


def _send_status_email_async(to_email, supervisor_name, order_id, status, notes, items):
    def _send():
        send_order_status_update(to_email, supervisor_name, order_id, status, notes, items)

    threading.Thread(target=_send, daemon=True).start()

@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@app.route('/', defaults={'path': ''}, methods=['OPTIONS'])
@app.route('/<path:path>', methods=['OPTIONS'])
def handle_options(path):
    return jsonify({}), 200


init_db()


@app.route('/')
def home():
    from flask import redirect
    return redirect('/order/')

@app.route('/api/canteen/login', methods=['POST'])
def canteen_login():
    data = request.json or {}
    conn = get_db()
    user = conn.execute(
        'SELECT * FROM canteen_users WHERE email=? AND password=?',
        (data.get('username'), data.get('password')),
    ).fetchone()
    conn.close()

    if user:
        conn = get_db()
        _maybe_send_pin_expiry_warning(conn, user.get('email') if isinstance(user, dict) else user['email'])
        conn.close()
        return jsonify(
            {
                'success': True,
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
            }
        )

    return jsonify({'success': False, 'message': 'Invalid credentials'}), 401


@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.json or {}
    required_fields = [
        'supervisor_name',
        'supervisor_email',
        'department',
        'shop_name',
        'shift',
        'people_count',
    ]

    missing = [field for field in required_fields if not data.get(field)]
    if missing:
        return jsonify({'success': False, 'error': f"Missing fields: {', '.join(missing)}"}), 400

    conn = get_db()
    # insert order and obtain new id; some sqlite setups can return None on
    # lastrowid if the connection was reused or type mismatch, so we fall back to
    # querying the current maximum id afterwards.
    cur = conn.execute(
        '''INSERT INTO orders
        (supervisor_id, supervisor_name, supervisor_email, department,
         shop_name, shift, people_count, delivery_date, delivery_time)
        VALUES (?,?,?,?,?,?,?,?,?)''',
        (
            data.get('supervisor_id'),
            data['supervisor_name'],
            data['supervisor_email'],
            data['department'],
            data['shop_name'],
            data['shift'],
            data['people_count'],
            data.get('delivery_date'),
            data.get('delivery_time'),
        ),
    )

    order_id = cur.lastrowid
    if not order_id:
        # fall back to reading max id in case lastrowid failed
        row = conn.execute('SELECT MAX(id) AS mid FROM orders').fetchone()
        order_id = row['mid'] if row else None
    print(f"[DEBUG] Created order id={order_id}")
    items = data.get('items', [])

    for item in items:
        conn.execute(
            'INSERT INTO order_items (order_id,item_name,quantity,unit) VALUES (?,?,?,?)',
            (order_id, item['name'], item['quantity'], item.get('unit', 'units')),
        )

    conn.commit()
    conn.close()

    def _send_received_email():
        send_order_received(
            data['supervisor_email'],
            data['supervisor_name'],
            order_id,
            data['department'],
            data['shop_name'],
            data['shift'],
            data['people_count'],
            items,
            data.get('delivery_time'),
            data.get('delivery_date'),
        )

    threading.Thread(target=_send_received_email, daemon=True).start()

    return jsonify({'success': True, 'order_id': order_id})


@app.route('/api/closer_orders', methods=['POST'])
def create_closer_order():
    data = request.json or {}
    required_fields = [
        'name',
        'email',
        'ticket_numbers',
        'department',
        'designation',
        'shift',
        'people_count',
    ]

    missing = [field for field in required_fields if not data.get(field)]
    if missing:
        return jsonify({'success': False, 'error': f"Missing fields: {', '.join(missing)}"}), 400

    conn = get_db()
    cur = conn.execute(
        '''INSERT INTO closer_orders
        (name, email, ticket_numbers, department,
         designation, shift, people_count)
        VALUES (?,?,?,?,?,?,?)''',
        (
            data['name'],
            data['email'],
            data['ticket_numbers'],
            data['department'],
            data['designation'],
            data['shift'],
            data['people_count'],
        ),
    )

    order_id = cur.lastrowid
    if not order_id:
        row = conn.execute('SELECT MAX(id) AS mid FROM closer_orders').fetchone()
        order_id = row['mid'] if row else None
    print(f"[DEBUG] Created closer order id={order_id}")
    items = data.get('items', [])

    for item in items:
        conn.execute(
            'INSERT INTO closer_order_items (closer_order_id,item_name,quantity,unit) VALUES (?,?,?,?)',
            (order_id, item['name'], item['quantity'], item.get('unit', 'units')),
        )

    conn.commit()
    conn.close()

    # Skip sending email for closer food for now, unless required later.
    return jsonify({'success': True, 'order_id': order_id})


@app.route('/api/closer_orders', methods=['GET'])
def get_closer_orders():
    conn = get_db()
    status = request.args.get('status')
    
    query = 'SELECT * FROM closer_orders WHERE 1=1'
    params = []
    
    if status:
        query += ' AND status=?'
        params.append(status)
        
    query += ' ORDER BY created_at DESC'
    
    rows = conn.execute(query, params).fetchall()
    orders = [dict(r) for r in rows]
    
    order_ids = [order['id'] for order in orders]
    if order_ids:
        placeholders = ','.join('?' for _ in order_ids)
        item_rows = conn.execute(
            f'SELECT * FROM closer_order_items WHERE closer_order_id IN ({placeholders}) ORDER BY id',
            order_ids
        ).fetchall()
        
        items_map = {}
        for row in item_rows:
            oid = row['closer_order_id']
            if oid not in items_map:
                items_map[oid] = []
            items_map[oid].append(dict(row))
            
        for order in orders:
            order['items'] = items_map.get(order['id'], [])
            order['pending_minutes'] = 0
            order['overdue'] = False
            created_at = _parse_created_at(order.get('created_at'))
            if created_at and order.get('status') == 'Pending':
                now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
                order['pending_minutes'] = max(int((now_utc - created_at).total_seconds() // 60), 0)
                order['overdue'] = order['pending_minutes'] >= 60
    else:
        for order in orders:
            order['items'] = []
            order['pending_minutes'] = 0
            order['overdue'] = False

    conn.close()
    return jsonify(orders)


@app.route('/api/orders', methods=['GET'])
def get_orders():
    conn = get_db()

    status = request.args.get('status')
    shift = request.args.get('shift')
    date = request.args.get('date')
    search = request.args.get('search')
    supervisor_id = request.args.get('supervisor_id')

    query = 'SELECT * FROM orders WHERE 1=1'
    params = []

    if status:
        query += ' AND status=?'
        params.append(status)
    if shift:
        query += ' AND shift=?'
        params.append(shift)
    if date:
        query += ' AND DATE(created_at)=?'
        params.append(date)
    if search:
        query += ' AND (supervisor_name LIKE ? OR department LIKE ? OR shop_name LIKE ? OR CAST(id AS CHAR) LIKE ?)'
        like_search = f'%{search}%'
        params.extend([like_search, like_search, like_search, like_search])
    if supervisor_id:
        query += ' AND supervisor_id=?'
        params.append(supervisor_id)

    query += ' ORDER BY created_at DESC'

    rows = conn.execute(query, params).fetchall()
    orders = [dict(r) for r in rows]

    order_ids = [order['id'] for order in orders]
    items_map = _get_items_for_orders(conn, order_ids)

    for order in orders:
        order['items'] = items_map.get(order['id'], [])
        _with_order_timing(order)

    conn.close()
    return jsonify(orders)


@app.route('/api/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    conn = get_db()
    order = _get_order_by_id(conn, order_id)
    conn.close()

    if not order:
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    return jsonify(order)


@app.route('/api/orders/<int:order_id>/approve', methods=['POST'])
def approve_order(order_id):
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401
    if not _is_reviewer_authorized():
        return _reviewer_required_response()

    data = request.json or {}
    notes = (data.get('notes') or '').strip()

    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    conn.execute(
        "UPDATE orders SET status='Approved', canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (notes, order_id),
    )
    conn.execute(
        "UPDATE order_items SET status='Approved', rejection_reason=NULL WHERE order_id=?",
        (order_id,),
    )
    conn.commit()

    order_payload = _get_order_by_id(conn, order_id)
    conn.close()

    _send_status_email_async(
        order['supervisor_email'],
        order['supervisor_name'],
        order_id,
        'Approved',
        notes,
        order_payload['items'],
    )

    return jsonify({'success': True})


@app.route('/api/orders/<int:order_id>/reject', methods=['POST'])
def reject_order(order_id):
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401
    if not _is_reviewer_authorized():
        return _reviewer_required_response()

    data = request.json or {}
    notes = (data.get('notes') or '').strip()

    if not notes:
        return jsonify({'success': False, 'error': 'Rejection reason is required'}), 400

    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    conn.execute(
        "UPDATE orders SET status='Rejected', canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
        (notes, order_id),
    )
    conn.execute(
        "UPDATE order_items SET status='Rejected', rejection_reason=? WHERE order_id=?",
        (notes, order_id),
    )
    conn.commit()

    order_payload = _get_order_by_id(conn, order_id)
    conn.close()

    _send_status_email_async(
        order['supervisor_email'],
        order['supervisor_name'],
        order_id,
        'Rejected',
        notes,
        order_payload['items'],
    )

    return jsonify({'success': True})


@app.route('/api/orders/<int:order_id>/partial', methods=['POST'])
def partial_review(order_id):
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401
    if not _is_reviewer_authorized():
        return _reviewer_required_response()

    data = request.json or {}
    updates = data.get('items') or []
    notes = (data.get('notes') or '').strip()

    if not isinstance(updates, list) or not updates:
        return jsonify({'success': False, 'error': 'No item updates provided'}), 400

    conn = get_db()
    order = conn.execute('SELECT * FROM orders WHERE id=?', (order_id,)).fetchone()
    if not order:
        conn.close()
        return jsonify({'success': False, 'error': 'Order not found'}), 404

    valid_statuses = {'Approved', 'Cancelled', 'Substituted'}

    for entry in updates:
        item_id = entry.get('id')
        status = entry.get('status')
        reason = (entry.get('reason') or '').strip()
        alt_item = (entry.get('alt_item') or '').strip()

        if status not in valid_statuses:
            conn.close()
            return jsonify({'success': False, 'error': f'Invalid status for item {item_id}'}), 400

        rejection_reason = None
        if status == 'Cancelled':
            if not reason:
                conn.close()
                return jsonify({'success': False, 'error': f'Cancellation reason required for item {item_id}'}), 400
            rejection_reason = reason
        elif status == 'Substituted':
            if not alt_item:
                conn.close()
                return jsonify({'success': False, 'error': f'Alternative item required for item {item_id}'}), 400
            rejection_reason = f'[ALT:{alt_item}] {reason}'.strip()

        conn.execute(
            'UPDATE order_items SET status=?, rejection_reason=? WHERE id=? AND order_id=?',
            (status, rejection_reason, item_id, order_id),
        )

    item_rows = conn.execute('SELECT status FROM order_items WHERE order_id=?', (order_id,)).fetchall()
    item_statuses = [row['status'] for row in item_rows]

    approved_like = sum(1 for s in item_statuses if s in {'Approved', 'Substituted'})
    cancelled_count = sum(1 for s in item_statuses if s == 'Cancelled')
    substituted_count = sum(1 for s in item_statuses if s == 'Substituted')

    if approved_like == 0:
        final_status = 'Rejected'
    else:
        final_status = 'Approved'

    conn.execute(
        'UPDATE orders SET status=?, canteen_notes=?, updated_at=CURRENT_TIMESTAMP WHERE id=?',
        (final_status, notes, order_id),
    )

    conn.commit()
    order_payload = _get_order_by_id(conn, order_id)
    conn.close()

    _send_status_email_async(
        order['supervisor_email'],
        order['supervisor_name'],
        order_id,
        final_status,
        notes,
        order_payload['items'],
    )

    return jsonify(
        {
            'success': True,
            'final_status': final_status,
            'approved': approved_like,
            'cancelled': cancelled_count,
            'substituted': substituted_count,
        }
    )


@app.route('/api/stats', methods=['GET'])
def get_stats():
    conn = get_db()

    total = conn.execute('SELECT COUNT(*) FROM orders').fetchone()[0]
    pending = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Pending'").fetchone()[0]
    approved = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Approved'").fetchone()[0]
    rejected = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Rejected'").fetchone()[0]
    cancelled = conn.execute("SELECT COUNT(*) FROM orders WHERE status='Cancelled'").fetchone()[0]
    completed = conn.execute("SELECT COUNT(*) FROM orders WHERE status<>'Pending'").fetchone()[0]

    overdue = conn.execute(
        """
        SELECT COUNT(*)
        FROM orders
        WHERE status='Pending'
          AND (strftime('%s','now') - strftime('%s', created_at)) >= 3600
        """
    ).fetchone()[0]

    conn.close()

    return jsonify(
        {
            'total': total,
            'pending': pending,
            'approved': approved,
            'rejected': rejected,
            'cancelled': cancelled,
            'completed': completed,
            'overdue': overdue,
        }
    )


@app.route('/api/reviewer/status', methods=['GET'])
def reviewer_status():
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401
    conn = get_db()
    policy = _ensure_reviewer_policy_row(conn)
    _maybe_send_pin_expiry_warning(conn, session.get('user', {}).get('email') if isinstance(session.get('user'), dict) else CANTEEN_HEAD_EMAIL)
    conn.close()
    return jsonify(
        {
            'success': True,
            'authorized': _is_reviewer_authorized(),
            'expires_in_seconds': _reviewer_auth_remaining_seconds(),
            'pin_expired': _reviewer_pin_is_expired(policy),
            'pin_days_left': _reviewer_pin_days_left(policy),
            'pin_expires_at': policy.get('expires_at'),
        }
    )


@app.route('/api/reviewer/unlock', methods=['POST'])
def reviewer_unlock():
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401
    data = request.json or {}
    pin = str(data.get('pin') or '').strip()
    if not pin:
        return jsonify({'success': False, 'error': 'PIN is required'}), 400
    conn = get_db()
    policy = _ensure_reviewer_policy_row(conn)
    _maybe_send_pin_expiry_warning(conn, session.get('user', {}).get('email') if isinstance(session.get('user'), dict) else CANTEEN_HEAD_EMAIL)

    if _reviewer_pin_is_expired(policy):
        conn.close()
        return (
            jsonify(
                {
                    'success': False,
                    'error': 'Reviewer PIN has expired. Please reset your PIN.',
                    'code': 'PIN_EXPIRED',
                    'pin_expires_at': policy.get('expires_at'),
                }
            ),
            403,
        )

    if _hash_pin(pin) != policy.get('pin_hash'):
        conn.close()
        return jsonify({'success': False, 'error': 'Invalid reviewer PIN'}), 401

    pin_expiry_dt = _reviewer_pin_expiry_dt(policy)
    now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
    seconds_until_pin_expiry = max(int((pin_expiry_dt - now_utc).total_seconds()), 0) if pin_expiry_dt else 0
    session_duration = min(REVIEWER_PIN_TTL_SECONDS, seconds_until_pin_expiry) if seconds_until_pin_expiry else 0
    session['reviewer_auth_expires_at'] = int(time.time()) + session_duration
    conn.close()
    return jsonify({'success': True, 'expires_in_seconds': session_duration})


@app.route('/api/reviewer/lock', methods=['POST'])
def reviewer_lock():
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401
    session.pop('reviewer_auth_expires_at', None)
    return jsonify({'success': True})


@app.route('/api/reviewer/reset-pin', methods=['POST'])
def reviewer_reset_pin():
    if not _is_canteen_session():
        return jsonify({'success': False, 'error': 'Canteen login required'}), 401

    data = request.json or {}
    current_pin = str(data.get('current_pin') or '').strip()
    new_pin = str(data.get('new_pin') or '').strip()

    if not current_pin or not new_pin:
        return jsonify({'success': False, 'error': 'Both current_pin and new_pin are required'}), 400
    if not new_pin.isdigit() or len(new_pin) < 4 or len(new_pin) > 8:
        return jsonify({'success': False, 'error': 'New PIN must be 4 to 8 digits'}), 400
    if current_pin == new_pin:
        return jsonify({'success': False, 'error': 'New PIN must be different from current PIN'}), 400

    conn = get_db()
    policy = _ensure_reviewer_policy_row(conn)
    if _hash_pin(current_pin) != policy.get('pin_hash'):
        conn.close()
        return jsonify({'success': False, 'error': 'Current PIN is incorrect'}), 401

    now_utc = datetime.utcnow().replace(tzinfo=timezone.utc)
    expires_utc = now_utc + timedelta(days=REVIEWER_PIN_VALIDITY_DAYS)
    conn.execute(
        'UPDATE reviewer_pin_policy SET pin_hash=?, pin_changed_at=?, expires_at=?, reminder_sent_at=NULL WHERE id=1',
        (_hash_pin(new_pin), _format_ts_utc(now_utc), _format_ts_utc(expires_utc)),
    )
    conn.commit()
    conn.close()

    session.pop('reviewer_auth_expires_at', None)
    return jsonify(
        {
            'success': True,
            'message': 'Reviewer PIN reset successfully',
            'pin_expires_at': _format_ts_utc(expires_utc),
            'pin_validity_days': REVIEWER_PIN_VALIDITY_DAYS,
        }
    )


@app.route('/set-session', methods=['POST'])
def set_session():
    data = request.json or {}
    if data.get('success'):
        session['user'] = data
        session['user_type'] = 'supervisor' if 'department' in data else 'canteen'
        session.pop('reviewer_auth_expires_at', None)
    return jsonify({'success': True})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '48000'))
    app.run(host='0.0.0.0', port=port, debug=True)
