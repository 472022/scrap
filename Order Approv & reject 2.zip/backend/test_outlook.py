import win32com.client as win32

outlook = win32.Dispatch('Outlook.Application')
mail = outlook.CreateItem(0)

mail.To = "canteendwd@tatamotors.com"
mail.Subject = "Test Email from Python"
mail.HTMLBody = "<h2>Outlook integration working</h2>"

mail.Send()

print("Email sent successfully")