import win32com.client as win32
import pythoncom
import os
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

pythoncom.CoInitialize()

# SMTP settings (uncomment and configure if using SMTP instead of Outlook)
SMTP_HOST = os.environ.get('SMTP_HOST', 'smtp.gmail.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', '587'))
SMTP_USER = os.environ.get('SMTP_USER', 'your-email@gmail.com')
SMTP_PASS = os.environ.get('SMTP_PASS', 'your-app-password')

FROM_NAME = 'Tata Motors Canteen'
FROM_EMAIL = SMTP_USER

EMAIL_ENABLED = True
CANTEEN_HEAD_EMAIL = "shekhara.h@tatamotors.com"
CANTEEN_DWD_EMAIL = "canteendwd@tatamotors.com"

# Email sending method: 'outlook' or 'smtp'
EMAIL_METHOD = os.environ.get('EMAIL_METHOD', 'outlook')

# If you have multiple Outlook accounts configured, set the SmtpAddress of the
# account you want to send from (e.g. "me@company.com"). If not set, Outlook
# uses the default account. By default we use the Canteen Head account.
OUTLOOK_ACCOUNT_EMAIL = os.environ.get('OUTLOOK_ACCOUNT_EMAIL', CANTEEN_HEAD_EMAIL)

def _iter_outlook_accounts(session):
    """Yield Outlook accounts safely for both MAPI collections and Python iteration."""
    accounts = session.Accounts
    try:
        for i in range(1, accounts.Count + 1):
            yield accounts.Item(i)
    except Exception:
        for acct in accounts:
            yield acct

def _account_label(account):
    """Best-effort account label for logs/errors."""
    try:
        smtp = account.SmtpAddress
    except Exception:
        smtp = ""
    try:
        name = account.DisplayName
    except Exception:
        name = "Unknown"
    return f"{name} ({smtp})" if smtp else name

def _find_outlook_account(outlook, account_email):
    """Return the Outlook Account object matching `account_email`.

    The user can pass either the SMTP address (preferred) or the account display
    name.
    """
    if not account_email:
        return None

    normalized = account_email.strip().lower()
    for acct in _iter_outlook_accounts(outlook.Session):
        try:
            if acct.SmtpAddress.lower() == normalized:
                return acct
        except Exception:
            pass
        try:
            if acct.DisplayName.lower() == normalized:
                return acct
        except Exception:
            pass
    return None

def _set_send_using_account(mail, account):
    """Apply SendUsingAccount reliably across pywin32 variants."""
    try:
        mail.SendUsingAccount = account
        return True
    except Exception:
        pass

    try:
        # Set 'SendUsingAccount' COM property directly.
        mail._oleobj_.Invoke(*(64209, 0, 8, 0, account))
        return True
    except Exception:
        return False

def send_email_smtp(to_email, subject, html_body, from_email=None):
    """Send email using SMTP instead of Outlook."""
    try:
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = f"{FROM_NAME} <{FROM_EMAIL}>"
        msg['To'] = to_email

        # Attach HTML body
        html_part = MIMEText(html_body, 'html')
        msg.attach(html_part)

        # Send via SMTP
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT)
        server.starttls()
        server.login(SMTP_USER, SMTP_PASS)
        server.sendmail(FROM_EMAIL, to_email, msg.as_string())
        server.quit()

        print(f"[EMAIL SENT via SMTP] To: {to_email} | Subject: {subject}")
        return True

    except Exception as e:
        print(f"[EMAIL FAILED via SMTP] {e}")
        return False

def send_email(to_email, subject, html_body, from_email=None):
    if EMAIL_METHOD == 'smtp':
        return send_email_smtp(to_email, subject, html_body, from_email)
    else:
        return send_email_outlook(to_email, subject, html_body, from_email)

def send_email_outlook(to_email, subject, html_body, from_email=None):
    # Every thread that uses COM must initialise it separately. The import-time
    # pythoncom.CoInitialize() call only applies to the main thread.
    try:
        pythoncom.CoInitialize()
    except Exception:
        # If it was already initialised this may raise; ignore.
        pass

    if not EMAIL_ENABLED:
        print(f"[EMAIL SKIPPED] To: {to_email} | Subject: {subject}")
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass
        return True

    # Handle to_email as string or list
    if isinstance(to_email, list):
        to_email = ';'.join(to_email)

    try:
        outlook = win32.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)

        # If user wants to send from a specific Outlook account, use it.
        account_email = (from_email or OUTLOOK_ACCOUNT_EMAIL)
        if account_email:
            account = _find_outlook_account(outlook, account_email)
            if account:
                if not _set_send_using_account(mail, account):
                    print(f"[EMAIL WARNING] Failed to set SendUsingAccount for: {_account_label(account)}")
            else:
                available = [_account_label(a) for a in _iter_outlook_accounts(outlook.Session)]
                print(
                    f"[EMAIL WARNING] Outlook account not found: {account_email}. "
                    f"Available accounts: {available}"
                )

        mail.To = to_email
        mail.Subject = subject
        mail.HTMLBody = html_body
        mail.Send()

        print(f"[EMAIL SENT] To: {to_email} | Subject: {subject}")
        return True

    except Exception as e:
        print(f"[EMAIL FAILED] {e}")
        return False

    finally:
        try:
            pythoncom.CoUninitialize()
        except Exception:
            pass

def _base_template(body_content):
    year = datetime.now().year
    return f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:#eef2fb;font-family:'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#eef2fb;padding:32px 16px;">
<tr><td align="center">
<table width="620" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 8px 40px rgba(26,86,160,0.15);max-width:620px;">
  <tr><td style="background:linear-gradient(135deg,#0a2a5e 0%,#1a56a0 50%,#2e86de 100%);padding:24px 36px;">
    <table width="100%" cellpadding="0" cellspacing="0"><tr>
      <td><div style="font-size:22px;font-weight:900;color:#ffffff;letter-spacing:1px;">TATA MOTORS</div>
          <div style="font-size:10px;color:rgba(255,255,255,0.6);letter-spacing:2.5px;text-transform:uppercase;margin-top:3px;">Canteen Management System</div></td>
      <td style="text-align:right;vertical-align:middle;">
        <div style="background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.2);border-radius:50px;padding:5px 14px;display:inline-block;">
          <span style="font-size:10px;font-weight:700;color:rgba(255,255,255,0.85);text-transform:uppercase;letter-spacing:1px;">CONFIDENTIAL</span>
        </div>
      </td>
    </tr></table>
  </td></tr>
  <tr><td style="padding:36px;">{body_content}</td></tr>
  <tr><td style="background:#f8faff;border-top:1px solid #e2e8f0;padding:20px 36px;text-align:center;">
    <p style="margin:0;font-size:12px;color:#94a3b8;">&copy; {year} <strong style="color:#1a56a0;">Tata Motors Limited</strong> &nbsp;&middot;&nbsp; Canteen Management System &nbsp;&middot;&nbsp; <strong style="color:#1a56a0;">Confidential</strong></p>
    <p style="margin:6px 0 0;font-size:11px;color:#b0bec5;">This is an automated notification. Please do not reply.</p>
  </td></tr>
</table>
</td></tr></table>
</body></html>"""

def _info_row(label, value, icon=''):
    return f"""<tr>
      <td style="padding:7px 0;width:45%;vertical-align:top;">
        <span style="font-size:11px;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.5px;">{icon}&nbsp;{label}</span>
      </td>
      <td style="padding:7px 0 7px 12px;vertical-align:top;">
        <span style="font-size:13px;font-weight:600;color:#1e293b;">{value}</span>
      </td>
    </tr>"""

def _format_12h(time_str):
    """Convert a time string to 12-hour AM/PM form if possible."""
    if not time_str:
        return ''
    for fmt in ('%H:%M', '%H:%M:%S', '%I:%M %p', '%I:%M:%S %p'):
        try:
            t = datetime.strptime(time_str.strip(), fmt)
            return t.strftime('%I:%M %p').lstrip('0')
        except Exception:
            continue
    return time_str

def send_order_received(to_email, supervisor_name, order_id, department, shop_name, shift, people_count, items,
                        delivery_time=None, delivery_date=None, phone=None):
    """Sends professional new order notification to canteen head."""
    now = datetime.now()
    order_datetime = now.strftime("%d %B %Y, %I:%M %p")

    items_rows = ''
    for i, item in enumerate(items):
        bg = '#f8faff' if i % 2 == 0 else '#ffffff'
        items_rows += f"""<tr style="background:{bg};">
          <td style="padding:11px 16px;font-size:13px;font-weight:600;color:#1e293b;border-bottom:1px solid #eef2fb;">{item['name']}</td>
          <td style="padding:11px 16px;font-size:13px;color:#1a56a0;font-weight:700;text-align:center;border-bottom:1px solid #eef2fb;">{item['quantity']}</td>
          <td style="padding:11px 16px;font-size:12px;color:#64748b;border-bottom:1px solid #eef2fb;">{item.get('unit','units')}</td>
        </tr>"""

    if delivery_time and delivery_date:
        nice_time = _format_12h(delivery_time)
        delivery_info = f"{delivery_date} at {nice_time}"
    else:
        delivery_info = delivery_time or "As scheduled"
    phone_info = phone if phone else "Not provided"

    body = f"""
    <div style="background:linear-gradient(135deg,#e3f2fd,#bbdefb);border:2px solid #1a56a0;border-radius:12px;padding:18px 20px;margin-bottom:28px;">
      <table width="100%" cellpadding="0" cellspacing="0"><tr>
        <td><div style="font-size:18px;font-weight:800;color:#0d2f6e;">&#128203; New Canteen Order Received</div>
            <div style="font-size:13px;color:#1a56a0;margin-top:2px;">Immediate action required &#8212; please review and confirm</div></td>
        <td style="text-align:right;vertical-align:middle;">
          <div style="background:#1a56a0;color:#fff;font-size:14px;font-weight:800;padding:6px 14px;border-radius:8px;display:inline-block;">#ORD-{order_id:04d}</div>
          <div style="font-size:10px;color:#1a56a0;margin-top:4px;">{order_datetime}</div>
        </td>
      </tr></table>
    </div>

    <table width="100%" cellpadding="0" cellspacing="0" style="margin-bottom:24px;border-collapse:separate;border-spacing:10px 0;">
      <tr>
        <td width="50%" style="vertical-align:top;padding-right:8px;">
          <div style="background:#f8faff;border:1px solid #dce6f5;border-radius:12px;padding:18px 20px;">
            <div style="font-size:11px;font-weight:800;color:#1a56a0;text-transform:uppercase;letter-spacing:1px;padding-bottom:10px;border-bottom:2px solid #dce6f5;margin-bottom:12px;">&#128205; Order Details</div>
            <table cellpadding="0" cellspacing="0" width="100%">
              {_info_row('New Order From', f'<strong>{supervisor_name}</strong>', '&#128100;')}
              {_info_row('Shop / Location', shop_name, '&#127981;')}
              {_info_row('Department', department, '&#127970;')}
              {_info_row('Shift', shift, '&#128336;')}
              {_info_row('People Count', f'<strong style="color:#1a56a0;font-size:15px;">{people_count}</strong> people', '&#128101;')}
            </table>
          </div>
        </td>
        <td width="50%" style="vertical-align:top;padding-left:8px;">
          <div style="background:#f8faff;border:1px solid #dce6f5;border-radius:12px;padding:18px 20px;">
            <div style="font-size:11px;font-weight:800;color:#1a56a0;text-transform:uppercase;letter-spacing:1px;padding-bottom:10px;border-bottom:2px solid #dce6f5;margin-bottom:12px;">&#128204; Delivery &amp; Contact</div>
            <table cellpadding="0" cellspacing="0" width="100%">
              {_info_row('Order ID', f'<strong>#ORD-{order_id:04d}</strong>', '&#128278;')}
              {_info_row('Order Date &amp; Time', order_datetime, '&#128197;')}
              {_info_row('Delivery Time', delivery_info, '&#128666;')}
              {_info_row('Contact Phone', phone_info, '&#128222;')}
            </table>
          </div>
        </td>
      </tr>
    </table>

    <div style="margin-bottom:24px;">
      <div style="font-size:14px;font-weight:800;color:#1e293b;margin-bottom:12px;">&#127869; Order Items ({len(items)} items for {people_count} people)</div>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-radius:12px;overflow:hidden;border:1px solid #dce6f5;">
        <thead><tr style="background:linear-gradient(135deg,#0f3d7a,#1a56a0);">
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Item Name</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Quantity</th>
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:0.5px;">Unit</th>
        </tr></thead>
        <tbody>{items_rows}</tbody>
        <tfoot><tr style="background:#eff6ff;">
          <td colspan="3" style="padding:10px 16px;font-size:12px;font-weight:700;color:#1a56a0;">
            Total: <strong>{len(items)} items</strong> &nbsp;&middot;&nbsp; For <strong>{people_count} people</strong>
          </td>
        </tr></tfoot>
      </table>
    </div>

    <div style="background:linear-gradient(135deg,#fff8e1,#fffde7);border:2px solid #f59e0b;border-radius:12px;padding:16px 20px;text-align:center;">
      <div style="font-size:15px;font-weight:800;color:#92400e;margin-bottom:4px;">&#9889; Action Required</div>
      <div style="font-size:13px;color:#b45309;">Please log into the Canteen Portal to approve or reject this order promptly.</div>
    </div>
    """

    send_email(
        CANTEEN_HEAD_EMAIL,
        f'New Order #ORD-{order_id:04d} from {supervisor_name} | {shop_name} | {shift} | {people_count} people',
        _base_template(body)
    )

def send_reviewer_pin_expiry_warning(to_email, expiry_date, days_left):
    """Warn canteen that reviewer PIN expires soon."""
    expiry_text = expiry_date.strftime('%d %B %Y')
    body = f"""
    <div style="background:#fff7ed;border:2px solid #fb923c;border-radius:12px;padding:18px 20px;margin-bottom:24px;">
      <div style="font-size:20px;font-weight:900;color:#9a3412;margin-bottom:6px;">Reviewer PIN Expiry Alert</div>
      <div style="font-size:14px;color:#9a3412;">
        Your reviewer PIN will expire in <strong>{days_left} day(s)</strong> on <strong>{expiry_text}</strong>.
      </div>
    </div>
    <div style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:16px 18px;margin-bottom:20px;">
      <div style="font-size:13px;color:#334155;line-height:1.8;">
        Please reset the reviewer PIN before expiry to maintain secure approval/rejection access.
      </div>
    </div>
    """
    send_email(
        to_email,
        f'Reviewer PIN expires in {days_left} day(s) - Tata Motors Canteen',
        _base_template(body),
    )

def send_order_status_update(to_email, supervisor_name, order_id, status, notes, items):
    """Sends order status update (Approved/Rejected) to supervisor."""
    now = datetime.now()
    update_datetime = now.strftime("%d %B %Y, %I:%M %p")

    is_approved = status == 'Approved'
    status_color = '#059669' if is_approved else '#dc2626'
    status_bg = '#d1fae5' if is_approved else '#fee2e2'
    status_border = '#6ee7b7' if is_approved else '#fca5a5'
    status_icon = '&#9989;' if is_approved else '&#10060;'

    items_rows = ''
    for i, item in enumerate(items):
        item_status = item.get('status', status)
        s_color = '#059669' if item_status == 'Approved' else ('#dc2626' if item_status in ('Rejected', 'Cancelled') else '#d97706')
        s_bg = '#d1fae5' if item_status == 'Approved' else ('#fee2e2' if item_status in ('Rejected', 'Cancelled') else '#fef3c7')
        bg = '#f8faff' if i % 2 == 0 else '#ffffff'
        items_rows += f"""<tr style="background:{bg};">
          <td style="padding:10px 16px;font-size:13px;font-weight:600;color:#1e293b;border-bottom:1px solid #eef2fb;">{item['item_name']}</td>
          <td style="padding:10px 16px;font-size:13px;color:#1a56a0;font-weight:700;text-align:center;border-bottom:1px solid #eef2fb;">{item['quantity']} {item.get('unit','')}</td>
          <td style="padding:10px 16px;text-align:center;border-bottom:1px solid #eef2fb;">
            <span style="background:{s_bg};color:{s_color};font-size:11px;font-weight:700;padding:3px 10px;border-radius:50px;">{item_status}</span>
          </td>
        </tr>"""

    body = f"""
    <div style="background:{status_bg};border:2px solid {status_border};border-radius:12px;padding:20px 24px;margin-bottom:28px;text-align:center;">
      <div style="font-size:32px;margin-bottom:8px;">{status_icon}</div>
      <div style="font-size:22px;font-weight:900;color:{status_color};margin-bottom:4px;">Order {status}</div>
      <div style="font-size:13px;color:{status_color};opacity:0.85;">{'Your order is confirmed and being prepared.' if is_approved else 'Your order could not be fulfilled at this time.'}</div>
    </div>

    <div style="background:#f8faff;border:1px solid #dce6f5;border-radius:12px;padding:18px 20px;margin-bottom:24px;">
      <div style="font-size:11px;font-weight:800;color:#1a56a0;text-transform:uppercase;letter-spacing:1px;padding-bottom:10px;border-bottom:2px solid #dce6f5;margin-bottom:12px;">&#128203; Order Summary</div>
      <table cellpadding="0" cellspacing="0" width="100%">
        {_info_row('Hi', f'<strong>{supervisor_name}</strong>', '&#128075;')}
        {_info_row('Order ID', f'<strong>#ORD-{order_id:04d}</strong>', '&#128278;')}
        {_info_row('Status', f'<strong style="color:{status_color};">{status}</strong>', '&#128204;')}
        {_info_row('Updated At', update_datetime, '&#128336;')}
      </table>
    </div>

    <div style="margin-bottom:24px;">
      <div style="font-size:14px;font-weight:800;color:#1e293b;margin-bottom:12px;">&#127869; Item Status</div>
      <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-radius:12px;overflow:hidden;border:1px solid #dce6f5;">
        <thead><tr style="background:linear-gradient(135deg,#0f3d7a,#1a56a0);">
          <th style="padding:12px 16px;text-align:left;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;">Item</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;">Quantity</th>
          <th style="padding:12px 16px;text-align:center;font-size:11px;font-weight:700;color:#fff;text-transform:uppercase;">Status</th>
        </tr></thead>
        <tbody>{items_rows}</tbody>
      </table>
    </div>

    {'<div style="background:#fffbeb;border:1px solid #fde68a;border-radius:12px;padding:16px 20px;margin-bottom:24px;"><div style="font-size:13px;font-weight:800;color:#92400e;margin-bottom:6px;">&#128221; Note from Canteen</div><div style="font-size:13px;color:#78350f;">' + notes + '</div></div>' if notes else ''}

    <div style="background:{'#ecfdf5' if is_approved else '#fff1f2'};border-radius:10px;padding:14px 20px;text-align:center;border:1px solid {'#a7f3d0' if is_approved else '#fecdd3'};">
      <div style="font-size:13px;color:{'#065f46' if is_approved else '#9f1239'};">
        {'&#128640; Your order is being prepared. Please be ready at the delivery location.' if is_approved else '&#128222; For queries, please contact your canteen.'}
      </div>
    </div>
    """

    send_email(
        [to_email, CANTEEN_DWD_EMAIL] if is_approved else to_email,
        f'Order #{order_id:04d} {status} - Tata Motors Canteen',
        _base_template(body)
    )
