#!/bin/bash
# Quick dev mode — Flask built-in server, auto-reload
cd "$(dirname "$0")/backend"
PORT="${PORT:-48000}" python app.py
