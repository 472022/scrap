from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for

supervisor_app = Blueprint(
    'supervisor_app',
    __name__,
    template_folder='templates',
    static_folder='static'
)

# Default supervisor context (no login needed)
DEFAULT_SUPERVISOR = {
    'id': 1,
    'name': 'Supervisor',
    'email': 'supervisor1@tata.com',
    'department': 'General'
}

def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user' not in session or session.get('user_type') != 'supervisor':
            return redirect(url_for('.login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@supervisor_app.route('/login')
def login():
    if 'user' in session and session.get('user_type') == 'supervisor':
        return redirect(url_for('supervisor_app.dashboard'))
    # Avoid template name collision with canteen_app/templates/login.html.
    return render_template('login_new.html')

@supervisor_app.route('/register')
def register():
    return render_template('register.html')

@supervisor_app.route('/')
def index():
    return redirect(url_for('supervisor_app.dashboard'))

@supervisor_app.route('/dashboard')
@login_required
def dashboard():
    return render_template('supervisor_dashboard.html', supervisor=session['user'])

@supervisor_app.route('/new-order')
@login_required
def new_order():
    return render_template('supervisor_new_order.html', supervisor=session['user'])

@supervisor_app.route('/order-history')
@login_required
def order_history():
    return render_template('supervisor_order_history.html', supervisor=session['user'])

@supervisor_app.route('/order/<int:order_id>')
@login_required
def order_detail(order_id):
    return render_template('supervisor_order_detail.html', supervisor=session['user'], order_id=order_id)

@supervisor_app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('user_type', None)
    return redirect(url_for('supervisor_app.login'))

@supervisor_app.route('/ping')
def ping():
    if 'user' in session and session.get('user_type') == 'supervisor':
        return jsonify({'alive': True, 'user': session['user']['name']})
    return jsonify({'alive': True})
