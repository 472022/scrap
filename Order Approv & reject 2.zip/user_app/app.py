from flask import Blueprint, render_template

user_app = Blueprint(
    'user_app',
    __name__,
    template_folder='templates',
    static_folder='static'
)

@user_app.route('/')
def index():
    return render_template('order.html', active_page='order_food')

@user_app.route('/closer/')
def closer():
    return render_template('closer.html', active_page='closer_food')

@user_app.route('/ping')
def ping():
    return {'status': 'ok'}
