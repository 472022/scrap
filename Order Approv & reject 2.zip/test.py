import win32com.client as win32

FROM_SMTP = "canteendwd@tatamotors.com"  # the account to send as
TO = "prathameshhalale@gmail.com"

outlook = win32.Dispatch("Outlook.Application")
session = outlook.Session  # MAPI namespace

# Create a mail first (so .SendUsingAccount can be applied)
mail = outlook.CreateItem(0)  # 0 = olMailItem
mail.To = TO
mail.Subject = "Test - send using specific Outlook account"
mail.HTMLBody = "<b>Hello</b> from Python + Outlook, sent using a chosen account."

# Find the matching Account object by its SMTP address
accounts = session.Accounts
chosen = None
for i in range(1, accounts.Count + 1):
    acct = accounts.Item(i)
    try:
        if acct.SmtpAddress.lower() == FROM_SMTP.lower():
            chosen = acct
            break
    except Exception:
        # Some account types may not expose SmtpAddress cleanly; ignore & continue
        pass

if not chosen:
    raise RuntimeError(f"Could not find Outlook account with SMTP '{FROM_SMTP}'. "
                       f"Available: {[accounts.Item(i).DisplayName for i in range(1, accounts.Count+1)]}")

# Tell Outlook to send USING this account
mail._oleobj_.Invoke(*(64209, 0, 8, 0, chosen))  # Set 'SendUsingAccount' COM property
# Alternative (sometimes works depending on pywin32 build):
# mail.SendUsingAccount = chosen

# Optional: add attachments
# mail.Attachments.Add(r"C:\path\report.pdf")

mail.Send()  # or mail.Display() to preview before sending
print("Mail sent using account:", chosen.DisplayName, chosen.SmtpAddress)