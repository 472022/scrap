# MySQL Migration Guide for Canteen Application

## Overview

Your canteen application consists of 2 main projects:
1. **canteen_final** (main project)
2. **canteen_out_updated** (updated version)

Both have SQLite databases (`canteen.db`) that need to be migrated to MySQL (`canteen_db`).

## Project Structure

```
canteen_final/
├── backend/                    # Flask backend API
│   ├── canteen.db             # SQLite database (SOURCE)
│   ├── database.py            # Database abstraction layer
│   ├── app.py                 # Main Flask app
│   ├── requirements.txt
│   └── .env                   # ✓ Configuration file (created)
├── canteen_app/               # Canteen user blueprint
├── supervisor_app/            # Supervisor blueprint
├── migrate_to_mysql.py        # ✓ Migration script (created)
└── requirements.txt

canteen_out_updated/
├── backend/                   # Updated backend
│   ├── canteen.db            # SQLite database (SOURCE)
│   ├── .env                  # ✓ Configuration file (created)
│   └── database.py           # Same as main
├── migrate_to_mysql.py       # ✓ Migration script (created)
└── ...
```

---

## Step 1: Ensure MySQL is Running

```bash
# On Windows (if using MySQL Service)
# MySQL should be running at localhost:3306

# Verify connection
mysql -h localhost -u root -padmin123 -e "SELECT 1;"
```

If MySQL is not installed, download from: https://dev.mysql.com/downloads/mysql/

---

## Step 2: Create MySQL Database

Run this command to create the `canteen_db` database:

```bash
mysql -h localhost -u root -padmin123 -e "CREATE DATABASE IF NOT EXISTS canteen_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
```

Verify it was created:
```bash
mysql -h localhost -u root -padmin123 -e "SHOW DATABASES;"
```

---

## Step 3: Migrate Data - canteen_final Project

Navigate to the project directory in PowerShell/Command Prompt:

```powershell
cd c:\Users\ssp860833\Documents\Projects\canteen_final
```

Install required dependencies (if not already installed):
```powershell
pip install mysql-connector-python
```

Run the migration script:
```powershell
python migrate_to_mysql.py
```

**Expected Output:**
```
============================================================
  SQLite → MySQL Data Migration
============================================================

📋 Configuration:
  SQLite: backend/canteen.db
  MySQL:  root@localhost:3306/canteen_db

🔌 Connecting to SQLite...
✓ SQLite connected
🔌 Connecting to MySQL...
✓ MySQL connected

📊 Creating/verifying tables...
✓ Table created/verified
✓ Table created/verified
✓ Table created/verified
✓ Table created/verified

📤 Migrating data...
✓ supervisors: Migrated X rows
✓ canteen_users: Migrated X rows
✓ orders: Migrated X rows
✓ order_items: Migrated X rows

✅ Migration completed successfully!
============================================================
```

---

## Step 4: Migrate Data - canteen_out_updated Project (Optional)

If you have data in the updated version as well:

```powershell
cd c:\Users\ssp860833\Documents\Projects\canteen_final\canteen_out_updated

python migrate_to_mysql.py
```

---

## Step 5: Run Your Application with MySQL

Now your application is configured to use MySQL. To start the backend:

```powershell
cd c:\Users\ssp860833\Documents\Projects\canteen_final\backend

# Install dependencies
pip install -r requirements.txt

# Run the app
python app.py
```

The app will automatically use the MySQL database configured in `.env`.

---

## Step 6: Verify Migration

Check the data in MySQL:

```bash
mysql -h localhost -u root -padmin123 canteen_db

# Inside MySQL console:
SHOW TABLES;

SELECT COUNT(*) as supervisor_count FROM supervisors;
SELECT COUNT(*) as user_count FROM canteen_users;
SELECT COUNT(*) as order_count FROM orders;
SELECT COUNT(*) as item_count FROM order_items;

# View some data
SELECT * FROM supervisors;
SELECT * FROM canteen_users;
SELECT * FROM orders LIMIT 5;
```

---

## Configuration Files Created

### `/backend/.env` - Main Project
```
DB_HOST=localhost
DB_PORT=3306
DB_NAME=canteen_db
DB_USER=root
DB_PASSWORD=admin123
USE_SQLITE=false
PORT=48000
```

### `/canteen_out_updated/backend/.env` - Updated Project
Same configuration as above.

---

## Database Schema

The migration creates 4 tables:

### supervisors
- **id** (INT, Primary Key, Auto Increment)
- **name** (VARCHAR)
- **email** (VARCHAR, Unique)
- **password** (VARCHAR)
- **department** (VARCHAR)
- **created_at** (TIMESTAMP)

### canteen_users
- **id** (INT, Primary Key, Auto Increment)
- **username** (VARCHAR, Unique)
- **password** (VARCHAR)
- **email** (VARCHAR)
- **created_at** (TIMESTAMP)

### orders
- **id** (INT, Primary Key, Auto Increment)
- **supervisor_id** (INT)
- **supervisor_name** (VARCHAR)
- **supervisor_email** (VARCHAR)
- **department** (VARCHAR)
- **shop_name** (VARCHAR)
- **shift** (VARCHAR)
- **people_count** (INT)
- **delivery_date** (VARCHAR)
- **delivery_time** (VARCHAR)
- **status** (VARCHAR, Default: 'Pending')
- **canteen_notes** (TEXT)
- **created_at** (TIMESTAMP)
- **updated_at** (TIMESTAMP)

### order_items
- **id** (INT, Primary Key, Auto Increment)
- **order_id** (INT)
- **item_name** (VARCHAR)
- **quantity** (INT)
- **unit** (VARCHAR, Default: 'units')
- **status** (VARCHAR, Default: 'Pending')
- **rejection_reason** (TEXT)

---

## Troubleshooting

### Connection Refused
```
Error: MySQL connection refused at localhost:3306
```
**Solution:** Ensure MySQL is running. Start MySQL Service on Windows.

### Authentication Failed
```
Error: Access denied for user 'root'@'localhost'
```
**Solution:** Verify username and password in `.env` file match your MySQL credentials.

### Database Not Found
```
Error: Unknown database 'canteen_db'
```
**Solution:** Run the database creation command from Step 2.

### mysql-connector-python Not Installed
```
Error: No module named 'mysql'
```
**Solution:** Run `pip install mysql-connector-python`

---

## Rollback to SQLite (if needed)

To revert to SQLite, edit `.env` and set:
```
USE_SQLITE=true
```

---

## Additional Notes

- The migration script uses `INSERT IGNORE` to skip duplicate entries
- All data from SQLite is preserved with auto-increment IDs
- Default users are automatically seeded if they don't exist
- Both projects share the same `canteen_db` MySQL database
- The application's database abstraction layer (database.py) automatically detects the configuration

---

For questions or issues, check the application logs and `.env` configuration.
