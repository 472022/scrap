"""
database.py — Unified DB layer for Tata Motors Canteen System
-------------------------------------------------------------
Driver priority (controlled via .env / environment variables):

  1. SQLite  (USE_SQLITE=true  OR  no MySQL credentials set)  ← local dev / testing
  2. pyodbc  (USE_PYODBC=true  AND  MySQL creds set)
  3. mysql-connector-python  (default when MySQL creds are present)

No code outside this file needs to change when switching drivers.
"""

import os
import sqlite3


# ---------------------------------------------------------------------------
# .env loader
# ---------------------------------------------------------------------------

def _load_local_env():
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if not os.path.exists(env_path):
        return
    with open(env_path, 'r', encoding='utf-8') as f:
        for raw_line in f:
            line = raw_line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            key, value = line.split('=', 1)
            key, value = key.strip(), value.strip()
            if key and key not in os.environ:
                os.environ[key] = value


def _db_config():
    _load_local_env()
    return {
        'host':       os.environ.get('DB_HOST', ''),
        'port':       int(os.environ.get('DB_PORT', '3306')),
        'database':   os.environ.get('DB_NAME', ''),
        'user':       os.environ.get('DB_USER', ''),
        'password':   os.environ.get('DB_PASSWORD', ''),
        'driver':     os.environ.get('DB_DRIVER', ''),
        'use_pyodbc': os.environ.get('USE_PYODBC', 'false').lower() == 'true',
        'use_sqlite': os.environ.get('USE_SQLITE', 'false').lower() == 'true',
    }


def _mysql_creds_present(config):
    return all([config['host'], config['database'], config['user'], config['password']])


# ---------------------------------------------------------------------------
# SQLite — dict-row wrapper (sqlite3 rows support both index & key access
#          when row_factory=sqlite3.Row, but we wrap for a uniform API)
# ---------------------------------------------------------------------------

class _SQLiteCursorWrapper:
    """Wraps sqlite3 cursor so rows behave like mysql dict rows."""

    def __init__(self, cursor):
        self._cursor = cursor

    @property
    def lastrowid(self):
        return self._cursor.lastrowid

    def fetchone(self):
        return self._cursor.fetchone()   # already a sqlite3.Row (dict-like)

    def fetchall(self):
        return self._cursor.fetchall()   # list of sqlite3.Row

    def __iter__(self):
        return iter(self._cursor)


class _SQLiteConnection:
    def __init__(self, conn):
        self._conn = conn

    def execute(self, query, params=None):
        # Translate MySQL-style backtick identifiers → plain (SQLite ignores them)
        # and AUTO_INCREMENT → AUTOINCREMENT for CREATE TABLE statements
        q = _mysql_to_sqlite_sql(query)
        cur = self._conn.execute(q, params or ())
        return _SQLiteCursorWrapper(cur)

    def commit(self):
        self._conn.commit()

    def close(self):
        self._conn.close()


def _mysql_to_sqlite_sql(sql):
    """Minimal MySQL→SQLite DDL translation used only for CREATE TABLE."""
    import re
    s = sql
    # AUTO_INCREMENT → AUTOINCREMENT (only inside PRIMARY KEY INT col def)
    s = re.sub(r'\bAUTO_INCREMENT\b', 'AUTOINCREMENT', s, flags=re.IGNORECASE)
    # Remove ON UPDATE CURRENT_TIMESTAMP (not supported in SQLite)
    s = re.sub(r'\s*ON UPDATE CURRENT_TIMESTAMP', '', s, flags=re.IGNORECASE)
    # INT PRIMARY KEY AUTOINCREMENT → INTEGER PRIMARY KEY AUTOINCREMENT
    s = re.sub(r'\bINT\s+PRIMARY KEY\s+AUTOINCREMENT\b',
               'INTEGER PRIMARY KEY AUTOINCREMENT', s, flags=re.IGNORECASE)
    # Remove MySQL-only column types precision, e.g. VARCHAR(255) → TEXT
    s = re.sub(r'\bVARCHAR\s*\(\d+\)', 'TEXT', s, flags=re.IGNORECASE)
    # TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    s = re.sub(r'\bTIMESTAMP\b', 'TEXT', s, flags=re.IGNORECASE)
    # Remove FOREIGN KEY constraints (SQLite supports them but needs PRAGMA)
    s = re.sub(r',?\s*FOREIGN KEY\s*\([^)]+\)\s*REFERENCES\s*\w+\s*\([^)]+\)',
               '', s, flags=re.IGNORECASE)
    # INSERT IGNORE → INSERT OR IGNORE
    s = re.sub(r'\bINSERT IGNORE\b', 'INSERT OR IGNORE', s, flags=re.IGNORECASE)
    return s


# ---------------------------------------------------------------------------
# pyodbc helpers
# ---------------------------------------------------------------------------

class _PyodbcCursorWrapper:
    def __init__(self, cursor):
        self._cursor = cursor

    @property
    def lastrowid(self):
        self._cursor.execute("SELECT LAST_INSERT_ID()")
        row = self._cursor.fetchone()
        return row[0] if row else None

    def fetchone(self):
        row = self._cursor.fetchone()
        if row is None:
            return None
        cols = [d[0] for d in self._cursor.description]
        return _DictRow(cols, row)

    def fetchall(self):
        cols = [d[0] for d in self._cursor.description]
        return [_DictRow(cols, r) for r in self._cursor.fetchall()]

    def __iter__(self):
        cols = [d[0] for d in self._cursor.description]
        for row in self._cursor:
            yield _DictRow(cols, row)


class _DictRow:
    def __init__(self, columns, values):
        self._data = dict(zip(columns, values))
        self._list = list(values)

    def __getitem__(self, key):
        return self._list[key] if isinstance(key, int) else self._data[key]

    def __iter__(self):
        return iter(self._data)

    def keys(self):
        return self._data.keys()

    def get(self, key, default=None):
        return self._data.get(key, default)

    def __contains__(self, key):
        return key in self._data


class _PyodbcConnection:
    def __init__(self, conn):
        self._conn = conn

    def execute(self, query, params=None):
        cur = self._conn.cursor()
        cur.execute(query, params or ())
        return _PyodbcCursorWrapper(cur)

    def commit(self):
        self._conn.commit()

    def close(self):
        self._conn.close()


# ---------------------------------------------------------------------------
# mysql-connector wrapper (keeps original DBConnection interface)
# ---------------------------------------------------------------------------

class _MySQLConnection:
    def __init__(self, conn):
        self._conn = conn

    def execute(self, query, params=None):
        cursor = self._conn.cursor(dictionary=True)
        cursor.execute(query, params or ())
        return cursor

    def commit(self):
        self._conn.commit()

    def close(self):
        self._conn.close()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_SQLITE_PATH = os.path.join(os.path.dirname(__file__), 'canteen.db')


def get_db():
    config = _db_config()

    # ── SQLite (local dev / no MySQL creds) ──────────────────────────────────
    if config['use_sqlite'] or not _mysql_creds_present(config):
        conn = sqlite3.connect(_SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return _SQLiteConnection(conn)

    # ── pyodbc ────────────────────────────────────────────────────────────────
    if config['use_pyodbc']:
        try:
            import pyodbc
        except ImportError:
            raise ImportError("pyodbc not installed. Run: pip install pyodbc --break-system-packages")
        driver = config['driver'] or 'MySQL ODBC 8.0 Unicode Driver'
        conn_str = (
            f"DRIVER={{{driver}}};"
            f"SERVER={config['host']};PORT={config['port']};"
            f"DATABASE={config['database']};"
            f"UID={config['user']};PWD={config['password']};"
            "charset=utf8mb4;"
        )
        return _PyodbcConnection(pyodbc.connect(conn_str, autocommit=False))

    # ── mysql-connector-python (default) ─────────────────────────────────────
    try:
        import mysql.connector
    except ImportError:
        raise ImportError(
            "mysql-connector-python not installed. "
            "Run: pip install mysql-connector-python --break-system-packages"
        )
    conn = mysql.connector.connect(
        host=config['host'], port=config['port'],
        user=config['user'], password=config['password'],
        database=config['database'],
    )
    return _MySQLConnection(conn)


# ---------------------------------------------------------------------------
# Schema init (works for both SQLite and MySQL)
# ---------------------------------------------------------------------------

def init_db():
    conn = get_db()
    c = conn.execute

    c('''CREATE TABLE IF NOT EXISTS supervisors (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        department VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    c('''CREATE TABLE IF NOT EXISTS canteen_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    c('''CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        supervisor_id INT,
        supervisor_name VARCHAR(255) NOT NULL,
        supervisor_email VARCHAR(255) NOT NULL,
        department VARCHAR(255) NOT NULL,
        shop_name VARCHAR(255) NOT NULL,
        shift VARCHAR(255) NOT NULL,
        people_count INT NOT NULL,
        delivery_date VARCHAR(50),
        delivery_time VARCHAR(50),
        status VARCHAR(50) DEFAULT 'Pending',
        canteen_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    c('''CREATE TABLE IF NOT EXISTS order_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_id INT NOT NULL,
        item_name VARCHAR(255) NOT NULL,
        quantity INT NOT NULL,
        unit VARCHAR(50) DEFAULT 'units',
        status VARCHAR(50) DEFAULT 'Pending',
        rejection_reason TEXT
    )''')

    c("INSERT OR IGNORE INTO supervisors (name, email, password, department) "
      "VALUES ('Admin Supervisor', 'supervisor@tata.com', 'pass123', 'General')")

    c("INSERT OR IGNORE INTO canteen_users (username, password, email) "
      "VALUES ('canteen', 'canteen123', 'canteen@tata.com')")

    conn.commit()
    conn.close()
    print("[DB] Initialized successfully.")
