from flask import Blueprint, render_template, request, jsonify

supervisor_app = Blueprint(
    'supervisor_app',
    __name__,
    template_folder='templates',
    static_folder='static'
)

# Default supervisor context (no login needed)
DEFAULT_SUPERVISOR = {
    'id': 1,
    'name': 'Supervisor',
    'email': 'supervisor1@tata.com',
    'department': 'General'
}

@supervisor_app.route('/')
def index():
    return render_template('supervisor_dashboard.html', supervisor=DEFAULT_SUPERVISOR)

@supervisor_app.route('/dashboard')
def dashboard():
    return render_template('supervisor_dashboard.html', supervisor=DEFAULT_SUPERVISOR)

@supervisor_app.route('/new-order')
def new_order():
    return render_template('supervisor_new_order.html', supervisor=DEFAULT_SUPERVISOR)

@supervisor_app.route('/order-history')
def order_history():
    return render_template('supervisor_order_history.html', supervisor=DEFAULT_SUPERVISOR)

@supervisor_app.route('/order/<int:order_id>')
def order_detail(order_id):
    return render_template('supervisor_order_detail.html', supervisor=DEFAULT_SUPERVISOR, order_id=order_id)

@supervisor_app.route('/ping')
def ping():
    return jsonify({'alive': True, 'user': DEFAULT_SUPERVISOR['name']})
