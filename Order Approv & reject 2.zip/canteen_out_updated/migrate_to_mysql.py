"""
migrate_to_mysql.py - For canteen_out_updated project
------------------------------------------------------
Migrates data from SQLite (canteen.db) to MySQL (canteen_db)

Usage:
  python migrate_to_mysql.py

Environment variables (optional, defaults shown):
  DB_HOST=localhost
  DB_PORT=3306
  DB_NAME=canteen_db
  DB_USER=root
  DB_PASSWORD=admin123
"""

import os
import sys
import sqlite3
import mysql.connector
from mysql.connector import Error as MySQLError


def load_env():
    """Load .env file if it exists."""
    env_path = os.path.join(os.path.dirname(__file__), '.env')
    if os.path.exists(env_path):
        with open(env_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#') or '=' not in line:
                    continue
                key, value = line.split('=', 1)
                key = key.strip()
                if key not in os.environ:
                    os.environ[key] = value.strip()


def get_mysql_config():
    """Get MySQL configuration from environment or defaults."""
    return {
        'host': os.environ.get('DB_HOST', 'localhost'),
        'port': int(os.environ.get('DB_PORT', '3306')),
        'user': os.environ.get('DB_USER', 'root'),
        'password': os.environ.get('DB_PASSWORD', 'admin123'),
        'database': os.environ.get('DB_NAME', 'canteen_db'),
    }


def connect_mysql(config):
    """Connect to MySQL server."""
    try:
        conn = mysql.connector.connect(
            host=config['host'],
            port=config['port'],
            user=config['user'],
            password=config['password'],
            database=config['database'],
            charset='utf8mb4',
            use_unicode=True,
        )
        return conn
    except MySQLError as e:
        print(f"❌ MySQL connection error: {e}")
        raise


def connect_sqlite():
    """Connect to SQLite database."""
    db_path = os.path.join(os.path.dirname(__file__), 'canteen.db')
    if not os.path.exists(db_path):
        print(f"❌ SQLite database not found at: {db_path}")
        sys.exit(1)
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def create_tables_mysql(mysql_conn):
    """Create tables in MySQL if they don't exist."""
    cursor = mysql_conn.cursor()
    
    tables = [
        '''CREATE TABLE IF NOT EXISTS supervisors (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            department VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
        
        '''CREATE TABLE IF NOT EXISTS canteen_users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
        
        '''CREATE TABLE IF NOT EXISTS orders (
            id INT PRIMARY KEY AUTO_INCREMENT,
            supervisor_id INT,
            supervisor_name VARCHAR(255) NOT NULL,
            supervisor_email VARCHAR(255) NOT NULL,
            department VARCHAR(255) NOT NULL,
            shop_name VARCHAR(255) NOT NULL,
            shift VARCHAR(255) NOT NULL,
            people_count INT NOT NULL,
            delivery_date VARCHAR(50),
            delivery_time VARCHAR(50),
            status VARCHAR(50) DEFAULT 'Pending',
            canteen_notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
        
        '''CREATE TABLE IF NOT EXISTS order_items (
            id INT PRIMARY KEY AUTO_INCREMENT,
            order_id INT NOT NULL,
            item_name VARCHAR(255) NOT NULL,
            quantity INT NOT NULL,
            unit VARCHAR(50) DEFAULT 'units',
            status VARCHAR(50) DEFAULT 'Pending',
            rejection_reason TEXT,
            KEY fk_order_id (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci''',
    ]
    
    for table_sql in tables:
        try:
            cursor.execute(table_sql)
            print(f"✓ Table created/verified")
        except MySQLError as e:
            print(f"⚠ Table creation error (may be expected): {e}")
    
    mysql_conn.commit()
    cursor.close()


def migrate_data(sqlite_conn, mysql_conn):
    """Migrate data from SQLite to MySQL."""
    
    tables = [
        ('supervisors', ['id', 'name', 'email', 'password', 'department', 'created_at']),
        ('canteen_users', ['id', 'username', 'password', 'email', 'created_at']),
        ('orders', ['id', 'supervisor_id', 'supervisor_name', 'supervisor_email', 'department',
                   'shop_name', 'shift', 'people_count', 'delivery_date', 'delivery_time',
                   'status', 'canteen_notes', 'created_at', 'updated_at']),
        ('order_items', ['id', 'order_id', 'item_name', 'quantity', 'unit', 'status', 'rejection_reason']),
    ]
    
    sqlite_cursor = sqlite_conn.cursor()
    mysql_cursor = mysql_conn.cursor()
    
    for table_name, columns in tables:
        try:
            # Check if table exists in SQLite
            sqlite_cursor.execute(f"SELECT COUNT(*) as cnt FROM {table_name}")
            count = sqlite_cursor.fetchone()[0]
            
            if count == 0:
                print(f"  {table_name}: No data to migrate")
                continue
            
            # Read data from SQLite
            column_str = ', '.join(columns)
            sqlite_cursor.execute(f"SELECT {column_str} FROM {table_name}")
            rows = sqlite_cursor.fetchall()
            
            # Insert data into MySQL (skip duplicates on email/username)
            placeholders = ', '.join(['%s'] * len(columns))
            insert_sql = f"INSERT IGNORE INTO {table_name} ({column_str}) VALUES ({placeholders})"
            
            for row in rows:
                try:
                    mysql_cursor.execute(insert_sql, row)
                except MySQLError as e:
                    print(f"    Warning: Failed to insert row in {table_name}: {e}")
                    continue
            
            mysql_conn.commit()
            print(f"✓ {table_name}: Migrated {len(rows)} rows")
            
        except sqlite3.OperationalError as e:
            print(f"⚠ {table_name}: Table not found or error: {e}")
        except MySQLError as e:
            print(f"❌ {table_name}: MySQL error: {e}")
    
    sqlite_cursor.close()
    mysql_cursor.close()


def main():
    """Main migration function."""
    print("=" * 60)
    print("  SQLite → MySQL Data Migration (canteen_out_updated)")
    print("=" * 60)
    
    # Load environment variables
    load_env()
    
    # Get configurations
    mysql_config = get_mysql_config()
    
    print(f"\n📋 Configuration:")
    print(f"  SQLite: backend/canteen.db")
    print(f"  MySQL:  {mysql_config['user']}@{mysql_config['host']}:{mysql_config['port']}/{mysql_config['database']}")
    
    try:
        # Connect to databases
        print(f"\n🔌 Connecting to SQLite...")
        sqlite_conn = connect_sqlite()
        print(f"✓ SQLite connected")
        
        print(f"🔌 Connecting to MySQL...")
        mysql_conn = connect_mysql(mysql_config)
        print(f"✓ MySQL connected")
        
        # Create tables
        print(f"\n📊 Creating/verifying tables...")
        create_tables_mysql(mysql_conn)
        
        # Migrate data
        print(f"\n📤 Migrating data...")
        migrate_data(sqlite_conn, mysql_conn)
        
        # Close connections
        sqlite_conn.close()
        mysql_conn.close()
        
        print(f"\n✅ Migration completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Migration failed: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
