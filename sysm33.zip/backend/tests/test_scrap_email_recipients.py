from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def _patch_email_sending(sn):
    calls: list[dict[str, object]] = []

    def fake_send_outlook_email(*, to, subject, html_body, sender=None, cc=None):
        calls.append({"to": to, "cc": cc, "sender": sender, "subject": subject, "html_body": html_body})
        return sn.OutlookSendResult(success=True)

    sn.send_outlook_email = fake_send_outlook_email
    sn.render_template = lambda *args, **kwargs: "<html></html>"
    sn._log_email_attempt = lambda *args, **kwargs: None
    return calls


def test_new_request_email_includes_settings_admins_in_cc() -> None:
    from app.email import scrap_notifications as sn

    calls = _patch_email_sending(sn)
    settings = sn.ScrapEmailSettings(
        admin_notify_to="admin1@example.com; admin2@example.com",
        outlook_sender="sender@example.com",
        cc="cc1@example.com,cc2@example.com",
    )
    row = {"id": 10, "email": "user@example.com", "ticket_no": "T-001"}

    result = sn.send_new_request_email(None, request_row=row, settings=settings)
    assert result.success is True
    assert calls == [
        {
            "to": ("user@example.com",),
            "cc": ("admin1@example.com", "admin2@example.com", "cc1@example.com", "cc2@example.com"),
            "sender": "sender@example.com",
            "subject": "New Scrap Pickup Request - Ticket T-001",
            "html_body": "<html></html>",
        }
    ]


def test_new_request_email_falls_back_to_admins_if_user_email_missing() -> None:
    from app.email import scrap_notifications as sn

    calls = _patch_email_sending(sn)
    settings = sn.ScrapEmailSettings(
        admin_notify_to="admin1@example.com, admin2@example.com",
        outlook_sender="",
        cc="cc1@example.com;cc2@example.com",
    )
    row = {"id": 11, "email": "", "ticket_no": "T-002"}

    result = sn.send_new_request_email(None, request_row=row, settings=settings)
    assert result.success is True
    assert calls[0]["to"] == ("admin1@example.com", "admin2@example.com")
    assert calls[0]["cc"] == ("cc1@example.com", "cc2@example.com")


def test_acceptance_email_sends_to_user_and_ccs_admin_settings() -> None:
    from app.email import scrap_notifications as sn

    calls = _patch_email_sending(sn)
    settings = sn.ScrapEmailSettings(
        admin_notify_to="ADMIN1@example.com, admin1@example.com, admin2@example.com",
        outlook_sender="sender@example.com",
        cc="cc@example.com",
    )
    row = {"id": 12, "email": "user@example.com"}

    result = sn.send_acceptance_email(None, request_row=row, settings=settings)
    assert result.success is True
    assert calls[0]["to"] == "user@example.com"
    assert calls[0]["cc"] == ("ADMIN1@example.com", "admin2@example.com", "cc@example.com")


def test_reschedule_email_sends_to_user_and_ccs_admin_settings() -> None:
    from app.email import scrap_notifications as sn

    calls = _patch_email_sending(sn)
    settings = sn.ScrapEmailSettings(
        admin_notify_to="admin@example.com",
        outlook_sender="",
        cc="",
    )
    row = {"id": 13, "email": "user@example.com"}

    result = sn.send_reschedule_email(None, request_row=row, settings=settings)
    assert result.success is True
    assert calls[0]["to"] == "user@example.com"
    assert calls[0]["cc"] == ("admin@example.com",)
