from __future__ import annotations

from pathlib import Path


def test_memo_parser_is_internal() -> None:
    from app.modules.memo import pdf_parser

    src = Path(pdf_parser.__file__).read_text(encoding="utf-8")
    assert "sys.path.insert" not in src
    assert "tools_dir" not in src
    assert "parents[5]" not in src


def test_memo_parse_module_exists() -> None:
    from app.modules.memo import parse_memo_pdf

    assert callable(parse_memo_pdf.parse_pdf)

