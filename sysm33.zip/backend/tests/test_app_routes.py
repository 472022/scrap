from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def test_app_builds() -> None:
    from app import create_app

    app = create_app()
    assert app is not None


def test_key_routes_registered() -> None:
    from app import create_app

    app = create_app()
    rules = {r.rule for r in app.url_map.iter_rules()}

    assert "/scratch/auth/login" in rules
    assert "/scratch/dashboard" in rules
    assert "/scratch/dashboard/api/summary" in rules
    assert "/scratch/memo/list" in rules
    assert "/scratch/mutilation/list" in rules
    assert "/scratch/segregation/list" in rules
    assert "/scratch/outward/list" in rules
    assert "/scratch/inventory/list" in rules
    assert "/scratch/reports" in rules
    assert "/scratch/reports/schedules" in rules
    assert "/scratch/requests" in rules
    assert "/scratch/settings/pricing" in rules
    assert "/scratch/settings/categories" in rules
    assert "/scratch/settings/lots" in rules
    assert "/scratch/settings/parts" in rules
    assert "/scratch/settings/expiry" in rules
    assert "/scratch/settings/uoms" in rules
    assert "/scratch/settings/counterparties" in rules
    assert "/scrap-request" in rules
    assert "/scrap-admin/login" in rules
    assert "/scrap-admin/logout" in rules
    assert "/scrap-admin/create_admin" in rules
    assert "/scrap-admin/requests" in rules
    assert "/scrap-admin/settings" in rules


def test_no_php_routes_registered() -> None:
    from app import create_app

    app = create_app()
    rules = [r.rule for r in app.url_map.iter_rules()]
    assert all(".php" not in r for r in rules)
