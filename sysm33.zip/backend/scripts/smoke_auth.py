import re

import requests


def main() -> None:
    s = requests.Session()
    html = s.get("http://127.0.0.1:8000/scratch/auth/login").text
    m = re.search(r'name="csrf_token" value="([^"]+)"', html)
    token = m.group(1) if m else ""
    r = s.post(
        "http://127.0.0.1:8000/scratch/auth/login",
        data={"csrf_token": token, "username": "sqpdcme", "password": "sqpdcme123"},
        allow_redirects=False,
    )
    print(r.status_code, r.headers.get("Location"))


if __name__ == "__main__":
    main()
