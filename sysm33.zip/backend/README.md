# Backend Notes

Project-level documentation is maintained in:

- `../README.md`

Quick backend run:

```powershell
cd "E:\projects\Tata Motors\syms\backend"
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python run.py
```
