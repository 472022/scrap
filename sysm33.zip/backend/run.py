from __future__ import annotations

import os

from app import create_app

app = create_app()

if __name__ == "__main__":
    host = (os.getenv("SYMS_HOST") or "10.146.248.77").strip() or "10.146.248.77"
    port = int(os.getenv("SYMS_PORT") or "8002")
    debug = (os.getenv("SYMS_DEBUG") or "0").strip() not in {"0", "false", "False", "no", "NO"}
    app.run(host=host, port=port, debug=debug)
