from __future__ import annotations

from app.db.query import execute, fetch_one


def app_setting_get(conn, key: str, default: str = "") -> str:
    row = fetch_one(conn, "SELECT setting_value FROM app_settings WHERE setting_key = :k LIMIT 1", {"k": key}) or {}
    v = str(row.get("setting_value") or "").strip()
    return v if v != "" else default


def app_setting_set(conn, key: str, value: str) -> None:
    execute(
        conn,
        "INSERT INTO app_settings (setting_key, setting_value, updated_at)\n"
        "VALUES (:k, :v, NOW())\n"
        "ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()",
        {"k": key, "v": str(value)},
    )

