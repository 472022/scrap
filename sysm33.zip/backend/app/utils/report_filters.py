from __future__ import annotations

from datetime import date, timedelta

from flask import request


def _date_defaults() -> tuple[str, str]:
    today = date.today().isoformat()
    return today, today


def read_filters() -> dict[str, object]:
    preset = (request.args.get("preset") or "").strip()
    from_s = (request.args.get("from") or "").strip()
    to_s = (request.args.get("to") or "").strip()

    if preset:
        end = date.today()
        if preset == "today":
            start = end
        elif preset == "7d":
            start = end - timedelta(days=6)
        elif preset == "30d":
            start = end - timedelta(days=29)
        else:
            start = end
        from_s = start.isoformat()
        to_s = end.isoformat()

    try:
        date.fromisoformat(from_s)
        date.fromisoformat(to_s)
    except (ValueError, TypeError):
        from_s, to_s = _date_defaults()

    def _int(name: str) -> int:
        try:
            return int(request.args.get(name) or 0)
        except Exception:
            return 0

    page = _int("page")
    limit = _int("limit")
    if page < 1:
        page = 1
    if limit < 25:
        limit = 25
    if limit > 500:
        limit = 500

    return {
        "preset": preset,
        "from": from_s,
        "to": to_s,
        "material_type": (request.args.get("material_type") or "").strip(),
        "memo_number": (request.args.get("memo_number") or "").strip(),
        "status": (request.args.get("status") or "").strip(),
        "source": (request.args.get("source") or "").strip(),
        "ref_type": (request.args.get("ref_type") or "").strip(),
        "valuation_status": (request.args.get("valuation_status") or "").strip(),
        "state": (request.args.get("state") or "").strip(),
        "category_id": max(0, _int("category_id")),
        "material_id": max(0, _int("material_id")),
        "lot_id": max(0, _int("lot_id")),
        "mismatch_only": 1 if request.args.get("mismatch_only") is not None else 0,
        "page": page,
        "limit": limit,
    }

