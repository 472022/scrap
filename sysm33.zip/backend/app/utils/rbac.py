from __future__ import annotations

from flask import abort, session


def current_user_role() -> str:
    return str(session.get("role") or "")


def can_view_report(report_key: str) -> bool:
    role = current_user_role()
    if role == "admin":
        return True

    worker = {
        "memo": True,
        "inward_items": True,
        "outward": True,
        "inventory": True,
        "expiry_alerts": True,
    }

    supervisor = {
        **worker,
        "dash_ops": True,
        "dash_inventory": True,
        "segregation": True,
        "movements": True,
        "mismatches": True,
        "schedules": True,
        "financial_summary": True,
        "vendor": True,
        "exceptions": True,
    }

    if role == "supervisor":
        return bool(supervisor.get(report_key))
    if role == "worker":
        return bool(worker.get(report_key))
    return False


def require_report_access(report_key: str) -> None:
    if not can_view_report(report_key):
        abort(403)


def require_admin() -> None:
    if current_user_role() != "admin":
        abort(403)


_OPERATIONAL_ROLES = frozenset({"admin", "supervisor", "worker"})


def require_operational_role() -> None:
    """Block requestor and sqpdcme from reaching operational write routes."""
    if current_user_role() not in _OPERATIONAL_ROLES:
        abort(403)

