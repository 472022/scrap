from __future__ import annotations

from app.db.engine import db_conn
from app.db.query import fetch_all, fetch_one


def expiry_alert_summary() -> dict[str, object]:
    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT\n"
            "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN 1 ELSE 0 END) AS near_lots,\n"
            "    SUM(CASE WHEN alert_state = 'EXPIRED' THEN 1 ELSE 0 END) AS expired_lots,\n"
            "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN balance_weight ELSE 0 END) AS near_weight,\n"
            "    SUM(CASE WHEN alert_state = 'EXPIRED' THEN balance_weight ELSE 0 END) AS expired_weight\n"
            "FROM expiry_alerts_vw",
        ) or {}

        rows = fetch_all(
            conn,
            "SELECT\n"
            "    COALESCE(uom_code, '') AS uom_code,\n"
            "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN balance_weight ELSE 0 END) AS near_qty,\n"
            "    SUM(CASE WHEN alert_state = 'EXPIRED' THEN balance_weight ELSE 0 END) AS expired_qty\n"
            "FROM expiry_alerts_vw\n"
            "GROUP BY uom_code\n"
            "ORDER BY uom_code ASC",
        )

    near_parts: list[str] = []
    expired_parts: list[str] = []
    for r in rows:
        code = str(r.get("uom_code") or "").strip()
        n = float(r.get("near_qty") or 0)
        e = float(r.get("expired_qty") or 0)
        if n > 0:
            near_parts.append(f"{n:.2f}" + (f" {code}" if code else ""))
        if e > 0:
            expired_parts.append(f"{e:.2f}" + (f" {code}" if code else ""))

    return {
        "near_lots": int(row.get("near_lots") or 0),
        "expired_lots": int(row.get("expired_lots") or 0),
        "near_weight": float(row.get("near_weight") or 0),
        "expired_weight": float(row.get("expired_weight") or 0),
        "near_by_uom": ", ".join(near_parts),
        "expired_by_uom": ", ".join(expired_parts),
    }


def expiry_untracked_summary() -> dict[str, object]:
    sql = (
        "SELECT\n"
        "    COUNT(*) AS untracked_items,\n"
        "    COALESCE(SUM(t.balance_weight), 0) AS untracked_weight\n"
        "FROM (\n"
        "    SELECT\n"
        "        sm.material_id,\n"
        "        SUM(CASE WHEN sm.direction = 'IN' THEN sm.weight ELSE -sm.weight END) AS balance_weight\n"
        "    FROM stock_movements_v2 sm\n"
        "    WHERE sm.lot_id IS NULL\n"
        "    GROUP BY sm.material_id\n"
        "    HAVING balance_weight > 0\n"
        ") t"
    )
    with db_conn() as conn:
        row = fetch_one(conn, sql) or {}
    return {
        "untracked_items": int(row.get("untracked_items") or 0),
        "untracked_weight": float(row.get("untracked_weight") or 0),
    }


def expiry_alert_dataset(
    category_id: int | None,
    material_id: int | None,
    lot_id: int | None,
    state: str,
    from_date: str | None,
    to_date: str | None,
    limit: int,
    offset: int,
    max_limit: int = 500,
) -> dict[str, object]:
    where_parts: list[str] = ["1=1"]
    params: dict[str, object] = {}

    if category_id and int(category_id) > 0:
        where_parts.append("category_id = :category_id")
        params["category_id"] = int(category_id)
    if material_id and int(material_id) > 0:
        where_parts.append("material_id = :material_id")
        params["material_id"] = int(material_id)
    if lot_id and int(lot_id) > 0:
        where_parts.append("lot_id = :lot_id")
        params["lot_id"] = int(lot_id)

    state_u = (state or "ALL").strip().upper()
    if state_u and state_u != "ALL":
        where_parts.append("alert_state = :state")
        params["state"] = state_u

    if from_date:
        where_parts.append("expiry_date >= :from_date")
        params["from_date"] = from_date
    if to_date:
        where_parts.append("expiry_date <= :to_date")
        params["to_date"] = to_date

    if limit < 25:
        limit = 25
    if limit > max_limit:
        limit = max_limit
    if offset < 0:
        offset = 0

    where_sql = "WHERE " + " AND ".join(where_parts)

    sql_rows = (
        "SELECT\n"
        "    lot_id,\n"
        "    lot_number,\n"
        "    material_id,\n"
        "    part_no_norm,\n"
        "    product_description,\n"
        "    category_id,\n"
        "    category_name,\n"
        "    inward_date,\n"
        "    expiry_date,\n"
        "    days_to_expiry,\n"
        "    uom_code,\n"
        "    balance_weight,\n"
        "    alert_state\n"
        "FROM expiry_alerts_vw\n"
        f"{where_sql}\n"
        "ORDER BY\n"
        "    CASE alert_state WHEN 'EXPIRED' THEN 0 WHEN 'NEAR_EXPIRY' THEN 1 WHEN 'UNTRACKED' THEN 2 ELSE 3 END,\n"
        "    days_to_expiry ASC,\n"
        "    lot_number ASC\n"
        "LIMIT :limit OFFSET :offset"
    )
    params_rows = {**params, "limit": int(limit), "offset": int(offset)}

    sql_summary = (
        "SELECT\n"
        "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN 1 ELSE 0 END) AS near_lots,\n"
        "    SUM(CASE WHEN alert_state = 'EXPIRED' THEN 1 ELSE 0 END) AS expired_lots,\n"
        "    SUM(CASE WHEN alert_state = 'UNTRACKED' THEN 1 ELSE 0 END) AS untracked_items,\n"
        "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN balance_weight ELSE 0 END) AS near_weight,\n"
        "    SUM(CASE WHEN alert_state = 'EXPIRED' THEN balance_weight ELSE 0 END) AS expired_weight,\n"
        "    SUM(CASE WHEN alert_state = 'UNTRACKED' THEN balance_weight ELSE 0 END) AS untracked_weight\n"
        "FROM expiry_alerts_vw\n"
        f"{where_sql}"
    )
    sql_by_uom = (
        "SELECT\n"
        "    COALESCE(uom_code, '') AS uom_code,\n"
        "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN balance_weight ELSE 0 END) AS near_qty,\n"
        "    SUM(CASE WHEN alert_state = 'EXPIRED' THEN balance_weight ELSE 0 END) AS expired_qty,\n"
        "    SUM(CASE WHEN alert_state = 'UNTRACKED' THEN balance_weight ELSE 0 END) AS untracked_qty\n"
        "FROM expiry_alerts_vw\n"
        f"{where_sql}\n"
        "GROUP BY uom_code\n"
        "ORDER BY uom_code ASC"
    )

    with db_conn() as conn:
        rows = fetch_all(conn, sql_rows, params_rows)
        srow = fetch_one(conn, sql_summary, params) or {}
        by_uom = fetch_all(conn, sql_by_uom, params)

    near_parts: list[str] = []
    expired_parts: list[str] = []
    untracked_parts: list[str] = []
    for r in by_uom:
        code = str(r.get("uom_code") or "").strip()
        n = float(r.get("near_qty") or 0)
        e = float(r.get("expired_qty") or 0)
        u = float(r.get("untracked_qty") or 0)
        if n > 0:
            near_parts.append(f"{n:.2f}" + (f" {code}" if code else ""))
        if e > 0:
            expired_parts.append(f"{e:.2f}" + (f" {code}" if code else ""))
        if u > 0:
            untracked_parts.append(f"{u:.2f}" + (f" {code}" if code else ""))

    summary = {
        "near_lots": int(srow.get("near_lots") or 0),
        "expired_lots": int(srow.get("expired_lots") or 0),
        "untracked_items": int(srow.get("untracked_items") or 0),
        "near_weight": float(srow.get("near_weight") or 0),
        "expired_weight": float(srow.get("expired_weight") or 0),
        "untracked_weight": float(srow.get("untracked_weight") or 0),
        "near_by_uom": ", ".join(near_parts),
        "expired_by_uom": ", ".join(expired_parts),
        "untracked_by_uom": ", ".join(untracked_parts),
    }

    return {"rows": rows, "summary": summary}
