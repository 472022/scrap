from __future__ import annotations

from typing import Any

from flask import session


def flash_set(type_: str, message: str) -> None:
    session["flash"] = {"type": type_, "message": message}


def flash_get() -> dict[str, Any] | None:
    flash = session.get("flash")
    if not isinstance(flash, dict):
        return None
    session.pop("flash", None)
    return flash

