from __future__ import annotations

from app.db.engine import db_conn
from app.db.query import fetch_all, fetch_one


def valuation_inventory_totals() -> dict[str, object]:
    sql = (
        "SELECT\n"
        "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NOT NULL THEN ib.balance_weight * mr.rate_per_weight ELSE 0 END), 0) AS inventory_worth,\n"
        "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NULL THEN ib.balance_weight ELSE 0 END), 0) AS unvalued_stock_weight\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        "WHERE ib.balance_weight > 0"
    )
    sql_by_uom = (
        "SELECT\n"
        "    COALESCE(ib.uom_code, '') AS uom_code,\n"
        "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NULL THEN ib.balance_weight ELSE 0 END), 0) AS unvalued_qty\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        "WHERE ib.balance_weight > 0\n"
        "GROUP BY ib.uom_code\n"
        "ORDER BY ib.uom_code ASC"
    )
    with db_conn() as conn:
        row = fetch_one(conn, sql) or {}
        rows = fetch_all(conn, sql_by_uom)

    parts: list[str] = []
    for r in rows:
        code = str(r.get("uom_code") or "").strip()
        qty = float(r.get("unvalued_qty") or 0)
        if qty <= 0:
            continue
        parts.append(f"{qty:.2f}" + (f" {code}" if code else ""))

    return {
        "inventory_worth": float(row.get("inventory_worth") or 0),
        "unvalued_stock_weight": float(row.get("unvalued_stock_weight") or 0),
        "unvalued_stock_by_uom": ", ".join(parts),
    }


def valuation_outward_totals(from_date: str, to_date: str) -> dict[str, object]:
    sql = (
        "SELECT\n"
        "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NOT NULL THEN sm.weight * mr.rate_per_weight ELSE 0 END), 0) AS outward_worth,\n"
        "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NULL THEN sm.weight ELSE 0 END), 0) AS unvalued_outward_weight\n"
        "FROM stock_movements_v2 sm\n"
        "LEFT JOIN material_rates mr ON mr.material_id = sm.material_id AND mr.is_active = 1\n"
        "WHERE sm.direction = 'OUT'\n"
        "  AND sm.ref_type = 'OUTWARD'\n"
        "  AND DATE(sm.created_at) BETWEEN :from_date AND :to_date"
    )
    sql_by_uom = (
        "SELECT\n"
        "    COALESCE(u.code, '') AS uom_code,\n"
        "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NULL THEN sm.weight ELSE 0 END), 0) AS unvalued_qty\n"
        "FROM stock_movements_v2 sm\n"
        "LEFT JOIN material_rates mr ON mr.material_id = sm.material_id AND mr.is_active = 1\n"
        "LEFT JOIN uoms u ON u.id = sm.uom_id\n"
        "WHERE sm.direction = 'OUT'\n"
        "  AND sm.ref_type = 'OUTWARD'\n"
        "  AND DATE(sm.created_at) BETWEEN :from_date AND :to_date\n"
        "GROUP BY uom_code\n"
        "ORDER BY uom_code ASC"
    )
    with db_conn() as conn:
        row = fetch_one(conn, sql, {"from_date": from_date, "to_date": to_date}) or {}
        rows = fetch_all(conn, sql_by_uom, {"from_date": from_date, "to_date": to_date})

    parts: list[str] = []
    for r in rows:
        code = str(r.get("uom_code") or "").strip()
        qty = float(r.get("unvalued_qty") or 0)
        if qty <= 0:
            continue
        parts.append(f"{qty:.2f}" + (f" {code}" if code else ""))

    return {
        "outward_worth": float(row.get("outward_worth") or 0),
        "unvalued_outward_weight": float(row.get("unvalued_outward_weight") or 0),
        "unvalued_outward_by_uom": ", ".join(parts),
    }

