from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
import time

_log = logging.getLogger(__name__)


def _cache_dir() -> str:
    d = os.path.join(tempfile.gettempdir(), "syms_report_cache")
    os.makedirs(d, exist_ok=True)
    return d


def _cache_path(key: str) -> str:
    h = hashlib.sha1(key.encode("utf-8")).hexdigest()
    return os.path.join(_cache_dir(), f"{h}.json")


def get_cached(key: str, ttl_seconds: int) -> dict | None:
    path = _cache_path(key)
    try:
        st = os.stat(path)
    except OSError:
        return None
    if int(time.time() - int(st.st_mtime)) > int(ttl_seconds):
        return None
    try:
        raw = open(path, "r", encoding="utf-8").read()
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception as exc:
        _log.warning("report_cache: read failed for key=%s: %s", key, exc)
        return None


def set_cached(key: str, data: dict) -> None:
    path = _cache_path(key)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception as exc:
        _log.warning("report_cache: write failed for key=%s: %s", key, exc)
        return

