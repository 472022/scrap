from __future__ import annotations

from typing import Any

from app.db.engine import db_conn
from app.db.query import execute, fetch_one
from sqlalchemy.engine import Connection


def material_find_by_id(material_id: int) -> dict[str, Any] | None:
    if material_id <= 0:
        return None
    with db_conn() as conn:
        return fetch_one(
            conn,
            "SELECT id, part_no_raw, part_no_norm, product_description, category_id, uom_id, is_active\n"
            "FROM materials WHERE id = :id",
            {"id": material_id},
        )


def uom_find_by_code(code: str) -> dict[str, Any] | None:
    code = (code or "").strip()
    if code == "":
        return None
    with db_conn() as conn:
        return fetch_one(conn, "SELECT id, code, name, is_active FROM uoms WHERE code = :code", {"code": code})


def counterparty_find_by_id(counterparty_id: int) -> dict[str, Any] | None:
    if counterparty_id <= 0:
        return None
    with db_conn() as conn:
        return fetch_one(
            conn,
            "SELECT id, type, name, phone, email, address, gstin, is_active FROM counterparties WHERE id = :id",
            {"id": counterparty_id},
        )


def lot_find_by_id(lot_id: int) -> dict[str, Any] | None:
    if lot_id <= 0:
        return None
    with db_conn() as conn:
        return fetch_one(
            conn,
            "SELECT id, lot_number, category_id, inward_date, expiry_date, expiry_override FROM material_lots WHERE id = :id",
            {"id": lot_id},
        )


def material_active_rate(material_id: int) -> float | None:
    if material_id <= 0:
        return None
    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT rate_per_weight FROM material_rates WHERE material_id = :id AND is_active = 1 ORDER BY id DESC LIMIT 1",
            {"id": material_id},
        )
    if not row:
        return None
    return float(row.get("rate_per_weight") or 0)


def material_balance_v2(material_id: int) -> float:
    if material_id <= 0:
        return 0.0
    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT COALESCE(balance_weight, 0) AS balance_weight FROM inventory_balances_v2 WHERE material_id = :id",
            {"id": material_id},
        ) or {}
    return float(row.get("balance_weight") or 0)


def inventory_balance(material_type: str, uom_id: int | None = None) -> float:
    material_type = (material_type or "").strip()
    if material_type == "":
        return 0.0
    params: dict[str, object] = {"material_type": material_type}
    sql = "SELECT COALESCE(SUM(balance_weight), 0) AS balance_weight FROM inventory_balances WHERE material_type = :material_type"
    if uom_id and int(uom_id) > 0:
        sql = "SELECT COALESCE(balance_weight, 0) AS balance_weight FROM inventory_balances WHERE material_type = :material_type AND uom_id = :uom_id"
        params["uom_id"] = int(uom_id)
    with db_conn() as conn:
        row = fetch_one(conn, sql, params) or {}
    return float(row.get("balance_weight") or 0)


def inventory_add_movement(
    ref_type: str,
    ref_id: int,
    from_type: str | None,
    to_type: str | None,
    weight: float,
    uom_id: int | None = None,
    conn: Connection | None = None,
) -> None:
    if weight <= 0:
        return
    uom_or_null = int(uom_id) if uom_id and int(uom_id) > 0 else None
    if conn is not None:
        execute(
            conn,
            "INSERT INTO inventory_movements (ref_type, ref_id, from_type, to_type, uom_id, weight)\n"
            "VALUES (:ref_type, :ref_id, :from_type, :to_type, :uom_id, :weight)",
            {
                "ref_type": ref_type,
                "ref_id": int(ref_id),
                "from_type": from_type,
                "to_type": to_type,
                "uom_id": uom_or_null,
                "weight": float(weight),
            },
        )
        return
    with db_conn() as c:
        with c.begin():
            inventory_add_movement(ref_type, ref_id, from_type, to_type, weight, uom_id, conn=c)


def stock_v2_add_movement(
    ref_type: str,
    ref_id: int,
    material_id: int,
    weight: float,
    direction: str,
    valuation_note: str = "",
    lot_id: int | None = None,
    category_id: int | None = None,
    expiry_snapshot: str | None = None,
    uom_id: int | None = None,
    conn: Connection | None = None,
) -> None:
    if material_id <= 0 or weight <= 0:
        return
    direction = (direction or "").strip().upper()
    if direction not in {"IN", "OUT"}:
        return

    rate = material_active_rate(material_id)
    is_valued = 1 if rate is not None else 0
    if valuation_note == "":
        valuation_note = "" if is_valued else "MISSING_RATE"

    if uom_id is None or int(uom_id) <= 0:
        m = material_find_by_id(material_id) or {}
        uom_id = int(m.get("uom_id") or 0)
    uom_or_null = int(uom_id) if uom_id and int(uom_id) > 0 else None

    lot_or_null = int(lot_id) if lot_id and int(lot_id) > 0 else None
    cat_or_null = int(category_id) if category_id and int(category_id) > 0 else None

    if conn is not None:
        execute(
            conn,
            "INSERT INTO stock_movements_v2\n"
            " (ref_type, ref_id, material_id, uom_id, weight, direction, is_valued, valuation_note, lot_id, category_id, expiry_date_snapshot)\n"
            "VALUES\n"
            " (:ref_type, :ref_id, :material_id, :uom_id, :weight, :direction, :is_valued, :valuation_note, :lot_id, :category_id, :expiry_snapshot)",
            {
                "ref_type": ref_type,
                "ref_id": int(ref_id),
                "material_id": int(material_id),
                "uom_id": uom_or_null,
                "weight": float(weight),
                "direction": direction,
                "is_valued": int(is_valued),
                "valuation_note": valuation_note,
                "lot_id": lot_or_null,
                "category_id": cat_or_null,
                "expiry_snapshot": expiry_snapshot,
            },
        )
        return
    with db_conn() as c:
        with c.begin():
            stock_v2_add_movement(
                ref_type,
                ref_id,
                material_id,
                weight,
                direction,
                valuation_note,
                lot_id,
                category_id,
                expiry_snapshot,
                uom_id,
                conn=c,
            )
