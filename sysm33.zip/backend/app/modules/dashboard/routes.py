from __future__ import annotations

from flask import Blueprint, jsonify, redirect, render_template, request

from app.db.engine import db_conn
from app.db.query import fetch_all, fetch_one
from app.security.auth import login_required
from app.utils.expiry import expiry_alert_summary, expiry_untracked_summary
from app.utils.rbac import can_view_report, current_user_role
from app.utils.report_filters import read_filters
from app.utils.valuation import valuation_inventory_totals, valuation_outward_totals

bp = Blueprint("dashboard", __name__)


@bp.get("/scratch/dashboard")
@login_required
def dashboard_page() -> object:
    if current_user_role() == "requestor":
        return redirect("/scratch/requests")

    with db_conn() as conn:
        verified_memos = fetch_all(
            conn,
            "SELECT id, memo_number, memo_date\n"
            "FROM memos\n"
            "WHERE status IN ('VERIFIED','MUTILATION_COMPLETED')\n"
            "ORDER BY memo_date DESC, created_at DESC\n"
            "LIMIT 300",
        )
        materials = fetch_all(
            conn,
            "SELECT id, part_no_raw, part_no_norm, product_description, category_id, uom_id\n"
            "FROM materials\n"
            "WHERE is_active = 1\n"
            "ORDER BY product_description ASC, part_no_norm ASC",
        )
        uoms = fetch_all(
            conn,
            "SELECT id, code, name\n"
            "FROM uoms\n"
            "WHERE is_active = 1\n"
            "ORDER BY code ASC",
        )
        counterparties = fetch_all(
            conn,
            "SELECT id, type, name, phone, email, address, gstin, is_active\n"
            "FROM counterparties\n"
            "WHERE is_active = 1\n"
            "ORDER BY type ASC, name ASC",
        )
        outward_categories = fetch_all(
            conn,
            "SELECT\n"
            "    ib.material_id,\n"
            "    ib.uom_id,\n"
            "    ib.uom_code,\n"
            "    ib.part_no_norm,\n"
            "    ib.product_description,\n"
            "    ib.balance_weight\n"
            "FROM inventory_balances_v2 ib\n"
            "WHERE ib.balance_weight > 0\n"
            "ORDER BY ib.product_description ASC, ib.part_no_norm ASC",
        )

    return render_template(
        "dashboard/index.html",
        pageTitle="Dashboard - SYMS",
        verifiedMemos=verified_memos,
        materials=materials,
        uoms=uoms,
        counterparties=counterparties,
        outwardCategories=outward_categories,
    )


@bp.get("/scratch/dashboard/api/summary")
@login_required
def api_summary() -> object:
    out = {
        "role": current_user_role(),
        "can_memo": can_view_report("memo"),
        "can_outward": can_view_report("outward"),
        "can_inventory": can_view_report("inventory"),
        "can_dash_ops": can_view_report("dash_ops"),
        "can_dash_inventory": can_view_report("dash_inventory"),
        "can_schedules": can_view_report("schedules"),
        "total_memos": 0,
        "pending_memos": 0,
        "verified_memos": 0,
        "mismatch_lines": 0,
        "verified_percent": 0.0,
        "new_memos_7d": 0,
        "outward_weight_7d": 0.0,
        "outward_7d_by_uom": "",
        "inventory_total": 0.0,
        "inventory_by_uom": "",
        "top_inventory": {"material_type": "", "balance_weight": 0.0, "uom_code": ""},
        "active_schedules": 0,
    }

    with db_conn() as conn:
        if out["can_memo"]:
            row = fetch_one(conn, "SELECT COUNT(*) AS total FROM memos") or {}
            out["total_memos"] = int(row.get("total") or 0)

            row = fetch_one(conn, "SELECT COUNT(*) AS total FROM memos WHERE status = 'UPLOADED'") or {}
            out["pending_memos"] = int(row.get("total") or 0)

            row = fetch_one(
                conn,
                "SELECT COUNT(*) AS total FROM memos WHERE status IN ('VERIFIED','MUTILATION_COMPLETED')",
            ) or {}
            out["verified_memos"] = int(row.get("total") or 0)

            row = fetch_one(conn, "SELECT COALESCE(SUM(mismatch_count), 0) AS total FROM memos") or {}
            out["mismatch_lines"] = int(row.get("total") or 0)

        if out["total_memos"] > 0:
            out["verified_percent"] = round((out["verified_memos"] / out["total_memos"]) * 100, 1)

        if out["can_memo"]:
            row = fetch_one(conn, "SELECT COUNT(*) AS total FROM memos WHERE created_at >= (NOW() - INTERVAL 7 DAY)") or {}
            out["new_memos_7d"] = int(row.get("total") or 0)

        if out["can_outward"]:
            row = fetch_one(
                conn,
                "SELECT COALESCE(SUM(weight), 0) AS total FROM outward_entries WHERE created_at >= (NOW() - INTERVAL 7 DAY)",
            ) or {}
            out["outward_weight_7d"] = float(row.get("total") or 0)

            rows = fetch_all(
                conn,
                "SELECT\n"
                "    COALESCE(u.code, '') AS uom_code,\n"
                "    COALESCE(SUM(oe.weight), 0) AS total_qty\n"
                "FROM outward_entries oe\n"
                "LEFT JOIN materials m ON m.id = oe.material_id\n"
                "LEFT JOIN uoms u ON u.id = COALESCE(oe.uom_id, m.uom_id)\n"
                "WHERE oe.created_at >= (NOW() - INTERVAL 7 DAY)\n"
                "GROUP BY uom_code\n"
                "ORDER BY uom_code ASC",
            )
            parts: list[str] = []
            for r in rows:
                code = str(r.get("uom_code") or "").strip()
                qty = float(r.get("total_qty") or 0)
                if qty <= 0:
                    continue
                parts.append(f"{qty:.2f}" + (f" {code}" if code else ""))
            out["outward_7d_by_uom"] = ", ".join(parts)

        if out["can_inventory"]:
            row = fetch_one(conn, "SELECT COALESCE(SUM(balance_weight), 0) AS total FROM inventory_balances_v2") or {}
            out["inventory_total"] = float(row.get("total") or 0)

            row = fetch_one(
                conn,
                "SELECT product_description AS material_type, balance_weight, uom_code\n"
                "FROM inventory_balances_v2\n"
                "ORDER BY balance_weight DESC\n"
                "LIMIT 1",
            )
            if row:
                out["top_inventory"] = {
                    "material_type": str(row.get("material_type") or ""),
                    "balance_weight": float(row.get("balance_weight") or 0),
                    "uom_code": str(row.get("uom_code") or ""),
                }

            rows = fetch_all(
                conn,
                "SELECT COALESCE(uom_code, '') AS uom_code, COALESCE(SUM(balance_weight), 0) AS total_qty\n"
                "FROM inventory_balances_v2\n"
                "GROUP BY uom_code\n"
                "ORDER BY uom_code ASC",
            )
            parts = []
            for r in rows:
                code = str(r.get("uom_code") or "").strip()
                qty = float(r.get("total_qty") or 0)
                if qty <= 0:
                    continue
                parts.append(f"{qty:.2f}" + (f" {code}" if code else ""))
            out["inventory_by_uom"] = ", ".join(parts)

        if out["can_schedules"]:
            row = fetch_one(conn, "SELECT COUNT(*) AS total FROM report_schedules WHERE enabled = 1") or {}
            out["active_schedules"] = int(row.get("total") or 0)

    return jsonify(out)


@bp.get("/scratch/dashboard/api/pending_memos")
@login_required
def api_pending_memos() -> object:
    if not can_view_report("memo"):
        return jsonify({"allowed": False, "items": []})

    with db_conn() as conn:
        rows = fetch_all(
            conn,
            "SELECT id, memo_number, memo_date, source, created_at\n"
            "FROM memos\n"
            "WHERE status = 'UPLOADED'\n"
            "ORDER BY created_at DESC\n"
            "LIMIT 10",
        )

    items = [
        {
            "id": int(r.get("id") or 0),
            "memo_number": str(r.get("memo_number") or ""),
            "memo_date": str(r.get("memo_date") or ""),
            "source": str(r.get("source") or ""),
            "created_at": str(r.get("created_at") or ""),
        }
        for r in rows
    ]
    return jsonify({"allowed": True, "items": items})


@bp.get("/scratch/dashboard/api/inventory_top")
@login_required
def api_inventory_top() -> object:
    if not can_view_report("inventory"):
        return jsonify({"allowed": False, "labels": [], "values": []})

    with db_conn() as conn:
        rows = fetch_all(
            conn,
            "SELECT product_description, uom_code, balance_weight\n"
            "FROM inventory_balances_v2\n"
            "ORDER BY balance_weight DESC\n"
            "LIMIT 10",
        )

    labels: list[str] = []
    values: list[float] = []
    for r in rows:
        label = str(r.get("product_description") or "")
        u = str(r.get("uom_code") or "").strip()
        if u:
            label += f" ({u})"
        labels.append(label)
        values.append(float(r.get("balance_weight") or 0))

    return jsonify({"allowed": True, "labels": labels, "values": values})


@bp.get("/scratch/dashboard/api/inventory_composition")
@login_required
def api_inventory_composition() -> object:
    if not can_view_report("inventory"):
        return jsonify({"allowed": False, "items": []})

    filters = read_filters()
    material_type = str(filters.get("material_type") or "")

    with db_conn() as conn:
        if material_type:
            rows = fetch_all(
                conn,
                "SELECT product_description, uom_code, balance_weight\n"
                "FROM inventory_balances_v2\n"
                "WHERE product_description = :material_type",
                {"material_type": material_type},
            )
        else:
            rows = fetch_all(
                conn,
                "SELECT product_description, uom_code, balance_weight\n"
                "FROM inventory_balances_v2\n"
                "ORDER BY balance_weight DESC",
            )

    items: list[dict[str, object]] = []
    for r in rows:
        name = str(r.get("product_description") or "")
        u = str(r.get("uom_code") or "").strip()
        if u:
            name += f" ({u})"
        val = float(r.get("balance_weight") or 0)
        if name == "" or val <= 0:
            continue
        items.append({"name": name, "value": val})

    return jsonify({"allowed": True, "items": items[:20]})


@bp.get("/scratch/dashboard/api/outward_by_category")
@login_required
def api_outward_by_category() -> object:
    if not can_view_report("outward"):
        return jsonify({"allowed": False, "labels": [], "values": []})

    filters = read_filters()
    from_date = str(filters.get("from") or "")
    to_date = str(filters.get("to") or "")
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if material_type:
        where += " AND material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT\n"
        "    oe.material_type,\n"
        "    COALESCE(u.code, '') AS uom_code,\n"
        "    COALESCE(SUM(oe.weight), 0) AS w\n"
        "FROM outward_entries oe\n"
        "LEFT JOIN materials m ON m.id = oe.material_id\n"
        "LEFT JOIN uoms u ON u.id = COALESCE(oe.uom_id, m.uom_id)\n"
        f"{where}\n"
        "GROUP BY oe.material_type, uom_code\n"
        "ORDER BY w DESC"
    )

    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    labels: list[str] = []
    values: list[float] = []
    for r in rows:
        label = str(r.get("material_type") or "")
        u = str(r.get("uom_code") or "").strip()
        if u:
            label += f" ({u})"
        labels.append(label)
        values.append(float(r.get("w") or 0))

    return jsonify({"allowed": True, "labels": labels, "values": values})


@bp.get("/scratch/dashboard/api/recent_activity")
@login_required
def api_recent_activity() -> object:
    parts: list[str] = []
    if can_view_report("memo"):
        parts.append(
            "(\n"
            "    SELECT\n"
            "        'memo' AS type,\n"
            "        created_at AS happened_at,\n"
            "        CONCAT(memo_number, ' | ', COALESCE(source, '')) AS label,\n"
            "        CONCAT('/scratch/mutilation/verify?id=', id) AS url\n"
            "    FROM memos\n"
            "    ORDER BY created_at DESC\n"
            "    LIMIT 20\n"
            ")"
        )
    if can_view_report("outward"):
        parts.append(
            "(\n"
            "    SELECT\n"
            "        'outward' AS type,\n"
            "        created_at AS happened_at,\n"
            "        CONCAT(material_type, ' | ', weight) AS label,\n"
            "        CONCAT('/scratch/outward/edit?id=', id) AS url\n"
            "    FROM outward_entries\n"
            "    ORDER BY created_at DESC\n"
            "    LIMIT 20\n"
            ")"
        )
    if can_view_report("segregation"):
        parts.append(
            "(\n"
            "    SELECT\n"
            "        'segregation' AS type,\n"
            "        created_at AS happened_at,\n"
            "        CONCAT(material_type, ' | ', weight) AS label,\n"
            "        '/scratch/segregation/list' AS url\n"
            "    FROM segregation_entries\n"
            "    ORDER BY created_at DESC\n"
            "    LIMIT 20\n"
            ")"
        )

    if not parts:
        return jsonify({"allowed": False, "items": []})

    sql = " UNION ALL ".join(parts) + " ORDER BY happened_at DESC LIMIT 15"

    with db_conn() as conn:
        rows = fetch_all(conn, sql)

    items = [
        {
            "type": str(r.get("type") or ""),
            "happened_at": str(r.get("happened_at") or ""),
            "label": str(r.get("label") or ""),
            "url": str(r.get("url") or ""),
        }
        for r in rows
    ]
    return jsonify({"allowed": True, "items": items})


@bp.get("/scratch/dashboard/api/recent_segregation")
@login_required
def api_recent_segregation() -> object:
    if not can_view_report("segregation"):
        return jsonify({"allowed": False, "items": []})

    sql = (
        "SELECT\n"
        "    COALESCE(m.memo_number, CONCAT('Memo #', se.memo_id)) AS memo_ref,\n"
        "    se.material_type,\n"
        "    se.weight,\n"
        "    COALESCE(u.code,'') AS uom_code,\n"
        "    se.created_at\n"
        "FROM segregation_entries se\n"
        "LEFT JOIN memos m ON m.id = se.memo_id\n"
        "LEFT JOIN materials mt ON mt.id = se.material_id\n"
        "LEFT JOIN uoms u ON u.id = COALESCE(se.uom_id, mt.uom_id)\n"
        "ORDER BY se.created_at DESC\n"
        "LIMIT 10"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql)

    items = [
        {
            "memo": str(r.get("memo_ref") or ""),
            "material_type": str(r.get("material_type") or ""),
            "weight": str(r.get("weight") or ""),
            "uom_code": str(r.get("uom_code") or ""),
            "created_at": str(r.get("created_at") or ""),
        }
        for r in rows
    ]
    return jsonify({"allowed": True, "items": items})


@bp.get("/scratch/dashboard/api/schedule_summary")
@login_required
def api_schedule_summary() -> object:
    if not can_view_report("schedules"):
        return jsonify({"allowed": False, "enabled_count": 0, "next_runs": [], "recent_exports": []})

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT COUNT(*) AS total FROM report_schedules WHERE enabled = 1") or {}
        enabled_count = int(row.get("total") or 0)

        runs = fetch_all(
            conn,
            "SELECT id, report_key, frequency, next_run_at\n"
            "FROM report_schedules\n"
            "WHERE enabled = 1\n"
            "ORDER BY next_run_at ASC\n"
            "LIMIT 5",
        )
        exports = fetch_all(
            conn,
            "SELECT id, schedule_id, file_path, generated_at\n"
            "FROM report_exports\n"
            "ORDER BY generated_at DESC\n"
            "LIMIT 5",
        )

    next_runs = [
        {
            "id": int(r.get("id") or 0),
            "report_key": str(r.get("report_key") or ""),
            "frequency": str(r.get("frequency") or ""),
            "next_run_at": str(r.get("next_run_at") or ""),
        }
        for r in runs
    ]
    recent_exports = [
        {
            "id": int(x.get("id") or 0),
            "schedule_id": int(x.get("schedule_id") or 0),
            "generated_at": str(x.get("generated_at") or ""),
            "download_url": f"/scratch/reports/export_download?id={int(x.get('id') or 0)}",
        }
        for x in exports
    ]
    return jsonify(
        {"allowed": True, "enabled_count": enabled_count, "next_runs": next_runs, "recent_exports": recent_exports}
    )


@bp.get("/scratch/dashboard/api/stock_worth")
@login_required
def api_stock_worth() -> object:
    filters = read_filters()
    from_date = str(filters.get("from") or "")
    to_date = str(filters.get("to") or "")

    inventory = valuation_inventory_totals()
    outward = valuation_outward_totals(from_date, to_date)

    return jsonify(
        {
            "allowed": can_view_report("inventory") or can_view_report("outward"),
            "from": from_date,
            "to": to_date,
            "inventory_worth": float(inventory.get("inventory_worth") or 0),
            "unvalued_stock_weight": float(inventory.get("unvalued_stock_weight") or 0),
            "unvalued_stock_by_uom": str(inventory.get("unvalued_stock_by_uom") or ""),
            "outward_worth": float(outward.get("outward_worth") or 0),
            "unvalued_outward_weight": float(outward.get("unvalued_outward_weight") or 0),
            "unvalued_outward_by_uom": str(outward.get("unvalued_outward_by_uom") or ""),
        }
    )


@bp.get("/scratch/dashboard/api/expiry_summary")
@login_required
def api_expiry_summary() -> object:
    allowed = can_view_report("inventory") or can_view_report("dash_inventory")
    if not allowed:
        return jsonify({"allowed": False})

    summary = expiry_alert_summary()
    untracked = expiry_untracked_summary()

    return jsonify(
        {
            "allowed": True,
            "near_lots": int(summary.get("near_lots") or 0),
            "expired_lots": int(summary.get("expired_lots") or 0),
            "near_weight": float(summary.get("near_weight") or 0),
            "expired_weight": float(summary.get("expired_weight") or 0),
            "near_by_uom": str(summary.get("near_by_uom") or ""),
            "expired_by_uom": str(summary.get("expired_by_uom") or ""),
            "untracked_items": int(untracked.get("untracked_items") or 0),
            "untracked_weight": float(untracked.get("untracked_weight") or 0),
        }
    )


@bp.get("/scratch/dashboard/api/expiry_alerts")
@login_required
def api_expiry_alerts() -> object:
    allowed = can_view_report("inventory") or can_view_report("dash_inventory")
    if not allowed:
        return jsonify({"allowed": False, "items": []})

    try:
        limit = int(request.args.get("limit") or 20)
    except Exception:
        limit = 20
    if limit < 1:
        limit = 20
    if limit > 50:
        limit = 50

    sql = (
        "SELECT\n"
        "    lot_id,\n"
        "    lot_number,\n"
        "    material_id,\n"
        "    part_no_norm,\n"
        "    product_description,\n"
        "    category_name,\n"
        "    inward_date,\n"
        "    expiry_date,\n"
        "    days_to_expiry,\n"
        "    uom_code,\n"
        "    balance_weight,\n"
        "    alert_state\n"
        "FROM expiry_alerts_vw\n"
        "WHERE alert_state IN ('NEAR_EXPIRY', 'EXPIRED')\n"
        "ORDER BY\n"
        "    CASE alert_state WHEN 'EXPIRED' THEN 0 WHEN 'NEAR_EXPIRY' THEN 1 ELSE 2 END,\n"
        "    days_to_expiry ASC,\n"
        "    lot_number ASC\n"
        "LIMIT 400"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql)

    return jsonify({"allowed": True, "items": rows[:limit]})
