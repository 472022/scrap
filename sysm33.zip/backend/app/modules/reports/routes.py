from __future__ import annotations

import json
import os
from datetime import date, datetime, timedelta
from pathlib import Path

from flask import Blueprint, Response, abort, redirect, render_template, request, send_file, session

from app.config import load_settings
from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.domain import lot_find_by_id
from app.utils.expiry import expiry_alert_dataset
from app.utils.flash import flash_set
from app.utils.rbac import can_view_report, current_user_role, require_admin, require_report_access
from app.utils.report_filters import read_filters

bp = Blueprint("reports", __name__)


def _backend_dir() -> Path:
    return Path(__file__).resolve().parents[3]


def _material_type_options() -> list[str]:
    with db_conn() as conn:
        rows = fetch_all(
            conn,
            "SELECT DISTINCT product_description AS t\n"
            "FROM materials\n"
            "WHERE is_active = 1 AND product_description IS NOT NULL AND product_description <> ''\n"
            "ORDER BY t ASC",
        )
    return [str(r.get("t") or "") for r in rows if str(r.get("t") or "").strip() != ""]


def _category_options() -> list[dict]:
    with db_conn() as conn:
        return fetch_all(conn, "SELECT id, name FROM material_categories WHERE is_active = 1 ORDER BY name ASC")


def _material_options() -> list[dict]:
    with db_conn() as conn:
        return fetch_all(
            conn,
            "SELECT id, part_no_raw, product_description FROM materials WHERE is_active = 1 ORDER BY product_description ASC, part_no_norm ASC",
        )


def _lot_options(material_id: int | None) -> list[dict]:
    with db_conn() as conn:
        if material_id and int(material_id) > 0:
            return fetch_all(
                conn,
                "SELECT id, lot_number FROM material_lots WHERE material_id = :id ORDER BY lot_number ASC",
                {"id": int(material_id)},
            )
        return fetch_all(conn, "SELECT id, lot_number FROM material_lots ORDER BY lot_number ASC LIMIT 500")


def _exports_dir() -> Path:
    settings = load_settings()
    base = Path(settings.export_dir)
    if not base.is_absolute():
        base = (_backend_dir() / base).resolve()
    return base.resolve()


def _parse_date_range(filters: dict[str, object]) -> tuple[str, str]:
    from_s = str(filters.get("from") or "")
    to_s = str(filters.get("to") or "")
    try:
        date.fromisoformat(from_s)
        date.fromisoformat(to_s)
    except (ValueError, TypeError):
        today = date.today().isoformat()
        return today, today
    return from_s, to_s


def _export_url(report_key: str) -> str:
    qs = request.query_string.decode("utf-8", "ignore")
    sep = "&" if qs else ""
    return f"/scratch/reports/export_excel?report_key={report_key}{sep}{qs}"


# ── Report Index ──────────────────────────────────────────────────────────────

CATEGORIES = [
    {"key": "dashboards",          "label": "Dashboards",           "icon": "bx-tachometer",     "color": "primary"},
    {"key": "operations",          "label": "Operations",            "icon": "bx-file",           "color": "info"},
    {"key": "inventory_stock",     "label": "Inventory & Stock",     "icon": "bx-box",            "color": "success"},
    {"key": "financials_disposal", "label": "Financials & Disposal", "icon": "bx-rupee",          "color": "warning"},
    {"key": "risk_compliance",     "label": "Risk & Compliance",     "icon": "bx-shield-quarter", "color": "danger"},
]

ALL_REPORTS = [
    {
        "key": "dash_ops",
        "category": "dashboards",
        "icon": "bx-tachometer",
        "title": "Operations Dashboard",
        "desc": "Trends, KPIs, and mismatch analytics for the selected period.",
        "url": "/scratch/reports/dashboards/ops",
    },
    {
        "key": "dash_inventory",
        "category": "dashboards",
        "icon": "bx-layer",
        "title": "Inventory Dashboard",
        "desc": "Stock composition, valuation overview, and expiry risk at a glance.",
        "url": "/scratch/reports/dashboards/inventory",
    },
    {
        "key": "memo",
        "category": "operations",
        "icon": "bx-file",
        "title": "Memo Report",
        "desc": "Memos with status, mismatch counts, and quick links to verify.",
        "url": "/scratch/reports/memo_report",
    },
    {
        "key": "inward_items",
        "category": "operations",
        "icon": "bx-log-in-circle",
        "title": "Inward Items Report",
        "desc": "Line-wise inward items with received qty and mismatch diagnostics.",
        "url": "/scratch/reports/inward_report",
    },
    {
        "key": "mismatches",
        "category": "operations",
        "icon": "bx-error-circle",
        "title": "Mismatch Summary Report",
        "desc": "Mismatch concentration and rate trend by date and source.",
        "url": "/scratch/reports/mismatch_report",
    },
    {
        "key": "inventory",
        "category": "inventory_stock",
        "icon": "bx-box",
        "title": "Inventory Report",
        "desc": "Current stock snapshot with valuation, rates, and worth by material.",
        "url": "/scratch/reports/inventory_report",
    },
    {
        "key": "movements",
        "category": "inventory_stock",
        "icon": "bx-transfer",
        "title": "Inventory Movements Report",
        "desc": "Audit trail of IN/OUT stock movements with ref type and material filters.",
        "url": "/scratch/reports/inventory_movement_report",
    },
    {
        "key": "segregation",
        "category": "inventory_stock",
        "icon": "bx-sort-alt-2",
        "title": "Segregation Report",
        "desc": "Segregation entries by memo, material type, and weight.",
        "url": "/scratch/reports/segregation_report",
    },
    {
        "key": "expiry_alerts",
        "category": "inventory_stock",
        "icon": "bx-alarm-exclamation",
        "title": "Expiry Alert Report",
        "desc": "Lot-wise near-expiry, expired, and untracked stock with action queue.",
        "url": "/scratch/reports/expiry_alert_report",
    },
    {
        "key": "outward",
        "category": "financials_disposal",
        "icon": "bx-log-out-circle",
        "title": "Disposal / Sale Report",
        "desc": "Outward shipments by material type, recycler, vehicle, and date.",
        "url": "/scratch/reports/outward_report",
    },
    {
        "key": "financial_summary",
        "category": "financials_disposal",
        "icon": "bx-money",
        "title": "Financial Summary",
        "desc": "Inventory worth, disposal revenue, and unvalued stock by material.",
        "url": "/scratch/reports/financial_summary_report",
    },
    {
        "key": "vendor",
        "category": "financials_disposal",
        "icon": "bx-buildings",
        "title": "Vendor / Counterparty Report",
        "desc": "Disposal analysis by recycler — shipment counts, weight, and value.",
        "url": "/scratch/reports/vendor_report",
    },
    {
        "key": "exceptions",
        "category": "risk_compliance",
        "icon": "bx-bug",
        "title": "Data Exceptions",
        "desc": "Negative balances, missing rates, expiry risks, and ledger anomalies.",
        "url": "/scratch/reports/exceptions_report",
    },
    {
        "key": "schedules",
        "category": "risk_compliance",
        "icon": "bx-calendar",
        "title": "Report Schedules",
        "desc": "Create scheduled PDF/Excel generation and manage past exports.",
        "url": "/scratch/reports/schedules",
    },
]


@bp.get("/scratch/reports")
@login_required
def reports_index() -> object:
    reports = [r for r in ALL_REPORTS if can_view_report(str(r.get("key") or ""))]
    visible_keys = {r["category"] for r in reports}
    categories = [c for c in CATEGORIES if c["key"] in visible_keys]
    return render_template(
        "reports/index.html",
        pageTitle="Reports - SYMS",
        reports=reports,
        categories=categories,
    )


# ── Dashboards ────────────────────────────────────────────────────────────────

@bp.get("/scratch/reports/dashboards/ops")
@login_required
def reports_ops_dashboard() -> object:
    require_report_access("dash_ops")
    filters = read_filters()
    # Default to 30-day window if no preset
    cur_preset = str(filters.get("preset") or "")
    if not cur_preset and not filters.get("from"):
        end = date.today()
        start = end - timedelta(days=29)
        filters["from"] = start.isoformat()
        filters["to"] = end.isoformat()
        filters["preset"] = "30d"
        cur_preset = "30d"
    from_date, to_date = _parse_date_range(filters)

    # KPI summary
    source = str(filters.get("source") or "")
    where = "WHERE memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND source LIKE :source"
        params["source"] = f"%{source}%"
    with db_conn() as conn:
        kpi = fetch_one(
            conn,
            "SELECT COUNT(*) AS total_memos,\n"
            "       SUM(CASE WHEN status IN ('VERIFIED','MUTILATION_COMPLETED') THEN 1 ELSE 0 END) AS verified,\n"
            "       COALESCE(SUM(mismatch_count), 0) AS total_mismatches,\n"
            "       COUNT(DISTINCT source) AS unique_sources\n"
            f"FROM memos {where}",
            params,
        )

    total = int((kpi or {}).get("total_memos") or 0)
    verified = int((kpi or {}).get("verified") or 0)
    mismatches = int((kpi or {}).get("total_mismatches") or 0)
    sources = int((kpi or {}).get("unique_sources") or 0)
    verif_rate = round((verified / total * 100), 1) if total > 0 else 0.0

    return render_template(
        "reports/dash_ops.html",
        pageTitle="Operations Dashboard - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        kpi={
            "total_memos": total,
            "verified": verified,
            "verif_rate": verif_rate,
            "total_mismatches": mismatches,
            "unique_sources": sources,
        },
    )


@bp.get("/scratch/reports/dashboards/inventory")
@login_required
def reports_inventory_dashboard() -> object:
    require_report_access("dash_inventory")

    with db_conn() as conn:
        inv_summary = fetch_one(
            conn,
            "SELECT\n"
            "    COUNT(*) AS total_materials,\n"
            "    COALESCE(SUM(ib.balance_weight), 0) AS total_weight,\n"
            "    COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NOT NULL\n"
            "                 THEN ib.balance_weight * mr.rate_per_weight ELSE 0 END), 0) AS total_worth,\n"
            "    SUM(CASE WHEN mr.rate_per_weight IS NULL THEN 1 ELSE 0 END) AS unvalued_count\n"
            "FROM inventory_balances_v2 ib\n"
            "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
            "WHERE ib.balance_weight > 0",
        )
        expiry_summary = fetch_one(
            conn,
            "SELECT\n"
            "    SUM(CASE WHEN alert_state = 'NEAR_EXPIRY' THEN 1 ELSE 0 END) AS near_lots,\n"
            "    SUM(CASE WHEN alert_state = 'EXPIRED'    THEN 1 ELSE 0 END) AS expired_lots\n"
            "FROM expiry_alerts_vw\n"
            "WHERE balance_weight > 0",
        )

    return render_template(
        "reports/dash_inventory.html",
        pageTitle="Inventory Dashboard - SYMS",
        inv=inv_summary or {},
        expiry=expiry_summary or {},
    )


# ── Schedules ─────────────────────────────────────────────────────────────────

@bp.get("/scratch/reports/schedules")
@login_required
def reports_schedules() -> object:
    require_report_access("schedules")

    with db_conn() as conn:
        schedules = fetch_all(
            conn,
            "SELECT id, report_key, frequency, next_run_at, enabled, created_at\n"
            "FROM report_schedules\n"
            "ORDER BY created_at DESC",
        )
        exports = fetch_all(
            conn,
            "SELECT id, schedule_id, file_path, generated_at\n"
            "FROM report_exports\n"
            "ORDER BY generated_at DESC\n"
            "LIMIT 50",
        )

    report_keys = {
        "memo": "Memo Report",
        "inward_items": "Inward Items Report",
        "outward": "Disposal / Sale Report",
        "inventory": "Inventory Report",
        "segregation": "Segregation Report",
        "expiry_alerts": "Expiry Alert Report",
        "movements": "Inventory Movements Report",
        "mismatches": "Mismatch Summary Report",
    }

    return render_template(
        "reports/schedules.html",
        pageTitle="Report Schedules - SYMS",
        schedules=schedules,
        exports=exports,
        reportKeys=report_keys,
        materialTypes=_material_type_options(),
    )


@bp.post("/scratch/reports/schedule_create")
@login_required
@csrf_protect
def schedule_create() -> object:
    require_report_access("schedules")

    report_key = str(request.form.get("report_key") or "").strip()[:50]
    frequency = str(request.form.get("frequency") or "").strip()[:20]
    preset = str(request.form.get("preset") or "").strip()[:20]
    material_type = str(request.form.get("material_type") or "").strip()[:50]
    status = str(request.form.get("status") or "").strip()[:20]
    source = str(request.form.get("source") or "").strip()[:100]
    memo_number = str(request.form.get("memo_number") or "").strip()[:50]
    ref_type = str(request.form.get("ref_type") or "").strip()[:20]
    valuation_status = str(request.form.get("valuation_status") or "").strip()[:20]
    mismatch_only = 1 if request.form.get("mismatch_only") is not None else 0
    paper = str(request.form.get("paper") or "A4").strip()[:10]
    orientation = str(request.form.get("orientation") or "portrait").strip()[:10]
    template = str(request.form.get("template") or "default").strip()[:30]

    allowed_keys = {"memo", "inward_items", "outward", "inventory", "segregation", "expiry_alerts", "movements", "mismatches"}
    if report_key not in allowed_keys:
        flash_set("error", "Invalid report type.")
        return redirect("/scratch/reports/schedules")

    if frequency not in {"daily", "weekly", "monthly"}:
        frequency = "daily"

    filters = {
        "preset": preset,
        "material_type": material_type,
        "status": status,
        "source": source,
        "memo_number": memo_number,
        "ref_type": ref_type,
        "valuation_status": valuation_status,
        "mismatch_only": mismatch_only,
    }
    filters_json = json.dumps(filters)

    next_run_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    enabled = 1
    created_by = int(session.get("user_id") or 0)

    with db_conn() as conn:
        with conn.begin():
            execute(
                conn,
                "INSERT INTO report_schedules (report_key, filters_json, paper, orientation, template, frequency, next_run_at, enabled, created_by)\n"
                "VALUES (:report_key, :filters_json, :paper, :orientation, :template, :frequency, :next_run_at, :enabled, :created_by)",
                {
                    "report_key": report_key,
                    "filters_json": filters_json,
                    "paper": paper,
                    "orientation": orientation,
                    "template": template,
                    "frequency": frequency,
                    "next_run_at": next_run_at,
                    "enabled": enabled,
                    "created_by": created_by,
                },
            )

    flash_set("success", "Schedule created.")
    return redirect("/scratch/reports/schedules")


@bp.post("/scratch/reports/schedule_toggle")
@login_required
@csrf_protect
def schedule_toggle() -> object:
    require_report_access("schedules")
    try:
        schedule_id = int(request.form.get("id") or 0)
    except Exception:
        schedule_id = 0
    if schedule_id <= 0:
        flash_set("error", "Invalid schedule.")
        return redirect("/scratch/reports/schedules")

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT enabled FROM report_schedules WHERE id = :id", {"id": schedule_id})
        if not row:
            flash_set("error", "Schedule not found.")
            return redirect("/scratch/reports/schedules")
        enabled = 0 if int(row.get("enabled") or 0) == 1 else 1
        with conn.begin():
            execute(conn, "UPDATE report_schedules SET enabled = :e WHERE id = :id", {"e": enabled, "id": schedule_id})

    flash_set("success", "Schedule updated.")
    return redirect("/scratch/reports/schedules")


@bp.post("/scratch/reports/schedule_delete")
@login_required
@csrf_protect
def schedule_delete() -> object:
    require_report_access("schedules")
    try:
        schedule_id = int(request.form.get("id") or 0)
    except Exception:
        schedule_id = 0
    if schedule_id <= 0:
        flash_set("error", "Invalid schedule.")
        return redirect("/scratch/reports/schedules")

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT id FROM report_schedules WHERE id = :id", {"id": schedule_id})
        if not row:
            flash_set("error", "Schedule not found.")
            return redirect("/scratch/reports/schedules")
        with conn.begin():
            execute(conn, "DELETE FROM report_exports WHERE schedule_id = :id", {"id": schedule_id})
            execute(conn, "DELETE FROM report_schedules WHERE id = :id", {"id": schedule_id})

    flash_set("success", "Schedule deleted.")
    return redirect("/scratch/reports/schedules")


@bp.post("/scratch/reports/schedule_run_now")
@login_required
@csrf_protect
def schedule_run_now() -> object:
    require_report_access("schedules")
    flash_set("info", "Manual schedule execution not available in this build.")
    return redirect("/scratch/reports/schedules")


@bp.get("/scratch/reports/export_download")
@login_required
def export_download() -> Response:
    require_report_access("schedules")

    try:
        export_id = int(request.args.get("id") or 0)
    except Exception:
        export_id = 0
    if export_id <= 0:
        return Response("Invalid export", status=400, mimetype="text/plain")

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT file_path FROM report_exports WHERE id = :id", {"id": export_id})
    if not row:
        return Response("Not found", status=404, mimetype="text/plain")

    file_path = str(row.get("file_path") or "")
    name = os.path.basename(file_path)
    exports_dir = _exports_dir()
    abs_path = (exports_dir / name).resolve()

    if not str(abs_path).startswith(str(exports_dir)) or not abs_path.is_file():
        return Response("File missing", status=404, mimetype="text/plain")

    return send_file(abs_path, mimetype="application/pdf", as_attachment=True, download_name=name)


# ── Expiry Alert Report ────────────────────────────────────────────────────────

@bp.get("/scratch/reports/expiry_alert_report")
@login_required
def expiry_alert_report() -> object:
    require_report_access("expiry_alerts")

    try:
        category_id = int(request.args.get("category_id") or 0)
    except Exception:
        category_id = 0
    try:
        material_id = int(request.args.get("material_id") or 0)
    except Exception:
        material_id = 0
    try:
        lot_id = int(request.args.get("lot_id") or 0)
    except Exception:
        lot_id = 0
    state = str(request.args.get("state") or "ALL").strip()
    from_s = str(request.args.get("from") or "").strip()
    to_s = str(request.args.get("to") or "").strip()
    try:
        limit = int(request.args.get("limit") or 200)
    except Exception:
        limit = 200
    if limit < 25:
        limit = 25
    if limit > 500:
        limit = 500

    categories = _category_options()
    materials = _material_options()
    lots = _lot_options(material_id if material_id > 0 else None)

    dataset = expiry_alert_dataset(
        category_id if category_id > 0 else None,
        material_id if material_id > 0 else None,
        lot_id if lot_id > 0 else None,
        state,
        from_s or None,
        to_s or None,
        limit,
        0,
    )
    rows = list(dataset.get("rows") or [])
    summary = dict(dataset.get("summary") or {})

    filters = dict(request.args)
    return render_template(
        "reports/expiry_alert_report.html",
        pageTitle="Expiry Alert Report - SYMS",
        filters=filters,
        categoryId=category_id,
        materialId=material_id,
        lotId=lot_id,
        state=state,
        fromDate=from_s,
        toDate=to_s,
        limit=limit,
        categories=categories,
        materials=materials,
        lots=lots,
        rows=rows,
        summary=summary,
        role=current_user_role(),
        reset_url="/scratch/reports/expiry_alert_report",
        export_url=_export_url("expiry_alerts"),
    )


@bp.post("/scratch/reports/expiry_alert_update")
@login_required
@csrf_protect
def expiry_alert_update() -> object:
    require_admin()

    try:
        lot_id = int(request.form.get("lot_id") or 0)
    except Exception:
        lot_id = 0
    try:
        expiry_days = int(request.form.get("expiry_days") or 0)
    except Exception:
        expiry_days = -1
    return_to = str(request.form.get("return_to") or "").strip()
    if return_to == "":
        return_to = "/scratch/reports/expiry_alert_report"

    if lot_id <= 0:
        flash_set("error", "Invalid lot selected.")
        return redirect(return_to)
    if expiry_days < 0:
        flash_set("error", "Expiry days must be 0 or more.")
        return redirect(return_to)

    lot = lot_find_by_id(lot_id)
    if not lot:
        flash_set("error", "Lot not found.")
        return redirect(return_to)

    inward_date = str(lot.get("inward_date") or "")
    try:
        dt = date.fromisoformat(inward_date)
    except Exception:
        flash_set("error", "Invalid inward date on lot.")
        return redirect(return_to)

    expiry_date = (dt + timedelta(days=int(expiry_days))).isoformat()

    with db_conn() as conn:
        with conn.begin():
            execute(
                conn,
                "UPDATE material_lots SET expiry_date = :expiry_date, expiry_override = 1, updated_at = NOW() WHERE id = :id",
                {"expiry_date": expiry_date, "id": lot_id},
            )

    flash_set("success", "Lot expiry updated successfully.")
    return redirect(return_to)


# ── Memo Report ───────────────────────────────────────────────────────────────

@bp.get("/scratch/reports/memo_report")
@login_required
def memo_report() -> object:
    require_report_access("memo")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    status = str(filters.get("status") or "")
    memo_number = str(filters.get("memo_number") or "")
    source = str(filters.get("source") or "")

    where = "WHERE memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if status:
        where += " AND status = :status"
        params["status"] = status
    if memo_number:
        where += " AND memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if source:
        where += " AND source LIKE :source"
        params["source"] = f"%{source}%"

    sql = (
        "SELECT id, memo_number, memo_date, source, vehicle_number, status, mismatch_count\n"
        "FROM memos\n"
        f"{where}\n"
        "ORDER BY memo_date DESC, created_at DESC\n"
        "LIMIT 600"
    )
    sum_sql = (
        "SELECT COUNT(*) AS total_memos,\n"
        "       SUM(CASE WHEN status = 'UPLOADED' THEN 1 ELSE 0 END) AS pending,\n"
        "       SUM(CASE WHEN status IN ('VERIFIED','MUTILATION_COMPLETED') THEN 1 ELSE 0 END) AS completed,\n"
        "       SUM(CASE WHEN mismatch_count > 0 THEN 1 ELSE 0 END) AS with_mismatches\n"
        f"FROM memos {where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    summary_cards = [
        {"label": "Total Memos",       "value": int(sm.get("total_memos") or 0),    "icon": "bx-file",         "color": "primary"},
        {"label": "Pending",           "value": int(sm.get("pending") or 0),         "icon": "bx-time",         "color": "warning"},
        {"label": "Completed",         "value": int(sm.get("completed") or 0),       "icon": "bx-check-circle", "color": "success"},
        {"label": "With Mismatches",   "value": int(sm.get("with_mismatches") or 0), "icon": "bx-error-circle", "color": "danger"},
    ]

    return render_template(
        "reports/memo_report.html",
        pageTitle="Memo Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/memo_report",
        export_url=_export_url("memo"),
    )


# ── Inward Items Report ───────────────────────────────────────────────────────

@bp.get("/scratch/reports/inward_report")
@login_required
def inward_report() -> object:
    require_report_access("inward_items")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    memo_number = str(filters.get("memo_number") or "")
    mismatch_only = int(filters.get("mismatch_only") or 0) == 1

    where = "WHERE m.memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if memo_number:
        where += " AND m.memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if mismatch_only:
        where += " AND mi.is_mismatch = 1"

    sql = (
        "SELECT m.memo_number, mi.sr, COALESCE(mi.lot_number, mi.part_no) AS lot_number, mi.part_desc, mi.qty, mi.actual_qty, mi.is_mismatch, mi.mismatch_note\n"
        "FROM memo_items mi\n"
        "JOIN memos m ON m.id = mi.memo_id\n"
        f"{where}\n"
        "ORDER BY m.memo_date DESC, mi.sr ASC, mi.id ASC\n"
        "LIMIT 700"
    )
    sum_sql = (
        "SELECT COUNT(*) AS total_lines,\n"
        "       SUM(CASE WHEN mi.is_mismatch = 1 THEN 1 ELSE 0 END) AS mismatch_lines,\n"
        "       COUNT(DISTINCT m.id) AS memo_count,\n"
        "       ROUND(100.0 * SUM(CASE WHEN mi.is_mismatch = 1 THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1) AS mismatch_pct\n"
        "FROM memo_items mi\n"
        f"JOIN memos m ON m.id = mi.memo_id {where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    mismatch_pct = sm.get("mismatch_pct")
    pct_str = f"{float(mismatch_pct):.1f}%" if mismatch_pct is not None else "0.0%"
    summary_cards = [
        {"label": "Total Lines",   "value": int(sm.get("total_lines") or 0),    "icon": "bx-list-ul",      "color": "primary"},
        {"label": "Memo Count",    "value": int(sm.get("memo_count") or 0),     "icon": "bx-file",         "color": "info"},
        {"label": "Mismatch Lines","value": int(sm.get("mismatch_lines") or 0), "icon": "bx-error-circle", "color": "danger"},
        {"label": "Mismatch Rate", "value": pct_str,                             "icon": "bx-trending-up",  "color": "warning"},
    ]

    return render_template(
        "reports/inward_report.html",
        pageTitle="Inward Items Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/inward_report",
        export_url=_export_url("inward_items"),
    )


# ── Outward / Disposal Report ─────────────────────────────────────────────────

@bp.get("/scratch/reports/outward_report")
@login_required
def outward_report() -> object:
    require_report_access("outward")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if material_type:
        where += " AND material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT material_type, weight, vehicle_number, recycler_name, created_at\n"
        "FROM outward_entries\n"
        f"{where}\n"
        "ORDER BY created_at DESC\n"
        "LIMIT 700"
    )
    sum_sql = (
        "SELECT COUNT(*) AS total_entries,\n"
        "       COUNT(DISTINCT material_type) AS material_types,\n"
        "       COUNT(DISTINCT recycler_name) AS recycler_count,\n"
        "       COALESCE(SUM(weight), 0) AS total_weight\n"
        f"FROM outward_entries {where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    summary_cards = [
        {"label": "Shipments",       "value": int(sm.get("total_entries") or 0),                      "icon": "bx-log-out-circle", "color": "primary"},
        {"label": "Material Types",  "value": int(sm.get("material_types") or 0),                     "icon": "bx-category",       "color": "info"},
        {"label": "Total Weight",    "value": f"{float(sm.get('total_weight') or 0):.2f}",            "icon": "bx-package",        "color": "success"},
        {"label": "Unique Recyclers","value": int(sm.get("recycler_count") or 0),                     "icon": "bx-buildings",      "color": "warning"},
    ]

    return render_template(
        "reports/outward_report.html",
        pageTitle="Disposal / Sale Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        materialTypes=_material_type_options(),
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/outward_report",
        export_url=_export_url("outward"),
    )


# ── Inventory Report ──────────────────────────────────────────────────────────

@bp.get("/scratch/reports/inventory_report")
@login_required
def inventory_report() -> object:
    require_report_access("inventory")
    filters = read_filters()
    material_type = str(filters.get("material_type") or "")
    valuation_status = str(filters.get("valuation_status") or "")

    where = "WHERE ib.balance_weight > 0"
    params: dict[str, object] = {}
    if material_type:
        where += " AND ib.product_description = :material_type"
        params["material_type"] = material_type
    if valuation_status == "valued":
        where += " AND mr.rate_per_weight IS NOT NULL"
    if valuation_status == "unvalued":
        where += " AND mr.rate_per_weight IS NULL"

    sql = (
        "SELECT\n"
        "    ib.part_no_norm,\n"
        "    ib.product_description,\n"
        "    c.name AS category_name,\n"
        "    ib.uom_code,\n"
        "    ib.balance_weight,\n"
        "    mr.rate_per_weight\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN materials m ON m.id = ib.material_id\n"
        "LEFT JOIN material_categories c ON c.id = m.category_id\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        f"{where}\n"
        "ORDER BY ib.product_description ASC, ib.part_no_norm ASC"
    )
    sum_sql = (
        "SELECT COUNT(*) AS total_materials,\n"
        "       SUM(CASE WHEN mr.rate_per_weight IS NOT NULL THEN 1 ELSE 0 END) AS valued_count,\n"
        "       SUM(CASE WHEN mr.rate_per_weight IS NULL THEN 1 ELSE 0 END) AS unvalued_count,\n"
        "       COALESCE(SUM(ib.balance_weight), 0) AS total_weight,\n"
        "       COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NOT NULL\n"
        "                    THEN ib.balance_weight * mr.rate_per_weight ELSE 0 END), 0) AS total_worth\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        f"{where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    summary_cards = [
        {"label": "Materials",       "value": int(sm.get("total_materials") or 0),              "icon": "bx-box",         "color": "primary"},
        {"label": "Total Weight",    "value": f"{float(sm.get('total_weight') or 0):.2f}",     "icon": "bx-package",     "color": "info"},
        {"label": "Est. Worth (₹)",  "value": f"{float(sm.get('total_worth') or 0):,.2f}",     "icon": "bx-rupee",       "color": "success"},
        {"label": "Unvalued Items",  "value": int(sm.get("unvalued_count") or 0),              "icon": "bx-question-mark","color": "warning"},
    ]

    return render_template(
        "reports/inventory_report.html",
        pageTitle="Inventory Report - SYMS",
        filters=filters,
        materialTypes=_material_type_options(),
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/inventory_report",
        export_url=_export_url("inventory"),
    )


# ── Segregation Report ────────────────────────────────────────────────────────

@bp.get("/scratch/reports/segregation_report")
@login_required
def segregation_report() -> object:
    require_report_access("segregation")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    memo_number = str(filters.get("memo_number") or "")
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(se.created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if memo_number:
        where += " AND m.memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if material_type:
        where += " AND se.material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT COALESCE(m.memo_number, CONCAT('Memo #', se.memo_id)) AS memo_ref, se.material_type, se.weight, se.created_at\n"
        "FROM segregation_entries se\n"
        "LEFT JOIN memos m ON m.id = se.memo_id\n"
        f"{where}\n"
        "ORDER BY se.created_at DESC\n"
        "LIMIT 700"
    )
    sum_sql = (
        "SELECT COUNT(*) AS total_entries,\n"
        "       COUNT(DISTINCT se.memo_id) AS memo_count,\n"
        "       COUNT(DISTINCT se.material_type) AS material_types,\n"
        "       COALESCE(SUM(se.weight), 0) AS total_weight\n"
        "FROM segregation_entries se\n"
        f"LEFT JOIN memos m ON m.id = se.memo_id {where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    summary_cards = [
        {"label": "Entries",        "value": int(sm.get("total_entries") or 0),             "icon": "bx-sort-alt-2", "color": "primary"},
        {"label": "Memos",          "value": int(sm.get("memo_count") or 0),                "icon": "bx-file",       "color": "info"},
        {"label": "Material Types", "value": int(sm.get("material_types") or 0),            "icon": "bx-category",   "color": "success"},
        {"label": "Total Weight",   "value": f"{float(sm.get('total_weight') or 0):.2f}",  "icon": "bx-package",    "color": "warning"},
    ]

    return render_template(
        "reports/segregation_report.html",
        pageTitle="Segregation Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        materialTypes=_material_type_options(),
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/segregation_report",
        export_url=_export_url("segregation"),
    )


# ── Inventory Movements Report ────────────────────────────────────────────────

@bp.get("/scratch/reports/inventory_movement_report")
@login_required
def inventory_movement_report() -> object:
    require_report_access("movements")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    ref_type = str(filters.get("ref_type") or "")
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if ref_type:
        where += " AND ref_type = :ref_type"
        params["ref_type"] = ref_type
    if material_type:
        where += " AND (from_type = :material_type OR to_type = :material_type)"
        params["material_type"] = material_type

    sql = (
        "SELECT ref_type, ref_id, from_type, to_type, weight, created_at\n"
        "FROM inventory_movements\n"
        f"{where}\n"
        "ORDER BY created_at DESC\n"
        "LIMIT 800"
    )
    sum_sql = (
        "SELECT COUNT(*) AS total_movements,\n"
        "       SUM(CASE WHEN ref_type = 'INWARD' THEN 1 ELSE 0 END) AS inward_count,\n"
        "       SUM(CASE WHEN ref_type = 'OUTWARD' THEN 1 ELSE 0 END) AS outward_count,\n"
        "       SUM(CASE WHEN ref_type = 'SEGREGATION' THEN 1 ELSE 0 END) AS segregation_count\n"
        f"FROM inventory_movements {where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    summary_cards = [
        {"label": "Total Movements", "value": int(sm.get("total_movements") or 0),    "icon": "bx-transfer",     "color": "primary"},
        {"label": "Inward",          "value": int(sm.get("inward_count") or 0),       "icon": "bx-log-in-circle","color": "info"},
        {"label": "Segregation",     "value": int(sm.get("segregation_count") or 0),  "icon": "bx-sort-alt-2",   "color": "warning"},
        {"label": "Outward",         "value": int(sm.get("outward_count") or 0),      "icon": "bx-log-out-circle","color": "danger"},
    ]

    return render_template(
        "reports/inventory_movement_report.html",
        pageTitle="Inventory Movements Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        materialTypes=_material_type_options(),
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/inventory_movement_report",
        export_url=_export_url("movements"),
    )


# ── Mismatch Summary Report ───────────────────────────────────────────────────

@bp.get("/scratch/reports/mismatch_report")
@login_required
def mismatch_report() -> object:
    require_report_access("mismatches")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    source = str(filters.get("source") or "")

    where = "WHERE m.memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND m.source LIKE :source"
        params["source"] = f"%{source}%"

    sql = (
        "SELECT m.memo_date AS d,\n"
        "       m.source,\n"
        "       SUM(CASE WHEN mi.is_mismatch = 1 THEN 1 ELSE 0 END) AS mismatch_cnt,\n"
        "       COUNT(*) AS total_cnt\n"
        "FROM memo_items mi\n"
        "JOIN memos m ON m.id = mi.memo_id\n"
        f"{where}\n"
        "GROUP BY m.memo_date, m.source\n"
        "ORDER BY m.memo_date DESC, m.source ASC\n"
        "LIMIT 600"
    )
    sum_sql = (
        "SELECT COUNT(DISTINCT m.id) AS memo_count,\n"
        "       SUM(mi.is_mismatch) AS mismatch_lines,\n"
        "       COUNT(*) AS total_lines,\n"
        "       COUNT(DISTINCT m.source) AS source_count,\n"
        "       ROUND(100.0 * SUM(mi.is_mismatch) / NULLIF(COUNT(*), 0), 1) AS mismatch_rate\n"
        "FROM memo_items mi\n"
        f"JOIN memos m ON m.id = mi.memo_id {where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    mismatch_rate = sm.get("mismatch_rate")
    rate_str = f"{float(mismatch_rate):.1f}%" if mismatch_rate is not None else "0.0%"
    summary_cards = [
        {"label": "Memo Count",     "value": int(sm.get("memo_count") or 0),      "icon": "bx-file",         "color": "primary"},
        {"label": "Total Lines",    "value": int(sm.get("total_lines") or 0),     "icon": "bx-list-ul",      "color": "info"},
        {"label": "Mismatch Lines", "value": int(sm.get("mismatch_lines") or 0),  "icon": "bx-error-circle", "color": "danger"},
        {"label": "Mismatch Rate",  "value": rate_str,                             "icon": "bx-trending-up",  "color": "warning"},
    ]

    return render_template(
        "reports/mismatch_report.html",
        pageTitle="Mismatch Summary Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/mismatch_report",
        export_url=_export_url("mismatches"),
    )


# ── Financial Summary Report (new) ────────────────────────────────────────────

@bp.get("/scratch/reports/financial_summary_report")
@login_required
def financial_summary_report() -> object:
    require_report_access("financial_summary")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    material_type = str(filters.get("material_type") or "")

    inv_where = "WHERE ib.balance_weight > 0"
    inv_params: dict[str, object] = {}
    if material_type:
        inv_where += " AND ib.product_description = :material_type"
        inv_params["material_type"] = material_type

    oe_where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    oe_params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if material_type:
        oe_where += " AND material_type = :material_type"
        oe_params["material_type"] = material_type

    inv_sum_sql = (
        "SELECT COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NOT NULL\n"
        "             THEN ib.balance_weight * mr.rate_per_weight ELSE 0 END), 0) AS inventory_worth,\n"
        "       COUNT(*) AS total_materials,\n"
        "       SUM(CASE WHEN mr.rate_per_weight IS NOT NULL THEN 1 ELSE 0 END) AS valued_materials,\n"
        "       COALESCE(SUM(CASE WHEN mr.rate_per_weight IS NULL THEN ib.balance_weight ELSE 0 END), 0) AS unvalued_weight\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        f"{inv_where}"
    )
    oe_sum_sql = (
        "SELECT COUNT(*) AS disposal_count,\n"
        "       COALESCE(SUM(weight), 0) AS total_weight,\n"
        "       COALESCE(SUM(basic_value), 0) AS total_value\n"
        f"FROM outward_entries {oe_where}"
    )
    main_sql = (
        "SELECT ib.part_no_norm, ib.product_description, c.name AS category_name,\n"
        "       ib.uom_code, ib.balance_weight, mr.rate_per_weight,\n"
        "       CASE WHEN mr.rate_per_weight IS NOT NULL\n"
        "            THEN ib.balance_weight * mr.rate_per_weight ELSE NULL END AS worth,\n"
        "       COALESCE(oe_agg.disposed_weight, 0) AS disposed_weight,\n"
        "       COALESCE(oe_agg.disposed_value, 0) AS disposed_value\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN materials m ON m.id = ib.material_id\n"
        "LEFT JOIN material_categories c ON c.id = m.category_id\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        "LEFT JOIN (\n"
        "    SELECT material_id, SUM(weight) AS disposed_weight, SUM(basic_value) AS disposed_value\n"
        f"   FROM outward_entries {oe_where}\n"
        "    GROUP BY material_id\n"
        ") oe_agg ON oe_agg.material_id = ib.material_id\n"
        f"{inv_where}\n"
        "ORDER BY worth DESC, ib.product_description ASC\n"
        "LIMIT 500"
    )
    combined_params = {**inv_params, **oe_params}

    with db_conn() as conn:
        inv_sm = fetch_one(conn, inv_sum_sql, inv_params) or {}
        oe_sm = fetch_one(conn, oe_sum_sql, oe_params) or {}
        rows = fetch_all(conn, main_sql, combined_params)

    summary_cards = [
        {"label": "Inventory Worth (₹)", "value": f"{float(inv_sm.get('inventory_worth') or 0):,.2f}", "icon": "bx-money",   "color": "success"},
        {"label": "Disposed Value (₹)",  "value": f"{float(oe_sm.get('total_value') or 0):,.2f}",      "icon": "bx-rupee",   "color": "primary"},
        {"label": "Disposed Weight",     "value": f"{float(oe_sm.get('total_weight') or 0):.2f}",      "icon": "bx-package", "color": "info"},
        {"label": "Unvalued Weight",     "value": f"{float(inv_sm.get('unvalued_weight') or 0):.2f}",  "icon": "bx-question-mark", "color": "warning"},
    ]

    return render_template(
        "reports/financial_summary_report.html",
        pageTitle="Financial Summary - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        materialTypes=_material_type_options(),
        rows=rows,
        inv_sm=inv_sm,
        oe_sm=oe_sm,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/financial_summary_report",
        export_url=_export_url("financial_summary"),
    )


# ── Vendor / Counterparty Report (new) ───────────────────────────────────────

@bp.get("/scratch/reports/vendor_report")
@login_required
def vendor_report() -> object:
    require_report_access("vendor")
    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)
    recycler_name = str(filters.get("recycler_name") or "")
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(oe.created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if recycler_name:
        where += " AND oe.recycler_name LIKE :recycler_name"
        params["recycler_name"] = f"%{recycler_name}%"
    if material_type:
        where += " AND oe.material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT oe.recycler_name, oe.material_type,\n"
        "       COUNT(*) AS shipment_count,\n"
        "       COALESCE(SUM(oe.weight), 0) AS total_weight,\n"
        "       COALESCE(SUM(oe.basic_value), 0) AS total_value,\n"
        "       MIN(DATE(oe.created_at)) AS first_shipment,\n"
        "       MAX(DATE(oe.created_at)) AS last_shipment\n"
        "FROM outward_entries oe\n"
        f"{where}\n"
        "GROUP BY oe.recycler_name, oe.material_type\n"
        "ORDER BY total_value DESC, total_weight DESC\n"
        "LIMIT 500"
    )
    sum_sql = (
        "SELECT COUNT(DISTINCT oe.recycler_name) AS vendor_count,\n"
        "       COUNT(*) AS total_shipments,\n"
        "       COALESCE(SUM(oe.weight), 0) AS total_weight,\n"
        "       COALESCE(SUM(oe.basic_value), 0) AS total_value\n"
        "FROM outward_entries oe\n"
        f"{where}"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
        sm = fetch_one(conn, sum_sql, params) or {}

    summary_cards = [
        {"label": "Vendors",          "value": int(sm.get("vendor_count") or 0),                       "icon": "bx-buildings",      "color": "primary"},
        {"label": "Total Shipments",  "value": int(sm.get("total_shipments") or 0),                    "icon": "bx-log-out-circle", "color": "info"},
        {"label": "Total Weight",     "value": f"{float(sm.get('total_weight') or 0):.2f}",           "icon": "bx-package",        "color": "success"},
        {"label": "Total Value (₹)",  "value": f"{float(sm.get('total_value') or 0):,.2f}",           "icon": "bx-rupee",          "color": "warning"},
    ]

    return render_template(
        "reports/vendor_report.html",
        pageTitle="Vendor Report - SYMS",
        filters=filters,
        fromDate=from_date,
        toDate=to_date,
        materialTypes=_material_type_options(),
        rows=rows,
        summary_cards=summary_cards,
        reset_url="/scratch/reports/vendor_report",
        export_url=_export_url("vendor"),
    )


# ── Data Exceptions Report (new) ──────────────────────────────────────────────

@bp.get("/scratch/reports/exceptions_report")
@login_required
def exceptions_report() -> object:
    require_report_access("exceptions")
    from app.modules.reports_v2.exceptions import build_exceptions

    with db_conn() as conn:
        exceptions = build_exceptions(conn)

    total_issues = sum(int(e.get("count") or 0) for e in exceptions)
    return render_template(
        "reports/exceptions_report.html",
        pageTitle="Data Exceptions - SYMS",
        exceptions=exceptions,
        total_issues=total_issues,
    )


# ── Export PDF (stub) ─────────────────────────────────────────────────────────

@bp.get("/scratch/reports/export_pdf")
@login_required
def export_pdf() -> Response:
    report_key = str(request.args.get("report_key") or "").strip()
    if report_key == "":
        return Response("Missing report_key", status=400, mimetype="text/plain")
    require_report_access(report_key)
    return Response("PDF export not available in this build.", status=501, mimetype="text/plain")


# ── Export Excel (functional) ─────────────────────────────────────────────────

@bp.get("/scratch/reports/export_excel")
@login_required
def export_excel() -> Response:
    from app.modules.reports_v2.exporting import render_excel_bytes, send_export

    report_key = str(request.args.get("report_key") or "").strip()
    if report_key == "":
        return Response("Missing report_key", status=400, mimetype="text/plain")
    require_report_access(report_key)

    filters = read_filters()
    from_date, to_date = _parse_date_range(filters)

    EXPORTERS = {
        "memo": _export_memo,
        "inward_items": _export_inward,
        "outward": _export_outward,
        "inventory": _export_inventory,
        "segregation": _export_segregation,
        "movements": _export_movements,
        "mismatches": _export_mismatches,
        "expiry_alerts": _export_expiry_alerts,
        "financial_summary": _export_financial_summary,
        "vendor": _export_vendor,
        "exceptions": _export_exceptions,
    }
    fn = EXPORTERS.get(report_key)
    if fn is None:
        return Response("Export not supported for this report.", status=400, mimetype="text/plain")

    columns, rows = fn(filters, from_date, to_date)
    content = render_excel_bytes(columns, rows)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return send_export(
        content,
        filename=f"{report_key}_{stamp}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


# ── Export helper functions ───────────────────────────────────────────────────

def _export_memo(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    status = str(filters.get("status") or "")
    memo_number = str(filters.get("memo_number") or "")
    source = str(filters.get("source") or "")
    where = "WHERE memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if status:
        where += " AND status = :status"
        params["status"] = status
    if memo_number:
        where += " AND memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if source:
        where += " AND source LIKE :source"
        params["source"] = f"%{source}%"
    sql = f"SELECT memo_number, memo_date, source, vehicle_number, status, mismatch_count FROM memos {where} ORDER BY memo_date DESC, created_at DESC LIMIT 10000"
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["memo_number", "memo_date", "source", "vehicle_number", "status", "mismatch_count"], rows


def _export_inward(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    memo_number = str(filters.get("memo_number") or "")
    mismatch_only = int(filters.get("mismatch_only") or 0) == 1
    where = "WHERE m.memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if memo_number:
        where += " AND m.memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if mismatch_only:
        where += " AND mi.is_mismatch = 1"
    sql = (
        "SELECT m.memo_number, mi.sr, COALESCE(mi.lot_number, mi.part_no) AS lot_number, mi.part_desc, mi.qty, mi.actual_qty, mi.is_mismatch, mi.mismatch_note\n"
        "FROM memo_items mi JOIN memos m ON m.id = mi.memo_id\n"
        f"{where} ORDER BY m.memo_date DESC, mi.sr ASC LIMIT 10000"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["memo_number", "sr", "lot_number", "part_desc", "qty", "actual_qty", "is_mismatch", "mismatch_note"], rows


def _export_outward(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    material_type = str(filters.get("material_type") or "")
    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if material_type:
        where += " AND material_type = :material_type"
        params["material_type"] = material_type
    sql = f"SELECT material_type, weight, vehicle_number, recycler_name, created_at FROM outward_entries {where} ORDER BY created_at DESC LIMIT 10000"
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["material_type", "weight", "vehicle_number", "recycler_name", "created_at"], rows


def _export_inventory(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    material_type = str(filters.get("material_type") or "")
    valuation_status = str(filters.get("valuation_status") or "")
    where = "WHERE ib.balance_weight > 0"
    params: dict[str, object] = {}
    if material_type:
        where += " AND ib.product_description = :material_type"
        params["material_type"] = material_type
    if valuation_status == "valued":
        where += " AND mr.rate_per_weight IS NOT NULL"
    if valuation_status == "unvalued":
        where += " AND mr.rate_per_weight IS NULL"
    sql = (
        "SELECT ib.part_no_norm, ib.product_description, c.name AS category_name, ib.uom_code, ib.balance_weight, mr.rate_per_weight\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN materials m ON m.id = ib.material_id\n"
        "LEFT JOIN material_categories c ON c.id = m.category_id\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        f"{where} ORDER BY ib.product_description ASC LIMIT 10000"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["part_no_norm", "product_description", "category_name", "uom_code", "balance_weight", "rate_per_weight"], rows


def _export_segregation(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    memo_number = str(filters.get("memo_number") or "")
    material_type = str(filters.get("material_type") or "")
    where = "WHERE DATE(se.created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if memo_number:
        where += " AND m.memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if material_type:
        where += " AND se.material_type = :material_type"
        params["material_type"] = material_type
    sql = (
        "SELECT COALESCE(m.memo_number, CONCAT('Memo #', se.memo_id)) AS memo_ref, se.material_type, se.weight, se.created_at\n"
        "FROM segregation_entries se LEFT JOIN memos m ON m.id = se.memo_id\n"
        f"{where} ORDER BY se.created_at DESC LIMIT 10000"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["memo_ref", "material_type", "weight", "created_at"], rows


def _export_movements(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    ref_type = str(filters.get("ref_type") or "")
    material_type = str(filters.get("material_type") or "")
    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if ref_type:
        where += " AND ref_type = :ref_type"
        params["ref_type"] = ref_type
    if material_type:
        where += " AND (from_type = :material_type OR to_type = :material_type)"
        params["material_type"] = material_type
    sql = f"SELECT ref_type, ref_id, from_type, to_type, weight, created_at FROM inventory_movements {where} ORDER BY created_at DESC LIMIT 10000"
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["ref_type", "ref_id", "from_type", "to_type", "weight", "created_at"], rows


def _export_mismatches(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    source = str(filters.get("source") or "")
    where = "WHERE m.memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND m.source LIKE :source"
        params["source"] = f"%{source}%"
    sql = (
        "SELECT m.memo_date AS d, m.source,\n"
        "       SUM(CASE WHEN mi.is_mismatch = 1 THEN 1 ELSE 0 END) AS mismatch_cnt,\n"
        "       COUNT(*) AS total_cnt\n"
        "FROM memo_items mi JOIN memos m ON m.id = mi.memo_id\n"
        f"{where} GROUP BY m.memo_date, m.source ORDER BY m.memo_date DESC LIMIT 10000"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["d", "source", "mismatch_cnt", "total_cnt"], rows


def _export_expiry_alerts(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    try:
        category_id_v = int(filters.get("category_id") or 0)
    except Exception:
        category_id_v = 0
    try:
        material_id_v = int(filters.get("material_id") or 0)
    except Exception:
        material_id_v = 0
    try:
        lot_id_v = int(filters.get("lot_id") or 0)
    except Exception:
        lot_id_v = 0
    state = str(filters.get("state") or "ALL")
    dataset = expiry_alert_dataset(
        category_id_v if category_id_v > 0 else None,
        material_id_v if material_id_v > 0 else None,
        lot_id_v if lot_id_v > 0 else None,
        state,
        from_date or None,
        to_date or None,
        50000,
        0,
        max_limit=50000,
    )
    rows = list(dataset.get("rows") or [])
    return ["lot_number", "part_no_norm", "product_description", "category_name", "inward_date", "expiry_date", "days_to_expiry", "uom_code", "balance_weight", "alert_state"], rows


def _export_financial_summary(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    material_type = str(filters.get("material_type") or "")
    inv_where = "WHERE ib.balance_weight > 0"
    inv_params: dict[str, object] = {}
    oe_where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    oe_params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if material_type:
        inv_where += " AND ib.product_description = :material_type"
        inv_params["material_type"] = material_type
        oe_where += " AND material_type = :material_type"
        oe_params["material_type"] = material_type
    sql = (
        "SELECT ib.part_no_norm, ib.product_description, c.name AS category_name,\n"
        "       ib.uom_code, ib.balance_weight, mr.rate_per_weight,\n"
        "       CASE WHEN mr.rate_per_weight IS NOT NULL THEN ib.balance_weight * mr.rate_per_weight ELSE NULL END AS worth,\n"
        "       COALESCE(oe_agg.disposed_weight, 0) AS disposed_weight,\n"
        "       COALESCE(oe_agg.disposed_value, 0) AS disposed_value\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN materials m ON m.id = ib.material_id\n"
        "LEFT JOIN material_categories c ON c.id = m.category_id\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        "LEFT JOIN (\n"
        "    SELECT material_id, SUM(weight) AS disposed_weight, SUM(basic_value) AS disposed_value\n"
        f"   FROM outward_entries {oe_where} GROUP BY material_id\n"
        f") oe_agg ON oe_agg.material_id = ib.material_id {inv_where}\n"
        "ORDER BY worth DESC, ib.product_description ASC LIMIT 10000"
    )
    combined_params = {**inv_params, **oe_params}
    with db_conn() as conn:
        rows = fetch_all(conn, sql, combined_params)
    return ["part_no_norm", "product_description", "category_name", "uom_code", "balance_weight", "rate_per_weight", "worth", "disposed_weight", "disposed_value"], rows


def _export_vendor(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    recycler_name = str(filters.get("recycler_name") or "")
    material_type = str(filters.get("material_type") or "")
    where = "WHERE DATE(oe.created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if recycler_name:
        where += " AND oe.recycler_name LIKE :recycler_name"
        params["recycler_name"] = f"%{recycler_name}%"
    if material_type:
        where += " AND oe.material_type = :material_type"
        params["material_type"] = material_type
    sql = (
        "SELECT oe.recycler_name, oe.material_type, COUNT(*) AS shipment_count,\n"
        "       COALESCE(SUM(oe.weight), 0) AS total_weight, COALESCE(SUM(oe.basic_value), 0) AS total_value,\n"
        "       MIN(DATE(oe.created_at)) AS first_shipment, MAX(DATE(oe.created_at)) AS last_shipment\n"
        "FROM outward_entries oe\n"
        f"{where} GROUP BY oe.recycler_name, oe.material_type ORDER BY total_value DESC LIMIT 10000"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)
    return ["recycler_name", "material_type", "shipment_count", "total_weight", "total_value", "first_shipment", "last_shipment"], rows


def _export_exceptions(filters: dict, from_date: str, to_date: str) -> tuple[list[str], list[dict]]:
    from app.modules.reports_v2.exceptions import build_exceptions
    rows_out: list[dict] = []
    with db_conn() as conn:
        exceptions = build_exceptions(conn)
    for exc in exceptions:
        exc_type = str(exc.get("title") or exc.get("type") or "")
        for r in (exc.get("rows") or []):
            rows_out.append({"exception_type": exc_type, **r})
    return ["exception_type", "part_no_norm", "product_description", "uom_code", "balance_weight", "alert_state", "days_to_expiry"], rows_out
