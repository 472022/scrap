from __future__ import annotations

from datetime import date, timedelta

from flask import Blueprint, jsonify, request

from app.db.engine import db_conn
from app.db.query import fetch_all
from app.security.auth import login_required
from app.utils.report_cache import get_cached, set_cached
from app.utils.report_filters import read_filters
from app.utils.rbac import require_report_access

bp = Blueprint("reports_api_trends", __name__)


def _date_range(from_s: str, to_s: str) -> list[str]:
    start = date.fromisoformat(from_s)
    end = date.fromisoformat(to_s)
    out: list[str] = []
    d = start
    while d <= end:
        out.append(d.isoformat())
        d += timedelta(days=1)
    return out


@bp.get("/scratch/reports/api/trend_memos")
@login_required
def trend_memos() -> object:
    require_report_access("dash_ops")

    cache_key = f"trend_memos|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date = str(filters.get("from") or "")
    to_date = str(filters.get("to") or "")
    source = str(filters.get("source") or "")

    where = "WHERE memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND source LIKE :source"
        params["source"] = f"%{source}%"

    sql = (
        "SELECT memo_date AS d,\n"
        "       SUM(CASE WHEN status IN ('VERIFIED','MUTILATION_COMPLETED') THEN 1 ELSE 0 END) AS verified_cnt\n"
        "FROM memos\n"
        f"{where}\n"
        "GROUP BY memo_date\n"
        "ORDER BY memo_date ASC"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    mp = {str(r.get("d") or ""): int(r.get("verified_cnt") or 0) for r in rows}
    labels = _date_range(from_date, to_date)
    verified = [int(mp.get(d, 0)) for d in labels]

    out = {"labels": labels, "verified": verified}
    set_cached(cache_key, out)
    return jsonify(out)


@bp.get("/scratch/reports/api/trend_mismatches")
@login_required
def trend_mismatches() -> object:
    require_report_access("dash_ops")

    cache_key = f"trend_mismatches|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date = str(filters.get("from") or "")
    to_date = str(filters.get("to") or "")
    source = str(filters.get("source") or "")

    where = "WHERE m.memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND m.source LIKE :source"
        params["source"] = f"%{source}%"

    sql = (
        "SELECT m.memo_date AS d,\n"
        "       SUM(CASE WHEN mi.is_mismatch = 1 THEN 1 ELSE 0 END) AS mismatch_cnt,\n"
        "       COUNT(*) AS total_cnt\n"
        "FROM memo_items mi\n"
        "JOIN memos m ON m.id = mi.memo_id\n"
        f"{where}\n"
        "GROUP BY m.memo_date\n"
        "ORDER BY m.memo_date ASC"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    mp_m = {str(r.get("d") or ""): int(r.get("mismatch_cnt") or 0) for r in rows}
    mp_t = {str(r.get("d") or ""): int(r.get("total_cnt") or 0) for r in rows}

    labels = _date_range(from_date, to_date)
    count = []
    rate = []
    for d in labels:
        m = int(mp_m.get(d, 0))
        t = int(mp_t.get(d, 0))
        count.append(m)
        rate.append(round((m / t) * 100, 2) if t > 0 else 0)

    out = {"labels": labels, "count": count, "rate": rate}
    set_cached(cache_key, out)
    return jsonify(out)
