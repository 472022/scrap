from __future__ import annotations

from datetime import date, timedelta

from flask import Blueprint, jsonify, request

from app.db.engine import db_conn
from app.db.query import fetch_all
from app.security.auth import login_required
from app.utils.rbac import require_report_access
from app.utils.report_cache import get_cached, set_cached
from app.utils.report_filters import read_filters

bp = Blueprint("reports_api_charts", __name__)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _date_range(from_s: str, to_s: str) -> list[str]:
    try:
        start = date.fromisoformat(from_s)
        end = date.fromisoformat(to_s)
    except Exception:
        today = date.today()
        return [(today - timedelta(days=i)).isoformat() for i in range(29, -1, -1)]
    out: list[str] = []
    d = start
    while d <= end:
        out.append(d.isoformat())
        d += timedelta(days=1)
    return out


def _parse_dates(filters: dict) -> tuple[str, str]:
    from_s = str(filters.get("from") or "")
    to_s = str(filters.get("to") or "")
    try:
        date.fromisoformat(from_s)
        date.fromisoformat(to_s)
        return from_s, to_s
    except Exception:
        today = date.today()
        return (today - timedelta(days=29)).isoformat(), today.isoformat()


# ── Outward by Material ───────────────────────────────────────────────────────

@bp.get("/scratch/reports/api/outward_by_material")
@login_required
def outward_by_material() -> object:
    require_report_access("outward")

    cache_key = f"outward_by_material|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date, to_date = _parse_dates(filters)
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if material_type:
        where += " AND material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT material_type, COALESCE(SUM(weight), 0) AS total_weight\n"
        f"FROM outward_entries {where}\n"
        "GROUP BY material_type\n"
        "ORDER BY total_weight DESC\n"
        "LIMIT 20"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    out = {
        "labels": [str(r.get("material_type") or "") for r in rows],
        "values": [round(float(r.get("total_weight") or 0), 2) for r in rows],
    }
    set_cached(cache_key, out)
    return jsonify(out)


# ── Inventory by Category ─────────────────────────────────────────────────────

@bp.get("/scratch/reports/api/inventory_by_category")
@login_required
def inventory_by_category() -> object:
    require_report_access("inventory")

    cache_key = f"inventory_by_category|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    material_type = str(filters.get("material_type") or "")

    where = "WHERE ib.balance_weight > 0"
    params: dict[str, object] = {}
    if material_type:
        where += " AND ib.product_description = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT ib.product_description AS name, COALESCE(SUM(ib.balance_weight), 0) AS value\n"
        "FROM inventory_balances_v2 ib\n"
        f"{where}\n"
        "GROUP BY ib.product_description\n"
        "ORDER BY value DESC\n"
        "LIMIT 20"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    items = [{"name": str(r.get("name") or ""), "value": round(float(r.get("value") or 0), 2)} for r in rows]
    out = {"items": items}
    set_cached(cache_key, out)
    return jsonify(out)


# ── Mismatch Rate Trend (for mismatch report page) ────────────────────────────

@bp.get("/scratch/reports/api/mismatch_rate_trend")
@login_required
def mismatch_rate_trend() -> object:
    require_report_access("mismatches")

    cache_key = f"mismatch_rate_trend|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date, to_date = _parse_dates(filters)
    source = str(filters.get("source") or "")

    where = "WHERE m.memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND m.source LIKE :source"
        params["source"] = f"%{source}%"

    sql = (
        "SELECT m.memo_date AS d,\n"
        "       SUM(CASE WHEN mi.is_mismatch = 1 THEN 1 ELSE 0 END) AS mismatch_cnt,\n"
        "       COUNT(*) AS total_cnt\n"
        "FROM memo_items mi\n"
        "JOIN memos m ON m.id = mi.memo_id\n"
        f"{where}\n"
        "GROUP BY m.memo_date\n"
        "ORDER BY m.memo_date ASC"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    mp_m = {str(r.get("d") or ""): int(r.get("mismatch_cnt") or 0) for r in rows}
    mp_t = {str(r.get("d") or ""): int(r.get("total_cnt") or 0) for r in rows}

    labels = _date_range(from_date, to_date)
    count: list[int] = []
    rate: list[float] = []
    for d in labels:
        m = int(mp_m.get(d, 0))
        t = int(mp_t.get(d, 0))
        count.append(m)
        rate.append(round((m / t) * 100, 2) if t > 0 else 0.0)

    out = {"labels": labels, "count": count, "rate": rate}
    set_cached(cache_key, out)
    return jsonify(out)


# ── Segregation by Material ───────────────────────────────────────────────────

@bp.get("/scratch/reports/api/segregation_by_material")
@login_required
def segregation_by_material() -> object:
    require_report_access("segregation")

    cache_key = f"segregation_by_material|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date, to_date = _parse_dates(filters)
    memo_number = str(filters.get("memo_number") or "")
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(se.created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if memo_number:
        where += " AND m.memo_number LIKE :memo_number"
        params["memo_number"] = f"%{memo_number}%"
    if material_type:
        where += " AND se.material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT se.material_type, COALESCE(SUM(se.weight), 0) AS total_weight\n"
        "FROM segregation_entries se\n"
        "LEFT JOIN memos m ON m.id = se.memo_id\n"
        f"{where}\n"
        "GROUP BY se.material_type\n"
        "ORDER BY total_weight DESC\n"
        "LIMIT 15"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    out = {
        "labels": [str(r.get("material_type") or "") for r in rows],
        "values": [round(float(r.get("total_weight") or 0), 2) for r in rows],
    }
    set_cached(cache_key, out)
    return jsonify(out)


# ── Movements by Type Trend ───────────────────────────────────────────────────

@bp.get("/scratch/reports/api/movements_by_type_trend")
@login_required
def movements_by_type_trend() -> object:
    require_report_access("movements")

    cache_key = f"movements_by_type_trend|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date, to_date = _parse_dates(filters)
    ref_type_f = str(filters.get("ref_type") or "")

    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if ref_type_f:
        where += " AND ref_type = :ref_type"
        params["ref_type"] = ref_type_f

    sql = (
        "SELECT DATE(created_at) AS d, ref_type, COUNT(*) AS cnt\n"
        "FROM inventory_movements\n"
        f"{where}\n"
        "GROUP BY DATE(created_at), ref_type\n"
        "ORDER BY d ASC"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    labels = _date_range(from_date, to_date)
    mp: dict[str, dict[str, int]] = {}
    for r in rows:
        day = str(r.get("d") or "")
        rt = str(r.get("ref_type") or "")
        if day not in mp:
            mp[day] = {}
        mp[day][rt] = int(r.get("cnt") or 0)

    inward = [int(mp.get(d, {}).get("INWARD", 0)) for d in labels]
    segregation = [int(mp.get(d, {}).get("SEGREGATION", 0)) for d in labels]
    outward = [int(mp.get(d, {}).get("OUTWARD", 0)) for d in labels]

    out = {"labels": labels, "inward": inward, "segregation": segregation, "outward": outward}
    set_cached(cache_key, out)
    return jsonify(out)


# ── Financial by Category (for Financial Summary report) ──────────────────────

@bp.get("/scratch/reports/api/financial_by_category")
@login_required
def financial_by_category() -> object:
    require_report_access("financial_summary")

    cache_key = f"financial_by_category|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    material_type = str(filters.get("material_type") or "")

    where = "WHERE ib.balance_weight > 0 AND mr.rate_per_weight IS NOT NULL"
    params: dict[str, object] = {}
    if material_type:
        where += " AND ib.product_description = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT c.name AS category_name,\n"
        "       COALESCE(SUM(ib.balance_weight * mr.rate_per_weight), 0) AS worth\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN materials m ON m.id = ib.material_id\n"
        "LEFT JOIN material_categories c ON c.id = m.category_id\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        f"{where}\n"
        "GROUP BY c.name\n"
        "ORDER BY worth DESC\n"
        "LIMIT 20"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    items = [
        {"name": str(r.get("category_name") or "Uncategorised"), "value": round(float(r.get("worth") or 0), 2)}
        for r in rows
    ]
    out = {"items": items}
    set_cached(cache_key, out)
    return jsonify(out)


# ── Financial Top Materials ────────────────────────────────────────────────────

@bp.get("/scratch/reports/api/financial_top_materials")
@login_required
def financial_top_materials() -> object:
    require_report_access("financial_summary")

    cache_key = f"financial_top_materials|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    material_type = str(filters.get("material_type") or "")

    where = "WHERE ib.balance_weight > 0 AND mr.rate_per_weight IS NOT NULL"
    params: dict[str, object] = {}
    if material_type:
        where += " AND ib.product_description = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT ib.product_description,\n"
        "       COALESCE(SUM(ib.balance_weight * mr.rate_per_weight), 0) AS worth\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        f"{where}\n"
        "GROUP BY ib.product_description\n"
        "ORDER BY worth DESC\n"
        "LIMIT 10"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    out = {
        "labels": [str(r.get("product_description") or "") for r in rows],
        "values": [round(float(r.get("worth") or 0), 2) for r in rows],
    }
    set_cached(cache_key, out)
    return jsonify(out)


# ── Vendor by Value ───────────────────────────────────────────────────────────

@bp.get("/scratch/reports/api/vendor_by_value")
@login_required
def vendor_by_value() -> object:
    require_report_access("vendor")

    cache_key = f"vendor_by_value|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date, to_date = _parse_dates(filters)
    recycler_name = str(filters.get("recycler_name") or "")
    material_type = str(filters.get("material_type") or "")

    where = "WHERE DATE(created_at) BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if recycler_name:
        where += " AND recycler_name LIKE :recycler_name"
        params["recycler_name"] = f"%{recycler_name}%"
    if material_type:
        where += " AND material_type = :material_type"
        params["material_type"] = material_type

    sql = (
        "SELECT recycler_name, COALESCE(SUM(basic_value), 0) AS total_value\n"
        f"FROM outward_entries {where}\n"
        "GROUP BY recycler_name\n"
        "ORDER BY total_value DESC\n"
        "LIMIT 10"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql, params)

    out = {
        "labels": [str(r.get("recycler_name") or "") for r in rows],
        "values": [round(float(r.get("total_value") or 0), 2) for r in rows],
    }
    set_cached(cache_key, out)
    return jsonify(out)


# ── Ops Summary (for ops dashboard KPI cards via AJAX) ────────────────────────

@bp.get("/scratch/reports/api/ops_summary")
@login_required
def ops_summary() -> object:
    require_report_access("dash_ops")

    cache_key = f"ops_summary|{request.query_string.decode('utf-8', 'ignore')}"
    cached = get_cached(cache_key, 60)
    if cached:
        return jsonify(cached)

    filters = read_filters()
    from_date, to_date = _parse_dates(filters)
    source = str(filters.get("source") or "")

    where = "WHERE memo_date BETWEEN :from_date AND :to_date"
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    if source:
        where += " AND source LIKE :source"
        params["source"] = f"%{source}%"

    sql = (
        "SELECT COUNT(*) AS total_memos,\n"
        "       SUM(CASE WHEN status IN ('VERIFIED','MUTILATION_COMPLETED') THEN 1 ELSE 0 END) AS verified,\n"
        "       COALESCE(SUM(mismatch_count), 0) AS total_mismatches,\n"
        "       COUNT(DISTINCT source) AS unique_sources\n"
        f"FROM memos {where}"
    )
    from app.db.query import fetch_one
    with db_conn() as conn:
        row = fetch_one(conn, sql, params) or {}

    out = {
        "total_memos": int(row.get("total_memos") or 0),
        "verified": int(row.get("verified") or 0),
        "total_mismatches": int(row.get("total_mismatches") or 0),
        "unique_sources": int(row.get("unique_sources") or 0),
    }
    set_cached(cache_key, out)
    return jsonify(out)
