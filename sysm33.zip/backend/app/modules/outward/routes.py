from __future__ import annotations

import csv
import io
import logging
import os

_log = logging.getLogger(__name__)
import secrets
from datetime import date, datetime
from pathlib import Path
from urllib.parse import urlencode

from flask import Blueprint, Response, redirect, render_template, request, send_file

from app.config import load_settings
from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.constants import INVENTORY_UNSEGREGATED
from app.utils.domain import (
    counterparty_find_by_id,
    inventory_add_movement,
    lot_find_by_id,
    material_balance_v2,
    material_find_by_id,
    stock_v2_add_movement,
    uom_find_by_code,
)
from app.utils.flash import flash_set

bp = Blueprint("outward", __name__)


def _backend_dir() -> Path:
    return Path(__file__).resolve().parents[3]


def _uploads_outward_dir() -> Path:
    settings = load_settings()
    base = Path(settings.upload_dir)
    if not base.is_absolute():
        base = (_backend_dir() / base).resolve()
    return (base / "outward").resolve()


def _db_has_column(conn, table: str, column: str) -> bool:
    row = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt\n"
        "FROM information_schema.COLUMNS\n"
        "WHERE TABLE_SCHEMA = DATABASE()\n"
        "  AND TABLE_NAME = :t\n"
        "  AND COLUMN_NAME = :c",
        {"t": table, "c": column},
    ) or {}
    return int(row.get("cnt") or 0) > 0


def _normalize_part_no(value: str) -> str:
    v = (value or "").strip().upper()
    out: list[str] = []
    for ch in v:
        if ch.isalnum():
            out.append(ch)
    return "".join(out)[:100]


def _coerce_str(v: object) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip()
    return str(v).strip()


def _parse_date_any(v: object) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, (int, float)):
        try:
            from openpyxl.utils.datetime import from_excel

            d = from_excel(v)
            if isinstance(d, datetime):
                return d.date()
            if isinstance(d, date):
                return d
        except Exception:
            return None
    s = _coerce_str(v)
    if s == "":
        return None
    s2 = s.replace(".", "-").replace("/", "-")
    fmts = ["%Y-%m-%d", "%d-%m-%Y", "%d-%b-%Y", "%d-%B-%Y"]
    for f in fmts:
        try:
            return datetime.strptime(s2, f).date()
        except Exception:
            continue
    return None


def _parse_float_any(v: object) -> float | None:
    s = _coerce_str(v)
    if s == "":
        return None
    try:
        return float(s.replace(",", ""))
    except Exception:
        return None


def _outward_extra_columns(conn) -> list[str]:
    cols = [
        "invoice_no",
        "invoice_date",
        "customer_code",
        "vendor_name",
        "rate",
        "basic_value",
        "amount_incl_gst",
        "truck_no",
        "location",
    ]
    return [c for c in cols if _db_has_column(conn, "outward_entries", c)]


def _truncate_material_type(v: object) -> str:
    return str(v or "")[:50]


@bp.get("/scratch/outward/sample")
@login_required
def outward_sample() -> Response:
    fmt = request.args.get("format", "xlsx")
    output = io.BytesIO()

    headers = [
        "S.No",
        "Part No",
        "Product Description",
        "Rate",
        "UOM",
        "Weight",
        "Invoice No.",
        "Invoice Date",
        "Customer Code",
        "Vendor Name",
        "Basic value",
        "Amount (incl GST)",
        "Truck no",
        "Location",
    ]
    sample_data = [
        [
            "1",
            "A40D",
            "Packing Wood & Wooden Scrap",
            "3050.00",
            "MT",
            "4.160",
            "750303606",
            "2025-04-07",
            "7513087",
            "Golden Enterprises",
            "12688.00",
            "14210.56",
            "KA32A3494",
            "Scrap Yard",
        ],
        [
            "2",
            "DWD052",
            "MS Barrels - 200 Ltrs. Capacity",
            "310",
            "Nos",
            "144",
            "750303607",
            "2025-04-08",
            "8401237",
            "Century Enterprises",
            "44640.00",
            "52675.20",
            "KA06AA5393",
            "ETP",
        ],
    ]

    if fmt == "csv":
        si = io.StringIO()
        cw = csv.writer(si)
        cw.writerow(headers)
        cw.writerows(sample_data)
        output.write(si.getvalue().encode("utf-8"))
        output.seek(0)
        return send_file(output, mimetype="text/csv", as_attachment=True, download_name="outward_sale_sample.csv")

    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Outward Sale"
    ws.append(headers)
    for row in sample_data:
        ws.append(row)
    wb.save(output)
    output.seek(0)
    return send_file(
        output,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="outward_sale_sample.xlsx",
    )


@bp.post("/scratch/outward/upload")
@login_required
@csrf_protect
def outward_upload() -> object:
    return_to = str(request.form.get("return_to") or "").strip()
    if return_to and not return_to.startswith("/scratch/"):
        return_to = ""

    file = request.files.get("outward_file")
    if file is None:
        flash_set("error", "Outward file is required.")
        return redirect(return_to or "/scratch/outward/list")

    opt_auto_map_uom = request.form.get("auto_map_uom") == "1"
    opt_create_counterparties = request.form.get("create_counterparties") == "1"
    opt_create_materials = request.form.get("create_materials") == "1"
    opt_validate_stock = request.form.get("validate_stock") == "1"

    try:
        max_mb = int((request.form.get("max_upload_mb") or "").strip() or (request.args.get("max_upload_mb") or "").strip() or (os.getenv("SYMS_OUTWARD_MAX_UPLOAD_MB") or "50"))
    except Exception:
        max_mb = 50
    if max_mb < 1:
        max_mb = 50
    if max_mb > 250:
        max_mb = 250
    max_bytes = max_mb * 1024 * 1024
    file.stream.seek(0, 2)
    size = int(file.stream.tell() or 0)
    file.stream.seek(0)
    if size > max_bytes:
        flash_set("error", f"File is too large. Max {max_mb} MB.")
        return redirect(return_to or "/scratch/outward/list")

    original_name = str(file.filename or "")
    ext = original_name.lower().rsplit(".", 1)[-1] if "." in original_name else ""
    if ext not in {"xlsx", "csv"}:
        flash_set("error", "Supported formats: XLSX, CSV.")
        return redirect(return_to or "/scratch/outward/list")

    upload_dir = _uploads_outward_dir()
    upload_dir.mkdir(parents=True, exist_ok=True)
    random_name = f"{secrets.token_hex(16)}.{ext}"
    dest_path = (upload_dir / random_name).resolve()
    file.save(dest_path)

    rows: list[dict[str, object]] = []
    try:
        if ext == "csv":
            with open(dest_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for r in reader:
                    d: dict[str, object] = {}
                    for k, v in (r or {}).items():
                        kk = str(k or "").strip()
                        if kk == "":
                            continue
                        d[kk] = str(v or "").strip()
                    if any(_coerce_str(v) != "" for v in d.values()):
                        rows.append(d)
        else:
            from openpyxl import load_workbook

            wb = load_workbook(dest_path, read_only=True, data_only=True)
            ws = wb.active
            headers: list[str] = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    headers = [str(c or "").strip() for c in row]
                    continue
                d: dict[str, object] = {}
                for j, h in enumerate(headers):
                    if h == "":
                        continue
                    v = row[j] if j < len(row) else ""
                    d[h] = v if not isinstance(v, str) else v.strip()
                if any(_coerce_str(v) != "" for v in d.values()):
                    rows.append(d)
    except Exception as e:
        _log.error("Outward batch upload file-read error: %s", str(e), exc_info=True)
        msg = str(e) or "Could not read outward file."
        if len(msg) > 160:
            msg = msg[:160] + "..."
        flash_set("error", f"Could not read outward file: {msg}")
        return redirect(return_to or "/scratch/outward/list")

    def norm_col(name: str) -> str:
        v = (name or "").strip().lower()
        v = v.replace("_", " ").replace("-", " ")
        while "  " in v:
            v = v.replace("  ", " ")
        return v

    def pick_value(row: dict[str, object], *names: str) -> object:
        lookup = {norm_col(k): v for k, v in row.items()}
        for n in names:
            val = lookup.get(norm_col(n))
            if val is not None and _coerce_str(val) != "":
                return val
        return None

    total = len(rows)
    valid = 0
    invalid = 0
    notes: list[str] = []
    entries: list[dict[str, object]] = []

    for idx, r in enumerate(rows, start=1):
        part_no_raw = _coerce_str(pick_value(r, "Part No", "Part", "PartNo", "Part Number", "Part_Name"))
        product_description = _coerce_str(pick_value(r, "Product Description", "Description"))
        part_no_norm = _normalize_part_no(part_no_raw)
        weight = _parse_float_any(pick_value(r, "Weight", "Qty", "Quantity"))
        invoice_no = _coerce_str(pick_value(r, "Invoice No.", "Invoice No", "Invoice"))
        invoice_date = _parse_date_any(pick_value(r, "Invoice Date", "Date"))
        customer_code = _coerce_str(pick_value(r, "Customer Code", "Customer"))
        vendor_name = _coerce_str(pick_value(r, "Vendor Name", "Vendor"))
        uom_code = _coerce_str(pick_value(r, "UOM", "Unit"))
        rate = _parse_float_any(pick_value(r, "Rate"))
        basic_value = _parse_float_any(pick_value(r, "Basic value", "Basic Value"))
        amount_incl_gst = _parse_float_any(pick_value(r, "Amount (incl GST)", "Amount", "Gross Amount"))
        truck_no = _coerce_str(pick_value(r, "Truck no", "Truck No", "Vehicle No", "Vehicle"))
        location = _coerce_str(pick_value(r, "Location"))

        if part_no_norm == "" or weight is None or weight <= 0:
            invalid += 1
            if len(notes) < 10:
                notes.append(f"Row {idx}: missing Part No or invalid Weight")
            continue
        if invoice_date is None:
            invalid += 1
            if len(notes) < 10:
                notes.append(f"Row {idx}: missing/invalid Invoice Date")
            continue
        if vendor_name == "":
            invalid += 1
            if len(notes) < 10:
                notes.append(f"Row {idx}: Vendor Name is required")
            continue

        entries.append(
            {
                "part_no_raw": part_no_raw[:100],
                "part_no_norm": part_no_norm,
                "product_description": product_description[:255],
                "weight": float(weight),
                "uom_code": uom_code[:20],
                "invoice_no": invoice_no[:50],
                "invoice_date": invoice_date,
                "customer_code": customer_code[:50],
                "vendor_name": vendor_name[:255],
                "rate": float(rate) if rate is not None else None,
                "basic_value": float(basic_value) if basic_value is not None else None,
                "amount_incl_gst": float(amount_incl_gst) if amount_incl_gst is not None else None,
                "truck_no": truck_no[:50],
                "location": location[:100],
            }
        )
        valid += 1

    if valid <= 0:
        flash_set("error", "No valid outward rows found.")
        return redirect(return_to or "/scratch/outward/list")

    inserted = 0
    try:
        with db_conn() as conn:
            with conn.begin():
                extra_cols = _outward_extra_columns(conn)
                missing = []
                for c in ["basic_value", "amount_incl_gst", "location"]:
                    if c not in extra_cols:
                        missing.append(c)
                if missing and len(notes) < 10:
                    notes.append("DB columns missing (run DB migration): " + ", ".join(missing))
                for r in entries:
                    m = fetch_one(conn, "SELECT id, product_description, category_id, uom_id FROM materials WHERE part_no_norm = :n LIMIT 1", {"n": r["part_no_norm"]}) or {}
                    material_id = int(m.get("id") or 0)

                    material_type = _truncate_material_type(m.get("product_description") or "")
                    category_id = int(m.get("category_id") or 0)
                    uom_id = int(m.get("uom_id") or 0)

                    if material_id <= 0 and opt_create_materials:
                        desc = str(r.get("product_description") or "").strip()
                        if desc == "":
                            desc = str(r.get("part_no_raw") or "").strip()
                        desc = desc[:255]
                        execute(
                            conn,
                            "INSERT INTO materials (part_no_raw, part_no_norm, product_description, category_id, uom_id, is_active, updated_at)\n"
                            "VALUES (:raw, :norm, :desc, NULL, :uom_id, 1, NOW())\n"
                            "ON DUPLICATE KEY UPDATE part_no_raw = VALUES(part_no_raw), product_description = VALUES(product_description), uom_id = COALESCE(VALUES(uom_id), uom_id), is_active = 1, updated_at = NOW()",
                            {"raw": r["part_no_raw"], "norm": r["part_no_norm"], "desc": desc, "uom_id": None},
                        )
                        m = fetch_one(conn, "SELECT id, product_description, category_id, uom_id FROM materials WHERE part_no_norm = :n LIMIT 1", {"n": r["part_no_norm"]}) or {}
                        material_id = int(m.get("id") or 0)
                        material_type = _truncate_material_type(m.get("product_description") or "")
                        category_id = int(m.get("category_id") or 0)
                        uom_id = int(m.get("uom_id") or 0)

                    if material_id <= 0:
                        invalid += 1
                        if len(notes) < 10:
                            notes.append(f"Part not found: {r['part_no_raw']}")
                        continue

                    if material_type == INVENTORY_UNSEGREGATED:
                        invalid += 1
                        if len(notes) < 10:
                            notes.append(f"Cannot ship UNSEGREGATED: {r['part_no_raw']}")
                        continue

                    if r["uom_code"]:
                        code = str(r["uom_code"]).upper()[:20]
                        if opt_auto_map_uom:
                            execute(
                                conn,
                                "INSERT INTO uoms (code, name, is_active, created_at, updated_at)\n"
                                "VALUES (:code, :name, 1, NOW(), NOW())\n"
                                "ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
                                {"code": code, "name": code},
                            )
                        u = fetch_one(conn, "SELECT id FROM uoms WHERE code = :code LIMIT 1", {"code": code}) or {}
                        uid = int(u.get("id") or 0)
                        if uid > 0:
                            uom_id = uid
                            if opt_create_materials:
                                execute(
                                    conn,
                                    "UPDATE materials SET uom_id = COALESCE(uom_id, :uom_id), updated_at = NOW() WHERE id = :id",
                                    {"uom_id": uom_id, "id": material_id},
                                )

                    if uom_id <= 0:
                        default_uom = uom_find_by_code("KG") or {}
                        uom_id = int(default_uom.get("id") or 0)

                    weight = float(r["weight"] or 0)
                    if opt_validate_stock:
                        available = material_balance_v2(material_id)
                        if available < weight:
                            invalid += 1
                            if len(notes) < 10:
                                notes.append(f"Not enough stock: {r['part_no_raw']}")
                            continue

                    cp_or_null = None
                    if opt_create_counterparties:
                        cp = fetch_one(
                            conn,
                            "SELECT id FROM counterparties WHERE (code IS NOT NULL AND code = :code) OR name = :name LIMIT 1",
                            {"code": r["customer_code"], "name": r["vendor_name"]},
                        ) or {}
                        cid = int(cp.get("id") or 0)
                        if cid <= 0:
                            execute(
                                conn,
                                "INSERT INTO counterparties (type, code, name, is_active, created_at, updated_at)\n"
                                "VALUES ('CUSTOMER', :code, :name, 1, NOW(), NOW())\n"
                                "ON DUPLICATE KEY UPDATE code = COALESCE(VALUES(code), code), is_active = 1, updated_at = NOW()",
                                {"code": r["customer_code"] if r["customer_code"] else None, "name": r["vendor_name"]},
                            )
                            cp2 = fetch_one(conn, "SELECT id FROM counterparties WHERE name = :name LIMIT 1", {"name": r["vendor_name"]}) or {}
                            cid = int(cp2.get("id") or 0)
                        cp_or_null = cid if cid > 0 else None
                    else:
                        cp = fetch_one(
                            conn,
                            "SELECT id FROM counterparties WHERE (code IS NOT NULL AND code = :code) OR name = :name LIMIT 1",
                            {"code": r["customer_code"], "name": r["vendor_name"]},
                        ) or {}
                        cid = int(cp.get("id") or 0)
                        cp_or_null = cid if cid > 0 else None

                    cols = [
                        "material_id",
                        "lot_id",
                        "uom_id",
                        "material_type",
                        "weight",
                        "vehicle_number",
                        "recycler_name",
                        "counterparty_id",
                    ] + extra_cols
                    params = {
                        "material_id": material_id,
                        "lot_id": None,
                        "uom_id": uom_id if uom_id > 0 else None,
                        "material_type": material_type,
                        "weight": weight,
                        "vehicle_number": r["truck_no"],
                        "recycler_name": r["vendor_name"],
                        "counterparty_id": cp_or_null,
                    }
                    if "invoice_no" in extra_cols:
                        params["invoice_no"] = r["invoice_no"]
                    if "invoice_date" in extra_cols:
                        params["invoice_date"] = r["invoice_date"].strftime("%Y-%m-%d")
                    if "customer_code" in extra_cols:
                        params["customer_code"] = r["customer_code"] if r["customer_code"] else None
                    if "vendor_name" in extra_cols:
                        params["vendor_name"] = r["vendor_name"]
                    if "rate" in extra_cols:
                        params["rate"] = r["rate"]
                    if "basic_value" in extra_cols:
                        params["basic_value"] = r["basic_value"]
                    if "amount_incl_gst" in extra_cols:
                        params["amount_incl_gst"] = r["amount_incl_gst"]
                    if "truck_no" in extra_cols:
                        params["truck_no"] = r["truck_no"]
                    if "location" in extra_cols:
                        params["location"] = r["location"]

                    execute(
                        conn,
                        "INSERT INTO outward_entries (" + ", ".join(f"`{c}`" for c in cols) + ")\n"
                        "VALUES (" + ", ".join(f":{c}" for c in cols) + ")",
                        params,
                    )

                    row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                    outward_id = int(row.get("id") or 0)
                    if outward_id <= 0:
                        invalid += 1
                        if len(notes) < 10:
                            notes.append(f"Row insert failed: {r['part_no_raw']}")
                        continue

                    inventory_add_movement("OUTWARD", outward_id, material_type, None, weight, uom_id, conn=conn)
                    stock_v2_add_movement(
                        "OUTWARD",
                        outward_id,
                        material_id,
                        weight,
                        "OUT",
                        "",
                        None,
                        category_id if category_id > 0 else None,
                        None,
                        uom_id,
                        conn=conn,
                    )
                    inserted += 1
    except Exception as e:
        _log.error("Outward batch upload processing error: %s", str(e), exc_info=True)
        msg = str(e) or "Could not process outward upload."
        if len(msg) > 160:
            msg = msg[:160] + "..."
        flash_set("error", f"Could not process outward upload: {msg}")
        return redirect(return_to or "/scratch/outward/list")

    msg = f"Outward upload completed. Imported {inserted} of {total} rows."
    if notes:
        msg += " " + " | ".join(notes)
    flash_set("success", msg)
    return redirect(return_to or "/scratch/outward/list")


@bp.get("/scratch/outward/list")
@login_required
def outward_list() -> object:
    with db_conn() as conn:
        has_invoice_date = _db_has_column(conn, "outward_entries", "invoice_date")
        has_location = _db_has_column(conn, "outward_entries", "location")

        q = str(request.args.get("q") or "").strip()
        from_date = _parse_date_any(request.args.get("from_date"))
        to_date = _parse_date_any(request.args.get("to_date"))
        location = str(request.args.get("location") or "").strip()
        try:
            page = int(request.args.get("page") or 1)
        except Exception:
            page = 1
        try:
            per_page = int(request.args.get("per_page") or 50)
        except Exception:
            per_page = 50
        if page < 1:
            page = 1
        if per_page not in {25, 50, 100, 200}:
            per_page = 50
        offset = (page - 1) * per_page

        where_parts = ["1=1"]
        params: dict[str, object] = {}

        date_expr = "DATE(oe.created_at)"
        if has_invoice_date:
            date_expr = "COALESCE(oe.invoice_date, DATE(oe.created_at))"

        if from_date is not None:
            where_parts.append(f"{date_expr} >= :from_date")
            params["from_date"] = from_date.strftime("%Y-%m-%d")
        if to_date is not None:
            where_parts.append(f"{date_expr} <= :to_date")
            params["to_date"] = to_date.strftime("%Y-%m-%d")

        if q:
            qlike = f"%{q}%"
            parts = [
                "m.part_no_raw LIKE :q",
                "m.part_no_norm LIKE :q",
                "m.product_description LIKE :q",
                "oe.recycler_name LIKE :q",
                "oe.vehicle_number LIKE :q",
            ]
            if has_invoice_date:
                parts.extend(
                    [
                        "oe.invoice_no LIKE :q",
                        "oe.customer_code LIKE :q",
                        "oe.vendor_name LIKE :q",
                        "oe.truck_no LIKE :q",
                        "oe.location LIKE :q",
                    ]
                )
            where_parts.append("(" + " OR ".join(parts) + ")")
            params["q"] = qlike

        if has_location and location:
            where_parts.append("oe.location = :location")
            params["location"] = location

        where_sql = "WHERE " + " AND ".join(where_parts)

        order_sql = "ORDER BY oe.created_at DESC, oe.id DESC"
        if has_invoice_date:
            order_sql = f"ORDER BY {date_expr} DESC, oe.id DESC"

        sql = (
            "SELECT\n"
            "    oe.*,\n"
            "    m.part_no_raw,\n"
            "    m.part_no_norm,\n"
            "    m.product_description,\n"
            "    l.lot_number,\n"
            "    c.name AS category_name,\n"
            "    mr.rate_per_weight,\n"
            "    COALESCE(u.code, '') AS uom_code,\n"
            "    COALESCE(cp.name, '') AS counterparty_name\n"
            "FROM outward_entries oe\n"
            "LEFT JOIN materials m ON m.id = oe.material_id\n"
            "LEFT JOIN uoms u ON u.id = COALESCE(oe.uom_id, m.uom_id)\n"
            "LEFT JOIN material_lots l ON l.id = oe.lot_id\n"
            "LEFT JOIN material_categories c ON c.id = COALESCE(l.category_id, m.category_id)\n"
            "LEFT JOIN material_rates mr ON mr.material_id = oe.material_id AND mr.is_active = 1\n"
            "LEFT JOIN counterparties cp ON cp.id = oe.counterparty_id\n"
            f"{where_sql}\n"
            f"{order_sql}\n"
            "LIMIT :limit OFFSET :offset"
        )
        params["limit"] = per_page + 1
        params["offset"] = offset

        locations: list[dict[str, object]] = []
        if has_location:
            locations = fetch_all(
                conn,
                "SELECT DISTINCT location\n"
                "FROM outward_entries\n"
                "WHERE location IS NOT NULL AND location <> ''\n"
                "ORDER BY location ASC\n"
                "LIMIT 200",
            )

        all_rows = fetch_all(conn, sql, params)
        has_next = len(all_rows) > per_page
        rows = all_rows[:per_page]

    filters = {
        "q": q,
        "from_date": request.args.get("from_date") or "",
        "to_date": request.args.get("to_date") or "",
        "location": location,
        "per_page": str(per_page),
    }
    base_params = {"q": q, "from_date": filters["from_date"], "to_date": filters["to_date"], "location": location, "per_page": per_page}
    qs_base = urlencode({k: v for k, v in base_params.items() if v not in {"", None}})
    return render_template(
        "outward/list.html",
        pageTitle="Disposal / Sale Entries - SYMS",
        rows=rows,
        filters=filters,
        locations=locations,
        page=page,
        perPage=per_page,
        hasNext=has_next,
        qsBase=qs_base,
    )


@bp.get("/scratch/outward/add")
@login_required
def outward_add() -> object:
    with db_conn() as conn:
        categories = fetch_all(
            conn,
            "SELECT\n"
            "    ib.material_id,\n"
            "    ib.uom_id,\n"
            "    ib.uom_code,\n"
            "    ib.part_no_norm,\n"
            "    ib.product_description,\n"
            "    ib.balance_weight,\n"
            "    mr.rate_per_weight\n"
            "FROM inventory_balances_v2 ib\n"
            "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
            "WHERE ib.balance_weight > 0\n"
            "ORDER BY ib.product_description ASC, ib.part_no_norm ASC",
        )
        uoms = fetch_all(conn, "SELECT id, code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")
        counterparties = fetch_all(
            conn,
            "SELECT id, type, name, is_active FROM counterparties WHERE is_active = 1 ORDER BY type ASC, name ASC",
        )
    return render_template(
        "outward/add.html",
        pageTitle="Add Disposal / Sale - SYMS",
        categories=categories,
        uoms=uoms,
        counterparties=counterparties,
    )


@bp.post("/scratch/outward/add_process")
@login_required
@csrf_protect
def outward_add_process() -> object:
    return_to = str(request.form.get("return_to") or "").strip()
    if return_to and not return_to.startswith("/scratch/"):
        return_to = ""

    try:
        material_id = int(request.form.get("material_id") or 0)
    except Exception:
        material_id = 0
    try:
        uom_id = int(request.form.get("uom_id") or 0)
    except Exception:
        uom_id = 0
    try:
        weight = float(request.form.get("weight") or 0)
    except Exception:
        weight = 0.0
    truck_no = str(request.form.get("truck_no") or "").strip()[:50]
    vehicle_number = truck_no
    location = str(request.form.get("location") or "").strip()[:100]
    invoice_no = str(request.form.get("invoice_no") or "").strip()[:50]
    invoice_date = _parse_date_any(request.form.get("invoice_date"))
    customer_code = str(request.form.get("customer_code") or "").strip()[:50]
    rate = _parse_float_any(request.form.get("rate"))
    basic_value = _parse_float_any(request.form.get("basic_value"))
    amount_incl_gst = _parse_float_any(request.form.get("amount_incl_gst"))
    try:
        counterparty_id = int(request.form.get("counterparty_id") or 0)
    except Exception:
        counterparty_id = 0
    counterparty_other = str(request.form.get("counterparty_other") or "").strip()[:255]

    material = material_find_by_id(material_id)
    material_type = _truncate_material_type((material or {}).get("product_description") or "")
    category_id = int((material or {}).get("category_id") or 0)

    if material and int((material or {}).get("uom_id") or 0) > 0:
        uom_id = int((material or {}).get("uom_id") or 0)
    if uom_id <= 0:
        default_uom = uom_find_by_code("KG") or {}
        uom_id = int(default_uom.get("id") or 0)

    recycler_name = ""
    cp_or_null = None
    if counterparty_id > 0:
        cp = counterparty_find_by_id(counterparty_id)
        if cp and int(cp.get("is_active") or 0) == 1:
            recycler_name = str(cp.get("name") or "")
            cp_or_null = counterparty_id
    if recycler_name == "" and counterparty_id == 0 and counterparty_other:
        recycler_name = counterparty_other

    if not material or weight <= 0:
        flash_set("error", "Part and qty/number are required.")
        return redirect(return_to or "/scratch/outward/add")

    if material_type == INVENTORY_UNSEGREGATED:
        flash_set("error", "Cannot ship UNSEGREGATED stock. Segregate first.")
        return redirect(return_to or "/scratch/outward/add")

    available = material_balance_v2(material_id)
    if available < weight:
        flash_set("error", "Not enough stock for this part.")
        return redirect(return_to or "/scratch/outward/add")

    if recycler_name == "":
        flash_set("error", "Vendor/Customer is required.")
        return redirect(return_to or "/scratch/outward/add")

    try:
        with db_conn() as conn:
            with conn.begin():
                extra_cols = _outward_extra_columns(conn)
                cols = [
                    "material_id",
                    "lot_id",
                    "uom_id",
                    "material_type",
                    "weight",
                    "vehicle_number",
                    "recycler_name",
                    "counterparty_id",
                ] + extra_cols
                params = {
                    "material_id": material_id,
                    "lot_id": None,
                    "uom_id": uom_id if uom_id > 0 else None,
                    "material_type": material_type,
                    "weight": weight,
                    "vehicle_number": vehicle_number,
                    "recycler_name": recycler_name,
                    "counterparty_id": cp_or_null,
                }
                if "invoice_no" in extra_cols:
                    params["invoice_no"] = invoice_no
                if "invoice_date" in extra_cols:
                    params["invoice_date"] = invoice_date.strftime("%Y-%m-%d") if invoice_date is not None else None
                if "customer_code" in extra_cols:
                    params["customer_code"] = customer_code if customer_code else None
                if "vendor_name" in extra_cols:
                    params["vendor_name"] = recycler_name
                if "rate" in extra_cols:
                    params["rate"] = float(rate) if rate is not None else None
                if "basic_value" in extra_cols:
                    params["basic_value"] = float(basic_value) if basic_value is not None else None
                if "amount_incl_gst" in extra_cols:
                    params["amount_incl_gst"] = float(amount_incl_gst) if amount_incl_gst is not None else None
                if "truck_no" in extra_cols:
                    params["truck_no"] = truck_no
                if "location" in extra_cols:
                    params["location"] = location

                execute(
                    conn,
                    "INSERT INTO outward_entries (" + ", ".join(f"`{c}`" for c in cols) + ")\n"
                    "VALUES (" + ", ".join(f":{c}" for c in cols) + ")",
                    params,
                )
                row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                outward_id = int(row.get("id") or 0)
                if outward_id <= 0:
                    raise RuntimeError("Could not save.")

                inventory_add_movement("OUTWARD", outward_id, material_type, None, weight, uom_id, conn=conn)
                stock_v2_add_movement(
                    "OUTWARD",
                    outward_id,
                    material_id,
                    weight,
                    "OUT",
                    "",
                    None,
                    category_id if category_id > 0 else None,
                    None,
                    uom_id,
                    conn=conn,
                )
    except Exception:
        flash_set("error", "Could not add disposal / sale entry.")
        return redirect(return_to or "/scratch/outward/add")

    flash_set("success", "Disposal / sale entry added.")
    return redirect(return_to or "/scratch/outward/list")


@bp.route("/scratch/outward/edit", methods=["GET", "POST"])
@login_required
@csrf_protect
def outward_edit() -> object:
    try:
        outward_id = int(request.args.get("id") or 0)
    except Exception:
        outward_id = 0
    if outward_id <= 0:
        flash_set("error", "Invalid outward entry.")
        return redirect("/scratch/outward/list")

    with db_conn() as conn:
        entry = fetch_one(conn, "SELECT * FROM outward_entries WHERE id = :id", {"id": outward_id})
        if not entry:
            flash_set("error", "Disposal / sale entry not found.")
            return redirect("/scratch/outward/list")

        categories = fetch_all(
            conn,
            "SELECT\n"
            "    ib.material_id,\n"
            "    ib.uom_id,\n"
            "    ib.uom_code,\n"
            "    ib.part_no_norm,\n"
            "    ib.product_description,\n"
            "    ib.balance_weight,\n"
            "    mr.rate_per_weight\n"
            "FROM inventory_balances_v2 ib\n"
            "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
            "WHERE ib.balance_weight > 0\n"
            "ORDER BY ib.product_description ASC, ib.part_no_norm ASC",
        )
        uoms = fetch_all(conn, "SELECT id, code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")
        counterparties = fetch_all(
            conn,
            "SELECT id, type, name, is_active FROM counterparties WHERE is_active = 1 ORDER BY type ASC, name ASC",
        )

        current_material_id = int(entry.get("material_id") or 0)
        exists = False
        for c in categories:
            if int(c.get("material_id") or 0) == current_material_id:
                exists = True
                break
        if not exists and current_material_id > 0:
            one = fetch_one(
                conn,
                "SELECT\n"
                "    m.id AS material_id,\n"
                "    m.uom_id,\n"
                "    COALESCE(u.code, '') AS uom_code,\n"
                "    m.part_no_norm,\n"
                "    m.product_description,\n"
                "    COALESCE(ib.balance_weight, 0) AS balance_weight,\n"
                "    mr.rate_per_weight\n"
                "FROM materials m\n"
                "LEFT JOIN uoms u ON u.id = m.uom_id\n"
                "LEFT JOIN inventory_balances_v2 ib ON ib.material_id = m.id\n"
                "LEFT JOIN material_rates mr ON mr.material_id = m.id AND mr.is_active = 1\n"
                "WHERE m.id = :id",
                {"id": current_material_id},
            )
            if one:
                categories.append(one)

    if request.method == "GET":
        return render_template(
            "outward/edit.html",
            pageTitle="Edit Disposal / Sale - SYMS",
            entry=entry,
            categories=categories,
            uoms=uoms,
            counterparties=counterparties,
        )

    try:
        new_material_id = int(request.form.get("material_id") or 0)
    except Exception:
        new_material_id = 0
    try:
        uom_id = int(request.form.get("uom_id") or 0)
    except Exception:
        uom_id = 0
    try:
        new_weight = float(request.form.get("weight") or 0)
    except Exception:
        new_weight = 0.0
    truck_no = str(request.form.get("truck_no") or "").strip()[:50]
    vehicle_number = truck_no
    location = str(request.form.get("location") or "").strip()[:100]
    invoice_no = str(request.form.get("invoice_no") or "").strip()[:50]
    invoice_date = _parse_date_any(request.form.get("invoice_date"))
    customer_code = str(request.form.get("customer_code") or "").strip()[:50]
    rate = _parse_float_any(request.form.get("rate"))
    basic_value = _parse_float_any(request.form.get("basic_value"))
    amount_incl_gst = _parse_float_any(request.form.get("amount_incl_gst"))
    try:
        counterparty_id = int(request.form.get("counterparty_id") or 0)
    except Exception:
        counterparty_id = 0
    counterparty_other = str(request.form.get("counterparty_other") or "").strip()[:255]

    new_material = material_find_by_id(new_material_id)
    new_category = _truncate_material_type((new_material or {}).get("product_description") or "")
    new_category_id = int((new_material or {}).get("category_id") or 0)
    new_expiry_snapshot = None

    material_uom_id = int((new_material or {}).get("uom_id") or 0)
    if material_uom_id > 0:
        uom_id = material_uom_id
    if uom_id <= 0:
        default_uom = uom_find_by_code("KG") or {}
        uom_id = int(default_uom.get("id") or 0)

    recycler_name = ""
    cp_or_null = None
    if counterparty_id > 0:
        cp = counterparty_find_by_id(counterparty_id)
        if cp and int(cp.get("is_active") or 0) == 1:
            recycler_name = str(cp.get("name") or "")
            cp_or_null = counterparty_id
    if recycler_name == "" and counterparty_id == 0 and counterparty_other:
        recycler_name = counterparty_other

    if not new_material or new_weight <= 0:
        flash_set("error", "Part and qty/number are required.")
        return redirect(f"/scratch/outward/edit?id={outward_id}")

    if new_category == INVENTORY_UNSEGREGATED:
        flash_set("error", "Cannot ship UNSEGREGATED stock.")
        return redirect(f"/scratch/outward/edit?id={outward_id}")

    old_category = _truncate_material_type(entry.get("material_type") or "")
    old_material_id = int(entry.get("material_id") or 0)
    old_lot_id = int(entry.get("lot_id") or 0)
    old_uom_id = int(entry.get("uom_id") or 0)
    old_weight = float(entry.get("weight") or 0)

    if recycler_name == "":
        flash_set("error", "Vendor/Customer is required.")
        return redirect(f"/scratch/outward/edit?id={outward_id}")

    old_expiry_snapshot = None
    old_category_id = None
    if old_lot_id > 0:
        lot = lot_find_by_id(old_lot_id)
        if lot:
            old_category_id = int(lot.get("category_id") or 0) or None
            old_expiry_snapshot = str(lot.get("expiry_date") or "") or None

    try:
        with db_conn() as conn:
            with conn.begin():
                # Atomic balance check inside transaction to prevent TOCTOU race
                _bal_row = fetch_one(
                    conn,
                    "SELECT COALESCE(balance_weight, 0) AS bw FROM inventory_balances_v2 WHERE material_id = :id",
                    {"id": new_material_id},
                ) or {}
                _available = float(_bal_row.get("bw") or 0)
                if new_material_id == old_material_id:
                    _delta = new_weight - old_weight
                    if _delta > 0 and _available < _delta:
                        raise ValueError("Not enough stock to increase this outward entry.")
                else:
                    if _available < new_weight:
                        raise ValueError("Not enough stock for the new part.")

                extra_cols = _outward_extra_columns(conn)
                sets = [
                    "material_id = :material_id",
                    "lot_id = NULL",
                    "uom_id = :uom_id",
                    "material_type = :material_type",
                    "weight = :weight",
                    "vehicle_number = :vehicle_number",
                    "recycler_name = :recycler_name",
                    "counterparty_id = :counterparty_id",
                ]
                for c in extra_cols:
                    sets.append(f"`{c}` = :{c}")

                params = {
                    "material_id": new_material_id,
                    "uom_id": uom_id if uom_id > 0 else None,
                    "material_type": new_category,
                    "weight": new_weight,
                    "vehicle_number": vehicle_number,
                    "recycler_name": recycler_name,
                    "counterparty_id": cp_or_null,
                    "id": outward_id,
                }
                if "invoice_no" in extra_cols:
                    params["invoice_no"] = invoice_no
                if "invoice_date" in extra_cols:
                    params["invoice_date"] = invoice_date.strftime("%Y-%m-%d") if invoice_date is not None else None
                if "customer_code" in extra_cols:
                    params["customer_code"] = customer_code if customer_code else None
                if "vendor_name" in extra_cols:
                    params["vendor_name"] = recycler_name
                if "rate" in extra_cols:
                    params["rate"] = float(rate) if rate is not None else None
                if "basic_value" in extra_cols:
                    params["basic_value"] = float(basic_value) if basic_value is not None else None
                if "amount_incl_gst" in extra_cols:
                    params["amount_incl_gst"] = float(amount_incl_gst) if amount_incl_gst is not None else None
                if "truck_no" in extra_cols:
                    params["truck_no"] = truck_no
                if "location" in extra_cols:
                    params["location"] = location

                execute(conn, "UPDATE outward_entries SET " + ", ".join(sets) + " WHERE id = :id", params)

                if new_material_id == old_material_id:
                    delta = new_weight - old_weight
                    if delta > 0:
                        inventory_add_movement("OUTWARD", outward_id, new_category, None, delta, uom_id, conn=conn)
                        stock_v2_add_movement(
                            "OUTWARD",
                            outward_id,
                            new_material_id,
                            delta,
                            "OUT",
                            "",
                            None,
                            new_category_id if new_category_id > 0 else None,
                            new_expiry_snapshot,
                            uom_id,
                            conn=conn,
                        )
                    elif delta < 0:
                        inventory_add_movement("OUTWARD", outward_id, None, new_category, abs(delta), uom_id, conn=conn)
                        stock_v2_add_movement(
                            "OUTWARD",
                            outward_id,
                            new_material_id,
                            abs(delta),
                            "IN",
                            "",
                            None,
                            new_category_id if new_category_id > 0 else None,
                            new_expiry_snapshot,
                            uom_id,
                            conn=conn,
                        )
                else:
                    inventory_add_movement("OUTWARD", outward_id, None, old_category, old_weight, old_uom_id, conn=conn)
                    inventory_add_movement("OUTWARD", outward_id, new_category, None, new_weight, uom_id, conn=conn)
                    if old_material_id > 0:
                        stock_v2_add_movement(
                            "OUTWARD",
                            outward_id,
                            old_material_id,
                            old_weight,
                            "IN",
                            "MATERIAL_CHANGED",
                            old_lot_id if old_lot_id > 0 else None,
                            old_category_id,
                            old_expiry_snapshot,
                            old_uom_id,
                            conn=conn,
                        )
                    stock_v2_add_movement(
                        "OUTWARD",
                        outward_id,
                        new_material_id,
                        new_weight,
                        "OUT",
                        "MATERIAL_CHANGED",
                        None,
                        new_category_id if new_category_id > 0 else None,
                        new_expiry_snapshot,
                        uom_id,
                        conn=conn,
                    )
    except ValueError as e:
        flash_set("error", str(e))
        return redirect(f"/scratch/outward/edit?id={outward_id}")
    except Exception:
        flash_set("error", "Could not update outward entry.")
        return redirect(f"/scratch/outward/edit?id={outward_id}")

    flash_set("success", "Disposal / sale entry updated.")
    return redirect("/scratch/outward/list")


@bp.post("/scratch/outward/delete")
@login_required
@csrf_protect
def outward_delete() -> object:
    try:
        outward_id = int(request.form.get("id") or 0)
    except Exception:
        outward_id = 0
    if outward_id <= 0:
        flash_set("error", "Invalid disposal / sale entry.")
        return redirect("/scratch/outward/list")

    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT material_id, lot_id, uom_id, material_type, weight FROM outward_entries WHERE id = :id",
            {"id": outward_id},
        )
    if not row:
        flash_set("error", "Disposal / sale entry not found.")
        return redirect("/scratch/outward/list")

    material_type = str(row.get("material_type") or "")
    material_id = int(row.get("material_id") or 0)
    lot_id = int(row.get("lot_id") or 0)
    uom_id = int(row.get("uom_id") or 0)
    weight = float(row.get("weight") or 0)

    category_id = 0
    expiry_snapshot = None
    if material_id > 0:
        material = material_find_by_id(material_id) or {}
        category_id = int(material.get("category_id") or 0)
        material_uom_id = int(material.get("uom_id") or 0)
        if material_uom_id > 0:
            uom_id = material_uom_id
    if lot_id > 0:
        lot = lot_find_by_id(lot_id)
        if lot:
            if category_id <= 0:
                category_id = int(lot.get("category_id") or 0)
            expiry_snapshot = str(lot.get("expiry_date") or "") or None

    try:
        with db_conn() as conn:
            with conn.begin():
                if material_type and weight > 0:
                    inventory_add_movement("OUTWARD", outward_id, None, material_type, weight, uom_id, conn=conn)
                    if material_id > 0:
                        stock_v2_add_movement(
                            "OUTWARD",
                            outward_id,
                            material_id,
                            weight,
                            "IN",
                            "DELETE_OUTWARD",
                            lot_id if lot_id > 0 else None,
                            category_id if category_id > 0 else None,
                            expiry_snapshot,
                            uom_id,
                            conn=conn,
                        )
                execute(conn, "DELETE FROM outward_entries WHERE id = :id", {"id": outward_id})
    except Exception:
        flash_set("error", "Could not delete disposal / sale entry.")
        return redirect("/scratch/outward/list")

    flash_set("success", "Disposal / sale entry deleted.")
    return redirect("/scratch/outward/list")
