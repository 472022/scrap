from __future__ import annotations

from flask import Blueprint, redirect, render_template

from app.security.auth import login_required
from app.utils.rbac import current_user_role

bp = Blueprint("sqpdcme", __name__)


def _require_sqpdcme() -> bool:
    return current_user_role() == "sqpdcme"


@bp.get("/scratch/sqpdcme")
@login_required
def sqpdcme_index() -> object:
    if not _require_sqpdcme():
        return redirect("/scratch/dashboard")
    return render_template("sqpdcme/index.html", pageTitle="SQPDCME - Quality Monitoring")


@bp.get("/scratch/sqpdcme/safty")
@bp.get("/scratch/sqpdcme/quality")
@bp.get("/scratch/sqpdcme/productivity")
@bp.get("/scratch/sqpdcme/delivery")
@bp.get("/scratch/sqpdcme/cost")
@bp.get("/scratch/sqpdcme/morale")
@bp.get("/scratch/sqpdcme/environment")
@login_required
def sqpdcme_other() -> object:
    if not _require_sqpdcme():
        return redirect("/scratch/dashboard")
    return redirect("/scratch/sqpdcme")
