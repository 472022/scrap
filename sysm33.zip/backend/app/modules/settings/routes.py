from __future__ import annotations

import csv
import io
import secrets
from datetime import date, datetime, timedelta
from pathlib import Path

from flask import Blueprint, Response, jsonify, redirect, render_template, request, send_file, session
from sqlalchemy import text

from app.config import load_settings
from app.security.auth import login_required
from app.utils.rbac import require_admin
from app.db.opening_stock_schema import ensure_opening_stock_tables
from app.db.counterparty_schema import ensure_counterparty_schema
from app.db.engine import db_conn, db_txn
from app.db.query import execute, fetch_all, fetch_one
from app.security.csrf import csrf_protect
from app.utils.flash import flash_set

bp = Blueprint("settings", __name__)


def _backend_dir() -> Path:
    return Path(__file__).resolve().parents[3]


def _uploads_pricing_dir() -> Path:
    settings = load_settings()
    base = Path(settings.upload_dir)
    if not base.is_absolute():
        base = (_backend_dir() / base).resolve()
    return (base / "pricing").resolve()


def _uploads_opening_stock_dir() -> Path:
    settings = load_settings()
    base = Path(settings.upload_dir)
    if not base.is_absolute():
        base = (_backend_dir() / base).resolve()
    return (base / "opening_stock").resolve()


def _normalize_part_no(part_no: str) -> str:
    v = (part_no or "").strip().upper()
    out = []
    for ch in v:
        if ("A" <= ch <= "Z") or ("0" <= ch <= "9"):
            out.append(ch)
    return "".join(out)[:100]


def _normalize_category_name(name: str) -> str:
    v = (name or "").strip().lower()
    cleaned = []
    prev_space = False
    for ch in v:
        is_alnum = ("a" <= ch <= "z") or ("0" <= ch <= "9")
        if is_alnum:
            cleaned.append(ch)
            prev_space = False
            continue
        if not prev_space:
            cleaned.append(" ")
            prev_space = True
    s = "".join(cleaned).strip()
    while "  " in s:
        s = s.replace("  ", " ")
    return s[:255]


def _app_setting_get(conn, key: str, default: str) -> str:
    row = fetch_one(conn, "SELECT setting_value FROM app_settings WHERE setting_key = :k LIMIT 1", {"k": key}) or {}
    v = str(row.get("setting_value") or "").strip()
    return v if v != "" else default


def _app_setting_set(conn, key: str, value: str) -> None:
    execute(
        conn,
        "INSERT INTO app_settings (setting_key, setting_value, updated_at)\n"
        "VALUES (:k, :v, NOW())\n"
        "ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()",
        {"k": key, "v": str(value)},
    )


def _check_auto_sync_block(conn) -> bool:
    v = _app_setting_get(conn, "auto_sync_pricing", "0")
    return v == "1"


def _db_has_column(conn, table: str, column: str) -> bool:
    row = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt\n"
        "FROM information_schema.COLUMNS\n"
        "WHERE TABLE_SCHEMA = DATABASE()\n"
        "  AND TABLE_NAME = :t\n"
        "  AND COLUMN_NAME = :c",
        {"t": table, "c": column},
    ) or {}
    return int(row.get("cnt") or 0) > 0


def _coerce_str(v: object) -> str:
    if v is None:
        return ""
    if isinstance(v, str):
        return v.strip()
    return str(v).strip()


def _parse_datetime_any(v: object) -> datetime | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v
    if isinstance(v, date):
        return datetime(v.year, v.month, v.day)
    if isinstance(v, (int, float)):
        try:
            from openpyxl.utils.datetime import from_excel

            dt = from_excel(v)
            if isinstance(dt, datetime):
                return dt
            if isinstance(dt, date):
                return datetime(dt.year, dt.month, dt.day)
        except Exception:
            return None
    s = _coerce_str(v)
    if s == "":
        return None

    s2 = s.replace(".", "-").replace("/", "-")
    fmts = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d",
        "%d-%m-%Y %H:%M:%S",
        "%d-%m-%Y %H:%M",
        "%d-%m-%Y",
    ]
    for f in fmts:
        try:
            return datetime.strptime(s2, f)
        except Exception:
            continue
    return None


def _sql_quote(v: object) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "1" if v else "0"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, (datetime, date)):
        if isinstance(v, date) and not isinstance(v, datetime):
            s = v.isoformat()
        else:
            s = v.strftime("%Y-%m-%d %H:%M:%S")
        s = s.replace("\\", "\\\\").replace("'", "\\'")
        return f"'{s}'"
    s = str(v)
    s = s.replace("\\", "\\\\").replace("'", "\\'")
    return f"'{s}'"


@bp.get("/scratch/settings")
@login_required
def settings_home() -> object:
    require_admin()
    return redirect("/scratch/settings/general")


@bp.get("/scratch/settings/general")
@login_required
def general_page() -> object:
    require_admin()
    with db_conn() as conn:
        stats = {
            "parts": int((fetch_one(conn, "SELECT COUNT(*) as cnt FROM materials WHERE is_active = 1") or {}).get("cnt") or 0),
            "categories": int((fetch_one(conn, "SELECT COUNT(*) as cnt FROM material_categories WHERE is_active = 1") or {}).get("cnt") or 0),
            "lots": int((fetch_one(conn, "SELECT COUNT(*) as cnt FROM material_lots WHERE status = 'ACTIVE'") or {}).get("cnt") or 0),
            "uoms": int((fetch_one(conn, "SELECT COUNT(*) as cnt FROM uoms WHERE is_active = 1") or {}).get("cnt") or 0),
            "vendors": int((fetch_one(conn, "SELECT COUNT(*) as cnt FROM counterparties WHERE type = 'VENDOR' AND is_active = 1") or {}).get("cnt") or 0),
            "customers": int((fetch_one(conn, "SELECT COUNT(*) as cnt FROM counterparties WHERE type = 'CUSTOMER' AND is_active = 1") or {}).get("cnt") or 0),
        }
        recent_uploads = fetch_all(conn, "SELECT original_filename, status, uploaded_at FROM pricing_uploads ORDER BY uploaded_at DESC LIMIT 5")
    return render_template("settings/general.html", pageTitle="Settings Overview - SYMS", stats=stats, recent_uploads=recent_uploads)



@bp.get("/scratch/settings/pricing/sample")
@login_required
def pricing_sample() -> Response:
    require_admin()
    fmt = request.args.get("format", "xlsx")
    output = io.BytesIO()
    
    headers = ["Part_Name", "Description", "Rate", "Valid From", "Valid To", "Category", "UOM", "Vendor", "Customer"]
    sample_data = [
        ["Bolt M6", "Bolt M6 (100mm)", "12.5", "2026-01-01", "2026-12-31", "Steel", "PCS", "ABC Ltd", "Tata Motors"],
        ["Sheet A", "ABS Plastic Sheet A", "150.0", "2026-01-01", "", "Plastic", "KG", "XYZ Ltd", "Tata Motors"]
    ]
    
    if fmt == "csv":
        si = io.StringIO()
        cw = csv.writer(si)
        cw.writerow(headers)
        cw.writerows(sample_data)
        output.write(si.getvalue().encode("utf-8"))
        output.seek(0)
        return send_file(output, mimetype="text/csv", as_attachment=True, download_name="pricing_sample.csv")
    else:
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active
        ws.title = "Pricing Sample"
        ws.append(headers)
        for row in sample_data:
            ws.append(row)
        wb.save(output)
        output.seek(0)
        return send_file(output, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", as_attachment=True, download_name="pricing_sample.xlsx")


@bp.get("/scratch/settings/opening-stock/sample")
@login_required
def opening_stock_sample() -> Response:
    require_admin()
    fmt = request.args.get("format", "xlsx")
    output = io.BytesIO()

    headers = ["Part_No", "Quantity", "UOM", "Description", "Category"]
    sample_data = [
        ["BOLTM6", "100", "PCS", "Bolt M6", "Steel"],
        ["ABS001", "25.5", "KG", "ABS Plastic", "Plastic"],
    ]

    if fmt == "csv":
        si = io.StringIO()
        cw = csv.writer(si)
        cw.writerow(headers)
        cw.writerows(sample_data)
        output.write(si.getvalue().encode("utf-8"))
        output.seek(0)
        return send_file(output, mimetype="text/csv", as_attachment=True, download_name="opening_stock_sample.csv")

    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Opening Stock Sample"
    ws.append(headers)
    for row in sample_data:
        ws.append(row)
    wb.save(output)
    output.seek(0)
    return send_file(
        output,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="opening_stock_sample.xlsx",
    )


@bp.get("/scratch/settings/opening-stock")
@login_required
def opening_stock_page() -> object:
    require_admin()
    with db_conn() as conn:
        ensure_opening_stock_tables(conn)
        uploads = fetch_all(
            conn,
            "SELECT id, original_filename, status, rows_total, rows_valid, rows_invalid, uploaded_at\n"
            "FROM opening_stock_uploads\n"
            "ORDER BY uploaded_at DESC, id DESC\n"
            "LIMIT 25",
        )
    return render_template("settings/opening_stock.html", pageTitle="Opening Stock - SYMS", uploads=uploads)


@bp.post("/scratch/settings/opening-stock/upload")
@login_required
@csrf_protect
def opening_stock_upload() -> object:
    require_admin()
    file = request.files.get("opening_stock_file")
    if file is None:
        flash_set("error", "Opening stock file is required.")
        return redirect("/scratch/settings/opening-stock")

    opt_create_materials = request.form.get("create_materials") == "1"
    opt_create_categories = request.form.get("create_categories") == "1"
    opt_auto_map_uom = request.form.get("auto_map_uom") == "1"
    opt_replace = request.form.get("replace_opening_stock") == "1"

    max_bytes = 10 * 1024 * 1024
    file.stream.seek(0, 2)
    size = int(file.stream.tell() or 0)
    file.stream.seek(0)
    if size > max_bytes:
        flash_set("error", "File is too large.")
        return redirect("/scratch/settings/opening-stock")

    original_name = str(file.filename or "")
    ext = original_name.lower().rsplit(".", 1)[-1] if "." in original_name else ""
    if ext not in {"xlsx", "csv"}:
        flash_set("error", "Supported formats: XLSX, CSV.")
        return redirect("/scratch/settings/opening-stock")

    upload_dir = _uploads_opening_stock_dir()
    upload_dir.mkdir(parents=True, exist_ok=True)
    random_name = f"{secrets.token_hex(16)}.{ext}"
    dest_path = (upload_dir / random_name).resolve()
    file.save(dest_path)
    relative_path = f"uploads/opening_stock/{random_name}"

    rows: list[dict[str, str]] = []
    try:
        if ext == "csv":
            with open(dest_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for r in reader:
                    rows.append({str(k or "").strip(): str(v or "").strip() for k, v in (r or {}).items()})
        else:
            from openpyxl import load_workbook

            wb = load_workbook(dest_path, read_only=True, data_only=True)
            ws = wb.active
            headers: list[str] = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    headers = [str(c or "").strip() for c in row]
                    continue
                d: dict[str, str] = {}
                for j, h in enumerate(headers):
                    if h == "":
                        continue
                    v = row[j] if j < len(row) else ""
                    d[h] = str(v or "").strip()
                if any(v != "" for v in d.values()):
                    rows.append(d)
    except Exception:
        flash_set("error", "Could not read opening stock file.")
        return redirect("/scratch/settings/opening-stock")

    def norm_col(name: str) -> str:
        v = (name or "").strip().lower()
        v = v.replace("_", " ").replace("-", " ")
        while "  " in v:
            v = v.replace("  ", " ")
        return v

    def pick(row: dict[str, str], *names: str) -> str:
        lookup = {norm_col(k): v for k, v in row.items()}
        for n in names:
            val = lookup.get(norm_col(n))
            if val is not None and str(val).strip() != "":
                return str(val).strip()
        return ""

    total = len(rows)
    valid = 0
    invalid = 0
    notes: list[str] = []
    entries: list[dict[str, str]] = []

    for idx, r in enumerate(rows, start=1):
        part_no = pick(r, "Part No", "Part", "PartNo", "Part Number", "Part_Name", "Part_No")
        qty_s = pick(r, "Quantity", "Qty", "Opening Stock", "Opening_Stock")
        uom_code = pick(r, "UOM", "Unit", "Unit Of Measure")
        desc = pick(r, "Description", "Product Description")
        category = pick(r, "Category")

        part_no_raw = part_no.strip()
        part_no_norm = _normalize_part_no(part_no_raw)
        if part_no_norm == "":
            invalid += 1
            if len(notes) < 10:
                notes.append(f"Row {idx}: missing Part_No")
            continue

        try:
            qty = float(qty_s.replace(",", "")) if qty_s.strip() != "" else 0.0
        except Exception:
            qty = -1.0
        if qty <= 0:
            invalid += 1
            if len(notes) < 10:
                notes.append(f"Row {idx}: invalid Quantity")
            continue

        entries.append(
            {
                "part_no_raw": part_no_raw[:100],
                "part_no_norm": part_no_norm,
                "qty": str(qty),
                "uom": uom_code.strip()[:20],
                "desc": desc.strip()[:255],
                "category": category.strip()[:255],
            }
        )
        valid += 1

    user_id = int(session.get("user_id") or 0)
    with db_conn() as conn:
        try:
            with conn.begin():
                ensure_opening_stock_tables(conn)
                execute(
                    conn,
                    "INSERT INTO opening_stock_uploads (uploaded_by, original_filename, stored_path, status, rows_total, rows_valid, rows_invalid, upload_notes, uploaded_at)\n"
                    "VALUES (:uid, :orig, :path, 'PROCESSING', :t, 0, 0, NULL, NOW())",
                    {"uid": user_id if user_id > 0 else None, "orig": original_name, "path": relative_path, "t": total},
                )
                row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                upload_id = int(row.get("id") or 0)

                if valid <= 0:
                    execute(
                        conn,
                        "UPDATE opening_stock_uploads SET status = 'FAILED', rows_valid = 0, rows_invalid = :iv, upload_notes = :n WHERE id = :id",
                        {"iv": invalid, "n": "\n".join(notes) if notes else None, "id": upload_id},
                    )
                    flash_set("error", "No valid opening stock rows found.")
                    return redirect("/scratch/settings/opening-stock")

                if opt_replace:
                    execute(
                        conn,
                        "DELETE sm FROM stock_movements_v2 sm JOIN opening_stock_uploads os ON os.id = sm.ref_id WHERE sm.ref_type = 'ADJUSTMENT'",
                    )

                for r in entries:
                    uom_id = None
                    if opt_auto_map_uom and r["uom"]:
                        code = r["uom"].upper()[:20]
                        execute(
                            conn,
                            "INSERT INTO uoms (code, name, is_active, created_at, updated_at)\n"
                            "VALUES (:code, :name, 1, NOW(), NOW())\n"
                            "ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
                            {"code": code, "name": code},
                        )
                        u = fetch_one(conn, "SELECT id FROM uoms WHERE code = :code LIMIT 1", {"code": code}) or {}
                        uom_id = int(u.get("id") or 0) or None

                    cat_id = None
                    if opt_create_categories and r["category"]:
                        cname = r["category"]
                        norm = _normalize_category_name(cname)
                        execute(
                            conn,
                            "INSERT INTO material_categories (name, name_norm, is_active, created_at, updated_at)\n"
                            "VALUES (:name, :norm, 1, NOW(), NOW())\n"
                            "ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
                            {"name": cname, "norm": norm},
                        )
                        c = fetch_one(conn, "SELECT id FROM material_categories WHERE name_norm = :norm LIMIT 1", {"norm": norm}) or {}
                        cat_id = int(c.get("id") or 0) or None

                    m = fetch_one(conn, "SELECT id, uom_id, category_id FROM materials WHERE part_no_norm = :n LIMIT 1", {"n": r["part_no_norm"]})
                    if not m and opt_create_materials:
                        desc = r["desc"] if r["desc"] else r["part_no_raw"]
                        execute(
                            conn,
                            "INSERT INTO materials (part_no_raw, part_no_norm, product_description, category_id, uom_id, is_active, updated_at)\n"
                            "VALUES (:raw, :norm, :desc, :cat, :uom, 1, NOW())\n"
                            "ON DUPLICATE KEY UPDATE product_description = VALUES(product_description), category_id = COALESCE(VALUES(category_id), category_id), uom_id = COALESCE(VALUES(uom_id), uom_id), is_active = 1, updated_at = NOW()",
                            {"raw": r["part_no_raw"], "norm": r["part_no_norm"], "desc": desc, "cat": cat_id, "uom": uom_id},
                        )
                        m = fetch_one(conn, "SELECT id, uom_id, category_id FROM materials WHERE part_no_norm = :n LIMIT 1", {"n": r["part_no_norm"]})

                    if not m:
                        invalid += 1
                        if len(notes) < 10:
                            notes.append(f"Part not found: {r['part_no_raw']}")
                        continue

                    material_id = int(m.get("id") or 0)
                    final_uom_id = uom_id or (int(m.get("uom_id") or 0) or None)
                    final_cat_id = cat_id or (int(m.get("category_id") or 0) or None)

                    execute(
                        conn,
                        "INSERT INTO stock_movements_v2 (ref_type, ref_id, material_id, uom_id, weight, direction, is_valued, valuation_note, lot_id, category_id, expiry_date_snapshot)\n"
                        "VALUES ('ADJUSTMENT', :ref_id, :mid, :uom_id, :w, 'IN', 0, NULL, NULL, :cid, NULL)",
                        {"ref_id": upload_id, "mid": material_id, "uom_id": final_uom_id, "w": float(r["qty"]), "cid": final_cat_id},
                    )

                execute(
                    conn,
                    "UPDATE opening_stock_uploads SET status = :s, rows_valid = :v, rows_invalid = :iv, upload_notes = :n WHERE id = :id",
                    {"s": "SUCCESS", "v": valid, "iv": invalid, "n": "\n".join(notes) if notes else None, "id": upload_id},
                )
        except Exception:
            flash_set("error", "Could not process opening stock upload.")
            return redirect("/scratch/settings/opening-stock")

    flash_set("success", "Opening stock uploaded.")
    return redirect("/scratch/settings/opening-stock")


@bp.get("/scratch/settings/pricing")
@login_required
def pricing() -> object:
    with db_conn() as conn:
        has_valid_to = _db_has_column(conn, "material_rates", "valid_to")
        price_rows = fetch_all(
            conn,
            "SELECT\n"
            "  mr.id AS rate_id,\n"
            "  mr.upload_id,\n"
            "  pu.original_filename,\n"
            "  pu.uploaded_at,\n"
            "  m.part_no_raw,\n"
            "  m.part_no_norm,\n"
            "  m.product_description,\n"
            "  mr.rate_per_weight,\n"
            "  mr.effective_at AS valid_from,\n"
            f"  {'mr.valid_to' if has_valid_to else 'NULL'} AS valid_to,\n"
            "  mr.is_active\n"
            "FROM material_rates mr\n"
            "LEFT JOIN materials m ON m.id = mr.material_id\n"
            "LEFT JOIN pricing_uploads pu ON pu.id = mr.upload_id\n"
            "ORDER BY mr.id DESC\n"
            "LIMIT 500",
        )
    return render_template("settings/pricing.html", pageTitle="Pricing Settings - SYMS", price_rows=price_rows)


@bp.post("/scratch/settings/pricing/upload")
@login_required
@csrf_protect
def pricing_upload() -> object:
    require_admin()
    file = request.files.get("pricing_file")
    if file is None:
        flash_set("error", "Pricing file is required.")
        return redirect("/scratch/settings/pricing")

    # Options from form
    opt_create_materials = request.form.get("create_materials") == "1"
    opt_create_categories = request.form.get("create_categories") == "1"
    opt_create_counterparties = request.form.get("create_counterparties") == "1"
    opt_update_prices = request.form.get("update_prices") == "1"
    opt_auto_map_uom = request.form.get("auto_map_uom") == "1"

    max_bytes = 10 * 1024 * 1024
    file.stream.seek(0, 2)
    size = int(file.stream.tell() or 0)
    file.stream.seek(0)
    if size > max_bytes:
        flash_set("error", "File is too large.")
        return redirect("/scratch/settings/pricing")

    original_name = str(file.filename or "")
    ext = original_name.lower().rsplit(".", 1)[-1] if "." in original_name else ""
    if ext not in {"xlsx", "csv"}:
        flash_set("error", "Supported formats: XLSX, CSV.")
        return redirect("/scratch/settings/pricing")

    upload_dir = _uploads_pricing_dir()
    upload_dir.mkdir(parents=True, exist_ok=True)
    random_name = f"{secrets.token_hex(16)}.{ext}"
    dest_path = (upload_dir / random_name).resolve()
    file.save(dest_path)
    relative_path = f"uploads/pricing/{random_name}"

    rows: list[dict[str, object]] = []
    try:
        if ext == "csv":
            with open(dest_path, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for r in reader:
                    d: dict[str, object] = {}
                    for k, v in (r or {}).items():
                        kk = str(k or "").strip()
                        if kk == "":
                            continue
                        d[kk] = str(v or "").strip()
                    if any(_coerce_str(v) != "" for v in d.values()):
                        rows.append(d)
        else:
            from openpyxl import load_workbook
            wb = load_workbook(dest_path, read_only=True, data_only=True)
            ws = wb.active
            headers: list[str] = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    headers = [str(c or "").strip() for c in row]
                    continue
                d: dict[str, object] = {}
                for j, h in enumerate(headers):
                    if h == "": continue
                    v = row[j] if j < len(row) else ""
                    if isinstance(v, str):
                        d[h] = v.strip()
                    else:
                        d[h] = v
                if any(_coerce_str(v) != "" for v in d.values()):
                    rows.append(d)
    except Exception:
        flash_set("error", "Could not read pricing file.")
        return redirect("/scratch/settings/pricing")

    def norm_col(name: str) -> str:
        v = (name or "").strip().lower()
        v = v.replace("_", " ").replace("-", " ")
        while "  " in v: v = v.replace("  ", " ")
        return v

    def pick_value(row: dict[str, object], *names: str) -> object:
        lookup = {norm_col(k): v for k, v in row.items()}
        for n in names:
            val = lookup.get(norm_col(n))
            if val is not None and _coerce_str(val) != "":
                return val
        return None

    def pick_str(row: dict[str, object], *names: str) -> str:
        return _coerce_str(pick_value(row, *names))

    total = len(rows)
    valid = 0
    invalid = 0
    notes: list[str] = []
    entries: list[dict[str, str]] = []

    for idx, r in enumerate(rows, start=1):
        part_no = pick_str(r, "Part No", "Part", "PartNo", "Part Number", "Part_Name")
        desc = pick_str(r, "Product Description", "Description", "Part Description")
        category = pick_str(r, "Category")
        rate_s = pick_str(r, "Rate", "Rate / UOM", "Rate Per Weight")
        uom_code = pick_str(r, "UOM", "Unit", "Unit Of Measure")
        vendor_name = pick_str(r, "Vendor")
        customer_name = pick_str(r, "Customer")
        valid_from_raw = pick_value(r, "Valid From", "From", "Effective From", "Start Date", "Valid_From")
        valid_to_raw = pick_value(r, "Valid To", "To", "Effective To", "End Date", "Valid_To")

        part_no_raw = part_no.strip()
        part_no_norm = _normalize_part_no(part_no_raw)
        if part_no_norm == "" or desc.strip() == "":
            invalid += 1
            if len(notes) < 10: notes.append(f"Row {idx}: missing Part No or Description")
            continue

        valid_from_dt = _parse_datetime_any(valid_from_raw)
        if valid_from_dt is None:
            invalid += 1
            if len(notes) < 10: notes.append(f"Row {idx}: missing/invalid Valid From")
            continue
        valid_to_dt = _parse_datetime_any(valid_to_raw)
        if valid_to_dt is not None and valid_to_dt < valid_from_dt:
            invalid += 1
            if len(notes) < 10: notes.append(f"Row {idx}: Valid To must be after Valid From")
            continue

        try:
            rate = float(rate_s.replace(",", "")) if rate_s.strip() != "" else 0.0
        except Exception:
            rate = -1.0
        if rate < 0:
            invalid += 1
            if len(notes) < 10: notes.append(f"Row {idx}: invalid Rate")
            continue

        entries.append({
            "part_no_raw": part_no_raw[:100],
            "part_no_norm": part_no_norm,
            "product_description": desc.strip()[:255],
            "category": category.strip()[:255],
            "rate": str(rate),
            "uom": uom_code.strip()[:20],
            "vendor": vendor_name.strip()[:255],
            "customer": customer_name.strip()[:255],
            "valid_from": valid_from_dt.strftime("%Y-%m-%d %H:%M:%S"),
            "valid_to": valid_to_dt.strftime("%Y-%m-%d %H:%M:%S") if valid_to_dt is not None else "",
        })
        valid += 1

    user_id = int(session.get("user_id") or 0)
    with db_conn() as conn:
        try:
            with conn.begin():
                has_valid_to = _db_has_column(conn, "material_rates", "valid_to")
                execute(
                    conn,
                    "INSERT INTO pricing_uploads (uploaded_by, original_filename, stored_path, status, rows_total, rows_valid, rows_invalid, upload_notes, uploaded_at)\n"
                    "VALUES (:uid, :orig, :path, 'PROCESSING', :t, 0, 0, NULL, NOW())",
                    {"uid": user_id if user_id > 0 else None, "orig": original_name, "path": relative_path, "t": total},
                )
                row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                upload_id = int(row.get("id") or 0)

                if valid <= 0:
                    execute(conn, "UPDATE pricing_uploads SET status = 'FAILED', rows_invalid = :iv, upload_notes = :n WHERE id = :id",
                           {"iv": invalid, "n": "\n".join(notes) if notes else None, "id": upload_id})
                    flash_set("error", "No valid pricing rows found.")
                    return redirect("/scratch/settings/pricing")

                if opt_update_prices:
                    execute(conn, "UPDATE material_rates SET is_active = 0 WHERE is_active = 1")

                for r in entries:
                    uom_id = None
                    if opt_auto_map_uom and r["uom"]:
                        code = r["uom"].upper()
                        execute(conn, "INSERT INTO uoms (code, name, is_active, created_at, updated_at) VALUES (:c, :n, 1, NOW(), NOW()) ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
                               {"c": code, "n": code})
                        u = fetch_one(conn, "SELECT id FROM uoms WHERE code = :c", {"c": code}) or {}
                        uom_id = int(u.get("id") or 0) or None

                    cat_id = None
                    if opt_create_categories and r["category"]:
                        cname = r["category"]
                        norm = _normalize_category_name(cname)
                        execute(conn, "INSERT INTO material_categories (name, name_norm, is_active, created_at, updated_at) VALUES (:n, :norm, 1, NOW(), NOW()) ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
                               {"n": cname, "norm": norm})
                        c = fetch_one(conn, "SELECT id FROM material_categories WHERE name_norm = :norm", {"norm": norm}) or {}
                        cat_id = int(c.get("id") or 0) or None

                    def upsert_cp(tp: str, nm: str):
                        if not nm or not opt_create_counterparties: return None
                        execute(conn, "INSERT INTO counterparties (type, name, is_active, created_at, updated_at) VALUES (:t, :n, 1, NOW(), NOW()) ON DUPLICATE KEY UPDATE is_active = 1, updated_at = NOW()",
                               {"t": tp, "n": nm})
                        cp = fetch_one(conn, "SELECT id FROM counterparties WHERE type = :t AND name = :n", {"t": tp, "n": nm}) or {}
                        return int(cp.get("id") or 0) or None

                    upsert_cp("VENDOR", r["vendor"])
                    upsert_cp("CUSTOMER", r["customer"])

                    if opt_create_materials:
                        execute(conn, "INSERT INTO materials (part_no_raw, part_no_norm, product_description, category_id, uom_id, is_active, updated_at) VALUES (:raw, :norm, :desc, :cat, :uom, 1, NOW()) ON DUPLICATE KEY UPDATE product_description = VALUES(product_description), category_id = COALESCE(VALUES(category_id), category_id), uom_id = COALESCE(VALUES(uom_id), uom_id), is_active = 1, updated_at = NOW()",
                               {"raw": r["part_no_raw"], "norm": r["part_no_norm"], "desc": r["product_description"], "cat": cat_id, "uom": uom_id})
                    
                    m = fetch_one(conn, "SELECT id FROM materials WHERE part_no_norm = :n", {"n": r["part_no_norm"]}) or {}
                    mid = int(m.get("id") or 0)
                    if mid > 0:
                        if has_valid_to:
                            execute(
                                conn,
                                "INSERT INTO material_rates (material_id, rate_per_weight, effective_at, valid_to, upload_id, is_active)\n"
                                "VALUES (:mid, :rate, :eff, :vt, :uid, 1)",
                                {
                                    "mid": mid,
                                    "rate": r["rate"],
                                    "eff": r["valid_from"],
                                    "vt": r["valid_to"] if r["valid_to"] != "" else None,
                                    "uid": upload_id,
                                },
                            )
                        else:
                            execute(
                                conn,
                                "INSERT INTO material_rates (material_id, rate_per_weight, effective_at, upload_id, is_active)\n"
                                "VALUES (:mid, :rate, :eff, :uid, 1)",
                                {"mid": mid, "rate": r["rate"], "eff": r["valid_from"], "uid": upload_id},
                            )

                execute(conn, "UPDATE pricing_uploads SET status = 'SUCCESS', rows_valid = :v, rows_invalid = :iv, upload_notes = :n WHERE id = :id",
                       {"v": valid, "iv": invalid, "n": "\n".join(notes) if notes else None, "id": upload_id})
        except Exception as e:
            flash_set("error", f"Upload failed: {str(e)}")
            return redirect("/scratch/settings/pricing")

    flash_set("success", "Pricing data imported successfully.")
    return redirect("/scratch/settings/pricing")


@bp.post("/scratch/settings/pricing/rate/update")
@login_required
@csrf_protect
def pricing_rate_update() -> object:
    require_admin()
    rate_id = int(request.form.get("rate_id") or 0)
    rate_s = str(request.form.get("rate_per_weight") or "").strip()
    valid_from_s = request.form.get("valid_from")
    valid_to_s = request.form.get("valid_to")

    if rate_id <= 0:
        flash_set("error", "Invalid rate.")
        return redirect("/scratch/settings/pricing")

    try:
        rate = float(rate_s.replace(",", "")) if rate_s != "" else 0.0
    except Exception:
        flash_set("error", "Invalid rate.")
        return redirect("/scratch/settings/pricing")

    valid_from_dt = _parse_datetime_any(valid_from_s)
    if valid_from_dt is None:
        flash_set("error", "Valid From is required.")
        return redirect("/scratch/settings/pricing")

    valid_to_dt = _parse_datetime_any(valid_to_s)
    if valid_to_dt is not None and valid_to_dt < valid_from_dt:
        flash_set("error", "Valid To must be after Valid From.")
        return redirect("/scratch/settings/pricing")

    with db_conn() as conn:
        try:
            with conn.begin():
                has_valid_to = _db_has_column(conn, "material_rates", "valid_to")
                if has_valid_to:
                    execute(
                        conn,
                        "UPDATE material_rates\n"
                        "SET rate_per_weight = :r,\n"
                        "    effective_at = :vf,\n"
                        "    valid_to = :vt\n"
                        "WHERE id = :id",
                        {
                            "r": rate,
                            "vf": valid_from_dt.strftime("%Y-%m-%d %H:%M:%S"),
                            "vt": valid_to_dt.strftime("%Y-%m-%d %H:%M:%S") if valid_to_dt is not None else None,
                            "id": rate_id,
                        },
                    )
                else:
                    execute(
                        conn,
                        "UPDATE material_rates\n"
                        "SET rate_per_weight = :r,\n"
                        "    effective_at = :vf\n"
                        "WHERE id = :id",
                        {"r": rate, "vf": valid_from_dt.strftime("%Y-%m-%d %H:%M:%S"), "id": rate_id},
                    )
        except Exception as e:
            flash_set("error", f"Could not update rate: {str(e)}")
            return redirect("/scratch/settings/pricing")

    flash_set("success", "Rate updated.")
    return redirect("/scratch/settings/pricing")


@bp.get("/scratch/settings/pricing/history")
@login_required
def pricing_history() -> Response:
    require_admin()
    with db_conn() as conn:
        rows = fetch_all(
            conn,
            "SELECT id, original_filename, status, rows_total, rows_valid, rows_invalid, upload_notes, uploaded_at\n"
            "FROM pricing_uploads\n"
            "ORDER BY uploaded_at DESC, id DESC\n"
            "LIMIT 100",
        )
    return jsonify(rows)


@bp.get("/scratch/settings/expiry")
@login_required
def expiry_page() -> object:
    require_admin()
    with db_conn() as conn:
        default_expiry = _app_setting_get(conn, "expiry_days_default", "365")
        default_alert = _app_setting_get(conn, "expiry_alert_before_days_default", "30")
        categories = fetch_all(
            conn,
            "SELECT id, name, expiry_days_default, alert_before_days, is_active\n"
            "FROM material_categories\n"
            "ORDER BY name ASC",
        )
    return render_template(
        "settings/expiry.html",
        pageTitle="Expiry Alert Settings - SYMS",
        defaultExpiry=default_expiry,
        defaultAlert=default_alert,
        categories=categories,
    )


@bp.post("/scratch/settings/expiry")
@login_required
@csrf_protect
def expiry_save() -> object:
    require_admin()
    expiry_days_default = int(request.form.get("expiry_days_default") or 0)
    alert_before_days_default = int(request.form.get("expiry_alert_before_days_default") or 0)
    if expiry_days_default <= 0:
        flash_set("error", "Default Expiry Days must be greater than 0.")
        return redirect("/scratch/settings/expiry")
    if alert_before_days_default < 0:
        flash_set("error", "Default Alert Before Days must be 0 or greater.")
        return redirect("/scratch/settings/expiry")

    with db_conn() as conn:
        try:
            with conn.begin():
                _app_setting_set(conn, "expiry_days_default", str(expiry_days_default))
                _app_setting_set(conn, "expiry_alert_before_days_default", str(alert_before_days_default))
        except Exception:
            flash_set("error", "Could not save expiry defaults.")
            return redirect("/scratch/settings/expiry")

    flash_set("success", "Saved.")
    return redirect("/scratch/settings/expiry")


@bp.get("/scratch/settings/categories")
@login_required
def categories_page() -> object:
    require_admin()
    with db_conn() as conn:
        categories = fetch_all(
            conn,
            "SELECT id, name, expiry_days_default, alert_before_days, is_active FROM material_categories ORDER BY name ASC",
        )
    return render_template("settings/categories.html", pageTitle="Category Settings - SYMS", categories=categories)


@bp.post("/scratch/settings/categories/process")
@login_required
@csrf_protect
def categories_process() -> object:
    require_admin()
    action = str(request.form.get("action") or "").strip()
    with db_txn() as conn:
        if _check_auto_sync_block(conn):
            flash_set("error", "Manual edits are disabled because 'Auto Sync from Pricing Sheet' is enabled in System Rules.")
            return redirect("/scratch/settings/categories")
        try:
            if action == "toggle":
                cid = int(request.form.get("id") or 0)
                if cid <= 0:
                    raise RuntimeError("Invalid category.")
                execute(conn, "UPDATE material_categories SET is_active = 1 - is_active, updated_at = NOW() WHERE id = :id", {"id": cid})
            else:
                name = str(request.form.get("name") or "").strip()
                norm = _normalize_category_name(name)
                if name == "" or norm == "":
                    raise RuntimeError("Category name is required.")
                execute(
                    conn,
                    "INSERT INTO material_categories (name, name_norm, is_active, created_at, updated_at)\n"
                    "VALUES (:name, :norm, 1, NOW(), NOW())\n"
                    "ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
                    {"name": name[:255], "norm": norm},
                )
        except Exception as e:
            flash_set("error", str(e) or "Could not save category.")
            return redirect("/scratch/settings/categories")
    flash_set("success", "Saved.")
    return redirect("/scratch/settings/categories")


@bp.route("/scratch/settings/uoms", methods=["GET"])
@login_required
def uoms_page() -> object:
    require_admin()
    edit_id = int(request.args.get("id") or 0)
    with db_conn() as conn:
        edit = fetch_one(conn, "SELECT id, code, name, is_active FROM uoms WHERE id = :id", {"id": edit_id}) if edit_id > 0 else None
        uoms = fetch_all(conn, "SELECT id, code, name, is_active FROM uoms ORDER BY code ASC")
    return render_template("settings/uoms.html", pageTitle="UOM Settings - SYMS", edit=edit, uoms=uoms)


@bp.post("/scratch/settings/uoms/process")
@login_required
@csrf_protect
def uoms_process() -> object:
    require_admin()
    action = str(request.form.get("action") or "").strip()
    with db_txn() as conn:
        if _check_auto_sync_block(conn):
            flash_set("error", "Manual edits are disabled because 'Auto Sync from Pricing Sheet' is enabled in System Rules.")
            return redirect("/scratch/settings/uoms")
        try:
            if action == "toggle":
                uid = int(request.form.get("id") or 0)
                if uid <= 0:
                    raise RuntimeError("Invalid UOM.")
                execute(conn, "UPDATE uoms SET is_active = 1 - is_active, updated_at = NOW() WHERE id = :id", {"id": uid})
            elif action == "delete":
                uid = int(request.form.get("id") or 0)
                if uid <= 0:
                    raise RuntimeError("Invalid UOM.")
                refs = 0
                for sql in [
                    "SELECT COUNT(*) AS cnt FROM materials WHERE uom_id = :id",
                    "SELECT COUNT(*) AS cnt FROM stock_movements_v2 WHERE uom_id = :id",
                    "SELECT COUNT(*) AS cnt FROM inward_entries WHERE uom_id = :id",
                    "SELECT COUNT(*) AS cnt FROM segregation_entries WHERE uom_id = :id",
                    "SELECT COUNT(*) AS cnt FROM outward_entries WHERE uom_id = :id",
                ]:
                    row = fetch_one(conn, sql, {"id": uid}) or {}
                    refs += int(row.get("cnt") or 0)
                if refs > 0:
                    execute(conn, "UPDATE uoms SET is_active = 0, updated_at = NOW() WHERE id = :id", {"id": uid})
                else:
                    execute(conn, "DELETE FROM uoms WHERE id = :id", {"id": uid})
            else:
                uid = int(request.form.get("id") or 0)
                code = str(request.form.get("code") or "").strip().upper()[:20]
                name = str(request.form.get("name") or "").strip()[:100]
                is_active = 1 if str(request.form.get("is_active") or "1") == "1" else 0
                if code == "" or name == "":
                    raise RuntimeError("Code and name are required.")
                if uid > 0:
                    execute(
                        conn,
                        "UPDATE uoms SET name = :name, is_active = :active, updated_at = NOW() WHERE id = :id",
                        {"name": name, "active": is_active, "id": uid},
                    )
                else:
                    execute(
                        conn,
                        "INSERT INTO uoms (code, name, is_active, created_at, updated_at)\n"
                        "VALUES (:code, :name, :active, NOW(), NOW())\n"
                        "ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = VALUES(is_active), updated_at = NOW()",
                        {"code": code, "name": name, "active": is_active},
                    )
        except Exception as e:
            flash_set("error", str(e) or "Could not save UOM.")
            return redirect("/scratch/settings/uoms")
    flash_set("success", "Saved.")
    return redirect("/scratch/settings/uoms")


@bp.route("/scratch/settings/counterparties", methods=["GET"])
@login_required
def counterparties_page() -> object:
    require_admin()
    edit_id = int(request.args.get("id") or 0)
    with db_conn() as conn:
        ensure_counterparty_schema(conn)
        edit = (
            fetch_one(
                conn,
                "SELECT id, type, code, name, phone, email, address, gstin, is_active FROM counterparties WHERE id = :id",
                {"id": edit_id},
            )
            if edit_id > 0
            else None
        )
        rows = fetch_all(
            conn,
            "SELECT id, type, code, name, phone, email, address, gstin, is_active FROM counterparties ORDER BY type ASC, name ASC",
        )
    return render_template("settings/counterparties.html", pageTitle="Vendor / Customer Settings - SYMS", edit=edit, rows=rows)


@bp.post("/scratch/settings/counterparties/process")
@login_required
@csrf_protect
def counterparties_process() -> object:
    require_admin()
    action = str(request.form.get("action") or "").strip()
    with db_txn() as conn:
        if _check_auto_sync_block(conn):
            flash_set("error", "Manual edits are disabled because 'Auto Sync from Pricing Sheet' is enabled in System Rules.")
            return redirect("/scratch/settings/counterparties")
        try:
            ensure_counterparty_schema(conn)
            if action == "toggle":
                cid = int(request.form.get("id") or 0)
                if cid <= 0:
                    raise RuntimeError("Invalid record.")
                execute(conn, "UPDATE counterparties SET is_active = 1 - is_active, updated_at = NOW() WHERE id = :id", {"id": cid})
            elif action == "delete":
                cid = int(request.form.get("id") or 0)
                if cid <= 0:
                    raise RuntimeError("Invalid record.")
                row = fetch_one(conn, "SELECT COUNT(*) AS cnt FROM outward_entries WHERE counterparty_id = :id", {"id": cid}) or {}
                refs = int(row.get("cnt") or 0)
                if refs > 0:
                    execute(conn, "UPDATE counterparties SET is_active = 0, updated_at = NOW() WHERE id = :id", {"id": cid})
                else:
                    execute(conn, "DELETE FROM counterparties WHERE id = :id", {"id": cid})
            else:
                cid = int(request.form.get("id") or 0)
                tp = str(request.form.get("type") or "VENDOR").strip().upper()
                if tp not in {"VENDOR", "CUSTOMER"}:
                    tp = "VENDOR"
                code = str(request.form.get("code") or "").strip()[:50] or None
                name = str(request.form.get("name") or "").strip()[:255]
                phone = str(request.form.get("phone") or "").strip()[:50] or None
                email = str(request.form.get("email") or "").strip()[:100] or None
                gstin = str(request.form.get("gstin") or "").strip()[:30] or None
                address = str(request.form.get("address") or "").strip()[:255] or None
                is_active = 1 if str(request.form.get("is_active") or "1") == "1" else 0
                if name == "":
                    raise RuntimeError("Name is required.")
                if cid > 0:
                    execute(
                        conn,
                        "UPDATE counterparties\n"
                        "SET type = :t, code = :c, name = :n, phone = :p, email = :e, address = :a, gstin = :g, is_active = :ia, updated_at = NOW()\n"
                        "WHERE id = :id",
                        {"t": tp, "c": code, "n": name, "p": phone, "e": email, "a": address, "g": gstin, "ia": is_active, "id": cid},
                    )
                else:
                    execute(
                        conn,
                        "INSERT INTO counterparties (type, code, name, phone, email, address, gstin, is_active, created_at, updated_at)\n"
                        "VALUES (:t, :c, :n, :p, :e, :a, :g, :ia, NOW(), NOW())\n"
                        "ON DUPLICATE KEY UPDATE code = COALESCE(VALUES(code), code), phone = VALUES(phone), email = VALUES(email), address = VALUES(address), gstin = VALUES(gstin), is_active = VALUES(is_active), updated_at = NOW()",
                        {"t": tp, "c": code, "n": name, "p": phone, "e": email, "a": address, "g": gstin, "ia": is_active},
                    )
        except Exception as e:
            flash_set("error", str(e) or "Could not save record.")
            return redirect("/scratch/settings/counterparties")
    flash_set("success", "Saved.")
    return redirect("/scratch/settings/counterparties")


@bp.post("/scratch/settings/counterparties/upload")
@login_required
@csrf_protect
def counterparties_upload() -> object:
    require_admin()
    file = request.files.get("pricing_file")
    if not file:
        flash_set("error", "File is required.")
        return redirect("/scratch/settings/counterparties")

    original_name = str(file.filename or "")
    ext = original_name.lower().rsplit(".", 1)[-1] if "." in original_name else ""
    if ext not in {"xlsx", "csv"}:
        flash_set("error", "Supported formats: XLSX, CSV.")
        return redirect("/scratch/settings/counterparties")

    rows: list[dict[str, str]] = []
    try:
        if ext == "csv":
            content = file.read().decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(content))
            for r in reader:
                rows.append({str(k or "").strip().lower(): str(v or "").strip() for k, v in (r or {}).items()})
        else:
            from openpyxl import load_workbook
            wb = load_workbook(file, read_only=True, data_only=True)
            ws = wb.active
            headers = [str(c.value or "").strip().lower() for c in ws[1]]
            for i, row in enumerate(ws.iter_rows(min_row=2, values_only=True)):
                d = {headers[j]: str(row[j] or "").strip() for j in range(len(headers)) if j < len(row)}
                if any(d.values()): rows.append(d)
    except Exception as e:
        flash_set("error", f"Could not read file: {str(e)}")
        return redirect("/scratch/settings/counterparties")

    def pick(row, *keys):
        for k in keys:
            v = row.get(k.lower())
            if v: return v
        return ""

    success_count = 0
    with db_conn() as conn:
        try:
            with conn.begin():
                ensure_counterparty_schema(conn)
                for r in rows:
                    name = pick(r, "Name", "Company", "Vendor", "Customer")
                    tp = pick(r, "Type").upper()
                    phone = pick(r, "Phone", "Contact")
                    email = pick(r, "Email")
                    gstin = pick(r, "GSTIN")
                    address = pick(r, "Address")

                    if not name: continue
                    if tp not in {"VENDOR", "CUSTOMER"}: tp = "VENDOR"

                    code = ""
                    if tp == "VENDOR":
                        code = pick(r, "Vendor Code", "Vendor_Code", "Code", "Counterparty Code", "Counterparty_Code")
                    else:
                        code = pick(r, "Customer Code", "Customer_Code", "Code", "Counterparty Code", "Counterparty_Code")
                    code = code.strip()[:50] if code else None

                    execute(conn, 
                        "INSERT INTO counterparties (type, code, name, phone, email, address, gstin, is_active, created_at, updated_at)\n"
                        "VALUES (:t, :c, :n, :p, :e, :a, :g, 1, NOW(), NOW())\n"
                        "ON DUPLICATE KEY UPDATE code = COALESCE(VALUES(code), code), phone = VALUES(phone), email = VALUES(email), address = VALUES(address), gstin = VALUES(gstin), is_active = 1, updated_at = NOW()",
                        {"t": tp, "c": code, "n": name, "p": phone or None, "e": email or None, "a": address or None, "g": gstin or None}
                    )
                    success_count += 1
        except Exception as e:
            flash_set("error", f"Upload failed: {str(e)}")
            return redirect("/scratch/settings/counterparties")

    flash_set("success", f"Successfully imported {success_count} records.")
    return redirect("/scratch/settings/counterparties")


@bp.route("/scratch/settings/parts", methods=["GET", "POST"])
@login_required
@csrf_protect
def parts_page() -> object:
    require_admin()
    if request.method == "POST":
        action = str(request.form.get("action") or "").strip()
        with db_txn() as conn:
            if _check_auto_sync_block(conn):
                flash_set("error", "Manual edits are disabled because 'Auto Sync from Pricing Sheet' is enabled in System Rules.")
                return redirect("/scratch/settings/parts")
            try:
                if action == "add_part":
                    part_no = str(request.form.get("part_no") or "")
                    desc = str(request.form.get("product_description") or "")
                    cat_id = int(request.form.get("category_id") or 0)
                    part_no_raw = part_no.strip()[:100]
                    part_no_norm = _normalize_part_no(part_no_raw)
                    if part_no_norm == "" or desc.strip() == "":
                        raise RuntimeError("Part no and description are required.")
                    cat_or_null = cat_id if cat_id > 0 else None
                    execute(
                        conn,
                        "INSERT INTO materials (part_no_raw, part_no_norm, product_description, category_id, is_active, updated_at)\n"
                        "VALUES (:raw, :norm, :desc, :cat, 1, NOW())\n"
                        "ON DUPLICATE KEY UPDATE part_no_raw = VALUES(part_no_raw), product_description = VALUES(product_description), category_id = VALUES(category_id), is_active = 1, updated_at = NOW()",
                        {"raw": part_no_raw, "norm": part_no_norm, "desc": desc.strip()[:255], "cat": cat_or_null},
                    )
                elif action == "bulk_map":
                    for k, v in request.form.items():
                        if not k.startswith("map[") or not k.endswith("]"):
                            continue
                        mid_s = k[4:-1]
                        try:
                            mid = int(mid_s)
                        except Exception:
                            continue
                        if mid <= 0:
                            continue
                        try:
                            cid = int(v or 0)
                        except Exception:
                            cid = 0
                        execute(
                            conn,
                            "UPDATE materials SET category_id = :cid, updated_at = NOW() WHERE id = :id",
                            {"cid": cid if cid > 0 else None, "id": mid},
                        )
                else:
                    raise RuntimeError("Invalid action.")
            except Exception as e:
                flash_set("error", str(e) or "Could not save.")
                return redirect("/scratch/settings/parts")
        flash_set("success", "Saved.")
        return redirect("/scratch/settings/parts")

    with db_conn() as conn:
        materials = fetch_all(
            conn,
            "SELECT id, part_no_raw, part_no_norm, product_description, category_id\n"
            "FROM materials WHERE is_active = 1\n"
            "ORDER BY product_description ASC, part_no_norm ASC",
        )
        categories = fetch_all(
            conn,
            "SELECT id, name FROM material_categories WHERE is_active = 1 ORDER BY name ASC",
        )
    return render_template("settings/parts.html", pageTitle="Part Mapping - SYMS", materials=materials, categories=categories)


@bp.route("/scratch/settings/lots", methods=["GET"])
@login_required
def lots_page() -> object:
    require_admin()
    with db_conn() as conn:
        materials = fetch_all(
            conn,
            "SELECT id, part_no_raw, part_no_norm, product_description, category_id\n"
            "FROM materials WHERE is_active = 1\n"
            "ORDER BY product_description ASC, part_no_norm ASC",
        )
        categories = fetch_all(conn, "SELECT id, name FROM material_categories WHERE is_active = 1 ORDER BY name ASC")
        lots = fetch_all(
            conn,
            "SELECT\n"
            "  l.id,\n"
            "  l.lot_number,\n"
            "  l.inward_date,\n"
            "  l.expiry_date,\n"
            "  l.status,\n"
            "  m.part_no_raw,\n"
            "  m.product_description,\n"
            "  COALESCE(c.name, '') AS category_name,\n"
            "  COALESCE(b.balance_weight, 0) AS balance_weight\n"
            "FROM material_lots l\n"
            "JOIN materials m ON m.id = l.material_id\n"
            "LEFT JOIN material_categories c ON c.id = COALESCE(l.category_id, m.category_id)\n"
            "LEFT JOIN (\n"
            "  SELECT lot_id, COALESCE(SUM(balance_weight), 0) AS balance_weight\n"
            "  FROM inventory_lot_balances_v2\n"
            "  GROUP BY lot_id\n"
            ") b ON b.lot_id = l.id\n"
            "ORDER BY l.created_at DESC, l.id DESC\n"
            "LIMIT 500",
        )
    return render_template("settings/lots.html", pageTitle="Lot Settings - SYMS", materials=materials, categories=categories, lots=lots, today=date.today().isoformat())


@bp.post("/scratch/settings/lots/process")
@login_required
@csrf_protect
def lots_process() -> object:
    require_admin()
    lot_number = str(request.form.get("lot_number") or "").strip()[:100]
    material_id = int(request.form.get("material_id") or 0)
    category_id = int(request.form.get("category_id") or 0)
    inward_date_s = str(request.form.get("inward_date") or "").strip()
    status = str(request.form.get("status") or "").strip().upper()
    if status not in {"ACTIVE", "CLOSED"}:
        status = "ACTIVE"

    if lot_number == "" or material_id <= 0 or inward_date_s == "":
        flash_set("error", "Lot number, part and inward date are required.")
        return redirect("/scratch/settings/lots")

    with db_txn() as conn:
        if _check_auto_sync_block(conn):
            flash_set("error", "Manual edits are disabled because 'Auto Sync from Pricing Sheet' is enabled in System Rules.")
            return redirect("/scratch/settings/lots")
        try:
            if category_id <= 0:
                m = fetch_one(conn, "SELECT category_id FROM materials WHERE id = :id", {"id": material_id}) or {}
                category_id = int(m.get("category_id") or 0)
            cat_or_null = category_id if category_id > 0 else None
            inward_dt = date.fromisoformat(inward_date_s)

            execute(
                conn,
                "INSERT INTO material_lots (lot_number, material_id, category_id, inward_date, status, created_at, updated_at)\n"
                "VALUES (:lot, :mid, :cid, :inward, :status, NOW(), NOW())\n"
                "ON DUPLICATE KEY UPDATE material_id = VALUES(material_id), category_id = VALUES(category_id), inward_date = VALUES(inward_date), status = VALUES(status), updated_at = NOW()",
                {
                    "lot": lot_number,
                    "mid": material_id,
                    "cid": cat_or_null,
                    "inward": inward_dt.isoformat(),
                    "status": status,
                },
            )
        except Exception as e:
            flash_set("error", str(e) or "Could not save lot.")
            return redirect("/scratch/settings/lots")

    flash_set("success", "Lot saved.")
    return redirect("/scratch/settings/lots")


@bp.route("/scratch/settings/rules", methods=["GET", "POST"])
@login_required
@csrf_protect
def rules_page() -> object:
    require_admin()
    if request.method == "POST":
        currency = str(request.form.get("currency") or "INR").strip().upper()
        precision = int(request.form.get("precision") or 2)
        auto_sync = "1" if request.form.get("auto_sync") == "1" else "0"
        
        with db_conn() as conn:
            with conn.begin():
                _app_setting_set(conn, "default_currency", currency)
                _app_setting_set(conn, "decimal_precision", str(precision))
                _app_setting_set(conn, "auto_sync_pricing", auto_sync)
        
        flash_set("success", "System rules updated.")
        return redirect("/scratch/settings/rules")

    with db_conn() as conn:
        rules = {
            "currency": _app_setting_get(conn, "default_currency", "INR"),
            "precision": _app_setting_get(conn, "decimal_precision", "2"),
            "auto_sync": _app_setting_get(conn, "auto_sync_pricing", "0"),
        }
    return render_template("settings/rules.html", pageTitle="System Rules - SYMS", rules=rules)


@bp.get("/scratch/settings/logs")
@login_required
def logs_page() -> object:
    require_admin()
    with db_conn() as conn:
        ensure_opening_stock_tables(conn)
        pricing_logs = fetch_all(
            conn,
            "SELECT id, original_filename, status, rows_total, rows_valid, uploaded_at\n"
            "FROM pricing_uploads\n"
            "ORDER BY uploaded_at DESC LIMIT 100"
        )
        opening_logs = fetch_all(
            conn,
            "SELECT id, original_filename, status, rows_total, rows_valid, rows_invalid, uploaded_at\n"
            "FROM opening_stock_uploads\n"
            "ORDER BY uploaded_at DESC LIMIT 100",
        )
    return render_template(
        "settings/logs.html",
        pageTitle="Audit & Logs - SYMS",
        pricing_logs=pricing_logs,
        opening_logs=opening_logs,
    )


@bp.get("/scratch/settings/data-management")
@login_required
def data_management_page() -> object:
    require_admin()
    return render_template("settings/data_management.html", pageTitle="Data Management - SYMS")


@bp.post("/scratch/settings/data-management/export")
@login_required
@csrf_protect
def data_management_export() -> Response:
    require_admin()
    include_users = request.form.get("include_users") == "1"

    with db_conn() as conn:
        rows = fetch_all(
            conn,
            "SELECT TABLE_NAME AS t\n"
            "FROM information_schema.TABLES\n"
            "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'\n"
            "ORDER BY TABLE_NAME ASC",
        )
        tables = [str(r.get("t") or "") for r in rows if str(r.get("t") or "").strip() != ""]

        if not include_users:
            tables = [t for t in tables if t not in {"users", "scrap_admin_users"}]

        out = io.StringIO()
        out.write("SET FOREIGN_KEY_CHECKS=0;\n")
        for t in tables:
            cols = fetch_all(
                conn,
                "SELECT COLUMN_NAME AS c\n"
                "FROM information_schema.COLUMNS\n"
                "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :t\n"
                "ORDER BY ORDINAL_POSITION ASC",
                {"t": t},
            )
            col_names = [str(c.get("c") or "") for c in cols if str(c.get("c") or "").strip() != ""]
            if not col_names:
                continue
            sql = "SELECT * FROM `" + t + "`"
            data = conn.execute(text(sql)).mappings().all()
            for r in data:
                vals = [_sql_quote(r.get(c)) for c in col_names]
                out.write(
                    "INSERT INTO `"
                    + t
                    + "` ("
                    + ",".join("`" + c + "`" for c in col_names)
                    + ") VALUES ("
                    + ",".join(vals)
                    + ");\n"
                )
        out.write("SET FOREIGN_KEY_CHECKS=1;\n")

    b = out.getvalue().encode("utf-8")
    buf = io.BytesIO(b)
    buf.seek(0)
    name = "syms_export_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".sql"
    return send_file(buf, mimetype="application/sql", as_attachment=True, download_name=name)


@bp.post("/scratch/settings/data-management/wipe")
@login_required
@csrf_protect
def data_management_wipe() -> object:
    require_admin()
    confirm_text = str(request.form.get("confirm_text") or "").strip().upper()
    if confirm_text != "DELETE":
        flash_set("error", "Confirmation text does not match.")
        return redirect("/scratch/settings/data-management")

    include_master = request.form.get("include_master") == "1"
    include_settings = request.form.get("include_settings") == "1"
    include_users = request.form.get("include_users") == "1"

    transactional_tables = [
        "memo_items",
        "memos",
        "inward_entries",
        "segregation_entries",
        "outward_entries",
        "stock_movements_v2",
        "inventory_movements",
        "scrap_requests",
        "scrap_email_logs",
        "report_exports",
        "report_schedules",
    ]
    master_tables = [
        "material_rates",
        "material_lots",
        "materials",
        "material_category_aliases",
        "material_categories",
        "uoms",
        "counterparties",
    ]
    settings_tables = [
        "pricing_uploads",
        "opening_stock_uploads",
        "app_settings",
    ]
    user_tables = [
        "users",
        "scrap_admin_users",
    ]

    tables = list(transactional_tables)
    if include_settings:
        tables.extend(settings_tables)
    if include_master:
        tables.extend(master_tables)
    if include_users:
        tables.extend(user_tables)

    with db_txn() as conn:
        execute(conn, "SET FOREIGN_KEY_CHECKS=0")
        for t in tables:
            execute(conn, f"DELETE FROM `{t}`")
        execute(conn, "SET FOREIGN_KEY_CHECKS=1")

    try:
        settings = load_settings()
        base = Path(settings.upload_dir)
        if not base.is_absolute():
            base = (Path(__file__).resolve().parents[3] / base).resolve()
        for sub in ["memos", "opening_stock", "pricing", "outward"]:
            p = (base / sub).resolve()
            if p.exists() and p.is_dir():
                for child in p.glob("*"):
                    try:
                        if child.is_file():
                            child.unlink()
                    except Exception:
                        pass

        exp_base = Path(settings.export_dir)
        if not exp_base.is_absolute():
            exp_base = (Path(__file__).resolve().parents[3] / exp_base).resolve()
        if exp_base.exists() and exp_base.is_dir():
            for child in exp_base.glob("*"):
                try:
                    if child.is_file():
                        child.unlink()
                except Exception:
                    pass
    except Exception:
        pass

    flash_set("success", "Platform data deleted.")
    return redirect("/scratch/settings/data-management")
