from __future__ import annotations

from flask import Blueprint, redirect

from app.config import load_settings

bp = Blueprint("core", __name__)


@bp.get("/")
def root() -> object:
    return redirect("/scrap-request")


@bp.get("/scratch/")
def scratch_index() -> object:
    return redirect("/scratch/dashboard")


@bp.get("/scratch/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok"}
