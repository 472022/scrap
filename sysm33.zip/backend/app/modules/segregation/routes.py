from __future__ import annotations

from flask import Blueprint, abort, redirect, render_template, request, session

from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.domain import inventory_add_movement, inventory_balance, material_find_by_id, stock_v2_add_movement, uom_find_by_code
from app.utils.flash import flash_set
from app.utils.rbac import require_operational_role

bp = Blueprint("segregation", __name__)


@bp.get("/scratch/segregation/list")
@login_required
def segregation_list() -> object:
    sql = (
        "SELECT se.id, se.memo_id, se.inward_id, se.material_id, se.lot_id, se.uom_id, se.material_type, se.weight, se.created_at,\n"
        "       m.memo_number, mt.part_no_raw, mt.product_description, l.lot_number,\n"
        "       c.name AS category_name, COALESCE(u.code, '') AS uom_code\n"
        "FROM segregation_entries se\n"
        "LEFT JOIN memos m ON m.id = se.memo_id\n"
        "LEFT JOIN materials mt ON mt.id = se.material_id\n"
        "LEFT JOIN uoms u ON u.id = COALESCE(se.uom_id, mt.uom_id)\n"
        "LEFT JOIN material_lots l ON l.id = se.lot_id\n"
        "LEFT JOIN material_categories c ON c.id = COALESCE(l.category_id, mt.category_id)\n"
        "ORDER BY se.created_at DESC"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql)
    return render_template("segregation/list.html", pageTitle="Segregation - SYMS", rows=rows)


@bp.get("/scratch/segregation/add")
@login_required
def segregation_add() -> object:
    try:
        selected_memo_id = int(request.args.get("memo_id") or 0)
    except Exception:
        selected_memo_id = 0

    with db_conn() as conn:
        memos = fetch_all(
            conn,
            "SELECT id, memo_number, memo_date\n"
            "FROM memos\n"
            "WHERE status IN ('VERIFIED','MUTILATION_COMPLETED')\n"
            "ORDER BY memo_date DESC, created_at DESC\n"
            "LIMIT 300",
        )
        materials = fetch_all(
            conn,
            "SELECT id, part_no_raw, product_description, uom_id\n"
            "FROM materials\n"
            "WHERE is_active = 1\n"
            "ORDER BY product_description ASC, part_no_norm ASC",
        )
        uoms = fetch_all(conn, "SELECT id, code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")

    return render_template(
        "segregation/add.html",
        pageTitle="Add Segregation - SYMS",
        selectedMemoId=selected_memo_id,
        memos=memos,
        materials=materials,
        uoms=uoms,
    )


@bp.post("/scratch/segregation/add_process")
@login_required
@csrf_protect
def segregation_add_process() -> object:
    require_operational_role()
    return_to = str(request.form.get("return_to") or "").strip()
    if return_to and not return_to.startswith("/scratch/"):
        return_to = ""

    try:
        memo_id = int(request.form.get("memo_id") or 0)
    except Exception:
        memo_id = 0
    try:
        material_id = int(request.form.get("material_id") or 0)
    except Exception:
        material_id = 0
    try:
        uom_id = int(request.form.get("uom_id") or 0)
    except Exception:
        uom_id = 0
    try:
        weight = float(request.form.get("weight") or 0)
    except Exception:
        weight = 0.0

    material = material_find_by_id(material_id)
    material_type = str((material or {}).get("product_description") or "")
    category_id = int((material or {}).get("category_id") or 0)
    if material and int((material or {}).get("uom_id") or 0) > 0:
        uom_id = int((material or {}).get("uom_id") or 0)
    if uom_id <= 0:
        u = uom_find_by_code("KG") or {}
        uom_id = int(u.get("id") or 0)

    if memo_id <= 0 or not material or weight <= 0:
        flash_set("error", "Memo, Part and qty/number are required.")
        return redirect(return_to or "/scratch/segregation/add")

    with db_conn() as conn:
        memo = fetch_one(conn, "SELECT id, status FROM memos WHERE id = :id", {"id": memo_id})
    if not memo or str(memo.get("status") or "") not in {"VERIFIED", "MUTILATION_COMPLETED"}:
        flash_set("error", "Memo must be verified before segregation.")
        return redirect(return_to or "/scratch/segregation/add")

    user_id = int(session.get("user_id") or 0)

    try:
        with db_conn() as conn:
            with conn.begin():
                execute(
                    conn,
                    "INSERT INTO segregation_entries (memo_id, inward_id, material_id, lot_id, uom_id, material_type, weight)\n"
                    "VALUES (:memo_id, NULL, :material_id, NULL, :uom_id, :material_type, :weight)",
                    {
                        "memo_id": memo_id,
                        "material_id": material_id,
                        "uom_id": uom_id if uom_id > 0 else None,
                        "material_type": material_type,
                        "weight": weight,
                    },
                )
                row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                segr_id = int(row.get("id") or 0)
                if segr_id <= 0:
                    raise RuntimeError("Could not save segregation entry.")

                inventory_add_movement("SEGREGATION", segr_id, None, material_type, weight, uom_id, conn=conn)
                stock_v2_add_movement(
                    "SEGREGATION",
                    segr_id,
                    material_id,
                    weight,
                    "IN",
                    "",
                    None,
                    category_id if category_id > 0 else None,
                    None,
                    uom_id,
                    conn=conn,
                )

                # Only move memo to VERIFIED if it hasn't progressed further (preserve MUTILATION_COMPLETED)
                execute(
                    conn,
                    "UPDATE memos SET status = 'VERIFIED', verified_by = :uid, verified_at = NOW()\n"
                    " WHERE id = :id AND status != 'MUTILATION_COMPLETED'",
                    {"uid": user_id, "id": memo_id},
                )
    except Exception:
        flash_set("error", "Could not add segregation entry.")
        return redirect(return_to or "/scratch/segregation/add")

    flash_set("success", "Segregation entry added.")
    return redirect(return_to or "/scratch/segregation/list")


def _require_edit_permission() -> None:
    from app.utils.rbac import current_user_role
    if current_user_role() not in ("admin", "supervisor"):
        abort(403)


@bp.get("/scratch/segregation/edit")
@login_required
def segregation_edit() -> object:
    _require_edit_permission()
    try:
        segr_id = int(request.args.get("id") or 0)
    except Exception:
        segr_id = 0
    if segr_id <= 0:
        flash_set("error", "Invalid entry.")
        return redirect("/scratch/segregation/list")

    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT se.id, se.memo_id, se.material_id, se.uom_id, se.material_type, se.weight,\n"
            "       m.memo_number, m.memo_date\n"
            "FROM segregation_entries se\n"
            "LEFT JOIN memos m ON m.id = se.memo_id\n"
            "WHERE se.id = :id",
            {"id": segr_id},
        )
        if not row:
            flash_set("error", "Entry not found.")
            return redirect("/scratch/segregation/list")
        materials = fetch_all(
            conn,
            "SELECT id, part_no_raw, product_description, uom_id FROM materials WHERE is_active = 1 ORDER BY product_description ASC, part_no_norm ASC",
        )
        uoms = fetch_all(conn, "SELECT id, code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")

    return render_template(
        "segregation/edit.html",
        pageTitle="Edit Segregation - SYMS",
        entry=row,
        materials=materials,
        uoms=uoms,
    )


@bp.post("/scratch/segregation/edit")
@login_required
@csrf_protect
def segregation_edit_post() -> object:
    _require_edit_permission()
    try:
        segr_id = int(request.form.get("id") or 0)
    except Exception:
        segr_id = 0
    if segr_id <= 0:
        flash_set("error", "Invalid entry.")
        return redirect("/scratch/segregation/list")

    try:
        new_material_id = int(request.form.get("material_id") or 0)
    except Exception:
        new_material_id = 0
    try:
        new_uom_id = int(request.form.get("uom_id") or 0)
    except Exception:
        new_uom_id = 0
    try:
        new_weight = float(request.form.get("weight") or 0)
    except Exception:
        new_weight = 0.0

    new_material = material_find_by_id(new_material_id)
    if not new_material or new_weight <= 0:
        flash_set("error", "Part and qty/number are required.")
        return redirect(f"/scratch/segregation/edit?id={segr_id}")

    new_material_type = str((new_material or {}).get("product_description") or "")
    new_category_id = int((new_material or {}).get("category_id") or 0)
    if int((new_material or {}).get("uom_id") or 0) > 0:
        new_uom_id = int((new_material or {}).get("uom_id") or 0)
    if new_uom_id <= 0:
        u = uom_find_by_code("KG") or {}
        new_uom_id = int(u.get("id") or 0)

    with db_conn() as conn:
        old = fetch_one(
            conn,
            "SELECT material_id, lot_id, uom_id, material_type, weight FROM segregation_entries WHERE id = :id",
            {"id": segr_id},
        )
    if not old:
        flash_set("error", "Entry not found.")
        return redirect("/scratch/segregation/list")

    old_material_id = int(old.get("material_id") or 0)
    old_lot_id = int(old.get("lot_id") or 0)
    old_uom_id = int(old.get("uom_id") or 0)
    old_material_type = str(old.get("material_type") or "")
    old_weight = float(old.get("weight") or 0)

    old_material = material_find_by_id(old_material_id) or {}
    old_category_id = int(old_material.get("category_id") or 0)
    old_material_uom = int(old_material.get("uom_id") or 0)
    if old_material_uom > 0:
        old_uom_id = old_material_uom

    try:
        with db_conn() as conn:
            with conn.begin():
                # Atomic balance check inside transaction to prevent TOCTOU race
                _bal_sql = (
                    "SELECT COALESCE(balance_weight, 0) AS bw FROM inventory_balances"
                    " WHERE material_type = :mt AND uom_id = :uom"
                    if old_uom_id > 0
                    else "SELECT COALESCE(SUM(balance_weight), 0) AS bw FROM inventory_balances WHERE material_type = :mt"
                )
                _bal_params: dict = {"mt": old_material_type}
                if old_uom_id > 0:
                    _bal_params["uom"] = old_uom_id
                _bal_row = fetch_one(conn, _bal_sql, _bal_params) or {}
                if float(_bal_row.get("bw") or 0) < old_weight:
                    raise ValueError("Not enough stock to edit this entry (balance would go negative).")

                # Reverse old movement
                inventory_add_movement("SEGREGATION", segr_id, old_material_type, None, old_weight, old_uom_id, conn=conn)
                if old_material_id > 0:
                    stock_v2_add_movement(
                        "SEGREGATION", segr_id, old_material_id, old_weight, "OUT",
                        "EDIT_SEGREGATION_OLD",
                        old_lot_id if old_lot_id > 0 else None,
                        old_category_id if old_category_id > 0 else None,
                        None,
                        old_uom_id,
                        conn=conn,
                    )

                # Update the entry
                execute(
                    conn,
                    "UPDATE segregation_entries SET material_id = :material_id, uom_id = :uom_id, material_type = :material_type, weight = :weight WHERE id = :id",
                    {
                        "material_id": new_material_id,
                        "uom_id": new_uom_id if new_uom_id > 0 else None,
                        "material_type": new_material_type,
                        "weight": new_weight,
                        "id": segr_id,
                    },
                )

                # Add new movement
                inventory_add_movement("SEGREGATION", segr_id, None, new_material_type, new_weight, new_uom_id, conn=conn)
                stock_v2_add_movement(
                    "SEGREGATION", segr_id, new_material_id, new_weight, "IN",
                    "EDIT_SEGREGATION_NEW",
                    None,
                    new_category_id if new_category_id > 0 else None,
                    None,
                    new_uom_id,
                    conn=conn,
                )
    except Exception as e:
        flash_set("error", str(e) or "Could not update segregation entry.")
        return redirect(f"/scratch/segregation/edit?id={segr_id}")

    flash_set("success", "Segregation entry updated.")
    return redirect("/scratch/segregation/list")


@bp.post("/scratch/segregation/delete")
@login_required
@csrf_protect
def segregation_delete() -> object:
    _require_edit_permission()
    try:
        segr_id = int(request.form.get("id") or 0)
    except Exception:
        segr_id = 0
    if segr_id <= 0:
        flash_set("error", "Invalid segregation entry.")
        return redirect("/scratch/segregation/list")

    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT material_id, lot_id, uom_id, material_type, weight FROM segregation_entries WHERE id = :id",
            {"id": segr_id},
        )
    if not row:
        flash_set("error", "Segregation entry not found.")
        return redirect("/scratch/segregation/list")

    material_type = str(row.get("material_type") or "")
    material_id = int(row.get("material_id") or 0)
    lot_id = int(row.get("lot_id") or 0)
    uom_id = int(row.get("uom_id") or 0)
    weight = float(row.get("weight") or 0)

    material = material_find_by_id(material_id) or {}
    category_id = int(material.get("category_id") or 0)
    material_uom_id = int(material.get("uom_id") or 0)
    if material_uom_id > 0:
        uom_id = material_uom_id

    expiry_snapshot = None
    if lot_id > 0:
        with db_conn() as conn:
            lot = fetch_one(conn, "SELECT category_id, expiry_date FROM material_lots WHERE id = :id", {"id": lot_id})
        if lot:
            if category_id <= 0:
                category_id = int(lot.get("category_id") or 0)
            expiry_snapshot = str(lot.get("expiry_date") or "") or None

    if material_type == "" or weight <= 0:
        flash_set("error", "Invalid segregation entry.")
        return redirect("/scratch/segregation/list")

    try:
        with db_conn() as conn:
            with conn.begin():
                # Atomic balance check inside transaction to prevent TOCTOU race
                _del_bal_sql = (
                    "SELECT COALESCE(balance_weight, 0) AS bw FROM inventory_balances"
                    " WHERE material_type = :mt AND uom_id = :uom"
                    if uom_id > 0
                    else "SELECT COALESCE(SUM(balance_weight), 0) AS bw FROM inventory_balances WHERE material_type = :mt"
                )
                _del_bal_params: dict = {"mt": material_type}
                if uom_id > 0:
                    _del_bal_params["uom"] = uom_id
                _del_bal_row = fetch_one(conn, _del_bal_sql, _del_bal_params) or {}
                if float(_del_bal_row.get("bw") or 0) < weight:
                    raise ValueError("Not enough stock in this category to reverse segregation.")

                inventory_add_movement("SEGREGATION", segr_id, material_type, None, weight, uom_id, conn=conn)
                if material_id > 0:
                    stock_v2_add_movement(
                        "SEGREGATION",
                        segr_id,
                        material_id,
                        weight,
                        "OUT",
                        "DELETE_SEGREGATION",
                        lot_id if lot_id > 0 else None,
                        category_id if category_id > 0 else None,
                        expiry_snapshot,
                        uom_id,
                        conn=conn,
                    )
                execute(conn, "DELETE FROM segregation_entries WHERE id = :id", {"id": segr_id})
    except Exception:
        flash_set("error", "Could not delete segregation entry.")
        return redirect("/scratch/segregation/list")

    flash_set("success", "Segregation entry deleted.")
    return redirect("/scratch/segregation/list")
