from __future__ import annotations

from flask import Blueprint, redirect, render_template, request, session

from app.db.engine import db_conn
from app.db.query import execute, fetch_one
from app.security.csrf import csrf_protect
from app.utils.flash import flash_set
from app.utils.rbac import current_user_role

from .services import hash_password, is_legacy_plaintext, normalize_password, normalize_username, verify_password

bp = Blueprint("auth", __name__)


@bp.get("/scratch/auth/login")
def login_page() -> object:
    if session.get("user_id"):
        if str(session.get("role") or "") == "sqpdcme":
            return redirect("/scratch/sqpdcme")
        return redirect("/scratch/dashboard")

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT COUNT(*) AS cnt FROM users")
        user_count = int((row or {}).get("cnt") or 0)

    return render_template("auth/login.html", pageTitle="Login - SYMS", userCount=user_count)


@bp.route("/scratch/auth/create_admin", methods=["GET", "POST"])
@csrf_protect
def create_admin() -> object:
    with db_conn() as conn:
        row = fetch_one(conn, "SELECT COUNT(*) AS cnt FROM users") or {}
        user_count = int(row.get("cnt") or 0)
    if user_count > 0:
        return redirect("/scratch/auth/login")

    if request.method == "GET":
        return render_template("auth/create_admin.html", pageTitle="Create Admin - SYMS")

    username = normalize_username(request.form.get("username"))
    password = normalize_password(request.form.get("password"))
    confirm = normalize_password(request.form.get("confirm_password"))

    if username == "" or password == "":
        flash_set("error", "Username and password are required.")
        return redirect("/scratch/auth/create_admin")
    if password != confirm:
        flash_set("error", "Passwords do not match.")
        return redirect("/scratch/auth/create_admin")

    pw_hash = hash_password(password)
    if pw_hash == "":
        flash_set("error", "Could not set password.")
        return redirect("/scratch/auth/create_admin")

    try:
        with db_conn() as conn:
            with conn.begin():
                execute(
                    conn,
                    "INSERT INTO users (username, password, role) VALUES (:username, :password, 'admin')",
                    {"username": username, "password": pw_hash},
                )
                row2 = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                user_id = int(row2.get("id") or 0)
    except Exception:
        flash_set("error", "Could not create admin user.")
        return redirect("/scratch/auth/create_admin")

    session.clear()
    session["user_id"] = int(user_id or 0)
    session["role"] = "admin"
    flash_set("success", "Admin created.")
    return redirect("/scratch/dashboard")


@bp.post("/scratch/auth/login")
@csrf_protect
def login_process() -> object:
    username = normalize_username(request.form.get("username"))
    password = normalize_password(request.form.get("password"))

    if username == "" or password == "":
        flash_set("error", "Username and password are required.")
        return redirect("/scratch/auth/login")

    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT id, password, role FROM users WHERE username = :username",
            {"username": username},
        )

    if not row:
        flash_set("error", "Invalid credentials.")
        return redirect("/scratch/auth/login")

    stored_hash = str(row.get("password") or "")
    if not verify_password(password, stored_hash):
        flash_set("error", "Invalid credentials.")
        return redirect("/scratch/auth/login")

    user_id = int(row.get("id") or 0)
    role = str(row.get("role") or "worker")

    # Migrate plain-text passwords to werkzeug hash on successful login
    if is_legacy_plaintext(stored_hash):
        new_hash = hash_password(password)
        if new_hash:
            try:
                with db_conn() as conn:
                    with conn.begin():
                        execute(
                            conn,
                            "UPDATE users SET password = :pw WHERE id = :id",
                            {"pw": new_hash, "id": user_id},
                        )
            except Exception:
                pass

    session.clear()
    session["user_id"] = user_id
    session["role"] = role
    flash_set("success", "Welcome back.")

    if role == "requestor":
        return redirect("/scratch/requests")
    if role == "sqpdcme":
        return redirect("/scratch/sqpdcme")
    return redirect("/scratch/dashboard")


@bp.get("/scratch/auth/logout")
def logout() -> object:
    session.clear()
    return redirect("/scratch/auth/login")
