from __future__ import annotations

from typing import Any

from werkzeug.security import check_password_hash, generate_password_hash


def verify_password(password: str, password_hash: str) -> bool:
    if not password or not password_hash:
        return False
    try:
        return check_password_hash(password_hash, password)
    except Exception:
        # Migration fallback: plain-text passwords stored before hashing was introduced
        return password == password_hash


def hash_password(password: str) -> str:
    if not password:
        return ""
    return generate_password_hash(password)


def is_legacy_plaintext(password_hash: str) -> bool:
    """Returns True if the stored value is a plain-text password (pre-hashing migration)."""
    return not password_hash.startswith(("pbkdf2:", "scrypt:", "bcrypt:"))


def normalize_username(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return value.strip()[:50]


def normalize_password(value: Any) -> str:
    if not isinstance(value, str):
        return ""
    return value.strip()[:200]
