from __future__ import annotations

import os
import re
import time
from pathlib import Path

from flask import Blueprint, render_template_string, request
from sqlalchemy import text

from app.db.engine import db_conn

bp = Blueprint("setup", __name__)

# ── Path to the combined setup SQL ────────────────────────────
_SQL_FILE = Path(__file__).resolve().parents[4] / "db" / "setup.sql"

# ── Access guard ──────────────────────────────────────────────
# The page is accessible ONLY when:
#   1. The users table does not yet exist (fresh DB), OR
#   2. The users table exists but has 0 rows, OR
#   3. The env var SYMS_SETUP_KEY is set and the request passes ?key=<that value>
def _is_allowed() -> bool:
    setup_key = (os.getenv("SYMS_SETUP_KEY") or "").strip()
    if setup_key and request.args.get("key") == setup_key:
        return True
    try:
        with db_conn() as conn:
            row = conn.execute(text("SELECT COUNT(*) AS cnt FROM users")).mappings().one_or_none()
            return int((row or {}).get("cnt") or 0) == 0
    except Exception:
        return True  # table doesn't exist yet — allow setup


# ── SQL splitter (handles CREATE VIEW, DROP VIEW, etc.) ───────
_DELIMITER_RE = re.compile(r";\s*\n", re.MULTILINE)

def _split_statements(sql: str) -> list[str]:
    stmts = []
    for raw in _DELIMITER_RE.split(sql):
        s = raw.strip()
        # Skip blank lines and pure comments
        lines = [l for l in s.splitlines() if l.strip() and not l.strip().startswith("--")]
        if not lines:
            continue
        # Skip the two DB-level lines — the engine already targets the right DB
        first = lines[0].upper()
        if first.startswith("CREATE DATABASE") or first.startswith("USE "):
            continue
        stmts.append(s)
    return stmts


# ── HTML template ─────────────────────────────────────────────
_PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SYMS Database Setup</title>
<style>
  *{box-sizing:border-box}
  body{font-family:Calibri,Arial,sans-serif;background:#f0f4f8;margin:0;padding:24px}
  .card{background:#fff;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,.1);max-width:820px;margin:0 auto;padding:32px}
  h1{color:#1f3864;margin-top:0}
  h2{color:#2e75b6;font-size:1.1rem;margin-top:24px}
  .badge{display:inline-block;padding:3px 10px;border-radius:12px;font-size:.82rem;font-weight:600}
  .ok{background:#e2efda;color:#375623}
  .err{background:#fce4d6;color:#9c2a10}
  .warn{background:#fff2cc;color:#7f6000}
  .skip{background:#f0f0f0;color:#666}
  table{width:100%;border-collapse:collapse;font-size:.9rem}
  th{background:#2e75b6;color:#fff;padding:8px 10px;text-align:left}
  td{padding:7px 10px;border-bottom:1px solid #e0e8f0;vertical-align:top}
  tr:nth-child(even) td{background:#f7fafd}
  .stmt{font-family:monospace;font-size:.8rem;color:#333;word-break:break-all}
  .summary{background:#e8f5e9;border-left:4px solid #43a047;padding:14px 18px;border-radius:6px;margin:20px 0}
  .summary.fail{background:#fce4d6;border-color:#e53935}
  .btn{display:inline-block;background:#1f3864;color:#fff;padding:12px 28px;border:none;border-radius:6px;font-size:1rem;cursor:pointer;text-decoration:none;margin-top:8px}
  .btn:hover{background:#2e75b6}
  .btn-back{background:#6c757d}
  .creds{background:#fff8e1;border:1px solid #ffe082;border-radius:8px;padding:16px;margin-top:16px}
  .creds table td,  .creds table th{border:1px solid #ffe082;padding:6px 12px}
  .creds table th{background:#fff8e1;color:#7f6000}
  pre{white-space:pre-wrap;word-break:break-all}
</style>
</head>
<body>
<div class="card">
  <h1>⚙ SYMS — Database Setup</h1>

  {% if not allowed %}
  <div class="summary fail">
    <strong>Access denied.</strong><br>
    This page is only accessible on a fresh (empty) database, or when
    <code>SYMS_SETUP_KEY</code> is set in the environment and
    <code>?key=&lt;value&gt;</code> is passed in the URL.
  </div>
  <a href="/scratch/auth/login" class="btn btn-back">← Back to Login</a>

  {% elif not ran %}
  <p>Click the button below to create all database tables and insert the default users.<br>
     This is safe to re-run — every statement uses <code>CREATE … IF NOT EXISTS</code> or <code>INSERT IGNORE</code>.</p>

  <div class="creds">
    <strong>Default credentials after setup:</strong>
    <table>
      <tr><th>Role</th><th>Username</th><th>Password</th></tr>
      <tr><td>Admin</td><td>admin</td><td>admin</td></tr>
      <tr><td>SQPDCME</td><td>sqpdcme</td><td>sqpdcme123</td></tr>
    </table>
    <p style="margin:8px 0 0;color:#7f3f00;font-size:.9rem">
      ⚠ Change both passwords immediately after first login.
    </p>
  </div>

  <form method="post" style="margin-top:20px">
    <input type="hidden" name="confirm" value="1">
    {% if key %}<input type="hidden" name="key" value="{{ key }}">{% endif %}
    <button type="submit" class="btn">Run Setup Now</button>
  </form>

  {% else %}
  <div class="summary {% if errors > 0 %}fail{% endif %}">
    <strong>Setup {% if errors == 0 %}completed successfully{% else %}finished with {{ errors }} error(s){% endif %}.</strong><br>
    {{ ok }} statement(s) OK &nbsp;·&nbsp; {{ skip }} skipped &nbsp;·&nbsp; {{ errors }} failed
    &nbsp;·&nbsp; took {{ duration }}s
  </div>

  {% if errors == 0 %}
  <div class="creds">
    <strong>You can now log in:</strong>
    <table>
      <tr><th>Username</th><th>Password</th><th>Role</th></tr>
      <tr><td>admin</td><td>admin</td><td>Admin</td></tr>
      <tr><td>sqpdcme</td><td>sqpdcme123</td><td>SQPDCME</td></tr>
    </table>
  </div>
  <a href="/scratch/auth/login" class="btn" style="margin-top:16px">Go to Login →</a>
  {% endif %}

  <h2>Statement Log</h2>
  <table>
    <tr><th>#</th><th>Status</th><th>Statement</th><th>Detail</th></tr>
    {% for r in results %}
    <tr>
      <td>{{ loop.index }}</td>
      <td><span class="badge {{ r.cls }}">{{ r.status }}</span></td>
      <td class="stmt">{{ r.sql[:120] }}{% if r.sql|length > 120 %}…{% endif %}</td>
      <td>{{ r.detail }}</td>
    </tr>
    {% endfor %}
  </table>
  {% endif %}
</div>
</body>
</html>"""


@bp.get("/scratch/setup")
def setup_page() -> object:
    return render_template_string(
        _PAGE,
        allowed=_is_allowed(),
        ran=False,
        key=request.args.get("key", ""),
    )


@bp.post("/scratch/setup")
def setup_run() -> object:
    if not _is_allowed():
        return render_template_string(_PAGE, allowed=False, ran=False, key="")

    if not request.form.get("confirm"):
        return render_template_string(_PAGE, allowed=True, ran=False, key=request.form.get("key", ""))

    if not _SQL_FILE.exists():
        return render_template_string(
            _PAGE, allowed=True, ran=True,
            ok=0, skip=0, errors=1, duration="0.00",
            results=[{"cls": "err", "status": "ERROR", "sql": str(_SQL_FILE), "detail": "setup.sql file not found"}],
        )

    sql_text = _SQL_FILE.read_text(encoding="utf-8")
    statements = _split_statements(sql_text)

    results = []
    ok = skip = errors = 0
    t0 = time.time()

    with db_conn() as conn:
        for stmt in statements:
            first_word = stmt.split()[0].upper() if stmt.split() else ""
            preview = stmt[:200].replace("\n", " ")
            try:
                conn.execute(text(stmt))
                conn.commit()
                ok += 1
                results.append({"cls": "ok", "status": "OK", "sql": preview, "detail": ""})
            except Exception as exc:
                msg = str(exc)
                # "Duplicate key name" / "already exists" are expected on re-runs — treat as skip
                skip_phrases = (
                    "already exists", "duplicate key", "duplicate entry",
                    "can't create table", "constraint already exists",
                )
                if any(p in msg.lower() for p in skip_phrases):
                    skip += 1
                    results.append({"cls": "skip", "status": "SKIP", "sql": preview, "detail": msg[:160]})
                else:
                    errors += 1
                    results.append({"cls": "err", "status": "ERROR", "sql": preview, "detail": msg[:300]})
                try:
                    conn.rollback()
                except Exception:
                    pass

    duration = f"{time.time() - t0:.2f}"
    return render_template_string(
        _PAGE,
        allowed=True, ran=True,
        ok=ok, skip=skip, errors=errors, duration=duration,
        results=results,
        key="",
    )
