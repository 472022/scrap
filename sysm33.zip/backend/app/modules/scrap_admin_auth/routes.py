from __future__ import annotations

from flask import Blueprint, redirect, render_template, request, session
from werkzeug.security import check_password_hash, generate_password_hash

from app.db.engine import db_conn
from app.db.query import execute, fetch_one
from app.db.scrap_schema import ensure_scrap_tables
from app.security.csrf import csrf_protect
from app.utils.flash import flash_set

bp = Blueprint("scrap_admin_auth", __name__)


def _admin_count(conn) -> int:
    ensure_scrap_tables(conn)
    row = fetch_one(conn, "SELECT COUNT(*) AS cnt FROM scrap_admin_users") or {}
    return int(row.get("cnt") or 0)


@bp.get("/scrap-admin/login")
def scrap_admin_login_page() -> object:
    if session.get("scrap_admin_user_id"):
        return redirect("/scrap-admin/requests")
    with db_conn() as conn:
        user_count = _admin_count(conn)
    return render_template("scrap_admin/login.html", pageTitle="Scrap Admin Login - SYMS", userCount=user_count)


@bp.post("/scrap-admin/login")
@csrf_protect
def scrap_admin_login_process() -> object:
    if session.get("scrap_admin_user_id"):
        return redirect("/scrap-admin/requests")
    username = str(request.form.get("username") or "").strip()
    password = str(request.form.get("password") or "")
    if username == "" or password == "":
        flash_set("error", "Username and password are required.")
        return redirect("/scrap-admin/login")

    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT id, username, password_hash, is_active FROM scrap_admin_users WHERE username = :u LIMIT 1",
            {"u": username},
        ) or {}
        uid = int(row.get("id") or 0)
        if uid <= 0 or int(row.get("is_active") or 0) != 1:
            flash_set("error", "Invalid login.")
            return redirect("/scrap-admin/login")
        stored_hash = str(row.get("password_hash") or "")
        if stored_hash == "" or check_password_hash(stored_hash, password) is False:
            flash_set("error", "Invalid login.")
            return redirect("/scrap-admin/login")

    session["scrap_admin_user_id"] = uid
    session["scrap_admin_username"] = username
    flash_set("success", "Signed in.")
    return redirect("/scrap-admin/requests")


@bp.get("/scrap-admin/logout")
def scrap_admin_logout() -> object:
    session.pop("scrap_admin_user_id", None)
    session.pop("scrap_admin_username", None)
    flash_set("success", "Signed out.")
    return redirect("/scrap-admin/login")


@bp.route("/scrap-admin/create_admin", methods=["GET", "POST"])
@csrf_protect
def scrap_admin_create_admin() -> object:
    with db_conn() as conn:
        if _admin_count(conn) > 0:
            return redirect("/scrap-admin/login")

    if request.method == "GET":
        return render_template("scrap_admin/create_admin.html", pageTitle="Create Scrap Admin - SYMS")

    username = str(request.form.get("username") or "").strip()
    password = str(request.form.get("password") or "")
    confirm = str(request.form.get("confirm_password") or "")

    if username == "" or password == "":
        flash_set("error", "Username and password are required.")
        return redirect("/scrap-admin/create_admin")
    if password != confirm:
        flash_set("error", "Passwords do not match.")
        return redirect("/scrap-admin/create_admin")

    password_hash = generate_password_hash(password)

    with db_conn() as conn:
        try:
            with conn.begin():
                execute(
                    conn,
                    "INSERT INTO scrap_admin_users (username, password_hash, is_active, created_at)\n"
                    "VALUES (:u, :p, 1, NOW())",
                    {"u": username[:50], "p": password_hash[:255]},
                )
        except Exception:
            flash_set("error", "Could not create admin user.")
            return redirect("/scrap-admin/create_admin")

    flash_set("success", "Admin user created. Please sign in.")
    return redirect("/scrap-admin/login")
