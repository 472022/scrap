from __future__ import annotations

from flask import Blueprint, redirect, render_template, request, session

from app.config import load_settings
from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.flash import flash_set
from app.utils.rbac import require_operational_role

bp = Blueprint("mutilation", __name__)


def _has_column(table: str, col: str) -> bool:
    settings = load_settings()
    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT COUNT(*) AS cnt\n"
            "FROM information_schema.columns\n"
            "WHERE table_schema = :db AND table_name = :table AND column_name = :col",
            {"db": settings.mysql_db, "table": table, "col": col},
        ) or {}
    return int(row.get("cnt") or 0) > 0


def _status_type() -> str:
    with db_conn() as conn:
        row = fetch_one(conn, "SHOW COLUMNS FROM memos LIKE 'status'") or {}
    return str(row.get("Type") or "")


@bp.get("/scratch/mutilation/list")
@login_required
def mutilation_list() -> object:
    has_is_mutilated = _has_column("memo_items", "is_mutilated")
    items_expr = (
        "(SELECT COUNT(*) FROM memo_items mi WHERE mi.memo_id = m.id AND mi.is_mutilated = 1) AS items_mutilated"
        if has_is_mutilated
        else "0 AS items_mutilated"
    )
    sql = (
        "SELECT\n"
        "    m.id,\n"
        "    m.memo_number,\n"
        "    m.memo_date,\n"
        "    m.source,\n"
        "    m.vehicle_number,\n"
        "    m.status,\n"
        "    m.created_at,\n"
        "    (SELECT COUNT(*) FROM memo_items mi WHERE mi.memo_id = m.id) AS items_total,\n"
        f"    {items_expr}\n"
        "FROM memos m\n"
        "ORDER BY m.created_at DESC"
    )
    with db_conn() as conn:
        memos = fetch_all(conn, sql)

    return render_template(
        "mutilation/list.html",
        pageTitle="Mutilation - SYMS",
        hasIsMutilated=has_is_mutilated,
        memos=memos,
    )


@bp.get("/scratch/mutilation/verify")
@login_required
def mutilation_verify() -> object:
    try:
        memo_id = int(request.args.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        flash_set("error", "Invalid memo.")
        return redirect("/scratch/mutilation/list")

    has_is_mutilated = _has_column("memo_items", "is_mutilated")

    with db_conn() as conn:
        memo = fetch_one(conn, "SELECT * FROM memos WHERE id = :id", {"id": memo_id})
        if not memo:
            flash_set("error", "Memo not found.")
            return redirect("/scratch/mutilation/list")

        status = str(memo.get("status") or "UPLOADED")
        is_readonly = status == "VERIFIED"

        items = fetch_all(
            conn,
            "SELECT * FROM memo_items WHERE memo_id = :memo_id ORDER BY sr ASC, id ASC",
            {"memo_id": memo_id},
        )

    total = len(items)
    done = 0
    if has_is_mutilated:
        for r in items:
            if int(r.get("is_mutilated") or 0) == 1:
                done += 1

    return render_template(
        "mutilation/verify.html",
        pageTitle="Mutilation - SYMS",
        memoId=memo_id,
        memo=memo,
        status=status,
        isReadonly=is_readonly,
        hasIsMutilated=has_is_mutilated,
        items=items,
        total=total,
        done=done,
    )


@bp.post("/scratch/mutilation/verify_process")
@login_required
@csrf_protect
def mutilation_verify_process() -> object:
    require_operational_role()
    try:
        memo_id = int(request.form.get("memo_id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        flash_set("error", "Invalid memo.")
        return redirect("/scratch/mutilation/list")

    status_type = _status_type()
    missing: list[str] = []
    if not _has_column("memo_items", "is_mutilated"):
        missing.append("memo_items.is_mutilated")
    if not _has_column("memo_items", "mutilated_at"):
        missing.append("memo_items.mutilated_at")
    if not _has_column("memo_items", "mutilated_by"):
        missing.append("memo_items.mutilated_by")
    if not _has_column("memos", "mutilation_completed_at"):
        missing.append("memos.mutilation_completed_at")
    if not _has_column("memos", "mutilation_completed_by"):
        missing.append("memos.mutilation_completed_by")
    if status_type and "MUTILATION_COMPLETED" not in status_type.upper():
        missing.append("memos.status (enum missing MUTILATION_COMPLETED)")

    if missing:
        flash_set(
            "error",
            "Database migration is pending (missing: " + ", ".join(missing) + ").",
        )
        return redirect(f"/scratch/mutilation/verify?id={memo_id}")

    user_id = int(session.get("user_id") or 0)
    bulk = str(request.form.get("bulk") or "") == "1"
    is_complete = False

    with db_conn() as conn:
        redirect_to = f"/scratch/mutilation/verify?id={memo_id}"
        status = "UPLOADED"
        try:
            with conn.begin():
                memo = fetch_one(conn, "SELECT id, status FROM memos WHERE id = :id", {"id": memo_id})
                if not memo:
                    redirect_to = "/scratch/mutilation/list"
                    raise RuntimeError("Memo not found.")

                status = str(memo.get("status") or "UPLOADED")
                if status == "VERIFIED":
                    raise RuntimeError("This memo is already verified.")

                row = fetch_one(conn, "SELECT COUNT(*) AS cnt FROM memo_items WHERE memo_id = :memo_id", {"memo_id": memo_id}) or {}
                total = int(row.get("cnt") or 0)
                if total == 0:
                    raise RuntimeError("No line items found for this memo.")

                if bulk:
                    execute(
                        conn,
                        "UPDATE memo_items SET is_mutilated = 1, mutilated_at = NOW(), mutilated_by = :user_id WHERE memo_id = :memo_id",
                        {"user_id": user_id, "memo_id": memo_id},
                    )
                else:
                    execute(
                        conn,
                        "UPDATE memo_items SET is_mutilated = 0, mutilated_at = NULL, mutilated_by = NULL WHERE memo_id = :memo_id",
                        {"memo_id": memo_id},
                    )
                    raw_ids = request.form.getlist("mutilated_ids[]")
                    ids = []
                    seen = set()
                    for v in raw_ids:
                        try:
                            i = int(v)
                        except Exception:
                            continue
                        if i > 0 and i not in seen:
                            seen.add(i)
                            ids.append(i)

                    if ids:
                        ph = ",".join([f":id{i}" for i in range(len(ids))])
                        params: dict[str, object] = {"user_id": user_id, "memo_id": memo_id}
                        for i, val in enumerate(ids):
                            params[f"id{i}"] = val
                        execute(
                            conn,
                            "UPDATE memo_items\n"
                            "SET is_mutilated = 1, mutilated_at = NOW(), mutilated_by = :user_id\n"
                            f"WHERE memo_id = :memo_id AND id IN ({ph})",
                            params,
                        )

                row = fetch_one(
                    conn,
                    "SELECT COUNT(*) AS cnt FROM memo_items WHERE memo_id = :memo_id AND is_mutilated = 1",
                    {"memo_id": memo_id},
                ) or {}
                done = int(row.get("cnt") or 0)

                is_complete = done > 0 and done == total
                if is_complete:
                    execute(
                        conn,
                        "UPDATE memos SET status = 'MUTILATION_COMPLETED', mutilation_completed_at = NOW(), mutilation_completed_by = :user_id WHERE id = :memo_id",
                        {"user_id": user_id, "memo_id": memo_id},
                    )
                elif status == "MUTILATION_COMPLETED":
                    execute(
                        conn,
                        "UPDATE memos SET status = 'UPLOADED', mutilation_completed_at = NULL, mutilation_completed_by = NULL WHERE id = :memo_id",
                        {"memo_id": memo_id},
                    )
        except Exception as e:
            flash_set("error", str(e) or "Could not save.")
            return redirect(redirect_to)

    if is_complete:
        flash_set("success", "Mutilation completed. Proceed to segregation.")
        return redirect(f"/scratch/segregation/add?memo_id={memo_id}")

    flash_set("success", "Saved.")
    return redirect(f"/scratch/mutilation/verify?id={memo_id}")
