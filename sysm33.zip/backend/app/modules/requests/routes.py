from __future__ import annotations

from datetime import date

from flask import Blueprint, redirect, render_template, request

from app.db.engine import db_conn
from app.db.query import execute, fetch_one
from app.db.scrap_schema import ensure_scrap_tables
from app.email.scrap_notifications import load_scrap_email_settings, send_new_request_email
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.flash import flash_set

bp = Blueprint("requests", __name__)

def _is_past_date(d: date) -> bool:
    return d < date.today()


def _parse_location(location: str, location_other: str) -> tuple[str, str]:
    loc = str(location or "").strip()
    other = str(location_other or "").strip()
    if loc in {"Other", "Other (Specify)"}:
        return loc, other
    return loc, ""


def _parse_scrap_type(scrap_types: list[str], scrap_type_other: str) -> tuple[str, str]:
    other = str(scrap_type_other or "").strip()
    cleaned = [str(s or "").strip() for s in (scrap_types or []) if str(s or "").strip() != ""]
    st = ", ".join(cleaned)
    return st, other


def _insert_scrap_request(conn, *, source: str, payload: dict[str, object]) -> dict[str, object]:
    ensure_scrap_tables(conn)
    execute(
        conn,
        "INSERT INTO scrap_requests (\n"
        "  source, req_date, ticket_no, designation, email, contact_no, department,\n"
        "  location, location_other, shift, weight, scrap_type, scrap_type_other, vehicle_type,\n"
        "  status, created_at\n"
        ")\n"
        "VALUES (\n"
        "  :source, :req_date, :ticket_no, :designation, :email, :contact_no, :department,\n"
        "  :location, :location_other, :shift, :weight, :scrap_type, :scrap_type_other, :vehicle_type,\n"
        "  'PENDING', NOW()\n"
        ")",
        {
            "source": source,
            "req_date": payload.get("req_date"),
            "ticket_no": payload.get("ticket_no"),
            "designation": payload.get("designation"),
            "email": payload.get("email"),
            "contact_no": payload.get("contact_no"),
            "department": payload.get("department"),
            "location": payload.get("location"),
            "location_other": payload.get("location_other") or None,
            "shift": payload.get("shift"),
            "weight": payload.get("weight"),
            "scrap_type": payload.get("scrap_type"),
            "scrap_type_other": payload.get("scrap_type_other") or None,
            "vehicle_type": payload.get("vehicle_type"),
        },
    )
    row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
    rid = int(row.get("id") or 0)
    return fetch_one(conn, "SELECT * FROM scrap_requests WHERE id = :id LIMIT 1", {"id": rid}) or {}


@bp.route("/scratch/requests", methods=["GET", "POST"])
@login_required
@csrf_protect
def requests_index() -> object:
    if request.method == "POST":
        req_date_raw = str(request.form.get("req_date") or "").strip()
        ticket_no = str(request.form.get("ticket_no") or "").strip()
        designation = str(request.form.get("designation") or "").strip()
        email = str(request.form.get("email") or "").strip()
        contact_no = str(request.form.get("contact_no") or "").strip()
        department = str(request.form.get("department") or "").strip()

        location, location_other = _parse_location(
            str(request.form.get("location") or ""),
            str(request.form.get("location_other") or ""),
        )

        shift = str(request.form.get("shift") or "").strip()
        weight_raw = str(request.form.get("weight") or "").strip()
        scrap_types = request.form.getlist("scrap_type[]")
        scrap_type_str, scrap_type_other = _parse_scrap_type(scrap_types, request.form.get("scrap_type_other"))

        vehicle_type = str(request.form.get("vehicle_type") or "").strip()

        errors: list[str] = []
        if not req_date_raw:
            errors.append("Request Date is required.")
        if not ticket_no:
            errors.append("Ticket No is required.")
        if not designation:
            errors.append("Designation is required.")
        if not email:
            errors.append("Email is required.")
        if not contact_no:
            errors.append("Contact No is required.")
        if not department:
            errors.append("Department is required.")
        if not location:
            errors.append("Location is required.")
        if not shift:
            errors.append("Shift is required.")
        if not weight_raw:
            errors.append("Weight is required.")
        if not scrap_types:
            errors.append("At least one scrap type is required.")
        if not vehicle_type:
            errors.append("Vehicle type is required.")

        if errors:
            flash_set("error", " ".join(errors))
        else:
            try:
                req_date = date.fromisoformat(req_date_raw)
                if _is_past_date(req_date):
                    flash_set("error", "Request Date cannot be in the past.")
                    return redirect("/scratch/requests")
                weight = float(weight_raw) if weight_raw != "" else 0.0
                with db_conn() as conn:
                    with conn.begin():
                        row = _insert_scrap_request(
                            conn,
                            source="INTERNAL",
                            payload={
                                "req_date": req_date.isoformat(),
                                "ticket_no": ticket_no,
                                "designation": designation,
                                "email": email,
                                "contact_no": contact_no,
                                "department": department,
                                "location": location,
                                "location_other": location_other,
                                "shift": shift,
                                "weight": weight,
                                "scrap_type": scrap_type_str,
                                "scrap_type_other": scrap_type_other,
                                "vehicle_type": vehicle_type,
                            },
                        )
                        settings = load_scrap_email_settings(conn)
                        result = send_new_request_email(conn, request_row=row, settings=settings)
                if result.success:
                    flash_set("success", "Request submitted successfully. Email sent.")
                else:
                    flash_set("success", "Request submitted successfully.")
                return redirect("/scratch/requests")
            except Exception as e:
                flash_set("error", f"Request could not be submitted. {str(e)}")

@bp.route("/scrap-request", methods=["GET", "POST"])
@csrf_protect
def public_scrap_request() -> object:
    if request.method == "POST":
        req_date_raw = str(request.form.get("req_date") or "").strip()
        ticket_no = str(request.form.get("ticket_no") or "").strip()
        designation = str(request.form.get("designation") or "").strip()
        email = str(request.form.get("email") or "").strip()
        contact_no = str(request.form.get("contact_no") or "").strip()
        department = str(request.form.get("department") or "").strip()

        location, location_other = _parse_location(
            str(request.form.get("location") or ""),
            str(request.form.get("location_other") or ""),
        )

        shift = str(request.form.get("shift") or "").strip()
        weight_raw = str(request.form.get("weight") or "").strip()
        scrap_types = request.form.getlist("scrap_type[]")
        scrap_type_str, scrap_type_other = _parse_scrap_type(scrap_types, request.form.get("scrap_type_other"))

        vehicle_type = str(request.form.get("vehicle_type") or "").strip()

        errors: list[str] = []
        if not req_date_raw:
            errors.append("Request Date is required.")
        if not ticket_no:
            errors.append("Ticket No is required.")
        if not designation:
            errors.append("Designation is required.")
        if not email:
            errors.append("Email is required.")
        if not contact_no:
            errors.append("Contact No is required.")
        if not department:
            errors.append("Department is required.")
        if not location:
            errors.append("Location is required.")
        if not shift:
            errors.append("Shift is required.")
        if not weight_raw:
            errors.append("Weight is required.")
        if not scrap_types:
            errors.append("At least one scrap type is required.")
        if not vehicle_type:
            errors.append("Vehicle type is required.")

        if errors:
            flash_set("error", " ".join(errors))
        else:
            try:
                req_date = date.fromisoformat(req_date_raw)
                if _is_past_date(req_date):
                    flash_set("error", "Request Date cannot be in the past.")
                    return redirect("/scrap-request")
                weight = float(weight_raw) if weight_raw != "" else 0.0
                with db_conn() as conn:
                    with conn.begin():
                        row = _insert_scrap_request(
                            conn,
                            source="PUBLIC",
                            payload={
                                "req_date": req_date.isoformat(),
                                "ticket_no": ticket_no,
                                "designation": designation,
                                "email": email,
                                "contact_no": contact_no,
                                "department": department,
                                "location": location,
                                "location_other": location_other,
                                "shift": shift,
                                "weight": weight,
                                "scrap_type": scrap_type_str,
                                "scrap_type_other": scrap_type_other,
                                "vehicle_type": vehicle_type,
                            },
                        )
                        settings = load_scrap_email_settings(conn)
                        result = send_new_request_email(conn, request_row=row, settings=settings)
                if result.success:
                    flash_set("success", "Request submitted successfully. Email sent.")
                else:
                    flash_set("success", "Request submitted successfully.")
                return redirect("/scrap-request")
            except Exception as e:
                flash_set("error", f"Request could not be submitted. {str(e)}")

    return render_template("requests/public.html", pageTitle="Scrap Lifting Request")
