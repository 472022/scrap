from __future__ import annotations

from flask import Blueprint, redirect, render_template, request

from app.db.engine import db_conn
from app.security.csrf import csrf_protect
from app.security.scrap_admin_auth import scrap_admin_login_required
from app.utils.app_settings import app_setting_get, app_setting_set
from app.utils.flash import flash_set

bp = Blueprint("scrap_admin_settings", __name__)


@bp.get("/scrap-admin/settings")
@scrap_admin_login_required
def scrap_admin_settings_page() -> object:
    with db_conn() as conn:
        data = {
            "scrap_admin_notify_to": app_setting_get(conn, "scrap_admin_notify_to", ""),
            "scrap_outlook_sender": app_setting_get(conn, "scrap_outlook_sender", ""),
            "scrap_email_cc": app_setting_get(conn, "scrap_email_cc", ""),
        }
    return render_template("scrap_admin/settings.html", pageTitle="Scrap Admin Settings - SYMS", data=data)


@bp.post("/scrap-admin/settings")
@scrap_admin_login_required
@csrf_protect
def scrap_admin_settings_save() -> object:
    notify_to = str(request.form.get("scrap_admin_notify_to") or "").strip()
    outlook_sender = str(request.form.get("scrap_outlook_sender") or "").strip()
    cc = str(request.form.get("scrap_email_cc") or "").strip()

    with db_conn() as conn:
        with conn.begin():
            app_setting_set(conn, "scrap_admin_notify_to", notify_to)
            app_setting_set(conn, "scrap_outlook_sender", outlook_sender)
            app_setting_set(conn, "scrap_email_cc", cc)

    flash_set("success", "Settings saved.")
    return redirect("/scrap-admin/settings")

