from __future__ import annotations

import json
import secrets

from flask import Blueprint, Response, request, session, stream_with_context
from openai import OpenAI

from app.config import load_settings
from app.modules.chatbot.context import build_system_prompt
from app.security.auth import login_required
from app.utils.rbac import current_user_role

bp = Blueprint("chatbot", __name__)


def _validate_csrf(data: dict) -> bool:
    token = str(data.get("csrf_token") or "")
    session_token = str(session.get("csrf_token") or "")
    if not token or not session_token:
        return False
    return secrets.compare_digest(session_token, token)


def _stream_response(messages: list[dict], api_key: str):
    client = OpenAI(
        base_url="https://integrate.api.nvidia.com/v1",
        api_key=api_key,
    )
    try:
        completion = client.chat.completions.create(
            model="z-ai/glm4.7",
            messages=messages,
            temperature=0.7,
            top_p=1,
            max_tokens=4096,
            extra_body={"chat_template_kwargs": {"enable_thinking": False}},
            stream=True,
        )
        for chunk in completion:
            if not getattr(chunk, "choices", None):
                continue
            if not chunk.choices:
                continue
            delta = chunk.choices[0].delta
            content = getattr(delta, "content", None)
            if content:
                yield f"data: {json.dumps(content)}\n\n"
    except Exception as exc:
        yield f"data: {json.dumps(f'Error: {exc}')}\n\n"
    yield "data: [DONE]\n\n"


@bp.post("/scratch/chatbot/ask")
@login_required
def ask() -> Response:
    data = request.get_json(silent=True) or {}

    if not _validate_csrf(data):
        return Response("Invalid CSRF token", status=419, mimetype="text/plain")

    message = (data.get("message") or "").strip()
    if not message:
        return Response("data: [DONE]\n\n", content_type="text/event-stream")

    history: list[dict] = (data.get("history") or [])[-10:]

    system_prompt = build_system_prompt(current_user_role())
    messages = [{"role": "system", "content": system_prompt}] + history + [{"role": "user", "content": message}]

    api_key = load_settings().nvidia_api_key
    if not api_key:
        return Response(
            "data: " + json.dumps("Chatbot is not configured (missing API key).") + "\n\ndata: [DONE]\n\n",
            status=503,
            content_type="text/event-stream",
        )

    return Response(
        stream_with_context(_stream_response(messages, api_key)),
        content_type="text/event-stream",
        headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
    )
