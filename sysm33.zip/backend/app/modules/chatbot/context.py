from __future__ import annotations

import re

from app.db.engine import db_conn
from app.db.query import fetch_all, fetch_one
from app.utils.expiry import expiry_alert_summary


# ── static summary context (cheap, runs on every request) ──────────────────

def get_live_context() -> dict:
    try:
        with db_conn() as conn:
            inv = fetch_one(
                conn,
                "SELECT COUNT(*) AS cnt FROM inventory_balances_v2 WHERE balance_weight > 0",
            )
            pending_memos = fetch_one(
                conn,
                "SELECT COUNT(*) AS cnt FROM memos WHERE status = 'UPLOADED'",
            )
            categories = fetch_all(
                conn,
                "SELECT name FROM material_categories WHERE is_active = 1 ORDER BY name",
            )
            memos_30d = fetch_one(
                conn,
                "SELECT COUNT(*) AS cnt FROM memos WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            )
            outward_30d = fetch_one(
                conn,
                "SELECT COUNT(*) AS cnt FROM outward_entries WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)",
            )
            total_materials = fetch_one(
                conn,
                "SELECT COUNT(*) AS cnt FROM materials WHERE is_active = 1",
            )
        expiry = expiry_alert_summary()
        return {
            "materials_in_stock": int((inv or {}).get("cnt") or 0),
            "total_materials": int((total_materials or {}).get("cnt") or 0),
            "pending_memos": int((pending_memos or {}).get("cnt") or 0),
            "expired_lots": int(expiry.get("expired_lots") or 0),
            "near_expiry_lots": int(expiry.get("near_lots") or 0),
            "categories": [c["name"] for c in categories],
            "memos_last_30_days": int((memos_30d or {}).get("cnt") or 0),
            "outward_last_30_days": int((outward_30d or {}).get("cnt") or 0),
        }
    except Exception:
        return {}


# ── dynamic context: query DB based on what the user is asking ─────────────

def get_dynamic_context(message: str) -> str:
    """
    Detect intent from the user's message and fetch relevant DB records.
    Returns a formatted string to inject into the conversation as context.
    """
    msg_lower = message.lower()
    # Extract uppercase tokens that could be part numbers / memo numbers
    tokens = list(dict.fromkeys(re.findall(r'\b[A-Z0-9]{2,}\b', message.upper())))

    sections: list[str] = []

    try:
        with db_conn() as conn:

            # ── 1. Specific material / part number lookup ──────────────────
            found_material_ids: list[int] = []
            for token in tokens[:5]:
                mat = fetch_one(
                    conn,
                    """
                    SELECT m.id, m.part_no_raw, m.part_no_norm, m.product_description,
                           c.name AS category, u.code AS uom, m.is_active
                    FROM materials m
                    LEFT JOIN material_categories c ON c.id = m.category_id
                    LEFT JOIN uoms u ON u.id = m.uom_id
                    WHERE UPPER(m.part_no_norm) = :t OR UPPER(m.part_no_raw) = :t
                    """,
                    {"t": token},
                )
                if not mat:
                    continue

                found_material_ids.append(int(mat["id"]))
                lines = [
                    f"Material '{token}':",
                    f"  Description : {mat['product_description']}",
                    f"  Category    : {mat.get('category') or 'N/A'}",
                    f"  UOM         : {mat.get('uom') or 'N/A'}",
                    f"  Active      : {'Yes' if mat['is_active'] else 'No'}",
                ]

                # Latest active rate
                rate = fetch_one(
                    conn,
                    """
                    SELECT rate_per_weight, effective_at FROM material_rates
                    WHERE material_id = :mid AND is_active = 1
                    ORDER BY effective_at DESC LIMIT 1
                    """,
                    {"mid": mat["id"]},
                )
                if rate:
                    lines.append(
                        f"  Rate        : {rate['rate_per_weight']} per {mat.get('uom') or 'unit'}"
                        f" (effective {rate['effective_at']})"
                    )
                else:
                    lines.append("  Rate        : No rate configured")

                # Current stock balance
                stock = fetch_one(
                    conn,
                    "SELECT balance_weight, uom_code FROM inventory_balances_v2 WHERE material_id = :mid",
                    {"mid": mat["id"]},
                )
                if stock:
                    lines.append(
                        f"  Stock       : {stock['balance_weight']} {stock.get('uom_code') or ''}"
                    )
                else:
                    lines.append("  Stock       : 0")

                # Active lots with expiry
                lots = fetch_all(
                    conn,
                    """
                    SELECT l.lot_number, l.expiry_date, l.status,
                           COALESCE(ilb.balance_weight, 0) AS balance_weight,
                           ea.alert_state
                    FROM material_lots l
                    LEFT JOIN inventory_lot_balances_v2 ilb ON ilb.lot_id = l.id
                    LEFT JOIN expiry_alerts_vw ea ON ea.lot_id = l.id
                    WHERE l.material_id = :mid AND COALESCE(ilb.balance_weight, 0) > 0
                    ORDER BY l.expiry_date ASC
                    LIMIT 8
                    """,
                    {"mid": mat["id"]},
                )
                if lots:
                    lines.append("  Active lots :")
                    for lot in lots:
                        alert = f" [{lot['alert_state']}]" if lot.get("alert_state") and lot["alert_state"] != "OK" else ""
                        lines.append(
                            f"    • {lot['lot_number']}: {lot['balance_weight']} {mat.get('uom') or ''}"
                            f", expires {lot['expiry_date']}{alert}"
                        )

                sections.append("\n".join(lines))

            # ── 2. All-rates query ─────────────────────────────────────────
            wants_rates = any(w in msg_lower for w in ("rate", "price", "pricing", "cost per", "worth"))
            if wants_rates and not found_material_ids:
                rows = fetch_all(
                    conn,
                    """
                    SELECT m.part_no_raw, m.product_description, u.code AS uom,
                           mr.rate_per_weight, mr.effective_at
                    FROM material_rates mr
                    JOIN materials m ON m.id = mr.material_id
                    LEFT JOIN uoms u ON u.id = m.uom_id
                    WHERE mr.is_active = 1
                      AND mr.effective_at = (
                          SELECT MAX(mr2.effective_at) FROM material_rates mr2
                          WHERE mr2.material_id = mr.material_id AND mr2.is_active = 1
                      )
                    ORDER BY m.part_no_raw ASC
                    LIMIT 50
                    """,
                )
                if rows:
                    lines = ["Current material rates:"]
                    for r in rows:
                        lines.append(
                            f"  {r['part_no_raw']} ({r['product_description']}): "
                            f"{r['rate_per_weight']} per {r['uom'] or 'unit'} [eff. {r['effective_at']}]"
                        )
                    sections.append("\n".join(lines))
                else:
                    sections.append("No material rates are configured yet.")

            # ── 3. Inventory / stock query ─────────────────────────────────
            wants_inv = any(w in msg_lower for w in ("stock", "inventory", "balance", "available", "how much"))
            if wants_inv and not found_material_ids:
                rows = fetch_all(
                    conn,
                    """
                    SELECT part_no_norm, product_description, uom_code, balance_weight
                    FROM inventory_balances_v2
                    WHERE balance_weight > 0
                    ORDER BY product_description ASC
                    LIMIT 50
                    """,
                )
                if rows:
                    lines = ["Current inventory (materials with stock > 0):"]
                    for r in rows:
                        lines.append(
                            f"  {r['part_no_norm']} — {r['product_description']}: "
                            f"{r['balance_weight']} {r['uom_code']}"
                        )
                    sections.append("\n".join(lines))
                else:
                    sections.append("No materials currently in stock.")

            # ── 4. Expiry / lot query ──────────────────────────────────────
            wants_expiry = any(w in msg_lower for w in ("expir", "near expiry", "expired", "lot"))
            if wants_expiry:
                rows = fetch_all(
                    conn,
                    """
                    SELECT lot_number, part_no_norm, product_description, uom_code,
                           balance_weight, expiry_date, days_to_expiry, alert_state
                    FROM expiry_alerts_vw
                    WHERE alert_state IN ('EXPIRED','NEAR_EXPIRY') AND balance_weight > 0
                    ORDER BY alert_state DESC, expiry_date ASC
                    LIMIT 30
                    """,
                )
                if rows:
                    lines = ["Expiry alerts:"]
                    for r in rows:
                        lines.append(
                            f"  [{r['alert_state']}] {r['part_no_norm']} — {r['product_description']}"
                            f", Lot {r['lot_number']}: {r['balance_weight']} {r['uom_code']}"
                            f", expires {r['expiry_date']} ({r['days_to_expiry']} days)"
                        )
                    sections.append("\n".join(lines))
                else:
                    sections.append("No expiry alerts at this time.")

            # ── 5. Memo query ──────────────────────────────────────────────
            wants_memo = any(w in msg_lower for w in ("memo", "inward", "delivery", "uploaded memo"))
            if wants_memo:
                rows = fetch_all(
                    conn,
                    """
                    SELECT memo_number, memo_date, status, source, created_at
                    FROM memos ORDER BY created_at DESC LIMIT 15
                    """,
                )
                if rows:
                    lines = ["Recent memos (last 15):"]
                    for r in rows:
                        lines.append(
                            f"  {r['memo_number']} | Date: {r['memo_date']} | Status: {r['status']}"
                            f" | Source: {r.get('source') or 'N/A'}"
                        )
                    sections.append("\n".join(lines))

            # ── 6. Outward / sale query ────────────────────────────────────
            wants_outward = any(w in msg_lower for w in ("outward", "sale", "sold", "dispatch", "disposal"))
            if wants_outward:
                rows = fetch_all(
                    conn,
                    """
                    SELECT o.invoice_date, o.invoice_no, m.part_no_raw,
                           m.product_description, o.weight, u.code AS uom,
                           o.rate, o.basic_value, o.amount_incl_gst,
                           COALESCE(c.name, o.vendor_name, o.recycler_name) AS counterparty
                    FROM outward_entries o
                    JOIN materials m ON m.id = o.material_id
                    LEFT JOIN uoms u ON u.id = o.uom_id
                    LEFT JOIN counterparties c ON c.id = o.counterparty_id
                    ORDER BY o.created_at DESC LIMIT 15
                    """,
                )
                if rows:
                    lines = ["Recent outward entries (last 15):"]
                    for r in rows:
                        lines.append(
                            f"  {r['invoice_date']} | {r['part_no_raw']} ({r['product_description']})"
                            f": {r['weight']} {r['uom']} @ {r['rate']} = ₹{r['basic_value']}"
                            f" | Invoice: {r.get('invoice_no') or 'N/A'} | To: {r.get('counterparty') or 'N/A'}"
                        )
                    sections.append("\n".join(lines))

            # ── 7. Vendor / customer query ─────────────────────────────────
            wants_parties = any(w in msg_lower for w in ("vendor", "customer", "counterpart", "supplier", "buyer"))
            if wants_parties:
                rows = fetch_all(
                    conn,
                    """
                    SELECT type, name, phone, email, gstin, code
                    FROM counterparties WHERE is_active = 1 ORDER BY type, name LIMIT 50
                    """,
                )
                if rows:
                    lines = ["Active counterparties:"]
                    for r in rows:
                        lines.append(
                            f"  [{r['type']}] {r['name']}"
                            + (f" (Code: {r['code']})" if r.get("code") else "")
                            + (f" | Phone: {r['phone']}" if r.get("phone") else "")
                            + (f" | GSTIN: {r['gstin']}" if r.get("gstin") else "")
                        )
                    sections.append("\n".join(lines))

            # ── 8. Users query ─────────────────────────────────────────────
            wants_users = any(w in msg_lower for w in ("user", "users", "who can", "roles", "access"))
            if wants_users:
                rows = fetch_all(
                    conn,
                    "SELECT username, role, created_at FROM users ORDER BY role, username",
                )
                if rows:
                    lines = ["System users:"]
                    for r in rows:
                        lines.append(f"  {r['username']} — Role: {r['role']} (created {r['created_at']})")
                    sections.append("\n".join(lines))

    except Exception as exc:
        sections.append(f"[DB lookup error: {exc}]")

    return "\n\n".join(sections)


# ── system prompt builder ──────────────────────────────────────────────────

def build_system_prompt(role: str) -> str:
    ctx = get_live_context()

    live_section = ""
    if ctx:
        cats = ", ".join(ctx.get("categories") or []) or "N/A"
        live_section = f"""
## Live Platform Summary (current)
- Total materials registered   : {ctx.get("total_materials", "N/A")}
- Materials currently in stock : {ctx.get("materials_in_stock", "N/A")}
- Memos awaiting verification  : {ctx.get("pending_memos", "N/A")}
- Expired lots                 : {ctx.get("expired_lots", "N/A")}
- Lots near expiry             : {ctx.get("near_expiry_lots", "N/A")}
- Memos created (last 30 days) : {ctx.get("memos_last_30_days", "N/A")}
- Outward entries (last 30 d)  : {ctx.get("outward_last_30_days", "N/A")}
- Active material categories   : {cats}
"""

    return f"""You are SYMS Assistant, an expert AI helper for the Scrap Yard Management System (SYMS) used by Tata Motors.
You have direct access to live database data which will be provided to you in each conversation turn as "LIVE DATABASE CONTEXT".
Always use the LIVE DATABASE CONTEXT to answer specific questions about rates, stock, memos, lots, or counterparties.
The current user's role is: {role}.

## What is SYMS?
SYMS tracks the complete lifecycle of scrap materials at a Tata Motors facility:
inward receipt (memo) → mutilation verification → segregation → inventory → outward dispatch (sale/disposal).

## Platform Modules
- **Dashboard** (/scratch/dashboard): Operational overview — inventory summary, expiry alerts, outward trends.
- **Material Inward / Memo** (/scratch/memo/list): Upload PDF memos from vendors, or create manually. Statuses: UPLOADED → VERIFIED → MUTILATION_COMPLETED.
- **Mutilation** (/scratch/mutilation/list): Verify physical destruction of scrap items before disposal.
- **Segregation** (/scratch/segregation/list): Assign inward material to categories and lots in inventory.
- **Inventory** (/scratch/inventory/list): Real-time stock balances per material and lot. Tracks expiry dates.
- **Outward / Disposal / Sale** (/scratch/outward/list): Record dispatch — weight, rate, invoice, counterparty.
- **Reports** (/scratch/reports): 12+ report types — inventory, outward history, valuations, expiry, trends. Excel export supported.
- **Settings** (/scratch/settings, admin only): Material categories, pricing upload, UOMs, counterparties, system rules.
- **Scrap Requests** (/scratch/requests): Employees submit pickup requests; admin accepts or reschedules.
- **SQPDCME** (/scratch/sqpdcme): Quality monitoring dashboard (Safety, Quality, Productivity, Delivery, Cost, Morale, Environment).

## User Roles
- **admin**: Full access — all modules, settings, reports, user management.
- **supervisor**: Operations — memos, mutilation, segregation, outward, inventory, most reports.
- **worker**: Basic ops — memo verification, outward, inventory view, basic reports.
- **requestor**: Scrap pickup requests only.
- **sqpdcme**: SQPDCME dashboard tabs only.

## Key Concepts
- **Material Lot**: A batch with lot number, expiry date, and weight. FIFO tracking.
- **Material Rate**: `rate_per_weight` from the `material_rates` table. Set via Excel upload in Settings → Pricing.
- **Expiry Alerts**: Lots flagged EXPIRED (past date) or NEAR_EXPIRY (within alert window). Badge shown on Reports menu.
- **Counterparties**: VENDORs (deliver material) and CUSTOMERs (buy scrap). Managed in Settings → Master Data.
- **Stock Movements**: Immutable IN/OUT records in `stock_movements_v2`. `inventory_balances_v2` view calculates real-time balances.
- **UOM**: Unit of measurement — KG, KWH, PIECE, METER, etc.
{live_section}
## Instructions
- When LIVE DATABASE CONTEXT is provided in the conversation, use it to give precise, data-driven answers.
- Mention specific values (rates, stock quantities, lot numbers, dates) from the context — do not say "I don't have access".
- If data is not in the context and you cannot derive it, say so clearly and tell the user which module to navigate to.
- Keep answers concise and structured. Use bullet points for lists.
- Never invent numbers or rates. Only report what is in the provided data.
"""
