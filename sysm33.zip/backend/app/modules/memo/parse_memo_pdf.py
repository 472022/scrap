from __future__ import annotations

import os
import re
from datetime import datetime


def _clean_cell(v: object) -> str:
    if v is None:
        return ""
    s = str(v)
    s = s.replace("\u00a0", " ")
    s = s.replace("\n", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _to_float(s: object) -> float:
    v = _clean_cell(s)
    if v == "":
        return 0.0
    v = v.replace(",", "")
    try:
        return float(v)
    except ValueError:
        return 0.0


def _parse_date(s: object) -> str:
    v = _clean_cell(s)
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(v, fmt).date().isoformat()
        except ValueError:
            pass
    return ""


def _parse_posting_datetime(s: object) -> str:
    v = _clean_cell(s)
    candidates = [
        ("%d/%m/%Y, %I:%M:%S %p", v),
        ("%d/%m/%Y %I:%M:%S %p", v),
        ("%d/%m/%Y, %H:%M:%S", v),
        ("%d/%m/%Y %H:%M:%S", v),
        ("%Y-%m-%d %H:%M:%S", v),
    ]
    for fmt, val in candidates:
        try:
            return datetime.strptime(val, fmt).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass
    return ""


def _extract_header(text: str) -> dict[str, str]:
    memo_no = ""
    memo_date = ""
    vehicle_no = ""
    location = ""

    m = re.search(r"\bMemo\s*No\s*[:\-]?\s*([A-Za-z0-9\/\-\._]+)", text, re.IGNORECASE)
    if m:
        memo_no = m.group(1).strip()

    m = re.search(r"\bDate\s*[:\-]?\s*([0-9]{2}[\/\-][0-9]{2}[\/\-][0-9]{4})", text, re.IGNORECASE)
    if m:
        memo_date = _parse_date(m.group(1))

    m = re.search(r"\bVehicle\s*No\.?\s*[:\-]?\s*([A-Za-z0-9\-]+)", text, re.IGNORECASE)
    if m:
        vehicle_no = m.group(1).strip()

    m = re.search(r"\bLocation\s*[:\-]?\s*([A-Za-z0-9\-]+)", text, re.IGNORECASE)
    if m:
        location = m.group(1).strip()

    return {
        "memo_number": memo_no,
        "memo_date": memo_date,
        "vehicle_number": vehicle_no,
        "source": location,
    }


def _normalize_header_row(row: list[object]) -> list[str]:
    return [_clean_cell(c).lower() for c in row]


def _is_target_table(header_row: list[object]) -> bool:
    h = " ".join(_normalize_header_row(header_row))
    needed = ["part", "qty", "unit", "scrap", "material", "cg", "posting", "movt", "reason"]
    return all(k in h for k in needed)


def _row_to_item(row: list[object]) -> dict[str, object]:
    cells = [_clean_cell(c) for c in row]
    while len(cells) < 14:
        cells.append("")
    return {
        "sr": int(cells[0]) if cells[0].isdigit() else None,
        "part_no": cells[1],
        "part_desc": cells[2],
        "qty": _to_float(cells[3]),
        "unit": cells[4],
        "scrap_value": _to_float(cells[5]),
        "material_doc_no": cells[6],
        "cg_no": cells[7],
        "item_no": cells[8],
        "posting_datetime": _parse_posting_datetime(cells[9]),
        "user_name": cells[10],
        "sloc": cells[11],
        "movt_type": cells[12],
        "reason_for_scrap": cells[13],
    }


def parse_pdf(pdf_path: str) -> dict[str, object]:
    try:
        import pdfplumber  # type: ignore
    except Exception as e:
        raise RuntimeError("pdfplumber not installed") from e

    if not os.path.isfile(pdf_path):
        raise RuntimeError("file not found")

    header: dict[str, str] = {"memo_number": "", "memo_date": "", "source": "", "vehicle_number": ""}
    items: list[dict[str, object]] = []

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            if header["memo_number"] == "" or header["memo_date"] == "" or header["vehicle_number"] == "" or header["source"] == "":
                h = _extract_header(text)
                for k in header:
                    if header[k] == "" and h.get(k):
                        header[k] = str(h[k])

            settings_lines = {
                "vertical_strategy": "lines",
                "horizontal_strategy": "lines",
                "intersection_tolerance": 6,
                "snap_tolerance": 4,
                "join_tolerance": 4,
                "edge_min_length": 10,
                "min_words_vertical": 1,
                "min_words_horizontal": 1,
            }

            tables = page.extract_tables(table_settings=settings_lines) or []
            for table in tables:
                if not table or len(table) < 2:
                    continue
                header_row = table[0]
                if not isinstance(header_row, list) or not _is_target_table(header_row):
                    continue
                for row in table[1:]:
                    if not row or not isinstance(row, list):
                        continue
                    item = _row_to_item(row)
                    if _clean_cell(item.get("part_no")) == "" and _clean_cell(item.get("part_desc")) == "":
                        continue
                    items.append(item)

    if len(items) == 0:
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                settings_text = {
                    "vertical_strategy": "text",
                    "horizontal_strategy": "text",
                    "snap_tolerance": 4,
                    "join_tolerance": 4,
                    "intersection_tolerance": 6,
                    "min_words_vertical": 2,
                    "min_words_horizontal": 1,
                }
                tables = page.extract_tables(table_settings=settings_text) or []
                for table in tables:
                    if not table or len(table) < 2:
                        continue
                    header_row = table[0]
                    if not isinstance(header_row, list) or not _is_target_table(header_row):
                        continue
                    for row in table[1:]:
                        if not row or not isinstance(row, list):
                            continue
                        item = _row_to_item(row)
                        if _clean_cell(item.get("part_no")) == "" and _clean_cell(item.get("part_desc")) == "":
                            continue
                        items.append(item)

        if len(items) == 0:
            if os.getenv("SYMS_ENABLE_OCR") == "1":
                try:
                    import pytesseract  # type: ignore
                    from pdf2image import convert_from_path  # type: ignore
                except Exception as e:
                    raise RuntimeError("no table rows found (OCR dependencies missing)") from e

                ocr_text = ""
                images = convert_from_path(pdf_path, dpi=300)
                for img in images:
                    ocr_text += "\n" + (pytesseract.image_to_string(img) or "")

                h = _extract_header(ocr_text)
                for k in header:
                    if header[k] == "" and h.get(k):
                        header[k] = str(h[k])

                raise RuntimeError("no table rows found (OCR extracted text but table parsing still failed)")
            raise RuntimeError("no table rows found")

    if header["memo_date"] == "":
        header["memo_date"] = datetime.now().date().isoformat()

    return {"header": header, "items": items}

