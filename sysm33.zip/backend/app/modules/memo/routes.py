from __future__ import annotations

import secrets
from datetime import date
from pathlib import Path

from flask import Blueprint, Response, abort, jsonify, redirect, render_template, request, send_file, session

from app.config import load_settings
from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.db.memo_schema import ensure_memo_columns
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.domain import stock_v2_add_movement
from app.utils.flash import flash_set
from app.utils.rbac import require_operational_role

from .pdf_parser import parse_memo_pdf

bp = Blueprint("memo", __name__)


def _backend_dir() -> Path:
    return Path(__file__).resolve().parents[3]


def _uploads_memos_dir() -> Path:
    settings = load_settings()
    base = Path(settings.upload_dir)
    if not base.is_absolute():
        base = (_backend_dir() / base).resolve()
    return (base / "memos").resolve()


def _normalize_part_no(value: str) -> str:
    v = (value or "").strip().upper()
    out: list[str] = []
    for ch in v:
        if ch.isalnum():
            out.append(ch)
    return "".join(out)


def _generate_manual_memo_number() -> str:
    d = date.today().strftime("%Y%m%d")
    suf = secrets.token_hex(3).upper()
    return f"MANUAL-{d}-{suf}"[:50]


def _uom_upsert_and_get_id(conn, code: str) -> int | None:
    c = (code or "").strip().upper()[:20]
    if c == "":
        c = "KG"
    execute(
        conn,
        "INSERT INTO uoms (code, name, is_active, created_at, updated_at)\n"
        "VALUES (:code, :name, 1, NOW(), NOW())\n"
        "ON DUPLICATE KEY UPDATE name = VALUES(name), is_active = 1, updated_at = NOW()",
        {"code": c, "name": c},
    )
    row = fetch_one(conn, "SELECT id FROM uoms WHERE code = :code LIMIT 1", {"code": c}) or {}
    uom_id = int(row.get("id") or 0)
    return uom_id if uom_id > 0 else None


def _material_upsert_and_get(conn, *, part_no_raw: str, part_desc: str, uom_id: int | None) -> dict[str, object] | None:
    raw = (part_no_raw or "").strip()[:100]
    norm = _normalize_part_no(raw)
    if norm == "":
        return None
    desc = (part_desc or "").strip()
    if desc == "":
        desc = raw
    desc = desc[:255]

    execute(
        conn,
        "INSERT INTO materials (part_no_raw, part_no_norm, product_description, category_id, uom_id, is_active, updated_at)\n"
        "VALUES (:raw, :norm, :desc, NULL, :uom_id, 1, NOW())\n"
        "ON DUPLICATE KEY UPDATE product_description = VALUES(product_description), uom_id = COALESCE(VALUES(uom_id), uom_id), is_active = 1, updated_at = NOW()",
        {"raw": raw, "norm": norm, "desc": desc, "uom_id": int(uom_id) if uom_id and int(uom_id) > 0 else None},
    )
    m = fetch_one(
        conn,
        "SELECT id, part_no_raw, part_no_norm, product_description, category_id, uom_id\n"
        "FROM materials WHERE part_no_norm = :n LIMIT 1",
        {"n": norm},
    )
    return m if m else None


def _post_memo_direct_to_inventory(conn, *, memo_id: int, items: list[dict[str, object]], user_id: int) -> None:
    if memo_id <= 0:
        return

    for it in items:
        part_no = str(it.get("part_no") or "").strip()
        part_desc = str(it.get("part_desc") or "").strip()
        unit = str(it.get("unit") or "").strip()
        try:
            qty = float(it.get("qty") or 0)
        except Exception:
            qty = 0.0

        if part_no == "" or qty <= 0:
            continue

        uom_id = _uom_upsert_and_get_id(conn, unit)
        m = _material_upsert_and_get(conn, part_no_raw=part_no, part_desc=part_desc, uom_id=uom_id)
        if not m:
            continue

        material_id = int(m.get("id") or 0)
        if material_id <= 0:
            continue

        category_id = int(m.get("category_id") or 0)
        final_uom_id = int(m.get("uom_id") or 0) or (int(uom_id) if uom_id else 0)
        material_type = str(m.get("product_description") or "")[:50]
        part_number = str(m.get("part_no_raw") or "")[:50]
        part_description = str(m.get("product_description") or "")

        execute(
            conn,
            "INSERT INTO inward_entries (memo_id, material_id, lot_id, uom_id, material_type, part_number, part_description, quantity, weight)\n"
            "VALUES (:memo_id, :material_id, NULL, :uom_id, :material_type, :part_number, :part_description, :quantity, :weight)",
            {
                "memo_id": memo_id,
                "material_id": material_id,
                "uom_id": final_uom_id if final_uom_id > 0 else None,
                "material_type": material_type if material_type else part_number,
                "part_number": part_number,
                "part_description": part_description,
                "quantity": int(qty),
                "weight": float(qty),
            },
        )
        row = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
        inward_id = int(row.get("id") or 0)
        if inward_id > 0:
            stock_v2_add_movement(
                "INWARD",
                inward_id,
                material_id,
                float(qty),
                "IN",
                "",
                None,
                category_id if category_id > 0 else None,
                None,
                final_uom_id if final_uom_id > 0 else None,
                conn=conn,
            )

    execute(
        conn,
        "UPDATE memo_items SET is_mutilated = 1, mutilated_at = NOW(), mutilated_by = :uid WHERE memo_id = :id",
        {"uid": user_id if user_id > 0 else None, "id": memo_id},
    )
    execute(
        conn,
        "UPDATE memos SET status = 'VERIFIED', verified_by = :uid, verified_at = NOW() WHERE id = :id",
        {"uid": user_id if user_id > 0 else None, "id": memo_id},
    )


def _safe_memo_path(file_path: str) -> Path | None:
    base = _uploads_memos_dir()
    try:
        base.mkdir(parents=True, exist_ok=True)
    except Exception:
        return None
    rel = (file_path or "").replace("\\", "/")
    if not rel.startswith("uploads/memos/"):
        return None
    static_dir = base.parent.parent
    full = (static_dir / rel).resolve()
    # Strict containment check: full path must be inside base directory
    try:
        full.relative_to(base)
    except ValueError:
        return None
    return full


@bp.get("/scratch/memo/list")
@login_required
def memo_list() -> object:
    with db_conn() as conn:
        ensure_memo_columns(conn)
        memos = fetch_all(
            conn,
            "SELECT id, memo_number, memo_date, source, vehicle_number, file_path, original_filename, created_via, upload_mode, non_auto_mutilated,\n"
            "       status, mismatch_count, created_at\n"
            "FROM memos\n"
            "ORDER BY created_at DESC",
        )
    return render_template("memo/list.html", pageTitle="Material (Inward) - SYMS", memos=memos)


@bp.get("/scratch/memo/upload")
@login_required
def memo_upload() -> object:
    return render_template("memo/upload.html", pageTitle="Upload Memo - SYMS")


@bp.get("/scratch/memo/api/material_lookup")
@login_required
def api_material_lookup() -> object:
    part_no = str(request.args.get("part_no") or "").strip()
    norm = _normalize_part_no(part_no)
    if norm == "":
        return jsonify({"found": False})

    with db_conn() as conn:
        row = fetch_one(
            conn,
            "SELECT m.product_description, u.code AS uom_code\n"
            "FROM materials m\n"
            "LEFT JOIN uoms u ON u.id = m.uom_id\n"
            "WHERE m.part_no_norm = :n\n"
            "LIMIT 1",
            {"n": norm},
        ) or {}

    desc = str(row.get("product_description") or "").strip()
    uom_code = str(row.get("uom_code") or "").strip()
    if desc == "" and uom_code == "":
        return jsonify({"found": False})
    return jsonify({"found": True, "description": desc, "uom_code": uom_code})


@bp.get("/scratch/memo/manual")
@login_required
def memo_manual() -> object:
    with db_conn() as conn:
        uoms = fetch_all(conn, "SELECT code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")
    return render_template(
        "memo/manual_upload.html",
        pageTitle="Manual Memo - SYMS",
        today=date.today().isoformat(),
        uoms=uoms,
        memoNumber=_generate_manual_memo_number(),
    )


@bp.post("/scratch/memo/manual_process")
@login_required
@csrf_protect
def memo_manual_process() -> object:
    require_operational_role()
    memo_number = _generate_manual_memo_number()
    memo_date = str(request.form.get("memo_date") or "").strip()
    source = str(request.form.get("source") or "").strip()
    vehicle_number = str(request.form.get("vehicle_number") or "").strip()

    upload_mode = str(request.form.get("upload_mode") or "AUTO_PART").strip().upper()
    if upload_mode not in {"AUTO_PART", "NON_AUTO_PART"}:
        upload_mode = "AUTO_PART"
    non_auto_mutilated = 1 if str(request.form.get("non_auto_mutilated") or "0") == "1" else 0

    part_nos = request.form.getlist("part_no[]")
    part_descs = request.form.getlist("part_desc[]")
    qtys = request.form.getlist("qty[]")
    units = request.form.getlist("unit[]")

    if memo_date == "":
        flash_set("error", "Memo date is required.")
        return redirect("/scratch/memo/manual")

    items: list[dict[str, object]] = []
    for i in range(max(len(part_nos), len(part_descs), len(qtys), len(units))):
        part_no = str(part_nos[i] if i < len(part_nos) else "").strip()
        part_desc = str(part_descs[i] if i < len(part_descs) else "").strip()
        unit = str(units[i] if i < len(units) else "").strip()
        qty_s = str(qtys[i] if i < len(qtys) else "").strip()
        try:
            qty = float(qty_s) if qty_s != "" else 0.0
        except Exception:
            qty = 0.0

        if part_no == "" and part_desc == "":
            continue
        items.append({"part_no": part_no[:50], "part_desc": part_desc[:2000], "qty": qty, "unit": unit[:20]})

    if len(items) <= 0:
        flash_set("error", "At least one line item is required.")
        return redirect("/scratch/memo/manual")

    user_id = int(session.get("user_id") or 0)
    memo_id = 0
    try:
        with db_conn() as conn:
            with conn.begin():
                ensure_memo_columns(conn)
                created = False
                for _ in range(5):
                    memo_number = _generate_manual_memo_number()
                    try:
                        execute(
                            conn,
                            "INSERT INTO memos (memo_number, memo_date, source, vehicle_number, file_path, original_filename, upload_mode, non_auto_mutilated, created_via)\n"
                            "VALUES (:memo_number, :memo_date, :source, :vehicle_number, NULL, NULL, :upload_mode, :non_auto_mutilated, 'MANUAL')",
                            {
                                "memo_number": memo_number,
                                "memo_date": memo_date,
                                "source": source,
                                "vehicle_number": vehicle_number,
                                "upload_mode": upload_mode,
                                "non_auto_mutilated": non_auto_mutilated,
                            },
                        )
                        created = True
                        break
                    except Exception:
                        continue
                if not created:
                    raise RuntimeError("Could not generate memo number.")
                row2 = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                memo_id = int(row2.get("id") or 0)
                if memo_id <= 0:
                    raise RuntimeError("Could not save memo.")

                for idx, item in enumerate(items, start=1):
                    execute(
                        conn,
                        "INSERT INTO memo_items (memo_id, sr, part_no, lot_number, part_desc, qty, unit, scrap_value, material_doc_no, cg_no, item_no, posting_datetime, user_name, sloc, movt_type, reason_for_scrap)\n"
                        "VALUES (:memo_id, :sr, :part_no, :lot_number, :part_desc, :qty, :unit, 0, '', '', '', NULL, '', '', '', '')",
                        {
                            "memo_id": memo_id,
                            "sr": idx,
                            "part_no": str(item.get("part_no") or ""),
                            "lot_number": str(item.get("lot_number") or ""),
                            "part_desc": str(item.get("part_desc") or ""),
                            "qty": float(item.get("qty") or 0),
                            "unit": str(item.get("unit") or ""),
                        },
                    )

                if upload_mode == "NON_AUTO_PART" and non_auto_mutilated == 1:
                    _post_memo_direct_to_inventory(conn, memo_id=memo_id, items=items, user_id=user_id)
    except Exception as e:
        flash_set("error", str(e) or "Could not save memo.")
        return redirect("/scratch/memo/manual")

    flash_set("success", "Memo saved.")
    if upload_mode == "NON_AUTO_PART" and non_auto_mutilated == 1:
        return redirect("/scratch/inventory/list")
    return redirect(f"/scratch/mutilation/verify?id={memo_id}")


@bp.post("/scratch/memo/upload_process")
@login_required
@csrf_protect
def memo_upload_process() -> object:
    require_operational_role()
    file = request.files.get("memo_file")
    if file is None:
        flash_set("error", "File is required.")
        return redirect("/scratch/memo/upload")

    max_bytes = 10 * 1024 * 1024
    file.stream.seek(0, 2)
    size = int(file.stream.tell() or 0)
    file.stream.seek(0)
    if size > max_bytes:
        flash_set("error", "File is too large.")
        return redirect("/scratch/memo/upload")

    original_name = str(file.filename or "")
    ext = original_name.lower().rsplit(".", 1)[-1] if "." in original_name else ""
    if ext != "pdf":
        flash_set("error", "Only PDF files are allowed.")
        return redirect("/scratch/memo/upload")

    mime = str(file.mimetype or "")
    if mime not in {"application/pdf", "application/x-pdf"}:
        flash_set("error", "Invalid file type.")
        return redirect("/scratch/memo/upload")

    upload_dir = _uploads_memos_dir()
    upload_dir.mkdir(parents=True, exist_ok=True)
    random_name = f"{secrets.token_hex(16)}.pdf"
    dest_path = (upload_dir / random_name).resolve()
    file.save(dest_path)

    relative_path = f"uploads/memos/{random_name}"

    try:
        parsed = parse_memo_pdf(str(dest_path))
        header = parsed.get("header") or {}
        items = parsed.get("items") or []

        memo_number = str(header.get("memo_number") or "").strip()
        memo_date = date.today().isoformat()
        source = str(header.get("source") or "").strip()
        vehicle_number = str(header.get("vehicle_number") or "").strip()

        upload_mode = str(request.form.get("upload_mode") or "AUTO_PART").strip().upper()
        if upload_mode not in {"AUTO_PART", "NON_AUTO_PART"}:
            upload_mode = "AUTO_PART"
        non_auto_mutilated = 1 if str(request.form.get("non_auto_mutilated") or "0") == "1" else 0

        if memo_number == "":
            raise RuntimeError("Could not read memo number from the PDF.")
        if not isinstance(items, list) or len(items) == 0:
            raise RuntimeError("Could not read line items from the PDF.")

        def clip(value: str, max_len: int) -> str:
            v = (value or "").strip()
            return v[:max_len] if len(v) > max_len else v

        with db_conn() as conn:
            with conn.begin():
                ensure_memo_columns(conn)
                execute(
                    conn,
                    "INSERT INTO memos (memo_number, memo_date, source, vehicle_number, file_path, original_filename, upload_mode, non_auto_mutilated, created_via)\n"
                    "VALUES (:memo_number, :memo_date, :source, :vehicle_number, :file_path, :original_filename, :upload_mode, :non_auto_mutilated, 'PDF')",
                    {
                        "memo_number": memo_number,
                        "memo_date": memo_date,
                        "source": source,
                        "vehicle_number": vehicle_number,
                        "file_path": relative_path,
                        "original_filename": original_name,
                        "upload_mode": upload_mode,
                        "non_auto_mutilated": non_auto_mutilated,
                    },
                )
                row2 = fetch_one(conn, "SELECT LAST_INSERT_ID() AS id") or {}
                memo_id = int(row2.get("id") or 0)
                if memo_id <= 0:
                    raise RuntimeError("Could not save memo.")

                items_for_post: list[dict[str, object]] = []
                for item in items:
                    if not isinstance(item, dict):
                        continue
                    sr = item.get("sr")
                    sr_val = int(sr) if isinstance(sr, int) else (int(sr) if str(sr).isdigit() else None)
                    part_no = clip(str(item.get("part_no") or ""), 50)
                    lot_number = clip(str(item.get("lot_number") or ""), 50)
                    part_desc = clip(str(item.get("part_desc") or ""), 2000)
                    qty = float(item.get("qty") or 0)
                    unit = clip(str(item.get("unit") or ""), 20)
                    scrap_value = float(item.get("scrap_value") or 0)
                    material_doc_no = clip(str(item.get("material_doc_no") or ""), 50)
                    cg_no = clip(str(item.get("cg_no") or ""), 50)
                    item_no = clip(str(item.get("item_no") or ""), 50)
                    posting_datetime = clip(str(item.get("posting_datetime") or ""), 19)
                    user_name = clip(str(item.get("user_name") or ""), 50)
                    sloc = clip(str(item.get("sloc") or ""), 50)
                    movt_type = clip(str(item.get("movt_type") or ""), 20)
                    reason = clip(str(item.get("reason_for_scrap") or ""), 255)

                    if part_no == "" and part_desc == "":
                        continue

                    posting_db = posting_datetime if posting_datetime else None

                    execute(
                        conn,
                        "INSERT INTO memo_items\n"
                        " (memo_id, sr, part_no, lot_number, part_desc, qty, unit, scrap_value, material_doc_no, cg_no, item_no, posting_datetime, user_name, sloc, movt_type, reason_for_scrap)\n"
                        "VALUES\n"
                        " (:memo_id, :sr, :part_no, :lot_number, :part_desc, :qty, :unit, :scrap_value, :material_doc_no, :cg_no, :item_no, :posting_datetime, :user_name, :sloc, :movt_type, :reason_for_scrap)",
                        {
                            "memo_id": memo_id,
                            "sr": sr_val,
                            "part_no": part_no,
                            "lot_number": lot_number,
                            "part_desc": part_desc,
                            "qty": qty,
                            "unit": unit,
                            "scrap_value": scrap_value,
                            "material_doc_no": material_doc_no,
                            "cg_no": cg_no,
                            "item_no": item_no,
                            "posting_datetime": posting_db,
                            "user_name": user_name,
                            "sloc": sloc,
                            "movt_type": movt_type,
                            "reason_for_scrap": reason,
                        },
                    )

                    items_for_post.append({"part_no": part_no, "part_desc": part_desc, "qty": qty, "unit": unit})

                if upload_mode == "NON_AUTO_PART" and non_auto_mutilated == 1:
                    user_id = int(session.get("user_id") or 0)
                    _post_memo_direct_to_inventory(conn, memo_id=memo_id, items=items_for_post, user_id=user_id)
    except Exception as e:
        try:
            dest_path.unlink(missing_ok=True)
        except Exception:
            pass
        msg = str(e) or "Could not save memo."
        flash_set("error", msg)
        return redirect("/scratch/memo/upload")

    flash_set("success", "Memo uploaded.")
    if upload_mode == "NON_AUTO_PART" and non_auto_mutilated == 1:
        return redirect("/scratch/inventory/list")
    return redirect(f"/scratch/mutilation/verify?id={memo_id}")


@bp.get("/scratch/memo/view")
@login_required
def memo_view() -> Response:
    try:
        memo_id = int(request.args.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        return Response("Invalid request", status=400, mimetype="text/plain")

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT file_path, original_filename FROM memos WHERE id = :id", {"id": memo_id})
    if not row:
        return Response("Not found", status=404, mimetype="text/plain")

    file_path = str(row.get("file_path") or "")
    original_name = str(row.get("original_filename") or "memo.pdf")
    full = _safe_memo_path(file_path)
    if full is None or not full.is_file():
        return Response("Not found", status=404, mimetype="text/plain")

    return send_file(full, mimetype="application/pdf", as_attachment=False, download_name=original_name)


@bp.get("/scratch/memo/download")
@login_required
def memo_download() -> Response:
    try:
        memo_id = int(request.args.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        return Response("Invalid request", status=400, mimetype="text/plain")

    with db_conn() as conn:
        row = fetch_one(conn, "SELECT file_path, original_filename FROM memos WHERE id = :id", {"id": memo_id})
    if not row:
        return Response("Not found", status=404, mimetype="text/plain")

    file_path = str(row.get("file_path") or "")
    original_name = str(row.get("original_filename") or "memo.pdf")
    full = _safe_memo_path(file_path)
    if full is None or not full.is_file():
        return Response("Not found", status=404, mimetype="text/plain")

    return send_file(full, mimetype="application/pdf", as_attachment=True, download_name=original_name)


@bp.post("/scratch/memo/delete")
@login_required
@csrf_protect
def memo_delete() -> object:
    _require_edit_permission()
    try:
        memo_id = int(request.form.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        flash_set("error", "Invalid memo.")
        return redirect("/scratch/memo/list")

    file_path = ""
    try:
        with db_conn() as conn:
            with conn.begin():
                row = fetch_one(conn, "SELECT file_path FROM memos WHERE id = :id", {"id": memo_id}) or {}
                file_path = str(row.get("file_path") or "")
                execute(conn, "DELETE FROM memos WHERE id = :id", {"id": memo_id})
    except Exception:
        flash_set("error", "Could not delete memo.")
        return redirect("/scratch/memo/list")

    if file_path:
        full = _safe_memo_path(file_path)
        if full and full.is_file():
            try:
                full.unlink()
            except Exception:
                pass

    flash_set("success", "Memo deleted.")
    return redirect("/scratch/memo/list")


def _require_edit_permission() -> None:
    from app.utils.rbac import current_user_role
    if current_user_role() not in ("admin", "supervisor"):
        abort(403)


@bp.get("/scratch/memo/edit")
@login_required
def memo_edit() -> object:
    _require_edit_permission()
    try:
        memo_id = int(request.args.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        flash_set("error", "Invalid memo.")
        return redirect("/scratch/memo/list")

    with db_conn() as conn:
        memo = fetch_one(conn, "SELECT id, memo_number, memo_date, source, vehicle_number, status FROM memos WHERE id = :id", {"id": memo_id})
        if not memo:
            flash_set("error", "Memo not found.")
            return redirect("/scratch/memo/list")
        items = fetch_all(
            conn,
            "SELECT sr, part_no, part_desc, qty, unit FROM memo_items WHERE memo_id = :id ORDER BY sr ASC",
            {"id": memo_id},
        )
        uoms = fetch_all(conn, "SELECT code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")

    return render_template(
        "memo/edit.html",
        pageTitle="Edit Memo - SYMS",
        memo=memo,
        items=items,
        uoms=uoms,
    )


@bp.post("/scratch/memo/edit")
@login_required
@csrf_protect
def memo_edit_post() -> object:
    _require_edit_permission()
    try:
        memo_id = int(request.form.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        flash_set("error", "Invalid memo.")
        return redirect("/scratch/memo/list")

    memo_date = str(request.form.get("memo_date") or "").strip()
    source = str(request.form.get("source") or "").strip()
    vehicle_number = str(request.form.get("vehicle_number") or "").strip()

    if memo_date == "":
        flash_set("error", "Memo date is required.")
        return redirect(f"/scratch/memo/edit?id={memo_id}")

    with db_conn() as conn:
        memo = fetch_one(conn, "SELECT id, status FROM memos WHERE id = :id", {"id": memo_id})
    if not memo:
        flash_set("error", "Memo not found.")
        return redirect("/scratch/memo/list")

    status = str(memo.get("status") or "UPLOADED")

    try:
        with db_conn() as conn:
            with conn.begin():
                execute(
                    conn,
                    "UPDATE memos SET memo_date = :memo_date, source = :source, vehicle_number = :vehicle_number WHERE id = :id",
                    {"memo_date": memo_date, "source": source, "vehicle_number": vehicle_number, "id": memo_id},
                )

                if status == "UPLOADED":
                    part_nos = request.form.getlist("part_no[]")
                    part_descs = request.form.getlist("part_desc[]")
                    qtys = request.form.getlist("qty[]")
                    units = request.form.getlist("unit[]")

                    items: list[dict[str, object]] = []
                    for i in range(max(len(part_nos), len(part_descs), len(qtys), len(units), 1)):
                        part_no = str(part_nos[i] if i < len(part_nos) else "").strip()
                        part_desc = str(part_descs[i] if i < len(part_descs) else "").strip()
                        unit = str(units[i] if i < len(units) else "").strip()
                        qty_s = str(qtys[i] if i < len(qtys) else "").strip()
                        try:
                            qty = float(qty_s) if qty_s != "" else 0.0
                        except Exception:
                            qty = 0.0
                        if part_no == "" and part_desc == "":
                            continue
                        items.append({"part_no": part_no[:50], "part_desc": part_desc[:2000], "qty": qty, "unit": unit[:20]})

                    if len(items) <= 0:
                        flash_set("error", "At least one line item is required.")
                        return redirect(f"/scratch/memo/edit?id={memo_id}")

                    execute(conn, "DELETE FROM memo_items WHERE memo_id = :id", {"id": memo_id})
                    for idx, item in enumerate(items, start=1):
                        execute(
                            conn,
                            "INSERT INTO memo_items (memo_id, sr, part_no, lot_number, part_desc, qty, unit, scrap_value, material_doc_no, cg_no, item_no, posting_datetime, user_name, sloc, movt_type, reason_for_scrap)\n"
                            "VALUES (:memo_id, :sr, :part_no, :lot_number, :part_desc, :qty, :unit, 0, '', '', '', NULL, '', '', '', '')",
                            {
                                "memo_id": memo_id,
                                "sr": idx,
                                "part_no": str(item.get("part_no") or ""),
                                "lot_number": str(item.get("part_no") or ""),
                                "part_desc": str(item.get("part_desc") or ""),
                                "qty": float(item.get("qty") or 0),
                                "unit": str(item.get("unit") or ""),
                            },
                        )
    except Exception as e:
        flash_set("error", str(e) or "Could not update memo.")
        return redirect(f"/scratch/memo/edit?id={memo_id}")

    flash_set("success", "Memo updated.")
    return redirect("/scratch/memo/list")


@bp.get("/scratch/memo/verify")
@login_required
def memo_verify_redirect() -> object:
    try:
        memo_id = int(request.args.get("id") or 0)
    except Exception:
        memo_id = 0
    if memo_id <= 0:
        flash_set("error", "Invalid memo.")
        return redirect("/scratch/memo/list")
    return redirect(f"/scratch/mutilation/verify?id={memo_id}")
