from __future__ import annotations

from .parse_memo_pdf import parse_pdf


def parse_memo_pdf(pdf_path: str) -> dict:
    out = parse_pdf(pdf_path)
    return {"ok": True, **out}
