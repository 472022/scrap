from __future__ import annotations

from flask import Blueprint, abort, redirect, render_template, request

from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.security.auth import login_required
from app.security.csrf import csrf_protect
from app.utils.flash import flash_set

bp = Blueprint("inventory", __name__)


def _require_edit_permission() -> None:
    from app.utils.rbac import current_user_role
    if current_user_role() not in ("admin", "supervisor"):
        abort(403)


@bp.get("/scratch/inventory/list")
@login_required
def inventory_list() -> object:
    sql = (
        "SELECT\n"
        "    ib.material_id,\n"
        "    ib.part_no_norm,\n"
        "    ib.product_description,\n"
        "    ib.uom_code,\n"
        "    ib.balance_weight,\n"
        "    c.name AS category_name,\n"
        "    mr.rate_per_weight\n"
        "FROM inventory_balances_v2 ib\n"
        "LEFT JOIN materials m ON m.id = ib.material_id\n"
        "LEFT JOIN material_categories c ON c.id = m.category_id\n"
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1\n"
        "WHERE ib.balance_weight > 0\n"
        "ORDER BY ib.product_description ASC, ib.part_no_norm ASC"
    )
    with db_conn() as conn:
        rows = fetch_all(conn, sql)
    return render_template("inventory/list.html", pageTitle="Inventory - SYMS", rows=rows)


@bp.get("/scratch/inventory/edit")
@login_required
def inventory_edit() -> object:
    _require_edit_permission()
    try:
        material_id = int(request.args.get("id") or 0)
    except Exception:
        material_id = 0
    if material_id <= 0:
        flash_set("error", "Invalid material.")
        return redirect("/scratch/inventory/list")

    with db_conn() as conn:
        material = fetch_one(
            conn,
            "SELECT m.id, m.part_no_raw, m.part_no_norm, m.product_description, m.category_id, m.uom_id,\n"
            "       u.code AS uom_code, c.name AS category_name\n"
            "FROM materials m\n"
            "LEFT JOIN uoms u ON u.id = m.uom_id\n"
            "LEFT JOIN material_categories c ON c.id = m.category_id\n"
            "WHERE m.id = :id",
            {"id": material_id},
        )
        if not material:
            flash_set("error", "Material not found.")
            return redirect("/scratch/inventory/list")
        rate_row = fetch_one(
            conn,
            "SELECT rate_per_weight FROM material_rates WHERE material_id = :id AND is_active = 1 ORDER BY effective_at DESC LIMIT 1",
            {"id": material_id},
        )
        categories = fetch_all(conn, "SELECT id, name FROM material_categories ORDER BY name ASC")
        uoms = fetch_all(conn, "SELECT id, code, name FROM uoms WHERE is_active = 1 ORDER BY code ASC")

    return render_template(
        "inventory/edit.html",
        pageTitle="Edit Material - SYMS",
        material=material,
        rate=rate_row,
        categories=categories,
        uoms=uoms,
    )


@bp.post("/scratch/inventory/edit")
@login_required
@csrf_protect
def inventory_edit_post() -> object:
    _require_edit_permission()
    try:
        material_id = int(request.form.get("id") or 0)
    except Exception:
        material_id = 0
    if material_id <= 0:
        flash_set("error", "Invalid material.")
        return redirect("/scratch/inventory/list")

    product_description = str(request.form.get("product_description") or "").strip()[:255]
    try:
        category_id = int(request.form.get("category_id") or 0)
    except Exception:
        category_id = 0
    try:
        uom_id = int(request.form.get("uom_id") or 0)
    except Exception:
        uom_id = 0
    rate_str = str(request.form.get("rate_per_weight") or "").strip()
    try:
        rate_val = float(rate_str) if rate_str != "" else None
    except Exception:
        rate_val = None

    if product_description == "":
        flash_set("error", "Product description is required.")
        return redirect(f"/scratch/inventory/edit?id={material_id}")

    try:
        with db_conn() as conn:
            with conn.begin():
                execute(
                    conn,
                    "UPDATE materials SET product_description = :desc, category_id = :cat, uom_id = :uom, updated_at = NOW() WHERE id = :id",
                    {
                        "desc": product_description,
                        "cat": category_id if category_id > 0 else None,
                        "uom": uom_id if uom_id > 0 else None,
                        "id": material_id,
                    },
                )
                if rate_val is not None and rate_val > 0:
                    # Deactivate existing rates then insert a fresh one
                    execute(
                        conn,
                        "UPDATE material_rates SET is_active = 0 WHERE material_id = :id",
                        {"id": material_id},
                    )
                    execute(
                        conn,
                        "INSERT INTO material_rates (material_id, rate_per_weight, effective_at, is_active, created_at)\n"
                        "VALUES (:material_id, :rate, NOW(), 1, NOW())",
                        {"material_id": material_id, "rate": rate_val},
                    )
                elif rate_val == 0:
                    # Clear rate
                    execute(
                        conn,
                        "UPDATE material_rates SET is_active = 0 WHERE material_id = :id",
                        {"id": material_id},
                    )
    except Exception as e:
        flash_set("error", str(e) or "Could not update material.")
        return redirect(f"/scratch/inventory/edit?id={material_id}")

    flash_set("success", "Material updated.")
    return redirect("/scratch/inventory/list")
