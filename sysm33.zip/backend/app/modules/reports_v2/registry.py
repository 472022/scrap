from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReportDefinition:
    key: str
    title: str
    description: str
    permission_key: str


REPORT_DEFINITIONS: dict[str, ReportDefinition] = {
    "dash_ops": ReportDefinition(
        key="dash_ops",
        title="Operations Dashboard",
        description="Operational KPIs, trends, and exceptions.",
        permission_key="dash_ops",
    ),
    "dash_inventory": ReportDefinition(
        key="dash_inventory",
        title="Inventory Dashboard",
        description="Inventory health, valuation, and expiry risk.",
        permission_key="dash_inventory",
    ),
    "memo": ReportDefinition(
        key="memo",
        title="Memo Report",
        description="Memo status, mismatches, and processing health.",
        permission_key="memo",
    ),
    "inward_items": ReportDefinition(
        key="inward_items",
        title="Inward Items Report",
        description="Line-wise inward details and mismatch diagnostics.",
        permission_key="inward_items",
    ),
    "segregation": ReportDefinition(
        key="segregation",
        title="Segregation Report",
        description="Segregation throughput by material and memo.",
        permission_key="segregation",
    ),
    "outward": ReportDefinition(
        key="outward",
        title="Disposal / Sale Report",
        description="Outward dispatch trends and valuation quality.",
        permission_key="outward",
    ),
    "inventory": ReportDefinition(
        key="inventory",
        title="Inventory Report",
        description="Current stock, valuation, and category composition.",
        permission_key="inventory",
    ),
    "expiry_alerts": ReportDefinition(
        key="expiry_alerts",
        title="Expiry Alert Report",
        description="Near-expiry and expired lots with action queue.",
        permission_key="expiry_alerts",
    ),
    "movements": ReportDefinition(
        key="movements",
        title="Inventory Movements Report",
        description="Ledger trail for IN/OUT movement auditing.",
        permission_key="movements",
    ),
    "mismatches": ReportDefinition(
        key="mismatches",
        title="Mismatch Summary Report",
        description="Mismatch concentration and source-level tracking.",
        permission_key="mismatches",
    ),
    "financial_summary": ReportDefinition(
        key="financial_summary",
        title="Financial Summary",
        description="Inventory valuation, disposal revenue, and unvalued stock by material.",
        permission_key="financial_summary",
    ),
    "vendor": ReportDefinition(
        key="vendor",
        title="Vendor / Counterparty Report",
        description="Disposal analysis by recycler with shipment counts and values.",
        permission_key="vendor",
    ),
    "exceptions": ReportDefinition(
        key="exceptions",
        title="Data Exceptions",
        description="Negative balances, missing rates, expiry risks, and ledger anomalies.",
        permission_key="exceptions",
    ),
}


def report_keys() -> list[str]:
    return list(REPORT_DEFINITIONS.keys())


def get_report_definition(report_key: str) -> ReportDefinition | None:
    return REPORT_DEFINITIONS.get(str(report_key or "").strip())
