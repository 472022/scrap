from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path

from flask import Response, send_file

from app.config import load_settings


def _exports_dir() -> Path:
    settings = load_settings()
    p = Path(settings.export_dir)
    if not p.is_absolute():
        p = (Path(__file__).resolve().parents[3] / p).resolve()
    p.mkdir(parents=True, exist_ok=True)
    return p


def _escape_pdf_text(s: str) -> str:
    return s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def build_simple_pdf(text_lines: list[str]) -> bytes:
    payload = "BT /F1 10 Tf 40 780 Td "
    first = True
    for line in text_lines:
        escaped = _escape_pdf_text(line[:150])
        if first:
            payload += f"({escaped}) Tj"
            first = False
        else:
            payload += f" T* ({escaped}) Tj"
    payload += " ET"

    content_bytes = payload.encode("latin-1", errors="replace")
    parts: list[bytes] = []
    parts.append(b"%PDF-1.4\n")
    offsets = [0]

    def _add(obj: bytes) -> None:
        offsets.append(sum(len(p) for p in parts))
        parts.append(obj)

    _add(b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n")
    _add(b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n")
    _add(b"3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj\n")
    _add((f"4 0 obj << /Length {len(content_bytes)} >> stream\n".encode("ascii") + content_bytes + b"\nendstream endobj\n"))
    _add(b"5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n")

    xref_pos = sum(len(p) for p in parts)
    xref = [f"xref\n0 {len(offsets)}\n".encode("ascii")]
    xref.append(b"0000000000 65535 f \n")
    for off in offsets[1:]:
        xref.append(f"{off:010d} 00000 n \n".encode("ascii"))

    trailer = (
        f"trailer << /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref_pos}\n%%EOF\n".encode("ascii")
    )

    return b"".join(parts + xref + [trailer])


def render_excel_bytes(columns: list[str], rows: list[dict[str, object]]) -> bytes:
    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "Report"

    ws.append(columns)
    for row in rows:
        ws.append([row.get(c, "") for c in columns])

    out = io.BytesIO()
    wb.save(out)
    out.seek(0)
    return out.getvalue()


def save_export_file(content: bytes, *, stem: str, ext: str) -> tuple[str, str]:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{stem}_{stamp}.{ext}"
    path = (_exports_dir() / name).resolve()
    path.write_bytes(content)
    return name, str(path)


def send_export(content: bytes, *, filename: str, mimetype: str) -> Response:
    buf = io.BytesIO(content)
    buf.seek(0)
    return send_file(buf, mimetype=mimetype, as_attachment=True, download_name=filename)
