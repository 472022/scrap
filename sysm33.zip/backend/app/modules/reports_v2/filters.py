from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from flask import Request


def _safe_date(value: str, fallback: date) -> date:
    raw = str(value or "").strip()
    try:
        return date.fromisoformat(raw)
    except Exception:
        return fallback


def parse_v2_filters(req: Request, *, source: str = "args") -> dict[str, Any]:
    bag = req.form if source == "form" else req.args

    preset = str(bag.get("preset") or "30d").strip()
    from_s = str(bag.get("from") or "").strip()
    to_s = str(bag.get("to") or "").strip()

    today = date.today()
    if preset in {"today", "7d", "30d"}:
        if preset == "today":
            start = today
        elif preset == "7d":
            start = today - timedelta(days=6)
        else:
            start = today - timedelta(days=29)
        end = today
    else:
        start = _safe_date(from_s, today - timedelta(days=29))
        end = _safe_date(to_s, today)

    if start > end:
        start, end = end, start

    # guardrail: cap window to 366 days
    if (end - start).days > 366:
        start = end - timedelta(days=366)

    def _int(name: str, default: int = 0) -> int:
        try:
            return int(bag.get(name) or default)
        except Exception:
            return default

    page = _int("page", 1)
    limit = _int("limit", 100)
    if page < 1:
        page = 1
    if limit < 25:
        limit = 25
    if limit > 500:
        limit = 500

    return {
        "preset": preset,
        "from": start.isoformat(),
        "to": end.isoformat(),
        "page": page,
        "limit": limit,
        "offset": (page - 1) * limit,
        "source": str(bag.get("source") or "").strip()[:100],
        "status": str(bag.get("status") or "").strip()[:30],
        "material_id": max(0, _int("material_id")),
        "category_id": max(0, _int("category_id")),
        "lot_id": max(0, _int("lot_id")),
        "mismatch_only": 1 if str(bag.get("mismatch_only") or "").strip() in {"1", "true", "True", "on"} else 0,
    }
