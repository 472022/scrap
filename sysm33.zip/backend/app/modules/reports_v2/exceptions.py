from __future__ import annotations

from sqlalchemy.engine import Connection

from app.db.query import fetch_all, fetch_one


def build_exceptions(conn: Connection) -> list[dict[str, object]]:
    out: list[dict[str, object]] = []

    negative_cnt = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt FROM inventory_balances_v2 WHERE balance_weight < 0",
    )
    negative_rows = fetch_all(
        conn,
        "SELECT part_no_norm, product_description, uom_code, balance_weight "
        "FROM inventory_balances_v2 WHERE balance_weight < 0 "
        "ORDER BY balance_weight ASC, part_no_norm ASC LIMIT 10",
    )
    out.append(
        {
            "type": "negative_balance",
            "title": "Negative Inventory Balances",
            "count": int((negative_cnt or {}).get("cnt") or 0),
            "rows": negative_rows,
        }
    )

    missing_rate_cnt = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt "
        "FROM inventory_balances_v2 ib "
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1 "
        "WHERE ib.balance_weight > 0 AND mr.id IS NULL",
    )
    missing_rate_rows = fetch_all(
        conn,
        "SELECT ib.part_no_norm, ib.product_description, ib.uom_code, ib.balance_weight "
        "FROM inventory_balances_v2 ib "
        "LEFT JOIN material_rates mr ON mr.material_id = ib.material_id AND mr.is_active = 1 "
        "WHERE ib.balance_weight > 0 AND mr.id IS NULL "
        "ORDER BY ib.balance_weight DESC, ib.part_no_norm ASC LIMIT 10",
    )
    out.append(
        {
            "type": "missing_rate",
            "title": "Stock Without Active Rate",
            "count": int((missing_rate_cnt or {}).get("cnt") or 0),
            "rows": missing_rate_rows,
        }
    )

    expiry_cnt = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt FROM expiry_alerts_vw "
        "WHERE balance_weight > 0 AND alert_state IN ('NEAR_EXPIRY','EXPIRED')",
    )
    expiry_rows = fetch_all(
        conn,
        "SELECT lot_number, product_description, uom_code, balance_weight, alert_state, days_to_expiry "
        "FROM expiry_alerts_vw "
        "WHERE balance_weight > 0 AND alert_state IN ('NEAR_EXPIRY','EXPIRED') "
        "ORDER BY CASE alert_state WHEN 'EXPIRED' THEN 0 ELSE 1 END, days_to_expiry ASC LIMIT 10",
    )
    out.append(
        {
            "type": "expiry_risk",
            "title": "Expiry Risk Lots",
            "count": int((expiry_cnt or {}).get("cnt") or 0),
            "rows": expiry_rows,
        }
    )

    recon_rows = fetch_all(
        conn,
        "SELECT t.material_id, t.part_no_norm, t.v2_balance, t.ledger_balance "
        "FROM ("
        "  SELECT ib.material_id, ib.part_no_norm, ib.balance_weight AS v2_balance, "
        "         COALESCE(SUM(CASE WHEN sm.direction = 'IN' THEN sm.weight ELSE -sm.weight END), 0) AS ledger_balance "
        "  FROM inventory_balances_v2 ib "
        "  LEFT JOIN stock_movements_v2 sm ON sm.material_id = ib.material_id "
        "  GROUP BY ib.material_id, ib.part_no_norm, ib.balance_weight"
        ") t "
        "WHERE ABS(t.v2_balance - t.ledger_balance) > 0.01 "
        "ORDER BY ABS(t.v2_balance - t.ledger_balance) DESC LIMIT 10",
    )
    out.append(
        {
            "type": "reconciliation_anomaly",
            "title": "Ledger Reconciliation Anomalies",
            "count": len(recon_rows),
            "rows": recon_rows,
        }
    )

    return out
