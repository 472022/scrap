from __future__ import annotations

from datetime import date

from flask import Blueprint, redirect, render_template, request

from app.db.engine import db_conn
from app.db.query import execute, fetch_all, fetch_one
from app.db.scrap_schema import ensure_scrap_tables
from app.email.scrap_notifications import load_scrap_email_settings, send_acceptance_email, send_reschedule_email
from app.security.csrf import csrf_protect
from app.security.scrap_admin_auth import scrap_admin_login_required
from app.utils.flash import flash_set

bp = Blueprint("scrap_admin_requests", __name__)


def _coerce_date(v: object) -> str:
    if isinstance(v, date):
        return v.isoformat()
    return str(v or "")


def _normalize_location_fields(row: dict[str, object]) -> None:
    loc = str(row.get("location") or "").strip()
    loc_other = str(row.get("location_other") or "").strip()
    if loc_other == "":
        low = loc.lower()
        if low.startswith("other:"):
            row["location"] = "Other"
            row["location_other"] = loc.split(":", 1)[1].strip()
        elif low.startswith("other -"):
            row["location"] = "Other"
            row["location_other"] = loc.split("-", 1)[1].strip()
        elif low.startswith("other "):
            row["location"] = "Other"
            row["location_other"] = loc[5:].strip()


@bp.get("/scrap-admin/requests")
@scrap_admin_login_required
def scrap_admin_requests_dashboard() -> object:
    with db_conn() as conn:
        ensure_scrap_tables(conn)
        rows = fetch_all(
            conn,
            "SELECT\n"
            "  id, source, req_date, ticket_no, designation, email, contact_no, department,\n"
            "  location, location_other, shift, weight, scrap_type, scrap_type_other, vehicle_type,\n"
            "  status, created_at\n"
            "FROM scrap_requests\n"
            "ORDER BY created_at DESC, id DESC\n"
            "LIMIT 500",
        )
    for r in rows:
        r["req_date"] = _coerce_date(r.get("req_date"))
    return render_template("scrap_admin/requests_dashboard.html", pageTitle="Scrap Requests - SYMS", rows=rows)


@bp.post("/scrap-admin/requests/<int:req_id>/accept")
@scrap_admin_login_required
@csrf_protect
def scrap_admin_accept_request(req_id: int) -> object:
    with db_conn() as conn:
        with conn.begin():
            ensure_scrap_tables(conn)
            execute(
                conn,
                "UPDATE scrap_requests SET status = 'ACCEPTED', accepted_at = NOW(), updated_at = NOW() WHERE id = :id",
                {"id": int(req_id)},
            )
            row = fetch_one(conn, "SELECT * FROM scrap_requests WHERE id = :id LIMIT 1", {"id": int(req_id)}) or {}
            if not row:
                flash_set("error", "Request not found.")
                return redirect("/scrap-admin/requests")
            row["req_date"] = _coerce_date(row.get("req_date"))
            settings = load_scrap_email_settings(conn)
            result = send_acceptance_email(conn, request_row=row, settings=settings)

    if result.success:
        flash_set("success", "Request accepted and email sent.")
    else:
        flash_set("error", f"Request accepted, but email failed. {str(result.error_message or '')}")
    return redirect("/scrap-admin/requests")


@bp.get("/scrap-admin/requests/<int:req_id>/reschedule")
@scrap_admin_login_required
def scrap_admin_reschedule_page(req_id: int) -> object:
    with db_conn() as conn:
        ensure_scrap_tables(conn)
        row = fetch_one(conn, "SELECT * FROM scrap_requests WHERE id = :id LIMIT 1", {"id": int(req_id)}) or {}
    if not row:
        flash_set("error", "Request not found.")
        return redirect("/scrap-admin/requests")
    row["req_date"] = _coerce_date(row.get("req_date"))
    _normalize_location_fields(row)
    return render_template("scrap_admin/reschedule.html", pageTitle="Reschedule Pickup - SYMS", r=row)


@bp.post("/scrap-admin/requests/<int:req_id>/reschedule")
@scrap_admin_login_required
@csrf_protect
def scrap_admin_reschedule_process(req_id: int) -> object:
    new_date = str(request.form.get("req_date") or "").strip()
    location = str(request.form.get("location") or "").strip()
    location_other = str(request.form.get("location_other") or "").strip()
    shift = str(request.form.get("shift") or "").strip()
    vehicle_type = str(request.form.get("vehicle_type") or "").strip()

    if new_date == "":
        flash_set("error", "Pickup date is required.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")
    if location == "":
        flash_set("error", "Location is required.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")
    if location == "Other" and location_other == "":
        flash_set("error", "Other location is required.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")
    if shift == "":
        flash_set("error", "Shift is required.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")
    if vehicle_type == "":
        flash_set("error", "Vehicle type is required.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")
    try:
        parsed_date = date.fromisoformat(new_date)
    except Exception:
        flash_set("error", "Invalid date.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")
    if parsed_date < date.today():
        flash_set("error", "Pickup date cannot be in the past.")
        return redirect(f"/scrap-admin/requests/{int(req_id)}/reschedule")

    with db_conn() as conn:
        with conn.begin():
            ensure_scrap_tables(conn)
            execute(
                conn,
                "UPDATE scrap_requests\n"
                "SET req_date = :d,\n"
                "    location = :loc,\n"
                "    location_other = :loc_other,\n"
                "    shift = :shift,\n"
                "    vehicle_type = :vehicle,\n"
                "    status = 'RESCHEDULED',\n"
                "    rescheduled_at = NOW(),\n"
                "    updated_at = NOW()\n"
                "WHERE id = :id",
                {
                    "id": int(req_id),
                    "d": new_date,
                    "loc": location,
                    "loc_other": location_other if location == "Other" else None,
                    "shift": shift,
                    "vehicle": vehicle_type,
                },
            )
            row = fetch_one(conn, "SELECT * FROM scrap_requests WHERE id = :id LIMIT 1", {"id": int(req_id)}) or {}
            if not row:
                flash_set("error", "Request not found.")
                return redirect("/scrap-admin/requests")
            row["req_date"] = _coerce_date(row.get("req_date"))
            _normalize_location_fields(row)
            settings = load_scrap_email_settings(conn)
            result = send_reschedule_email(conn, request_row=row, settings=settings)

    if result.success:
        flash_set("success", "Pickup rescheduled and email sent.")
    else:
        flash_set("error", f"Pickup rescheduled, but email failed. {str(result.error_message or '')}")
    return redirect("/scrap-admin/requests")
