(() => {
  const ensure = (url, done, fail) => {
    const s = document.createElement("script");
    s.src = url;
    s.async = true;
    s.onload = () => done && done();
    s.onerror = () => fail && fail();
    document.head.appendChild(s);
  };

  const load = () => {
    if (window.echarts) return;
    ensure(
      "/scratch/assets/js/echarts.min.js",
      () => {},
      () => {
        ensure("https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js");
      }
    );
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", load);
  } else {
    load();
  }
})();

