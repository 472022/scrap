(() => {
  const byId = (id) => document.getElementById(id);

  const setText = (id, value) => {
    const el = byId(id);
    if (!el) return;
    el.textContent = value;
  };

  const fmtNum = (v) => {
    if (v === null || v === undefined) return "-";
    const n = Number(v);
    if (!Number.isFinite(n)) return "-";
    return String(n);
  };

  const fmtDec = (v, digits = 2) => {
    if (v === null || v === undefined) return "-";
    const n = Number(v);
    if (!Number.isFinite(n)) return "-";
    return n.toFixed(digits);
  };

  const escapeHtml = (s) => {
    return String(s)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  };

  const loadSummary = async () => {
    const summary = await symsCharts.fetchJson("/scratch/dashboard/api/summary");

    if (summary.can_memo) {
      setText("kpiTotalMemos", fmtNum(summary.total_memos));
      setText("kpiPendingMemos", fmtNum(summary.pending_memos));
      setText("kpiVerifiedMemos", fmtNum(summary.verified_memos));
      setText("kpiMismatchLines", fmtNum(summary.mismatch_lines));
    } else {
      setText("kpiTotalMemos", "-");
      setText("kpiPendingMemos", "-");
      setText("kpiVerifiedMemos", "-");
      setText("kpiMismatchLines", "-");
    }
    setText(
      "kpiVerifiedPercent",
      Number.isFinite(Number(summary.verified_percent)) ? `${summary.verified_percent}%` : "-"
    );
    setText("kpiNewMemos7d", summary.can_memo ? fmtNum(summary.new_memos_7d) : "-");
    setText(
      "kpiOutwardWeight7d",
      summary.can_outward
        ? summary.outward_7d_by_uom
          ? summary.outward_7d_by_uom
          : fmtDec(summary.outward_weight_7d, 2)
        : "-"
    );
    setText(
      "kpiInventoryTotal",
      summary.can_inventory
        ? summary.inventory_by_uom
          ? summary.inventory_by_uom
          : fmtDec(summary.inventory_total, 2)
        : "-"
    );

    if (summary.can_inventory && summary.top_inventory && summary.top_inventory.material_type) {
      const mt = summary.top_inventory.material_type || "";
      const w = fmtDec(summary.top_inventory.balance_weight, 2);
      const u = summary.top_inventory.uom_code || "";
      setText("kpiTopInventory", `${mt} (${w}${u ? ` ${u}` : ""})`);
    } else {
      setText("kpiTopInventory", "-");
    }

    if (summary.can_schedules) {
      setText("kpiActiveSchedules", fmtNum(summary.active_schedules));
    } else {
      setText("kpiActiveSchedules", "-");
    }

    return summary;
  };

  const loadStockWorth = async () => {
    const data = await symsCharts.fetchJson("/scratch/dashboard/api/stock_worth?preset=today");
    setText("kpiInventoryWorth", fmtDec(data.inventory_worth, 2));
    setText("kpiOutwardWorth", fmtDec(data.outward_worth, 2));
    setText("kpiUnvaluedStock", data.unvalued_stock_by_uom ? String(data.unvalued_stock_by_uom) : fmtDec(data.unvalued_stock_weight, 2));
    setText("kpiUnvaluedOutward", data.unvalued_outward_by_uom ? String(data.unvalued_outward_by_uom) : fmtDec(data.unvalued_outward_weight, 2));
  };

  const loadExpirySummary = async () => {
    const data = await symsCharts.fetchJson("/scratch/dashboard/api/expiry_summary");
    if (!data.allowed) {
      setText("kpiNearExpiryLots", "-");
      setText("kpiExpiredLots", "-");
      setText("kpiNearExpiryWeight", "-");
      setText("kpiExpiredWeight", "-");
      return;
    }
    setText("kpiNearExpiryLots", fmtNum(data.near_lots));
    setText("kpiExpiredLots", fmtNum(data.expired_lots));
    setText("kpiNearExpiryWeight", data.near_by_uom ? String(data.near_by_uom) : fmtDec(data.near_weight, 2));
    setText("kpiExpiredWeight", data.expired_by_uom ? String(data.expired_by_uom) : fmtDec(data.expired_weight, 2));
  };

  const loadExpiryAlerts = async () => {
    const tbody = byId("tblExpiryAlerts");
    if (!tbody) return;

    const data = await symsCharts.fetchJson("/scratch/dashboard/api/expiry_alerts?limit=20");
    if (!data.allowed) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-body-secondary">No access</td></tr>`;
      return;
    }

    const items = Array.isArray(data.items) ? data.items : [];
    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-body-secondary">No alert lots</td></tr>`;
      return;
    }

    tbody.innerHTML = items
      .map((it) => {
        const lotNo = escapeHtml(it.lot_number || "");
        const partNo = escapeHtml(it.part_no_norm || "");
        const days = it.days_to_expiry === null || it.days_to_expiry === undefined ? "-" : escapeHtml(String(it.days_to_expiry));
        const state = escapeHtml(it.alert_state || "");
        return `<tr><td>${lotNo}</td><td>${partNo}</td><td>${days}</td><td>${state}</td></tr>`;
      })
      .join("");
  };

  const loadPendingMemos = async () => {
    const tbody = byId("tblPendingMemos");
    if (!tbody) return;

    const data = await symsCharts.fetchJson("/scratch/dashboard/api/pending_memos");
    if (!data.allowed) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-body-secondary">No access</td></tr>`;
      return;
    }
    const items = Array.isArray(data.items) ? data.items : [];
    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-body-secondary">No pending memos</td></tr>`;
      return;
    }

    tbody.innerHTML = items
      .map((m) => {
        const memoNo = escapeHtml(m.memo_number || "");
        const memoDate = escapeHtml(m.memo_date || "");
        const source = escapeHtml(m.source || "");
        const id = Number(m.id || 0);
        const url = `/scratch/mutilation/verify?id=${encodeURIComponent(id)}`;
        return `
          <tr>
            <td>${memoNo}</td>
            <td>${memoDate}</td>
            <td>${source}</td>
            <td class="text-end"><a class="btn btn-sm btn-outline-primary" href="${url}">Open</a></td>
          </tr>
        `;
      })
      .join("");
  };

  const loadInventoryTop = async () => {
    const tbody = byId("tblInventoryTop");
    if (!tbody) return;

    const data = await symsCharts.fetchJson("/scratch/dashboard/api/inventory_top");
    if (!data.allowed) {
      tbody.innerHTML = `<tr><td colspan="2" class="text-body-secondary">No access</td></tr>`;
      return;
    }

    const labels = Array.isArray(data.labels) ? data.labels : [];
    const values = Array.isArray(data.values) ? data.values : [];
    const rows = [];
    for (let i = 0; i < Math.min(labels.length, values.length, 5); i += 1) {
      rows.push({
        label: labels[i],
        value: values[i],
      });
    }
    if (rows.length === 0) {
      tbody.innerHTML = `<tr><td colspan="2" class="text-body-secondary">No inventory data</td></tr>`;
      return;
    }

    tbody.innerHTML = rows
      .map((r) => {
        return `<tr><td>${escapeHtml(r.label || "")}</td><td>${escapeHtml(fmtDec(r.value, 2))}</td></tr>`;
      })
      .join("");
  };

  const loadSchedules = async () => {
    const nextRunsEl = byId("listNextRuns");
    const exportsEl = byId("listRecentExports");
    if (!nextRunsEl || !exportsEl) return;

    const data = await symsCharts.fetchJson("/scratch/dashboard/api/schedule_summary");
    if (!data.allowed) {
      nextRunsEl.innerHTML = `<div class="text-body-secondary">No access</div>`;
      exportsEl.innerHTML = `<div class="text-body-secondary">No access</div>`;
      return;
    }

    const runs = Array.isArray(data.next_runs) ? data.next_runs : [];
    const exports = Array.isArray(data.recent_exports) ? data.recent_exports : [];

    nextRunsEl.innerHTML =
      runs.length === 0
        ? `<div class="text-body-secondary">No schedules</div>`
        : runs
            .map((r) => {
              const label = `${escapeHtml(r.report_key || "")} • ${escapeHtml(r.frequency || "")}`;
              const when = escapeHtml(r.next_run_at || "");
              return `<div class="d-flex flex-column"><span class="fw-semibold">${label}</span><small class="text-body-secondary">${when}</small></div>`;
            })
            .join("");

    exportsEl.innerHTML =
      exports.length === 0
        ? `<div class="text-body-secondary">No exports</div>`
        : exports
            .map((x) => {
              const when = escapeHtml(x.generated_at || "");
              const url = escapeHtml(x.download_url || "#");
              return `<div class="d-flex align-items-center justify-content-between gap-2"><small class="text-body-secondary">${when}</small><a class="btn btn-sm btn-outline-primary" href="${url}">Download</a></div>`;
            })
            .join("");
  };

  const loadRecentSegregation = async () => {
    const tbody = byId("tblSegregationRecent");
    if (!tbody) return;

    const data = await symsCharts.fetchJson("/scratch/dashboard/api/recent_segregation");
    if (!data.allowed) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-body-secondary">No access</td></tr>`;
      return;
    }

    const items = Array.isArray(data.items) ? data.items : [];
    if (items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" class="text-body-secondary">No data</td></tr>`;
      return;
    }

    tbody.innerHTML = items
      .map((it) => {
        const memo = escapeHtml(it.memo || "");
        const mt = escapeHtml(it.material_type || "");
        const w = escapeHtml(fmtDec(it.weight, 2));
        const u = escapeHtml(it.uom_code || "");
        const d = escapeHtml(it.created_at || "");
        return `<tr><td>${memo}</td><td>${mt}</td><td>${w}${u ? ` ${u}` : ""}</td><td>${d}</td></tr>`;
      })
      .join("");
  };

  const loadRecentActivity = async () => {
    const host = byId("listRecentActivity");
    if (!host) return;

    const data = await symsCharts.fetchJson("/scratch/dashboard/api/recent_activity");
    if (!data.allowed) {
      host.innerHTML = `<div class="text-body-secondary">No access</div>`;
      return;
    }
    const items = Array.isArray(data.items) ? data.items : [];
    if (items.length === 0) {
      host.innerHTML = `<div class="text-body-secondary">No recent activity</div>`;
      return;
    }

    const badge = (t) => {
      if (t === "memo") return "bg-label-primary";
      if (t === "outward") return "bg-label-warning";
      if (t === "segregation") return "bg-label-info";
      return "bg-label-secondary";
    };

    const icon = (t) => {
      if (t === "memo") return "bx-file";
      if (t === "outward") return "bx-export";
      if (t === "segregation") return "bx-filter-alt";
      return "bx-bell";
    };

    host.innerHTML = items
      .map((it) => {
        const t = String(it.type || "");
        const label = escapeHtml(it.label || "");
        const when = escapeHtml(it.happened_at || "");
        const url = escapeHtml(it.url || "#");
        return `
          <a href="${url}" class="list-group-item list-group-item-action border-0 d-flex align-items-center px-4 py-3">
            <div class="avatar avatar-sm me-3">
               <span class="avatar-initial rounded-circle ${badge(t)}"><i class='bx ${icon(t)}'></i></span>
            </div>
            <div class="d-flex flex-column flex-grow-1">
              <span class="fw-semibold text-dark">${label}</span>
              <small class="text-muted">${when}</small>
            </div>
            <i class="bx bx-chevron-right text-muted"></i>
          </a>
        `;
      })
      .join("");
  };

  const renderCharts = async (summary) => {
    const qs30d = "?preset=30d";
    const charts = [];

    if (summary.can_dash_ops) {
      const memosTrend = await symsCharts.fetchJson(`/scratch/reports/api/trend_memos${qs30d}`);
      const c1 = echarts.init(byId("chartVerifiedTrend"));
      c1.setOption({
        tooltip: { trigger: "axis" },
        xAxis: { type: "category", data: memosTrend.labels || [] },
        yAxis: { type: "value" },
        dataZoom: [{ type: "inside" }, { type: "slider" }],
        series: [{ type: "line", smooth: true, data: memosTrend.verified || [] }],
      });
      charts.push(c1);

      const mismatchTrend = await symsCharts.fetchJson(`/scratch/reports/api/trend_mismatches${qs30d}`);
      const c2 = echarts.init(byId("chartMismatchTrend"));
      c2.setOption({
        tooltip: { trigger: "axis" },
        legend: { data: ["Mismatch %", "Mismatches"] },
        xAxis: { type: "category", data: mismatchTrend.labels || [] },
        yAxis: [{ type: "value", name: "%" }, { type: "value", name: "Count" }],
        dataZoom: [{ type: "inside" }, { type: "slider" }],
        series: [
          { name: "Mismatch %", type: "line", smooth: true, yAxisIndex: 0, data: mismatchTrend.rate || [] },
          { name: "Mismatches", type: "bar", yAxisIndex: 1, data: mismatchTrend.count || [] },
        ],
      });
      charts.push(c2);
    } else {
      const v = byId("chartVerifiedTrend");
      const m = byId("chartMismatchTrend");
      if (v) v.innerHTML = `<div class="text-body-secondary">No access</div>`;
      if (m) m.innerHTML = `<div class="text-body-secondary">No access</div>`;
    }

    const outward = await symsCharts.fetchJson(`/scratch/dashboard/api/outward_by_category${qs30d}`);
    if (outward.allowed) {
      const c3 = echarts.init(byId("chartOutwardByCategory"));
      c3.setOption({
        tooltip: { trigger: "axis" },
        xAxis: { type: "category", data: outward.labels || [] },
        yAxis: { type: "value" },
        series: [{ type: "bar", data: outward.values || [] }],
      });
      charts.push(c3);
    } else {
      const o = byId("chartOutwardByCategory");
      if (o) o.innerHTML = `<div class="text-body-secondary">No access</div>`;
    }

    const comp = await symsCharts.fetchJson(`/scratch/dashboard/api/inventory_composition${qs30d}`);
    if (comp.allowed) {
      const c4 = echarts.init(byId("chartInventoryPie"));
      c4.setOption({
        tooltip: { trigger: "item" },
        series: [
          {
            type: "pie",
            radius: "70%",
            data: (comp.items || []).map((x) => ({ name: x.name, value: x.value })),
            emphasis: { itemStyle: { shadowBlur: 10 } },
          },
        ],
      });
      charts.push(c4);
    } else {
      const i = byId("chartInventoryPie");
      if (i) i.innerHTML = `<div class="text-body-secondary">No access</div>`;
    }

    symsCharts.attachResize(charts);
  };

  const main = async () => {
    try {
      const summary = await loadSummary();
      await Promise.all([
        loadStockWorth(),
        loadExpirySummary(),
        loadExpiryAlerts(),
        loadPendingMemos(),
        loadInventoryTop(),
        loadSchedules(),
        loadRecentSegregation(),
        loadRecentActivity(),
      ]);
      symsCharts.initWhenReady(() => renderCharts(summary));
    } catch (e) {
      setText("kpiTotalMemos", "-");
    }
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
  } else {
    main();
  }
})();
