const symsCharts = (() => {
  const fetchJson = async (url) => {
    const res = await fetch(url, { credentials: "same-origin" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  };

  const withSearch = (path) => {
    const qs = window.location.search || "";
    return `${path}${qs}`;
  };

  const initWhenReady = (fn) => {
    const start = () => {
      let tries = 0;
      const t = setInterval(() => {
        tries += 1;
        if (window.echarts) {
          clearInterval(t);
          fn();
        } else if (tries > 60) {
          clearInterval(t);
          document.querySelectorAll(".syms-chart-container, .chart-placeholder").forEach((el) => {
            el.innerHTML = '<p class="text-muted text-center py-3 mb-0"><small>Charts failed to load. Please refresh the page.</small></p>';
          });
        }
      }, 150);
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", start);
    } else {
      start();
    }
  };

  const attachResize = (charts) => {
    window.addEventListener("resize", () => {
      for (const c of charts) c && c.resize();
    });
  };

  return { fetchJson, withSearch, initWhenReady, attachResize };
})();

