from __future__ import annotations

from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.engine import Connection, Engine

from app.config import Settings

_engine: Engine | None = None


def init_engine(settings: Settings) -> Engine:
    global _engine
    if _engine is not None:
        return _engine

    url = (
        f"mysql+pymysql://{settings.mysql_user}:{settings.mysql_password}"
        f"@{settings.mysql_host}:{settings.mysql_port}/{settings.mysql_db}"
        "?charset=utf8mb4"
    )
    _engine = create_engine(
        url,
        pool_pre_ping=True,
        pool_recycle=1800,
        future=True,
    )
    return _engine


def get_engine() -> Engine:
    if _engine is None:
        raise RuntimeError("DB engine not initialized")
    return _engine


@contextmanager
def db_conn() -> Connection:
    engine = get_engine()
    with engine.connect() as conn:
        yield conn


@contextmanager
def db_txn() -> Connection:
    engine = get_engine()
    with engine.begin() as conn:
        yield conn
