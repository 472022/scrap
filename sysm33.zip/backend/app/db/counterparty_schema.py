from __future__ import annotations

from sqlalchemy.engine import Connection

from app.db.query import execute, fetch_one


def _has_column(conn: Connection, *, table: str, column: str) -> bool:
    row = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt\n"
        "FROM information_schema.columns\n"
        "WHERE table_schema = DATABASE() AND table_name = :t AND column_name = :c",
        {"t": table, "c": column},
    ) or {}
    return int(row.get("cnt") or 0) > 0


def _has_index(conn: Connection, *, table: str, index: str) -> bool:
    row = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt\n"
        "FROM information_schema.statistics\n"
        "WHERE table_schema = DATABASE() AND table_name = :t AND index_name = :i",
        {"t": table, "i": index},
    ) or {}
    return int(row.get("cnt") or 0) > 0


def _ensure_column(conn: Connection, *, table: str, column: str, ddl: str) -> None:
    if _has_column(conn, table=table, column=column):
        return
    execute(conn, f"ALTER TABLE {table} ADD COLUMN {ddl}")


def ensure_counterparty_schema(conn: Connection) -> None:
    _ensure_column(conn, table="counterparties", column="code", ddl="code VARCHAR(50) NULL AFTER type")
    if not _has_index(conn, table="counterparties", index="uniq_counterparty_type_code"):
        execute(conn, "ALTER TABLE counterparties ADD UNIQUE KEY uniq_counterparty_type_code (type, code)")

