from __future__ import annotations

from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Connection


def fetch_all(conn: Connection, sql: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    res = conn.execute(text(sql), params or {})
    rows = res.mappings().all()
    return [dict(r) for r in rows]


def fetch_one(conn: Connection, sql: str, params: dict[str, Any] | None = None) -> dict[str, Any] | None:
    res = conn.execute(text(sql), params or {})
    row = res.mappings().first()
    return dict(row) if row else None


def execute(conn: Connection, sql: str, params: dict[str, Any] | None = None) -> int:
    res = conn.execute(text(sql), params or {})
    return int(res.rowcount or 0)
