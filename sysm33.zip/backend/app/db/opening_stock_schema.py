from __future__ import annotations

from sqlalchemy.engine import Connection

from app.db.query import execute


def ensure_opening_stock_tables(conn: Connection) -> None:
    execute(
        conn,
        "CREATE TABLE IF NOT EXISTS opening_stock_uploads (\n"
        "  id BIGINT AUTO_INCREMENT PRIMARY KEY,\n"
        "  uploaded_by INT NULL,\n"
        "  original_filename VARCHAR(255) NOT NULL,\n"
        "  stored_path VARCHAR(255) NOT NULL,\n"
        "  status VARCHAR(30) NOT NULL DEFAULT 'UPLOADED',\n"
        "  rows_total INT NOT NULL DEFAULT 0,\n"
        "  rows_valid INT NOT NULL DEFAULT 0,\n"
        "  rows_invalid INT NOT NULL DEFAULT 0,\n"
        "  upload_notes TEXT NULL,\n"
        "  uploaded_at DATETIME NOT NULL,\n"
        "  INDEX idx_opening_stock_uploads_uploaded_at (uploaded_at),\n"
        "  INDEX idx_opening_stock_uploads_status (status)\n"
        ") ENGINE=InnoDB",
    )

