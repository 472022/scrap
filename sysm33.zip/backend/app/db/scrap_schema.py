from __future__ import annotations

from sqlalchemy.engine import Connection

from app.db.query import execute, fetch_one


def _has_column(conn: Connection, *, table: str, column: str) -> bool:
    row = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt\n"
        "FROM information_schema.columns\n"
        "WHERE table_schema = DATABASE() AND table_name = :t AND column_name = :c",
        {"t": table, "c": column},
    ) or {}
    return int(row.get("cnt") or 0) > 0


def _ensure_column(conn: Connection, *, table: str, column: str, ddl: str) -> None:
    if _has_column(conn, table=table, column=column):
        return
    execute(conn, f"ALTER TABLE {table} ADD COLUMN {ddl}")


def ensure_scrap_tables(conn: Connection) -> None:
    execute(
        conn,
        "CREATE TABLE IF NOT EXISTS scrap_requests (\n"
        "  id BIGINT AUTO_INCREMENT PRIMARY KEY,\n"
        "  source ENUM('PUBLIC','INTERNAL') NOT NULL DEFAULT 'PUBLIC',\n"
        "  req_date DATE NOT NULL,\n"
        "  ticket_no VARCHAR(50) NOT NULL,\n"
        "  designation VARCHAR(100) NOT NULL,\n"
        "  email VARCHAR(100) NOT NULL,\n"
        "  contact_no VARCHAR(50) NOT NULL,\n"
        "  department VARCHAR(100) NOT NULL,\n"
        "  location VARCHAR(100) NOT NULL,\n"
        "  location_other VARCHAR(100) NULL,\n"
        "  shift VARCHAR(20) NOT NULL,\n"
        "  weight DECIMAL(10,2) NOT NULL DEFAULT 0,\n"
        "  scrap_type VARCHAR(255) NOT NULL,\n"
        "  scrap_type_other VARCHAR(100) NULL,\n"
        "  vehicle_type VARCHAR(50) NOT NULL,\n"
        "  status ENUM('PENDING','ACCEPTED','RESCHEDULED') NOT NULL DEFAULT 'PENDING',\n"
        "  accepted_at DATETIME NULL,\n"
        "  rescheduled_at DATETIME NULL,\n"
        "  created_at DATETIME NOT NULL,\n"
        "  updated_at DATETIME NULL,\n"
        "  INDEX idx_scrap_requests_status_created (status, created_at),\n"
        "  INDEX idx_scrap_requests_email (email),\n"
        "  INDEX idx_scrap_requests_req_date (req_date)\n"
        ") ENGINE=InnoDB",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="source",
        ddl="source ENUM('PUBLIC','INTERNAL') NOT NULL DEFAULT 'PUBLIC' AFTER id",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="req_date",
        ddl="req_date DATE NOT NULL AFTER source",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="ticket_no",
        ddl="ticket_no VARCHAR(50) NOT NULL AFTER req_date",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="designation",
        ddl="designation VARCHAR(100) NOT NULL AFTER ticket_no",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="email",
        ddl="email VARCHAR(100) NOT NULL AFTER designation",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="contact_no",
        ddl="contact_no VARCHAR(50) NOT NULL AFTER email",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="department",
        ddl="department VARCHAR(100) NOT NULL AFTER contact_no",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="location",
        ddl="location VARCHAR(100) NOT NULL AFTER department",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="location_other",
        ddl="location_other VARCHAR(100) NULL AFTER location",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="shift",
        ddl="shift VARCHAR(20) NOT NULL AFTER location_other",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="weight",
        ddl="weight DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER shift",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="scrap_type",
        ddl="scrap_type VARCHAR(255) NOT NULL AFTER weight",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="scrap_type_other",
        ddl="scrap_type_other VARCHAR(100) NULL AFTER scrap_type",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="vehicle_type",
        ddl="vehicle_type VARCHAR(50) NOT NULL AFTER scrap_type_other",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="status",
        ddl="status ENUM('PENDING','ACCEPTED','RESCHEDULED') NOT NULL DEFAULT 'PENDING' AFTER vehicle_type",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="accepted_at",
        ddl="accepted_at DATETIME NULL AFTER status",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="rescheduled_at",
        ddl="rescheduled_at DATETIME NULL AFTER accepted_at",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="created_at",
        ddl="created_at DATETIME NOT NULL DEFAULT NOW() AFTER rescheduled_at",
    )
    _ensure_column(
        conn,
        table="scrap_requests",
        column="updated_at",
        ddl="updated_at DATETIME NULL AFTER created_at",
    )

    execute(
        conn,
        "CREATE TABLE IF NOT EXISTS scrap_admin_users (\n"
        "  id INT AUTO_INCREMENT PRIMARY KEY,\n"
        "  username VARCHAR(50) NOT NULL UNIQUE,\n"
        "  password_hash VARCHAR(255) NOT NULL,\n"
        "  is_active TINYINT(1) NOT NULL DEFAULT 1,\n"
        "  created_at DATETIME NOT NULL,\n"
        "  INDEX idx_scrap_admin_users_active (is_active)\n"
        ") ENGINE=InnoDB",
    )
    _ensure_column(
        conn,
        table="scrap_admin_users",
        column="username",
        ddl="username VARCHAR(50) NOT NULL UNIQUE AFTER id",
    )
    _ensure_column(
        conn,
        table="scrap_admin_users",
        column="password_hash",
        ddl="password_hash VARCHAR(255) NOT NULL AFTER username",
    )
    _ensure_column(
        conn,
        table="scrap_admin_users",
        column="is_active",
        ddl="is_active TINYINT(1) NOT NULL DEFAULT 1 AFTER password_hash",
    )
    _ensure_column(
        conn,
        table="scrap_admin_users",
        column="created_at",
        ddl="created_at DATETIME NOT NULL DEFAULT NOW() AFTER is_active",
    )

    execute(
        conn,
        "CREATE TABLE IF NOT EXISTS scrap_email_logs (\n"
        "  id BIGINT AUTO_INCREMENT PRIMARY KEY,\n"
        "  request_id BIGINT NULL,\n"
        "  email_type ENUM('NEW_REQUEST','ACCEPTANCE','RESCHEDULE') NOT NULL,\n"
        "  to_email TEXT NOT NULL,\n"
        "  subject VARCHAR(255) NOT NULL,\n"
        "  success TINYINT(1) NOT NULL DEFAULT 0,\n"
        "  error_message TEXT NULL,\n"
        "  created_at DATETIME NOT NULL,\n"
        "  INDEX idx_scrap_email_logs_req (request_id, created_at),\n"
        "  INDEX idx_scrap_email_logs_type (email_type, created_at)\n"
        ") ENGINE=InnoDB",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="request_id",
        ddl="request_id BIGINT NULL AFTER id",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="email_type",
        ddl="email_type ENUM('NEW_REQUEST','ACCEPTANCE','RESCHEDULE') NOT NULL AFTER request_id",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="to_email",
        ddl="to_email TEXT NOT NULL AFTER email_type",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="subject",
        ddl="subject VARCHAR(255) NOT NULL AFTER to_email",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="success",
        ddl="success TINYINT(1) NOT NULL DEFAULT 0 AFTER subject",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="error_message",
        ddl="error_message TEXT NULL AFTER success",
    )
    _ensure_column(
        conn,
        table="scrap_email_logs",
        column="created_at",
        ddl="created_at DATETIME NOT NULL DEFAULT NOW() AFTER error_message",
    )
