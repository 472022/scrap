from __future__ import annotations

from sqlalchemy.engine import Connection

from app.db.query import execute, fetch_one


def _has_column(conn: Connection, *, table: str, column: str) -> bool:
    row = fetch_one(
        conn,
        "SELECT COUNT(*) AS cnt\n"
        "FROM information_schema.columns\n"
        "WHERE table_schema = DATABASE() AND table_name = :t AND column_name = :c",
        {"t": table, "c": column},
    ) or {}
    return int(row.get("cnt") or 0) > 0


def _ensure_column(conn: Connection, *, table: str, column: str, ddl: str) -> None:
    if _has_column(conn, table=table, column=column):
        return
    execute(conn, f"ALTER TABLE {table} ADD COLUMN {ddl}")


def ensure_memo_columns(conn: Connection) -> None:
    _ensure_column(
        conn,
        table="memos",
        column="upload_mode",
        ddl="upload_mode ENUM('AUTO_PART','NON_AUTO_PART') NOT NULL DEFAULT 'AUTO_PART' AFTER original_filename",
    )
    _ensure_column(
        conn,
        table="memos",
        column="non_auto_mutilated",
        ddl="non_auto_mutilated TINYINT(1) NOT NULL DEFAULT 0 AFTER upload_mode",
    )
    _ensure_column(
        conn,
        table="memos",
        column="created_via",
        ddl="created_via ENUM('PDF','MANUAL') NOT NULL DEFAULT 'PDF' AFTER non_auto_mutilated",
    )

