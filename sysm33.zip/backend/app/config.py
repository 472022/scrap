from __future__ import annotations

import os
from dataclasses import dataclass


def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip() not in {"0", "false", "False", "no", "NO", ""}


@dataclass(frozen=True)
class Settings:
    base_path: str
    secret_key: str

    mysql_host: str
    mysql_port: int
    mysql_db: str
    mysql_user: str
    mysql_password: str

    upload_dir: str
    export_dir: str

    session_cookie_secure: bool

    nvidia_api_key: str


def load_settings() -> Settings:
    base_path = (os.getenv("SYMS_BASE_PATH") or "/scratch").rstrip("/")
    if base_path == "":
        base_path = ""

    secret_key = os.getenv("SYMS_SECRET_KEY") or ""
    if not secret_key or secret_key == "dev-secret":
        import warnings
        warnings.warn(
            "SYMS_SECRET_KEY is not set or uses the insecure default 'dev-secret'. "
            "Set a strong random value in the environment before deploying.",
            stacklevel=2,
        )
        if not secret_key:
            secret_key = "dev-secret"

    return Settings(
        base_path=base_path,
        secret_key=secret_key,
        mysql_host=os.getenv("SYMS_MYSQL_HOST") or "127.0.0.1",
        mysql_port=int(os.getenv("SYMS_MYSQL_PORT") or "3306"),
        mysql_db=os.getenv("SYMS_MYSQL_DB") or "scrap_yard_db",
        mysql_user=os.getenv("SYMS_MYSQL_USER") or "root",
        mysql_password=os.getenv("SYMS_MYSQL_PASSWORD") or "",
        upload_dir=os.getenv("SYMS_UPLOAD_DIR") or "app/static/uploads",
        export_dir=os.getenv("SYMS_EXPORT_DIR") or "app/static/exports",
        session_cookie_secure=_env_bool("SYMS_SESSION_COOKIE_SECURE", False),
        nvidia_api_key=os.getenv("SYMS_NVIDIA_API_KEY") or "",
    )
