from __future__ import annotations

import logging
from dataclasses import dataclass

from flask import render_template

from app.db.scrap_schema import ensure_scrap_tables
from app.db.query import execute
from app.email.outlook import OutlookSendResult, send_outlook_email
from app.utils.app_settings import app_setting_get

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ScrapEmailSettings:
    admin_notify_to: str
    outlook_sender: str
    cc: str


def load_scrap_email_settings(conn) -> ScrapEmailSettings:
    return ScrapEmailSettings(
        admin_notify_to=app_setting_get(conn, "scrap_admin_notify_to", ""),
        outlook_sender=app_setting_get(conn, "scrap_outlook_sender", ""),
        cc=app_setting_get(conn, "scrap_email_cc", ""),
    )


def _split_emails(v: str | None) -> list[str]:
    raw = str(v or "").replace(";", ",")
    parts = [p.strip() for p in raw.split(",")]
    out: list[str] = []
    seen: set[str] = set()
    for p in parts:
        if p == "":
            continue
        key = p.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def _merge_emails(*values: str | None) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for v in values:
        for p in _split_emails(v):
            key = p.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(p)
    return out


def _log_email_attempt(
    conn,
    *,
    request_id: int | None,
    email_type: str,
    to_email: str,
    subject: str,
    result: OutlookSendResult,
) -> None:
    ensure_scrap_tables(conn)
    execute(
        conn,
        "INSERT INTO scrap_email_logs (request_id, email_type, to_email, subject, success, error_message, created_at)\n"
        "VALUES (:rid, :tp, :to, :subj, :ok, :err, NOW())",
        {
            "rid": int(request_id) if request_id is not None and int(request_id) > 0 else None,
            "tp": str(email_type),
            "to": str(to_email),
            "subj": str(subject)[:255],
            "ok": 1 if result.success else 0,
            "err": (str(result.error_message)[:5000] if result.error_message else None),
        },
    )


def send_new_request_email(conn, *, request_row: dict[str, object], settings: ScrapEmailSettings) -> OutlookSendResult:
    requester_email = str(request_row.get("email") or "").strip()
    if requester_email != "":
        to_list = _merge_emails(requester_email)
        cc_list = _merge_emails(settings.admin_notify_to, settings.cc)
    else:
        to_list = _merge_emails(settings.admin_notify_to)
        cc_list = _merge_emails(settings.cc)
    subject = f"New Scrap Pickup Request - Ticket {str(request_row.get('ticket_no') or '').strip()}"
    html_body = render_template("emails/scrap/new_request.html", r=request_row)

    logger.info(
        "Scrap email recipients: NEW_REQUEST request_id=%s to=%s cc=%s sender=%s",
        str(request_row.get("id") or ""),
        "; ".join(to_list),
        "; ".join(cc_list),
        str(settings.outlook_sender or ""),
    )
    result = send_outlook_email(
        to=tuple(to_list),
        subject=subject,
        html_body=html_body,
        sender=(settings.outlook_sender or None),
        cc=tuple(cc_list) if cc_list else None,
    )
    _log_email_attempt(
        conn,
        request_id=int(request_row.get("id") or 0) or None,
        email_type="NEW_REQUEST",
        to_email="; ".join(to_list),
        subject=subject,
        result=result,
    )
    if result.success:
        logger.info("Scrap email sent: NEW_REQUEST request_id=%s", str(request_row.get("id") or ""))
    else:
        logger.error(
            "Scrap email failed: NEW_REQUEST request_id=%s error=%s",
            str(request_row.get("id") or ""),
            str(result.error_message or ""),
        )
    return result


def send_acceptance_email(conn, *, request_row: dict[str, object], settings: ScrapEmailSettings) -> OutlookSendResult:
    to_email = str(request_row.get("email") or "").strip()
    cc_list = _merge_emails(settings.admin_notify_to, settings.cc)
    subject = "Your Scrap Pickup Request Has Been Accepted"
    html_body = render_template("emails/scrap/acceptance.html", r=request_row)

    logger.info(
        "Scrap email recipients: ACCEPTANCE request_id=%s to=%s cc=%s sender=%s",
        str(request_row.get("id") or ""),
        to_email,
        "; ".join(cc_list),
        str(settings.outlook_sender or ""),
    )
    result = send_outlook_email(
        to=to_email,
        subject=subject,
        html_body=html_body,
        sender=(settings.outlook_sender or None),
        cc=tuple(cc_list) if cc_list else None,
    )
    _log_email_attempt(
        conn,
        request_id=int(request_row.get("id") or 0) or None,
        email_type="ACCEPTANCE",
        to_email=to_email,
        subject=subject,
        result=result,
    )
    if result.success:
        logger.info("Scrap email sent: ACCEPTANCE request_id=%s", str(request_row.get("id") or ""))
    else:
        logger.error(
            "Scrap email failed: ACCEPTANCE request_id=%s error=%s",
            str(request_row.get("id") or ""),
            str(result.error_message or ""),
        )
    return result


def send_reschedule_email(conn, *, request_row: dict[str, object], settings: ScrapEmailSettings) -> OutlookSendResult:
    to_email = str(request_row.get("email") or "").strip()
    cc_list = _merge_emails(settings.admin_notify_to, settings.cc)
    subject = "Your Scrap Pickup Schedule Has Been Updated"
    html_body = render_template("emails/scrap/reschedule.html", r=request_row)

    logger.info(
        "Scrap email recipients: RESCHEDULE request_id=%s to=%s cc=%s sender=%s",
        str(request_row.get("id") or ""),
        to_email,
        "; ".join(cc_list),
        str(settings.outlook_sender or ""),
    )
    result = send_outlook_email(
        to=to_email,
        subject=subject,
        html_body=html_body,
        sender=(settings.outlook_sender or None),
        cc=tuple(cc_list) if cc_list else None,
    )
    _log_email_attempt(
        conn,
        request_id=int(request_row.get("id") or 0) or None,
        email_type="RESCHEDULE",
        to_email=to_email,
        subject=subject,
        result=result,
    )
    if result.success:
        logger.info("Scrap email sent: RESCHEDULE request_id=%s", str(request_row.get("id") or ""))
    else:
        logger.error(
            "Scrap email failed: RESCHEDULE request_id=%s error=%s",
            str(request_row.get("id") or ""),
            str(result.error_message or ""),
        )
    return result
