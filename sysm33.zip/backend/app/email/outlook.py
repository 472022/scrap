from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence

logger = logging.getLogger(__name__)

# Default account to send as (used when caller doesn't pass `sender=`)
FROM_SMTP = "canteendwd@tatamotors.com"


@dataclass(frozen=True)
class OutlookSendResult:
    success: bool
    error_message: Optional[str] = None


def _parse_recipients(v: Optional[str | Iterable[str]]) -> List[str]:
    """
    Accept a single string (comma/semicolon-separated) or an iterable of strings,
    normalize, trim, deduplicate case-insensitively, and return a list.
    """
    if v is None:
        return []

    if isinstance(v, (list, tuple, set)):
        parts = [str(x or "").strip() for x in v]
    else:
        raw = str(v or "")
        raw = raw.replace(";", ",")
        parts = [p.strip() for p in raw.split(",")]

    out: List[str] = []
    seen: set[str] = set()
    for p in parts:
        if not p:
            continue
        key = p.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(p)
    return out


def send_outlook_email(
    *,
    to: str | Sequence[str],
    subject: str,
    html_body: str,
    cc: str | Sequence[str] | None = None,
    # NEW: allow caller to specify which Outlook account (SMTP) to send from
    sender: Optional[str] = None,
) -> OutlookSendResult:
    """
    Send an email via the local Outlook (win32com) client.

    Parameters
    ----------
    to : str | Sequence[str]
        Recipient(s). Accepts a string (comma/semicolon separated) or a sequence.
    subject : str
        Subject line.
    html_body : str
        HTML body.
    cc : str | Sequence[str] | None
        CC recipient(s); optional.
    sender : str | None
        SMTP address of the account to send from. If omitted, uses FROM_SMTP.

    Returns
    -------
    OutlookSendResult
        success=True on success, otherwise contains an error_message.
    """
    mode = (os.getenv("SYMS_SCRAP_EMAIL_MODE") or "outlook").strip().lower()
    if mode in {"off", "disabled", "none"}:
        return OutlookSendResult(success=True)

    to_list = _parse_recipients(to)
    cc_list = _parse_recipients(cc)

    if not to_list:
        return OutlookSendResult(
            success=False, error_message="Missing recipient email address."
        )

    try:
        import win32com.client as win32  # type: ignore
    except Exception as exc:
        return OutlookSendResult(
            success=False,
            error_message=f"Outlook (win32com) not available: {exc}",
        )

    smtp_to_use = (sender or FROM_SMTP or "").strip()
    if not smtp_to_use:
        return OutlookSendResult(
            success=False,
            error_message="No sender SMTP configured (both `sender` and FROM_SMTP are empty).",
        )

    try:
        outlook = win32.Dispatch("Outlook.Application")
        session = outlook.Session  # MAPI namespace

        # Create mail item (so we can set SendUsingAccount)
        mail = outlook.CreateItem(0)  # 0 = olMailItem
        mail.To = "; ".join(to_list)
        if cc_list:
            mail.CC = "; ".join(cc_list)
        mail.Subject = str(subject or "")
        mail.HTMLBody = str(html_body or "")

        # Choose the requested account
        accounts = session.Accounts
        chosen = None
        for i in range(1, accounts.Count + 1):
            acct = accounts.Item(i)
            try:
                if str(acct.SmtpAddress).lower() == smtp_to_use.lower():
                    chosen = acct
                    break
            except Exception:
                # Some accounts may not expose SmtpAddress cleanly; ignore and continue
                pass

        if not chosen:
            # Build a friendly list of available accounts for diagnostics
            try:
                available = [str(accounts.Item(i).DisplayName) for i in range(1, accounts.Count + 1)]
            except Exception:
                available = ["<unavailable>"]
            raise RuntimeError(
                f"Could not find Outlook account with SMTP '{smtp_to_use}'. "
                f"Available: {available}"
            )

        # Set SendUsingAccount COM property
        # (64209 is the DISPID for the 'SendUsingAccount' property)
        mail._oleobj_.Invoke(*(64209, 0, 8, 0, chosen))
        mail.Send()

        logger.info(
            "Outlook: email sent from=%r to=%r subject=%r",
            smtp_to_use,
            "; ".join(to_list),
            subject,
        )
        return OutlookSendResult(success=True)

    except Exception as exc:
        logger.error("Outlook: send failed: %s", exc)
        return OutlookSendResult(success=False, error_message=str(exc))