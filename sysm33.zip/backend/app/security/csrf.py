from __future__ import annotations

import secrets
from functools import wraps
from typing import Any, Callable, TypeVar

from flask import Response, request, session
from werkzeug.exceptions import HTTPException

T = TypeVar("T")

class CSRFError(HTTPException):
    code = 419
    description = "Invalid CSRF token"



def csrf_init() -> None:
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)

def csrf_token() -> str:
    csrf_init()
    return str(session.get("csrf_token") or "")


def validate_csrf_or_419() -> None:
    csrf_init()
    posted = request.form.get("csrf_token", "")
    if not isinstance(posted, str) or posted == "":
        raise CSRFError()
    if secrets.compare_digest(str(session.get("csrf_token") or ""), posted) is False:
        raise CSRFError()


def csrf_protect(view: Callable[..., T]) -> Callable[..., T]:
    @wraps(view)
    def wrapped(*args: Any, **kwargs: Any) -> T:
        if request.method == "POST":
            validate_csrf_or_419()
        return view(*args, **kwargs)

    return wrapped


def csrf_field_html() -> str:
    token = csrf_token().replace('"', "&quot;")
    return f'<input type="hidden" name="csrf_token" value="{token}">'


def register_csrf_error_handlers(app: Any) -> None:
    @app.errorhandler(CSRFError)
    def _csrf_error(_: CSRFError) -> Response:
        return Response("Invalid CSRF token", status=419, mimetype="text/plain")
