from __future__ import annotations

from functools import wraps
from typing import Any, Callable, TypeVar

from flask import redirect, session

T = TypeVar("T")


def scrap_admin_login_required(view: Callable[..., T]) -> Callable[..., T]:
    @wraps(view)
    def wrapped(*args: Any, **kwargs: Any) -> T:
        if not session.get("scrap_admin_user_id"):
            return redirect("/scrap-admin/login")
        return view(*args, **kwargs)

    return wrapped

