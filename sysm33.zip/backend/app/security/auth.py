from __future__ import annotations

from functools import wraps
from typing import Any, Callable, TypeVar

from flask import redirect, session

T = TypeVar("T")


def login_required(view: Callable[..., T]) -> Callable[..., T]:
    @wraps(view)
    def wrapped(*args: Any, **kwargs: Any) -> T:
        if not session.get("user_id"):
            return redirect("/scratch/auth/login")
        if str(session.get("role") or "") == "sqpdcme":
            return redirect("/scratch/sqpdcme")
        return view(*args, **kwargs)

    return wrapped
