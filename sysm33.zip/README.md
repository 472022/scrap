# SYMS (Scrap Yard Management System)

SYMS is a Flask + MySQL web application used to manage the full scrap-material lifecycle:

1. Material inward (memo upload/manual entry)
2. Mutilation verification
3. Segregation
4. Inventory tracking and valuation
5. Outward disposal/sale
6. Reporting, dashboards, and scrap pickup request handling

The project also includes a separate scrap-request portal (`/scrap-request`) and a scrap-admin console (`/scrap-admin/*`) for request operations and notifications.

## Tech Stack

- Python 3.10+ (3.11 recommended)
- Flask
- SQLAlchemy + PyMySQL
- MySQL/MariaDB
- Jinja templates + static assets
- OpenAI SDK (used with NVIDIA-compatible endpoint for chatbot streaming)
- Outlook COM (Windows) for scrap email notifications

## Repository Structure

```text
syms/
  backend/
    app/
      modules/              # feature modules (auth, memo, reports, settings, etc.)
      db/                   # DB helper/migration-safe schema utilities
      security/             # auth/role/csrf guards
      email/                # Outlook email + scrap notification flows
      templates/            # Jinja pages
      static/               # CSS/JS/images/uploads
      utils/                # inventory, expiry, filters, caching, logging helpers
    tests/                  # pytest tests
    scripts/                # utility scripts (e.g., auth smoke test)
    requirements.txt
    run.py
  db/
    schema.sql              # full DB schema + views
    seed.sql                # base seed data
```

## Main Functional Areas

- `Auth`: `/scratch/auth/*` (main SYMS login + bootstrap admin creation)
- `Dashboard`: `/scratch/dashboard` + JSON APIs for KPIs/charts
- `Memo/Inward`: `/scratch/memo/*` (PDF parse/manual inward)
- `Mutilation`: `/scratch/mutilation/*`
- `Segregation`: `/scratch/segregation/*`
- `Inventory`: `/scratch/inventory/*`
- `Outward`: `/scratch/outward/*` (manual + bulk upload)
- `Reports`: `/scratch/reports/*` + report chart APIs + Excel export
- `Settings`: `/scratch/settings/*` (master data, pricing, opening stock, lots, rules, data tools)
- `Scrap Requests`: `/scratch/requests` (internal) + `/scrap-request` (public form)
- `Scrap Admin`: `/scrap-admin/*` (auth, request accept/reschedule, notification settings)
- `Chatbot`: `/scratch/chatbot/ask` (SSE response streaming)
- `SQPDCME`: `/scratch/sqpdcme`

## Prerequisites

- Python installed and available in PATH
- MySQL/MariaDB server running
- Windows + Outlook desktop installed (if using scrap email sending)
- Optional OCR stack for difficult memo PDFs:
  - Tesseract OCR
  - Poppler (required by `pdf2image`)

## 1) Database Setup

From your MySQL client:

```sql
SOURCE E:/projects/Tata Motors/syms/db/schema.sql;
SOURCE E:/projects/Tata Motors/syms/db/seed.sql;
```

Or equivalent command-line import.

Default DB name in code: `scrap_yard_db`.

## 2) Python Environment + Install

From `backend/`:

```powershell
cd "E:\projects\Tata Motors\syms\backend"
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install --upgrade pip
pip install -r requirements.txt
```

## 3) Environment Variables

Create `backend/.env`:

```env
SYMS_SECRET_KEY=change-me

SYMS_MYSQL_HOST=127.0.0.1
SYMS_MYSQL_PORT=3306
SYMS_MYSQL_DB=scrap_yard_db
SYMS_MYSQL_USER=root
SYMS_MYSQL_PASSWORD=

SYMS_BASE_PATH=/scratch
SYMS_SESSION_COOKIE_SECURE=0

SYMS_UPLOAD_DIR=app/static/uploads
SYMS_EXPORT_DIR=app/static/exports

SYMS_HOST=127.0.0.1
SYMS_PORT=8002
SYMS_DEBUG=1

SYMS_MAX_CONTENT_MB=50
SYMS_OUTWARD_MAX_UPLOAD_MB=50

SYMS_LOG_LEVEL=INFO
SYMS_LOG_FILE=E:/projects/Tata Motors/syms/backend/syms.log

# Chatbot (NVIDIA-compatible endpoint via OpenAI SDK)
SYMS_NVIDIA_API_KEY=

# Optional OCR fallback for memo parsing
SYMS_ENABLE_OCR=0

# Scrap email mode: outlook/off
SYMS_SCRAP_EMAIL_MODE=outlook
```

## 4) Run the App

From `backend/`:

```powershell
python run.py
```

Then open:

- `http://127.0.0.1:8002/scratch/auth/login`
- `http://127.0.0.1:8002/scrap-request`

## 5) Default Access

- If `users` table is empty, create admin using:
  - `/scratch/auth/create_admin`
- Scrap admin bootstrap:
  - `/scrap-admin/create_admin` (only when no scrap admin exists)

## 6) Testing

From `backend/`:

```powershell
pytest -q
```

Optional auth smoke script:

```powershell
python scripts/smoke_auth.py
```

## Key Upload/Data Flows

### Memo Inward

- Upload PDF or create manual memo.
- Parser extracts header + line items (`memo_number`, item rows, etc.).
- For non-auto flow with immediate mutilation, inward stock movements are posted directly.

### Mutilation -> Segregation -> Inventory

- Mutilation verification updates `memo_items` and memo status.
- Segregation creates inventory movements.
- Inventory is computed from movement-ledger views (`inventory_balances_v2`, lot views).

### Outward Disposal/Sale

- Can be entered manually or via CSV/XLSX upload.
- Supports material mapping, optional stock validation, counterparty mapping.
- Posts OUT stock movements and keeps movement audit trail.

### Pricing + Opening Stock

- Settings module supports upload templates (CSV/XLSX).
- Pricing feeds `material_rates` for valuation.
- Opening stock uploads create adjustment IN movements.

### Reporting

- Multiple operational/inventory/financial reports under `/scratch/reports`.
- Chart APIs for dashboards and trend widgets.
- Excel export implemented (`/scratch/reports/export_excel`).
- PDF export endpoint exists but returns not implemented in this build.

## Important Runtime Notes

- Email notifications use Outlook COM (`pywin32`), not SMTP.
- Chatbot route uses OpenAI Python SDK with `base_url=https://integrate.api.nvidia.com/v1`.
- Large files are governed by:
  - `SYMS_MAX_CONTENT_MB`
  - `SYMS_OUTWARD_MAX_UPLOAD_MB`
- Application logs default to `backend/syms.log`.

## Dependency Notes

`backend/requirements.txt` now includes all imported runtime Python dependencies:

- Flask, SQLAlchemy, PyMySQL
- python-dotenv
- openpyxl
- pdfplumber
- pdf2image
- pytesseract
- pywin32
- openai
- requests
- pytest

## Troubleshooting

- `Invalid CSRF token`: refresh form page and retry.
- DB connection errors: verify `SYMS_MYSQL_*` values and DB availability.
- Memo OCR issues: install Tesseract + Poppler, then set `SYMS_ENABLE_OCR=1`.
- Scrap emails not sent: ensure Outlook is installed, profile is active, and `SYMS_SCRAP_EMAIL_MODE` is not `off`.
- Missing stock/rate outputs in reports: verify pricing and movement data in settings/uploads.
