USE scrap_yard_db;

-- Admin user (password: admin) — change immediately after first login
INSERT IGNORE INTO users (username, password, role)
VALUES ('admin', 'scrypt:32768:8:1$hTXvwiUraNxfj2xf$4f9e7d9ccea0597599ef58635e304b5db2fe6c781aaa2d46209deaf11604899eebdd1af118ea34bf06daae2efcb8de9ba8dd4156e77432112b89f6345b86cea9', 'admin');

-- SQPDCME read-only user (password: sqpdcme123) — change immediately after first login
INSERT IGNORE INTO users (username, password, role)
VALUES ('sqpdcme', 'scrypt:32768:8:1$1bu4jrlnIPQqs7kF$ba1748e98412438d8c81ec6241cb77b017e9e9c0b17e49d717b14cf28d9957e7f65c0a8cf473c076fce2a19944c90d60c48298df4918af940bf3fa4350e23013', 'sqpdcme');
