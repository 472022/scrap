-- ============================================================
--  SYMS — Full Database Setup Script
--  Run this once in MySQL Workbench (or any MySQL client)
--  to create the database, all tables, views, and default users.
--
--  Steps in MySQL Workbench:
--    1. Open a new SQL tab
--    2. Paste this entire file
--    3. Click the lightning bolt (Execute All)
--
--  Default logins after setup:
--    admin    / admin       (change immediately)
--    sqpdcme  / sqpdcme123  (change immediately)
-- ============================================================

CREATE DATABASE IF NOT EXISTS scrap_yard_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE scrap_yard_db;

-- ── Core tables ──────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','supervisor','worker','sqpdcme','requestor') NOT NULL DEFAULT 'worker',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS memos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    memo_number VARCHAR(50) NOT NULL,
    memo_date DATE NOT NULL,
    source VARCHAR(100),
    vehicle_number VARCHAR(50),
    file_path VARCHAR(255),
    original_filename VARCHAR(255),
    upload_mode ENUM('AUTO_PART','NON_AUTO_PART') NOT NULL DEFAULT 'AUTO_PART',
    non_auto_mutilated TINYINT(1) NOT NULL DEFAULT 0,
    created_via ENUM('PDF','MANUAL') NOT NULL DEFAULT 'PDF',
    status ENUM('UPLOADED','VERIFIED','MUTILATION_COMPLETED') NOT NULL DEFAULT 'UPLOADED',
    verified_at DATETIME NULL,
    verified_by INT NULL,
    mismatch_count INT NOT NULL DEFAULT 0,
    mutilation_completed_at DATETIME NULL,
    mutilation_completed_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_memo_number (memo_number),
    INDEX idx_memos_memo_date (memo_date),
    INDEX idx_memos_memo_date_status (memo_date, status),
    INDEX idx_memos_status (status),
    INDEX idx_memos_verified_by (verified_by),
    INDEX idx_memos_mutilation_completed_by (mutilation_completed_by),
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (mutilation_completed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS memo_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    memo_id INT NOT NULL,
    sr INT NULL,
    part_no VARCHAR(50) NULL,
    lot_number VARCHAR(50) NULL,
    part_desc TEXT NULL,
    qty DECIMAL(12,2) NOT NULL DEFAULT 0,
    unit VARCHAR(20) NULL,
    scrap_value DECIMAL(12,2) NOT NULL DEFAULT 0,
    material_doc_no VARCHAR(50) NULL,
    cg_no VARCHAR(50) NULL,
    item_no VARCHAR(50) NULL,
    posting_datetime DATETIME NULL,
    user_name VARCHAR(50) NULL,
    sloc VARCHAR(50) NULL,
    movt_type VARCHAR(20) NULL,
    reason_for_scrap VARCHAR(255) NULL,
    actual_qty DECIMAL(12,2) NULL,
    is_mismatch TINYINT(1) NOT NULL DEFAULT 0,
    mismatch_note VARCHAR(255) NULL,
    is_mutilated TINYINT(1) NOT NULL DEFAULT 0,
    mutilated_at DATETIME NULL,
    mutilated_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (memo_id) REFERENCES memos(id) ON DELETE CASCADE,
    INDEX idx_memo_items_memo_id (memo_id),
    INDEX idx_memo_items_part_no (part_no),
    INDEX idx_memo_items_lot_number (lot_number),
    INDEX idx_memo_items_mismatch (is_mismatch),
    INDEX idx_memo_items_mutilated (memo_id, is_mutilated)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inward_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    memo_id INT,
    material_id INT NULL,
    lot_id BIGINT NULL,
    uom_id INT NULL,
    material_type VARCHAR(50) NOT NULL,
    part_number VARCHAR(50),
    part_description TEXT,
    quantity DECIMAL(10,3) NOT NULL DEFAULT 0,
    weight DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (memo_id) REFERENCES memos(id) ON DELETE SET NULL,
    INDEX idx_inward_memo_id (memo_id),
    INDEX idx_inward_material_id (material_id),
    INDEX idx_inward_material (material_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS segregation_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    inward_id INT NULL,
    memo_id INT NULL,
    material_id INT NULL,
    lot_id BIGINT NULL,
    uom_id INT NULL,
    material_type VARCHAR(50) NOT NULL,
    weight DECIMAL(10,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inward_id) REFERENCES inward_entries(id) ON DELETE SET NULL,
    FOREIGN KEY (memo_id) REFERENCES memos(id) ON DELETE SET NULL,
    INDEX idx_segregation_inward_id (inward_id),
    INDEX idx_segregation_memo_id (memo_id),
    INDEX idx_segregation_material_id (material_id),
    INDEX idx_segregation_created_at (created_at),
    INDEX idx_segregation_material (material_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS outward_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    material_id INT NULL,
    lot_id BIGINT NULL,
    uom_id INT NULL,
    material_type VARCHAR(50) NOT NULL,
    weight DECIMAL(10,2) NOT NULL DEFAULT 0,
    vehicle_number VARCHAR(50),
    recycler_name VARCHAR(100),
    counterparty_id INT NULL,
    invoice_no VARCHAR(50) NULL,
    invoice_date DATE NULL,
    customer_code VARCHAR(50) NULL,
    vendor_name VARCHAR(255) NULL,
    rate DECIMAL(12,4) NULL,
    basic_value DECIMAL(14,2) NULL,
    amount_incl_gst DECIMAL(14,2) NULL,
    truck_no VARCHAR(50) NULL,
    location VARCHAR(100) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_outward_material_id (material_id),
    INDEX idx_outward_material (material_type),
    INDEX idx_outward_invoice_date (invoice_date),
    INDEX idx_outward_invoice_no (invoice_no)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS uoms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    INDEX idx_uoms_active (is_active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS counterparties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('VENDOR','CUSTOMER') NOT NULL,
    code VARCHAR(50) NULL,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NULL,
    email VARCHAR(100) NULL,
    address VARCHAR(255) NULL,
    gstin VARCHAR(30) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    UNIQUE KEY uniq_counterparty_type_name (type, name),
    UNIQUE KEY uniq_counterparty_type_code (type, code),
    INDEX idx_counterparties_active (is_active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS material_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    name_norm VARCHAR(255) NOT NULL UNIQUE,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    expiry_days_default INT NULL,
    alert_before_days INT NOT NULL DEFAULT 30,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    INDEX idx_material_categories_active (is_active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS material_category_aliases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    alias_name VARCHAR(255) NOT NULL,
    alias_norm VARCHAR(255) NOT NULL UNIQUE,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (category_id) REFERENCES material_categories(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS materials (
    id INT AUTO_INCREMENT PRIMARY KEY,
    part_no_raw VARCHAR(100) NOT NULL,
    part_no_norm VARCHAR(100) NOT NULL UNIQUE,
    product_description VARCHAR(255) NOT NULL,
    category_id INT NULL,
    uom_id INT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS material_lots (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    lot_number VARCHAR(100) NOT NULL UNIQUE,
    material_id INT NOT NULL,
    category_id INT NULL,
    inward_date DATE NOT NULL,
    expiry_date DATE NOT NULL,
    expiry_override TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('ACTIVE','CLOSED','EXPIRED') NOT NULL DEFAULT 'ACTIVE',
    notes VARCHAR(255) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    INDEX idx_material_lots_material (material_id),
    INDEX idx_material_lots_category (category_id),
    INDEX idx_material_lots_expiry (expiry_date),
    FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES material_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS app_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT NOT NULL,
    updated_at DATETIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scrap_requests (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    source ENUM('PUBLIC','INTERNAL') NOT NULL DEFAULT 'PUBLIC',
    req_date DATE NOT NULL,
    ticket_no VARCHAR(50) NOT NULL,
    designation VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    contact_no VARCHAR(50) NOT NULL,
    department VARCHAR(100) NOT NULL,
    location VARCHAR(100) NOT NULL,
    location_other VARCHAR(100) NULL,
    shift VARCHAR(20) NOT NULL,
    weight DECIMAL(10,2) NOT NULL DEFAULT 0,
    scrap_type VARCHAR(255) NOT NULL,
    scrap_type_other VARCHAR(100) NULL,
    vehicle_type VARCHAR(50) NOT NULL,
    status ENUM('PENDING','ACCEPTED','RESCHEDULED') NOT NULL DEFAULT 'PENDING',
    accepted_at DATETIME NULL,
    rescheduled_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NULL,
    INDEX idx_scrap_requests_status_created (status, created_at),
    INDEX idx_scrap_requests_email (email),
    INDEX idx_scrap_requests_req_date (req_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scrap_admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL,
    INDEX idx_scrap_admin_users_active (is_active)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS scrap_email_logs (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id BIGINT NULL,
    email_type ENUM('NEW_REQUEST','ACCEPTANCE','RESCHEDULE') NOT NULL,
    to_email TEXT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    success TINYINT(1) NOT NULL DEFAULT 0,
    error_message TEXT NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (request_id) REFERENCES scrap_requests(id) ON DELETE SET NULL,
    INDEX idx_scrap_email_logs_req (request_id, created_at),
    INDEX idx_scrap_email_logs_type (email_type, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pricing_uploads (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    uploaded_by INT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_path VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'UPLOADED',
    rows_total INT NOT NULL DEFAULT 0,
    rows_valid INT NOT NULL DEFAULT 0,
    rows_invalid INT NOT NULL DEFAULT 0,
    upload_notes TEXT NULL,
    uploaded_at DATETIME NOT NULL,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_pricing_uploads_uploaded_at (uploaded_at),
    INDEX idx_pricing_uploads_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS opening_stock_uploads (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    uploaded_by INT NULL,
    original_filename VARCHAR(255) NOT NULL,
    stored_path VARCHAR(255) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'UPLOADED',
    rows_total INT NOT NULL DEFAULT 0,
    rows_valid INT NOT NULL DEFAULT 0,
    rows_invalid INT NOT NULL DEFAULT 0,
    upload_notes TEXT NULL,
    uploaded_at DATETIME NOT NULL,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_opening_stock_uploads_uploaded_at (uploaded_at),
    INDEX idx_opening_stock_uploads_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS material_rates (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    material_id INT NOT NULL,
    rate_per_weight DECIMAL(12,4) NOT NULL DEFAULT 0,
    effective_at DATETIME NOT NULL,
    valid_to DATETIME NULL,
    upload_id BIGINT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_material_rates_material_active (material_id, is_active),
    INDEX idx_material_rates_upload (upload_id),
    FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_movements_v2 (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ref_type ENUM('INWARD','SEGREGATION','OUTWARD','ADJUSTMENT') NOT NULL,
    ref_id BIGINT NOT NULL,
    material_id INT NOT NULL,
    uom_id INT NULL,
    weight DECIMAL(10,2) NOT NULL,
    direction ENUM('IN','OUT') NOT NULL,
    is_valued TINYINT(1) NOT NULL DEFAULT 0,
    valuation_note VARCHAR(255) NULL,
    lot_id BIGINT NULL,
    category_id INT NULL,
    expiry_date_snapshot DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_stock_mov_v2_ref (ref_type, ref_id),
    INDEX idx_stock_mov_v2_material (material_id),
    INDEX idx_stock_mov_v2_created (created_at),
    FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE RESTRICT,
    FOREIGN KEY (lot_id) REFERENCES material_lots(id) ON DELETE SET NULL,
    FOREIGN KEY (category_id) REFERENCES material_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory_movements (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ref_type ENUM('INWARD','SEGREGATION','OUTWARD') NOT NULL,
    ref_id BIGINT NOT NULL,
    from_type VARCHAR(50) NULL,
    to_type VARCHAR(50) NULL,
    uom_id INT NULL,
    weight DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_mov_ref (ref_type, ref_id),
    INDEX idx_mov_created_at (created_at),
    INDEX idx_mov_from (from_type),
    INDEX idx_mov_to (to_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS report_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_key VARCHAR(50) NOT NULL,
    filters_json TEXT NOT NULL,
    paper VARCHAR(10) NOT NULL DEFAULT 'A4',
    orientation VARCHAR(10) NOT NULL DEFAULT 'portrait',
    template VARCHAR(30) NOT NULL DEFAULT 'default',
    frequency VARCHAR(20) NOT NULL DEFAULT 'daily',
    next_run_at DATETIME NOT NULL,
    enabled TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_report_schedules_next_run (enabled, next_run_at),
    INDEX idx_report_schedules_key (report_key),
    INDEX idx_report_schedules_created_by (created_by)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS report_exports (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    schedule_id INT NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    generated_at DATETIME NOT NULL,
    generated_by INT NULL,
    FOREIGN KEY (schedule_id) REFERENCES report_schedules(id) ON DELETE CASCADE,
    FOREIGN KEY (generated_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_report_exports_schedule (schedule_id, generated_at),
    INDEX idx_report_exports_generated_by (generated_by)
) ENGINE=InnoDB;

-- ── Views ─────────────────────────────────────────────────────

DROP VIEW IF EXISTS inventory_balances_v2;
CREATE VIEW inventory_balances_v2 AS
SELECT
    m.id AS material_id,
    m.uom_id,
    COALESCE(u.code, '') AS uom_code,
    m.part_no_norm,
    m.product_description,
    COALESCE(SUM(CASE WHEN sm.direction = 'IN' THEN sm.weight ELSE -sm.weight END), 0) AS balance_weight
FROM materials m
LEFT JOIN uoms u ON u.id = m.uom_id
LEFT JOIN stock_movements_v2 sm ON sm.material_id = m.id
GROUP BY m.id, m.uom_id, u.code, m.part_no_norm, m.product_description;

DROP VIEW IF EXISTS inventory_lot_balances_v2;
CREATE VIEW inventory_lot_balances_v2 AS
SELECT
    sm.material_id,
    sm.lot_id,
    sm.category_id,
    sm.uom_id,
    COALESCE(SUM(CASE WHEN sm.direction = 'IN' THEN sm.weight ELSE -sm.weight END), 0) AS balance_weight
FROM stock_movements_v2 sm
GROUP BY sm.material_id, sm.lot_id, sm.category_id, sm.uom_id;

DROP VIEW IF EXISTS expiry_alerts_vw;
CREATE VIEW expiry_alerts_vw AS
SELECT
    l.id AS lot_id,
    l.lot_number,
    l.material_id,
    m.part_no_norm,
    m.product_description,
    COALESCE(c.name, '') AS category_name,
    l.inward_date,
    l.expiry_date,
    DATEDIFF(l.expiry_date, CURDATE()) AS days_to_expiry,
    m.uom_id,
    COALESCE(u.code, '') AS uom_code,
    COALESCE(ilb.balance_weight, 0) AS balance_weight,
    CASE
        WHEN COALESCE(ilb.balance_weight, 0) <= 0 THEN 'OK'
        WHEN DATEDIFF(l.expiry_date, CURDATE()) < 0 THEN 'EXPIRED'
        WHEN DATEDIFF(l.expiry_date, CURDATE()) <= COALESCE(
          c.alert_before_days,
          (SELECT CAST(setting_value AS SIGNED) FROM app_settings WHERE setting_key = 'expiry_alert_before_days_default' LIMIT 1),
          30
        ) THEN 'NEAR_EXPIRY'
        ELSE 'OK'
    END AS alert_state
FROM material_lots l
JOIN materials m ON m.id = l.material_id
LEFT JOIN uoms u ON u.id = m.uom_id
LEFT JOIN material_categories c ON c.id = COALESCE(l.category_id, m.category_id)
LEFT JOIN inventory_lot_balances_v2 ilb ON ilb.lot_id = l.id AND ilb.uom_id = m.uom_id;

DROP VIEW IF EXISTS inventory_balances;
CREATE VIEW inventory_balances AS
SELECT
    material_type,
    uom_id,
    COALESCE(u.code, '') AS uom_code,
    SUM(delta_weight) AS balance_weight
FROM (
    SELECT to_type AS material_type, uom_id, weight AS delta_weight
    FROM inventory_movements WHERE to_type IS NOT NULL
    UNION ALL
    SELECT from_type AS material_type, uom_id, -weight AS delta_weight
    FROM inventory_movements WHERE from_type IS NOT NULL
) t
LEFT JOIN uoms u ON u.id = t.uom_id
GROUP BY material_type, uom_id, u.code;

-- ── Deferred FK constraints ────────────────────────────────────

ALTER TABLE materials
    ADD CONSTRAINT IF NOT EXISTS fk_materials_category FOREIGN KEY (category_id) REFERENCES material_categories(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_materials_uom FOREIGN KEY (uom_id) REFERENCES uoms(id) ON DELETE SET NULL;

ALTER TABLE inward_entries
    ADD CONSTRAINT IF NOT EXISTS fk_inward_material FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_inward_lot FOREIGN KEY (lot_id) REFERENCES material_lots(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_inward_uom FOREIGN KEY (uom_id) REFERENCES uoms(id) ON DELETE SET NULL;

ALTER TABLE segregation_entries
    ADD CONSTRAINT IF NOT EXISTS fk_segr_material FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_segr_lot FOREIGN KEY (lot_id) REFERENCES material_lots(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_segr_uom FOREIGN KEY (uom_id) REFERENCES uoms(id) ON DELETE SET NULL;

ALTER TABLE outward_entries
    ADD CONSTRAINT IF NOT EXISTS fk_outward_material FOREIGN KEY (material_id) REFERENCES materials(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_outward_lot FOREIGN KEY (lot_id) REFERENCES material_lots(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_outward_uom FOREIGN KEY (uom_id) REFERENCES uoms(id) ON DELETE SET NULL,
    ADD CONSTRAINT IF NOT EXISTS fk_outward_counterparty FOREIGN KEY (counterparty_id) REFERENCES counterparties(id) ON DELETE SET NULL;

-- ── Default users (idempotent) ─────────────────────────────────

-- admin / admin  (hashed with werkzeug scrypt)
INSERT IGNORE INTO users (username, password, role)
VALUES ('admin', 'scrypt:32768:8:1$hTXvwiUraNxfj2xf$4f9e7d9ccea0597599ef58635e304b5db2fe6c781aaa2d46209deaf11604899eebdd1af118ea34bf06daae2efcb8de9ba8dd4156e77432112b89f6345b86cea9', 'admin');

-- sqpdcme / sqpdcme123  (hashed with werkzeug scrypt)
INSERT IGNORE INTO users (username, password, role)
VALUES ('sqpdcme', 'scrypt:32768:8:1$1bu4jrlnIPQqs7kF$ba1748e98412438d8c81ec6241cb77b017e9e9c0b17e49d717b14cf28d9957e7f65c0a8cf473c076fce2a19944c90d60c48298df4918af940bf3fa4350e23013', 'sqpdcme');

-- ── Done ──────────────────────────────────────────────────────
SELECT 'SYMS database setup complete.' AS status;
