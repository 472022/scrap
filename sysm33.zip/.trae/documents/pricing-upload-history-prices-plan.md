# Plan: Pricing upload history should show uploaded prices + validity (from/to)

## 1) Current project structure (quick understanding)

- Backend: Flask app serving routes under `/scratch/...` (no PHP). Main entry: `backend/run.py`, modules in `backend/app/modules/*`.
- UI: Server-rendered Jinja templates in `backend/app/templates/*` with shared layout at `templates/app/layout.html`.
- DB: MySQL/MariaDB; schema in `db/schema.sql`. DB access helpers in `backend/app/db/*`.
- Pricing module:
  - Page: `GET /scratch/settings/pricing` renders `templates/settings/pricing.html`.
  - Upload: `POST /scratch/settings/pricing/upload` parses CSV/XLSX and inserts into:
    - `pricing_uploads` (file-level audit log)
    - `material_rates` (price rows, linked by `upload_id`)

## 2) What to change (requirements)

1) On `/scratch/settings/pricing`, the “Upload History” section must show uploaded price rows (not just file upload metadata).
2) Each uploaded price row must show validity dates (Valid From / Valid To).
3) Validity must be read from the uploaded Excel/CSV (not auto-filled only with upload timestamp).
4) Users must be able to manually edit an uploaded price if it is wrong (rate and validity).

## 3) Assumptions (so we can implement without rework)

- “Active rate” behavior stays the same: the app uses `material_rates.is_active = 1` for valuation and reports.
- Validity is primarily for display + audit + manual correction; we will not change valuation logic to be date-range based in this change.
- Admin-only: pricing upload and manual edits stay protected by admin check + CSRF, matching the existing settings module style.

## 4) Data model changes (DB)

### 4.1 Minimal safe schema change

- Keep existing `material_rates.effective_at` but treat it as “Valid From” (because it is already stored and referenced in queries).
- Add a new nullable column for “Valid To”.

Changes:
- `ALTER TABLE material_rates ADD COLUMN valid_to DATETIME NULL AFTER effective_at;`

Also update `db/schema.sql` so fresh installs include `valid_to`.

### 4.2 Backward compatibility

- Existing rows will have `valid_to = NULL`. UI will display it as blank/“-”.

## 5) Import changes (upload parsing)

### 5.1 Sheet format update

- Add columns to supported formats:
  - `Valid From` (or `From`, `Effective From`, `Start Date`)
  - `Valid To` (or `To`, `Effective To`, `End Date`)

### 5.2 Parsing & validation rules

- Parse dates from:
  - XLSX: handle Excel date types (datetime/date) and formatted strings.
  - CSV: parse common formats (`YYYY-MM-DD`, `DD-MM-YYYY`, `DD/MM/YYYY`, `YYYY-MM-DD HH:MM:SS`).
- Validations:
  - Valid From is required (reject row if missing/unparseable).
  - Valid To optional; if present must be >= Valid From.
- Store:
  - `effective_at = valid_from`
  - `valid_to = valid_to` (nullable)

### 5.3 Sample file update

- Update `/scratch/settings/pricing/sample` (CSV + XLSX) headers and example rows to include `Description` and validity columns, matching what the importer actually requires.

## 6) UI changes (pricing page)

### 6.1 Replace “Upload History” table with “Uploaded Prices”

- Query recent uploaded prices (e.g., last 500) joined to:
  - `materials` (part no + description)
  - `pricing_uploads` (filename, uploaded_at, status)
- Show columns:
  - Rate Row ID
  - Upload ID / Uploaded At / Filename
  - Part No (raw/norm) + Description
  - Rate
  - Valid From / Valid To
  - Active (is_active)
  - Actions (Edit)

### 6.2 Manual edit flow

- Add an admin-only POST endpoint to update a `material_rates` row:
  - Inputs: `rate_id`, `rate_per_weight`, `valid_from`, `valid_to`
  - Validations same as upload (numeric rate, valid dates)
  - CSRF protected
- UI: inline edit (small form row) or modal edit (preferred for cleanliness).

### 6.3 Optional filters (nice-to-have if low effort)

- Add quick filters to reduce noise:
  - Search by Part No / Description
  - Filter by Upload ID
  - Show only Active rows

## 7) Verification steps

- Database:
  - Apply `ALTER TABLE` on the running DB and confirm `valid_to` exists.
- Upload:
  - Upload sample XLSX and confirm rows insert with `effective_at` and `valid_to`.
- Page:
  - Confirm `/scratch/settings/pricing` shows uploaded price rows with validity.
  - Confirm editing a row updates the DB and reflects immediately.
- Regression:
  - Run backend tests (`pytest`) and do quick manual smoke-check for reports/dashboard that depend on `material_rates.is_active`.

## 8) Files expected to change

- Backend routes: `backend/app/modules/settings/routes.py`
- Pricing template: `backend/app/templates/settings/pricing.html`
- DB schema reference: `db/schema.sql`

