# Plan: Update Scrap Form Options (Scrap Type + Vehicle Type)

## Goal

Update the **Scrap Request Form** so:
- **Scrap Type** options are only: `Metal Scrap`, `Aluminum`, `Wood`, `Cardboard`, `Plastic`, `Other` (with textbox).
- **Vehicle Type** options are only: `Tata 407`, `Tractor`.
- Update any related pages so the system stays consistent (public form, internal form, scrap admin reschedule, and any UI/email pages that show these labels).

## Current State (What I’ll Align)

- Public form currently has extra scrap types (MS/SS/Copper/Rubber/etc.) and extra vehicle types (Tata Ace/Pickup/Truck/Container).
- Internal form already uses the intended reduced list for scrap types and vehicles.
- Scrap-admin reschedule form currently still has the old vehicle list, so it must be updated to match.

## Implementation Steps

1. **Confirm all current option lists**
   - Review these templates to ensure we update all relevant UI sources:
     - `backend/app/templates/requests/public.html`
     - `backend/app/templates/requests/index.html`
     - `backend/app/templates/scrap_admin/reschedule.html`

2. **Update public scrap request form**
   - Edit `requests/public.html`:
     - Replace Scrap Type checkbox list with only:
       - `Metal Scrap`, `Aluminum`, `Wood`, `Cardboard`, `Plastic`, `Other`
     - Keep “Other” textbox behavior (show textbox only when Other checked; textbox required only then).
     - Replace Vehicle Required dropdown with only:
       - `Tata 407`, `Tractor`

3. **Update scrap-admin reschedule form**
   - Edit `scrap_admin/reschedule.html`:
     - Replace Vehicle Required dropdown with only:
       - `Tata 407`, `Tractor`
   - Keep current “Location” and “Shift” reschedule controls intact.

4. **Update any “related pages” that display these values**
   - Scan for any other hard-coded vehicle/scrap-type option lists:
     - If found, update to match the new canonical lists.
   - Verify email templates do not hard-code old labels (they currently print DB values, so no change expected unless labels are embedded).

5. **Verification**
   - Run backend tests (`pytest`).
   - Manually verify in browser:
     - `/scrap-request` shows only the new Scrap Type and Vehicle Type options.
     - `/scratch/requests` remains correct (should already match).
     - `/scrap-admin/requests/<id>/reschedule` shows updated Vehicle Type options and saves successfully.

## Deliverables

- Updated `public.html` options (scrap type + vehicle type).
- Updated scrap-admin `reschedule.html` vehicle type options.
- Confirmed no other pages are left with old option lists.
- Tests passing and manual UI verification complete.

