# Plan: Outward (Disposal/Sale) Excel bulk upload + list format + filters

## 1) Current outward module (what exists)

- List: `GET /scratch/outward/list` renders `templates/outward/list.html`, reading from `outward_entries` joined with `materials`, `uoms`, `counterparties`, `material_rates` for rate.
- Add/Edit/Delete: `/scratch/outward/add`, `/scratch/outward/edit`, `/scratch/outward/delete`
  - These write inventory movement rows (reduces stock) via `stock_movements_v2` and `inventory_movements`.
- Current DB table: `outward_entries` only stores: material_id, uom_id, weight, vehicle_number, recycler_name/counterparty_id, created_at.

## 2) Goal (requested updates)

1) Add an **Excel/CSV bulk upload** option for Outward (Disposal/Sale) so users can upload many sale rows at once.
2) The table shown in `/scratch/outward/list` should match the business format:
   - S.No, Part No, Product Description, Rate, UOM, Weight, Invoice No., Invoice Date, Customer Code, Vendor Name, Basic value, Amount (incl GST), Truck no, Location
3) Add **search + filters** so users can quickly find a row (and filter by date range).

Confirmed decisions:
- Bulk upload **must affect stock** (create outward entries + OUT movements like manual add).
- Date filters should use **Invoice Date**.

## 3) Data model changes (DB)

### 3.1 Extend `outward_entries` to store invoice & sale metadata

Add columns (all nullable for backward compatibility):
- `invoice_no` VARCHAR(50) NULL
- `invoice_date` DATE NULL
- `customer_code` VARCHAR(50) NULL
- `vendor_name` VARCHAR(255) NULL (snapshot text; also keep `counterparty_id` when matched)
- `rate` DECIMAL(12,4) NULL (snapshot from Excel, not dependent on active pricing)
- `basic_value` DECIMAL(14,2) NULL
- `amount_incl_gst` DECIMAL(14,2) NULL
- `truck_no` VARCHAR(50) NULL (keep `vehicle_number` for old flows; map truck_no ↔ vehicle_number)
- `location` VARCHAR(100) NULL

Indexes:
- `INDEX idx_outward_invoice_date (invoice_date)`
- `INDEX idx_outward_invoice_no (invoice_no)`

### 3.2 Keep existing behavior intact

- Existing rows will show blanks for the new columns.
- No changes to stock movement schema.

## 4) Excel/CSV upload feature

### 4.1 New routes

- `GET /scratch/outward/sample?format=xlsx|csv`
  - Downloads a sample file with the exact columns and 2 example rows.
- `POST /scratch/outward/upload`
  - Uploads CSV/XLSX and imports rows into `outward_entries`, and writes stock OUT movements.

### 4.2 Upload UI placement

- Add an “Upload Sale Data” panel on top of `/scratch/outward/list`:
  - File picker + upload button
  - Sample download buttons (XLSX/CSV)
  - Upload options:
    - “Auto-create missing UOM codes” (on by default)
    - “Create missing Vendors/Customers” (on by default)
    - “Allow negative stock” (off by default; when off, rejects rows that exceed available stock)

### 4.3 Column mapping (tolerant headers)

Supported header variants (trimmed, case-insensitive, underscores ignored):
- Part No: `Part No`, `Part`, `Part_Name`, `PartNo`, `Part Number`
- Product Description: `Product Description`, `Description`
- Rate: `Rate`
- UOM: `UOM`, `Unit`
- Weight: `Weight`, `Qty`, `Quantity`
- Invoice No.: `Invoice No.`, `Invoice No`, `Invoice`
- Invoice Date: `Invoice Date`, `Date`
- Customer Code: `Customer Code`, `Customer`
- Vendor Name: `Vendor Name`, `Vendor`
- Basic value: `Basic value`, `Basic Value`
- Amount (incl GST): `Amount (incl GST)`, `Amount`, `Gross Amount`
- Truck no: `Truck no`, `Truck No`, `Vehicle No`, `Vehicle`
- Location: `Location`

### 4.4 Validations (per row)

Required:
- Part No (must map to an existing `materials.part_no_norm`)
- Weight > 0
- Invoice Date parseable
- Vendor Name present (either matched to counterparty or stored in `vendor_name`)

Optional but parsed if present:
- Rate, basic_value, amount_incl_gst

Stock checks:
- If “Allow negative stock” is off, validate `material_balance_v2(material_id) >= weight`.

### 4.5 DB writes per row (transactional)

For each valid row:
- Resolve material by normalized Part No.
- Resolve/ensure UOM from uploaded UOM (or default KG).
- Resolve counterparty by name/code (create if enabled), store both:
  - `counterparty_id` when matched/created
  - `vendor_name` snapshot text
- Insert into `outward_entries` including invoice metadata fields.
- Write stock movement rows exactly like manual Add:
  - `inventory_add_movement("OUTWARD", outward_id, material_type, ...)`
  - `stock_v2_add_movement("OUTWARD", outward_id, material_id, weight, "OUT", ...)`

Error handling:
- If file parsing fails: show flash error.
- For row-level failures: count invalid and show up to 10 notes; still import valid rows.

## 5) Update manual Add/Edit forms to match the same format

Update:
- `templates/outward/add.html` and `templates/outward/edit.html`
- `outward_add_process` and `outward_edit` POST handling

Add fields to the form:
- Invoice No, Invoice Date, Customer Code, Vendor Name (existing counterparty selection still used), Rate, Basic value, Amount (incl GST), Truck no, Location

Behavior:
- Truck no maps to existing `vehicle_number` + new `truck_no` (keep them consistent).
- Vendor Name uses the selected counterparty if chosen; otherwise use free-text.

## 6) Update list table format + search/filters

### 6.1 Table columns (match requested format)

Replace current list columns with:
- S.No (row index)
- Part No
- Product Description
- Rate
- UOM
- Weight
- Invoice No.
- Invoice Date
- Customer Code
- Vendor Name
- Basic value
- Amount (incl GST)
- Truck no
- Location
- Actions (Edit/Delete)

Rate sourcing:
- Prefer `outward_entries.rate` (uploaded/manual snapshot)
- Fall back to active `material_rates.rate_per_weight` when snapshot is NULL

### 6.2 Filters (server-side)

Add filter bar above the table:
- Date From / Date To (filters by `invoice_date`; fallback to `DATE(created_at)` when invoice_date is NULL)
- Search box (matches: Part No, Description, Invoice No, Vendor Name, Customer Code, Truck no, Location)
- Optional quick dropdown filters:
  - Location
  - Vendor/Customer

Implementation:
- Change list route to accept query params and add `WHERE` clauses.
- Add `LIMIT` (e.g., 700) for performance, similar to report pages.

## 7) Files expected to change

- Outward routes: `backend/app/modules/outward/routes.py`
- Outward templates:
  - `backend/app/templates/outward/list.html`
  - `backend/app/templates/outward/add.html`
  - `backend/app/templates/outward/edit.html`
- DB schema: `db/schema.sql`

## 8) Verification checklist

- DB: migrate existing DB with `ALTER TABLE outward_entries ...` and confirm new columns exist.
- Upload: import a sample XLSX using the provided format and confirm:
  - rows appear in `/scratch/outward/list`
  - date filters work by Invoice Date
  - stock decreases (inventory balances reflect movements)
- Manual Add/Edit: create/edit a row and confirm the new fields render and save.
- Regression: run `pytest` and smoke-check outward report and dashboard totals.

