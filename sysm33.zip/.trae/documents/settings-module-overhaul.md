# Plan: Refactor and Improve Main Admin Settings

This plan outlines the steps to restructure and enhance the admin settings module in the SYMS project, focusing on better navigation, smart data import, and simplified logic (removing expiry complexity).

## 1. Sidebar & Navigation Restructuring
- **File**: [layout.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/app/layout.html)
- **Action**: Update the sidebar to group all settings under a single "Settings" menu with the following sub-items:
    - General (Overview)
    - Pricing & Data Import (CORE)
    - Materials & Categories
    - Parts Management
    - Inventory & Lots
    - Master Data (UOM + Counterparties)
    - System Rules
    - Audit & Logs

## 2. CORE: Pricing & Data Import
- **File**: [routes.py](file:///e:/projects/Tata Motors/syms update/backend/app/modules/settings/routes.py), [pricing.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/settings/pricing.html)
- **Backend Changes**:
    - Update `pricing_upload` to accept new options: `create_materials`, `create_categories`, `create_counterparties`, `update_prices`, `auto_map_uom`.
    - Implement "Smart Logic": If an entity (Material, Category, Vendor/Customer) doesn't exist, create it on the fly if the respective option is enabled.
    - Create a route to generate and download a sample XLSX/CSV file with the required headers.
- **Frontend Changes**:
    - Refactor `pricing.html` into a card-based UI.
    - Card 1: Upload box with drag & drop.
    - Card 2: Checkbox options for the upload logic.
    - Card 3: Manual entry fallback (Modal or simple form).
    - Card 4: Upload history with "Rollback" functionality (if feasible, otherwise "View Detail").

## 3. Simplified Materials & Categories
- **File**: [routes.py](file:///e:/projects/Tata Motors/syms update/backend/app/modules/settings/routes.py), [categories.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/settings/categories.html)
- **Action**: 
    - Remove all expiry-related fields (`expiry_days_default`, `alert_before_days`) from the UI and backend processing.
    - Simplify the category form to just "Name" and "Description".
    - Ensure Materials management allows easy category and UOM assignment.

## 4. Parts Management
- **File**: [parts.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/settings/parts.html)
- **Action**: 
    - Update the UI to show two clear sections: "Manual Entry" and "Bulk Upload".
    - Ensure the bulk upload for parts follows the same "Smart Logic" as the pricing upload.

## 5. Inventory & Lot Management
- **File**: [lots.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/settings/lots.html)
- **Action**:
    - Remove expiry logic from the lot creation form and table.
    - Focus on Lot ID, Material, Quantity, and Status (Active/Closed).

## 6. Master Data (Combined Section)
- **File**: [uoms.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/settings/uoms.html), [counterparties.html](file:///e:/projects/Tata Motors/syms update/backend/app/templates/settings/counterparties.html)
- **Action**:
    - Group UOM and Counterparty management.
    - Add a bulk upload feature for Counterparties (Vendors/Customers) to `routes.py`.

## 7. System Rules & Audit Logs
- **File**: [routes.py](file:///e:/projects/Tata Motors/syms update/backend/app/modules/settings/routes.py), `backend/app/templates/settings/rules.html` (New)
- **Action**:
    - Implement "System Rules" for global toggles (Currency, Decimal Precision, Auto-create master data toggle).
    - Implement a basic "Audit Logs" view to track manual changes and uploads.

## 8. UX & Styling
- **Action**: Apply consistent Bootstrap Card styling across all settings pages. Use shadows, rounded corners, and colored headers for a professional SaaS feel.

## 9. Bonus: Auto Sync Feature
- **Action**: Add a toggle in "System Rules" to enable "Auto Sync from Pricing Sheet". If enabled, manual edits that conflict with the master pricing sheet will be restricted.
