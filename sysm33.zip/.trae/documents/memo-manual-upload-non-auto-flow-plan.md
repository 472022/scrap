# Plan: Memo Module Manual Upload + Auto/Non‑Auto Part Flow + Sidebar Rename

Goal: In `/scratch/memo/` add (1) a manual upload option, (2) a classification option to mark uploads as **Auto Part** vs **Non‑Auto Part**, and for **Non‑Auto Part** allow **Mutilated** vs **Non‑Mutilated** behavior. If **Non‑Auto Part + Mutilated**, the upload should **directly add stock into Inventory** (skip the existing mutilation → segregation process). Also rename sidebar item **“Memo (Inward)” → “Material (Inward)”**.

This plan is written to fit the current repo’s existing workflow:
- Memo upload creates `memos` + `memo_items` ([memo/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/memo/routes.py))
- Mutilation verify marks `memo_items.is_mutilated` and sets `memos.status='MUTILATION_COMPLETED'` ([mutilation/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/mutilation/routes.py))
- Segregation is where stock is actually added (`stock_movements_v2`) ([segregation/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/segregation/routes.py), [domain.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/utils/domain.py))

## 1) Sidebar Rename (UI only)
- **File**: [layout.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/app/layout.html)
- Change the label from **“Memo (Inward)”** to **“Material (Inward)”** (keep the link `/scratch/memo/list` unchanged).

## 2) Data Model / DB Support (Store upload classification)
We need to remember for each memo:
- Is this **Auto Part** or **Non‑Auto Part**?
- If **Non‑Auto Part**, is it **Mutilated** or **Non‑Mutilated**?
- Whether it was created by **PDF upload** or **Manual upload** (optional but helpful for auditing).

### 2.1 DB columns (recommended)
- **File**: [schema.sql](file:///e:/projects/Tata%20Motors/syms%20update/db/schema.sql)
- Add columns to `memos` (safe defaults so existing data is valid):
  - `upload_mode` ENUM('AUTO_PART','NON_AUTO_PART') NOT NULL DEFAULT 'AUTO_PART'
  - `non_auto_mutilated` TINYINT(1) NOT NULL DEFAULT 0
  - `created_via` ENUM('PDF','MANUAL') NOT NULL DEFAULT 'PDF'

### 2.2 Runtime “ensure” (so environments don’t break)
This repo does not have formal migrations; the existing pattern is “ensure table/columns” for scrap tables ([scrap_schema.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/db/scrap_schema.py)).
- Create `backend/app/db/memo_schema.py` with:
  - `ensure_memo_columns(conn)` which:
    - Adds the above columns using `ALTER TABLE ... ADD COLUMN ...` guarded by “column exists” checks.
- Call `ensure_memo_columns(conn)` at the start of memo actions (list/upload/manual/process) inside [memo/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/memo/routes.py).

## 3) Manual Upload UI + Classification UI (Memo Upload page)
### 3.1 Update upload page
- **File**: `backend/app/templates/memo/upload.html`
- Add a UI toggle to choose:
  - **Upload Type**: PDF Upload vs Manual Upload
  - **Part Type**: Auto Part vs Non‑Auto Part
  - If Non‑Auto Part: show **Mutilated?** (Yes / No)
- For clarity:
  - If Non‑Auto Part + Mutilated: show helper text “Stock will be added to Inventory directly (no segregation step).”
  - If Non‑Auto Part + Non‑Mutilated: show helper text “Will follow existing mutilation → segregation flow.”

### 3.2 Manual upload form
- **New template**: `backend/app/templates/memo/manual_upload.html` (or embedded in `upload.html` as a tab)
- Inputs:
  - Memo header: memo_number, memo_date, source, vehicle_number
  - Line items (repeatable rows): part_no, part_desc, qty, unit (+ optional fields you already store in `memo_items` if needed)
- Provide “Add Row”/“Remove Row” JS similar to existing simple table forms used elsewhere.

## 4) Manual Upload Backend (Create memos + memo_items)
- **File**: [memo/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/memo/routes.py)
- Add routes:
  - `GET /scratch/memo/manual` → renders manual form
  - `POST /scratch/memo/manual_process` → validates and inserts `memos` + `memo_items`
- Persist the classification flags on `memos`:
  - `upload_mode`, `non_auto_mutilated`, `created_via='MANUAL'`

## 5) Non‑Auto Part “Direct to Inventory” Behavior
Requirement: **If Non‑Auto Part + Mutilated**, after upload it should **directly store into inventory** and skip “mutilation verify” + “segregation add”.

### 5.1 Inventory write mechanism (must update stock_movements_v2)
The Inventory list uses `inventory_balances_v2` which sums `stock_movements_v2` ([schema.sql](file:///e:/projects/Tata%20Motors/syms%20update/db/schema.sql)). Therefore, the direct path must insert `stock_movements_v2` rows.

Implementation approach (consistent with existing patterns):
- For each memo item:
  1) Resolve/create `materials` row (if missing) using normalized part number (reuse normalization approach from settings import).
  2) Resolve/create `uoms` row (by `unit` code).
  3) Insert an `inward_entries` record (so we have a stable `ref_id` for stock movements).
  4) Call `stock_v2_add_movement('INWARD', inward_entry_id, material_id, weight, 'IN', ...)` ([domain.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/utils/domain.py)).

### 5.2 Memo status updates for the direct path
Since direct path skips segregation, we still want memo to appear “done”:
- Set `memo_items.is_mutilated=1` for all items
- Set `memos.status='VERIFIED'`, `verified_at=NOW()`, `verified_by=<current user>`
- Redirect user to `/scratch/inventory/list` (or memo list) with success message.

### 5.3 Apply to both PDF upload and Manual upload
Update both:
- `POST /scratch/memo/upload_process` (PDF path)
- `POST /scratch/memo/manual_process` (manual path)
…to check:
- If `upload_mode='NON_AUTO_PART'` AND `non_auto_mutilated=1` → execute direct inventory logic
- Else → continue existing redirect to mutilation verify: `/scratch/mutilation/verify?id=<memo_id>`

## 6) Non‑Auto Part + Non‑Mutilated Behavior (Use existing flow)
If `upload_mode='NON_AUTO_PART'` AND `non_auto_mutilated=0`:
- Do not auto-add to inventory
- Keep current pipeline:
  - Redirect to mutilation verify
  - Then segregation step adds inventory as usual

## 7) Verification Checklist (After Implementation)
- Open `/scratch/memo/upload`:
  - PDF upload works
  - Manual upload form submits
  - Options show/hide correctly
- Test Non‑Auto Part + Mutilated:
  - Upload creates memo + memo_items
  - Inventory balance increases in `/scratch/inventory/list`
  - Memo shows as VERIFIED in `/scratch/memo/list`
- Test Non‑Auto Part + Non‑Mutilated:
  - Redirect goes to `/scratch/mutilation/verify?id=...`
  - Segregation works as before
- Confirm sidebar label is “Material (Inward)”

