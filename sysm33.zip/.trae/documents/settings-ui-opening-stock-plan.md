# Plan: Settings UI Polish + Opening Stock Upload

Goal: Improve the current Settings UI to match the overall platform theme, and replace the “Inventory & Lots” Settings item with an “Opening Stock Upload” flow that updates Inventory balances.

## 1) UI Consistency (Match Platform Theme)
- **Reference UI**: The Dashboard header/cards pattern in [index.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/dashboard/index.html) and global styling in [custom.css](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/static/assets/ui/custom.css).
- **Standardize page headers** across Settings pages to the dashboard style:
  - Use the same header layout (`fw-bold`, breadcrumb-like muted prefix, optional subtitle).
  - Apply consistent spacing (`mb-4`, `row g-4`) and card structure (`border-0 shadow-sm` where used elsewhere).
- **Remove ad-hoc styling** in Settings templates and rely on the platform CSS:
  - Replace inline `<style>` blocks in Settings templates (e.g. in [pricing.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/pricing.html)) by moving reusable utilities into [custom.css](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/static/assets/ui/custom.css) (e.g., `border-dashed`, `cursor-pointer`).
  - Replace large inline `<script>` blocks (search filtering / drag-drop) with a small dedicated JS file loaded by Settings pages, following the pattern of existing UI JS under `backend/app/static/assets/ui/js/`.
- **Update card visual language**:
  - Prefer `avatar + bg-label-*` icon blocks (as used in dashboard KPI cards) rather than heavy `bg-primary` headers on every card.
  - Keep badges consistent with existing tables (e.g., `bg-label-success`, `bg-label-danger`) like [list.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/inventory/list.html).

Pages to polish:
- [general.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/general.html)
- [pricing.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/pricing.html)
- [categories.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/categories.html)
- [parts.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/parts.html)
- [uoms.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/uoms.html)
- [counterparties.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/counterparties.html)
- [rules.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/rules.html)
- [logs.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/logs.html)

## 2) Settings Navigation Change (Remove Lots, Add Opening Stock Upload)
- **File**: [layout.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/app/layout.html)
- Replace the Settings sub-item:
  - Remove: `Inventory & Lots` linking to `/scratch/settings/lots`
  - Add: `Opening Stock Upload` linking to `/scratch/settings/opening-stock`
- Ensure active highlighting works with `isActive('/settings/opening-stock')`.
- Keep the main Inventory module unchanged (Inventory menu outside Settings remains as-is).

## 3) Opening Stock Upload (Backend)
The Inventory screen reads balances from `inventory_balances_v2`, which sums rows in `stock_movements_v2` ([schema.sql](file:///e:/projects/Tata%20Motors/syms%20update/db/schema.sql)). To reflect opening stock, we will insert **ADJUSTMENT / IN** movements into `stock_movements_v2`.

### 3.1 Database Support
- **File**: [schema.sql](file:///e:/projects/Tata%20Motors/syms%20update/db/schema.sql)
- Add a new table to track opening stock imports:
  - `opening_stock_uploads` with fields similar to `pricing_uploads` (id, uploaded_by, original_filename, stored_path, status, rows_total, rows_valid, rows_invalid, upload_notes, uploaded_at).
- Rationale: `stock_movements_v2` requires a non-null `ref_id`. We will use `opening_stock_uploads.id` as `ref_id` for `ref_type='ADJUSTMENT'` rows.

### 3.2 Routes & Logic
- **File**: [settings/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/settings/routes.py)
- Add new endpoints:
  - `GET /scratch/settings/opening-stock` (page)
  - `POST /scratch/settings/opening-stock/upload` (process upload)
  - `GET /scratch/settings/opening-stock/sample?format=csv|xlsx` (download sample sheet)
  - Optional: `GET /scratch/settings/opening-stock/history` (JSON list for future)
- Parsing logic (CSV/XLSX):
  - Sample columns:
    - `Part_No` (or `Part_Name`) (required)
    - `Quantity` (required)
    - `UOM` (recommended)
    - `Description` (optional, used only if creating new material)
    - `Category` (optional, used only if creating/mapping)
  - Matching:
    - Normalize part number using existing `_normalize_part_no`.
    - Look up material by `materials.part_no_norm`.
  - Options (checkboxes on UI):
    - Create missing Materials
    - Auto-create Categories (optional)
    - Auto-map UOM
    - Replace previous Opening Stock (optional)
- Insert behavior:
  - For each valid row, insert into `stock_movements_v2`:
    - `ref_type='ADJUSTMENT'`
    - `ref_id=<opening_stock_upload_id>`
    - `material_id=<resolved material>`
    - `uom_id=<resolved/created uom>`
    - `weight=<quantity>`
    - `direction='IN'`
    - `category_id=<material.category_id>` (snapshot)
  - This automatically reflects in Inventory because [inventory_balances_v2](file:///e:/projects/Tata%20Motors/syms%20update/db/schema.sql) sums `stock_movements_v2`.
- “Replace previous Opening Stock” approach:
  - When enabled, delete prior `stock_movements_v2` rows with `ref_type='ADJUSTMENT'` and `ref_id` belonging to past `opening_stock_uploads` (or mark them logically inactive if we add such column later).

## 4) Opening Stock Upload (Frontend)
- **New template**: `backend/app/templates/settings/opening_stock.html`
- UI layout aligned with the platform:
  - Header (breadcrumb + subtitle)
  - Card: Upload area + Download Sample buttons
  - Card: Import options (checkboxes)
  - Card: Recent opening stock uploads (history table)
  - Small helper text: “Inventory will update automatically after import”
- Avoid inline CSS/JS; reuse shared helpers (Section 1).

## 5) Update Audit & Logs to Include Opening Stock Imports
- **Template**: [logs.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/settings/logs.html)
- Enhance into tabbed view:
  - Tab 1: Pricing uploads (existing)
  - Tab 2: Opening stock uploads (new)
- **Route**: `GET /scratch/settings/logs` in [settings/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/settings/routes.py) updated to fetch both datasets.

## 6) Remove “Inventory & Lots” Settings Page From UX
- We will keep the existing `/scratch/settings/lots` route intact temporarily for backward compatibility, but:
  - Remove it from navigation (Section 2).
  - Optionally add a simple redirect to Opening Stock or a “deprecated” info page if users hit it directly.

## 7) Verification Checklist (After Implementation)
- Run Python compilation checks on changed modules (Settings routes, any new module).
- Start the backend and validate:
  - Settings navigation links
  - Pricing import still works
  - Opening Stock import creates `stock_movements_v2` rows and Inventory list shows updated balances ([inventory/list.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/inventory/list.html))
  - Audit & Logs shows both pricing and opening stock imports

