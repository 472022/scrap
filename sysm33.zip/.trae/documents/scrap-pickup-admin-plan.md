# Scrap Pickup Admin + Outlook Email Plan

## 1) Current System Understanding (as-is)

- **Backend stack**: Flask (Jinja templates) + SQLAlchemy engine used with raw SQL helpers. App factory in [__init__.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/__init__.py#L17-L106).
- **Current Scrap Request Form**:
  - Public: `GET|POST /scrap-request` → [public_scrap_request](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/requests/routes.py#L149-L228) → template [public.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/requests/public.html).
  - Internal (authenticated): `GET|POST /scratch/requests` → [requests_index](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/requests/routes.py#L69-L148) → template [index.html](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/templates/requests/index.html).
  - **Data handling today**: submissions are validated and **emailed**; they are **not persisted to DB**.
- **Email sending today**: only SMTP-based sender exists (no win32com/Outlook code present).
  - Config via env vars and sender in [_smtp_settings/_send_request_email](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/requests/routes.py#L16-L67).
  - Email HTML is built inline with f-strings inside the request handlers.
- **Auth today**:
  - `/scratch/auth/login` etc. in [auth/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/auth/routes.py).
  - Guard is [login_required](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/security/auth.py#L1-L20), using `session["user_id"]`.
  - Password verification is currently plaintext (not secure): [services.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/auth/services.py#L6-L18).
- **Existing settings pattern**: key/value settings stored in `app_settings` table with helper `_app_setting_get/_app_setting_set` in [settings/routes.py](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/modules/settings/routes.py#L61-L75).

## 2) Goals (to-be)

- Add a **separate** admin login area specifically for scrap pickup request management (distinct from existing `/scratch/*` login).
- Persist scrap requests in DB and expose a **Requests Dashboard** for admins.
- Implement **Accept** and **Reschedule** actions only (remove/avoid Reject entirely).
- Send acceptance/reschedule emails via **Microsoft Outlook** using `win32com.client.Dispatch("Outlook.Application")`.
- Add reusable email functions:
  - `send_acceptance_email(request_data, settings)`
  - `send_reschedule_email(request_data, settings)`
- Add HTML email templates (acceptance + reschedule).
- Add logging:
  - Python logging for operational visibility.
  - DB-level log entries for email attempts (success/failure, timestamps, request id).
- Add a **Settings page** under the new scrap admin area to configure email settings (recipient lists, sender, etc.).
- Ensure existing form routes remain functional and are not broken.

## 3) Design Decisions

- **Separate login within a single Flask app**: implement separate session keys for scrap admin auth to avoid interfering with existing `/scratch/*` login.
  - Existing uses: `session["user_id"]`, `session["role"]`
  - Scrap admin will use: `session["scrap_admin_user_id"]`
- **DB persistence**: create a new `scrap_requests` table and write to it on form submission (public + internal). Dashboard reads from this table.
- **Outlook emails**: implement a new email sender module using `win32com.client`.
  - Use `SentOnBehalfOfName` only if configured and supported by the mailbox.
  - Keep SMTP sender intact for the rest of the system; scrap pickup email flows will use Outlook.
- **Templates**: store email bodies as Jinja templates under `templates/emails/scrap/`.
- **Auditability**: create `scrap_email_logs` table to record each outbound email attempt.

## 4) Implementation Steps (No Omissions)

### 4.1 Database changes

1. Update schema SQL to add:
   - `scrap_requests`
     - id (PK), name, email, phone, address fields, scrap_type, pickup_date, notes/extra fields
     - status (`PENDING`, `ACCEPTED`, `RESCHEDULED`)
     - created_at, updated_at
     - accepted_at, rescheduled_at (nullable)
   - `scrap_admin_users`
     - id (PK), username (unique), password_hash, is_active, created_at
   - `scrap_email_logs`
     - id, request_id (FK-like int), email_type (`ACCEPTANCE`, `RESCHEDULE`), to_email, subject
     - success (bool), error_message (nullable), created_at
2. Add a small admin bootstrap path (similar to existing create_admin) for the scrap admin area:
   - Only allowed when `scrap_admin_users` empty.

### 4.2 Persist requests on form submission (non-breaking)

1. Refactor existing scrap request handlers (`/scrap-request` and `/scratch/requests`) to:
   - Validate form fields as today.
   - Insert a new row into `scrap_requests` with status `PENDING`.
   - Preserve the existing flash messages and redirects.
2. Keep the current “notify admin” email behavior working:
   - Initially: send the “new request received” email to configured admin recipients.
   - Move inline HTML assembly into a reusable template (`templates/emails/scrap/new_request.html`) so both forms share it.

### 4.3 Add Outlook email sender module (win32com)

1. Add a new module, e.g. `app/email/outlook.py`, implementing:
   - `send_outlook_email(to_list, subject, html_body, sender=None, cc_list=None)`
   - Error handling that raises or returns structured failure info.
2. Add a small service layer, e.g. `app/email/scrap_notifications.py`, implementing:
   - `send_acceptance_email(request_row, settings)`
   - `send_reschedule_email(request_row, settings)`
   - `send_new_request_email(request_row, settings)` (for admin notification)
3. Ensure emails use HTML templates rendered by Jinja (not f-strings).

### 4.4 Add Python logging + DB logging for email attempts

1. Add an app logger setup function (e.g. `app/utils/app_logging.py`) and initialize it in `create_app()`:
   - Configure log level via env setting.
   - Log to a rotating file under backend directory (or configured path).
2. On every email attempt:
   - Insert a row into `scrap_email_logs` (success/failure, error_message, request_id, timestamp).
   - Log an INFO on success and ERROR on failure, including request id and email type.

### 4.5 Separate scrap admin login system

1. Create a new blueprint, e.g. `app/modules/scrap_admin_auth`:
   - `GET /scrap-admin/login` render login page.
   - `POST /scrap-admin/login` authenticate against `scrap_admin_users` using `werkzeug.security.check_password_hash`.
   - `GET /scrap-admin/logout` clears only scrap-admin session keys.
   - `GET|POST /scrap-admin/create_admin` bootstrap first scrap admin user.
2. Add `scrap_admin_login_required` decorator:
   - Checks `session["scrap_admin_user_id"]`.
   - Redirects to `/scrap-admin/login` if missing.
3. Add CSRF protection to all POST routes using existing `@csrf_protect`.

### 4.6 Requests Dashboard + actions

1. Create `app/modules/scrap_admin_requests` blueprint:
   - `GET /scrap-admin/requests`:
     - Display table with key fields and status.
     - Include “Accept” and “Reschedule” actions only.
2. Accept action:
   - `POST /scrap-admin/requests/<id>/accept`
   - Update DB: status = `ACCEPTED`, accepted_at = NOW(), updated_at = NOW()
   - Send acceptance email to requestor via Outlook:
     - Subject: `Your Scrap Pickup Request Has Been Accepted`
     - Body includes user name, scrap details, address, pickup date, status.
   - Persist email log entry + app log.
3. Reschedule action:
   - `GET /scrap-admin/requests/<id>/reschedule`:
     - Render a form with existing request data prefilled.
     - Only allow editing pickup date (and any explicitly allowed fields).
   - `POST /scrap-admin/requests/<id>/reschedule`:
     - Update pickup_date, status = `RESCHEDULED`, rescheduled_at, updated_at.
     - Send reschedule email:
       - Subject: `Your Scrap Pickup Schedule Has Been Updated`
       - Body includes updated pickup date and other request details.
     - Persist email log entry + app log.
4. Ensure no “Reject” endpoints, buttons, or backend handlers exist for scrap requests.

### 4.7 Scrap admin Settings page (email configuration)

1. Create `app/modules/scrap_admin_settings` blueprint:
   - `GET /scrap-admin/settings` shows form with current settings values.
   - `POST /scrap-admin/settings` saves values into `app_settings` table.
2. Settings keys (stored in `app_settings`):
   - `scrap_admin_notify_to` (comma-separated admin recipients for new requests)
   - `scrap_outlook_sender` (optional: sent on behalf address)
   - `scrap_email_cc` (optional)
   - Any additional toggles needed later (kept extensible).
3. Apply access control: scrap admin login required.

### 4.8 UI templates + navigation

1. Add templates:
   - `templates/scrap_admin/login.html`
   - `templates/scrap_admin/requests_dashboard.html`
   - `templates/scrap_admin/reschedule.html`
   - `templates/scrap_admin/settings.html`
   - `templates/emails/scrap/acceptance.html`
   - `templates/emails/scrap/reschedule.html`
   - `templates/emails/scrap/new_request.html`
2. Keep styling consistent by reusing existing layout fragments where possible.

### 4.9 Wiring into app factory

1. Register the new blueprints in [create_app](file:///e:/projects/Tata%20Motors/syms%20update/backend/app/__init__.py#L17-L106).
2. Ensure URL prefixes do not overlap existing `/scratch/*` routes.

### 4.10 Verification (functional + safety)

1. Add lightweight smoke checks:
   - Submitting `/scrap-request` still works and now creates DB row.
   - Scrap admin login gates the dashboard.
   - Accept/reschedule updates status and writes email log rows.
2. Provide an “email dry-run” mode for local testing if Outlook is unavailable, but keep production default as Outlook.

## 5) Deliverables Checklist (what will be implemented)

- Separate scrap admin login + session protection
- Requests dashboard listing stored scrap requests
- Accept + Reschedule actions with DB status updates
- Outlook email sender via `win32com.client`
- Jinja HTML email templates (acceptance + reschedule + new request)
- Settings page backed by `app_settings`
- Email attempt logging in DB + Python logging
- No Reject option anywhere

