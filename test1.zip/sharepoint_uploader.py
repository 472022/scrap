import json
import os
from dataclasses import dataclass
from urllib.parse import quote, urlparse

import msal
import requests

GRAPH_BASE_URL = "https://graph.microsoft.com/v1.0"


@dataclass(frozen=True)
class UploadResult:
    ok: bool
    message: str
    remote_name: str | None = None
    remote_url: str | None = None


def _env(name: str) -> str | None:
    v = os.environ.get(name)
    if v is None:
        return None
    v = v.strip()
    return v or None


def read_sharepoint_config_from_env() -> dict:
    auth_mode = (_env("SP_AUTH_MODE") or "device_code").lower()
    cfg = {
        "enabled": (_env("SP_AUTO_UPLOAD") or "0") == "1",
        "auth_mode": auth_mode,
        "site_url": _env("SP_SITE_URL"),
        "folder_path": _env("SP_FOLDER_PATH") or "",
        "tenant_id": _env("AZURE_TENANT_ID"),
        "client_id": _env("AZURE_CLIENT_ID"),
        "client_secret": _env("AZURE_CLIENT_SECRET"),
        "cache_path": _env("SP_TOKEN_CACHE_PATH"),
        "scopes": _env("SP_SCOPES"),
        "drive_id": _env("SP_DRIVE_ID"),
    }
    return cfg


def _default_cache_path() -> str:
    base = os.path.join(os.path.expanduser("~"), ".csr_attendance_tool")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "msal_token_cache.bin")


def _parse_scopes(scopes_csv: str | None, auth_mode: str) -> list[str]:
    if auth_mode == "client_credentials":
        return ["https://graph.microsoft.com/.default"]
    if scopes_csv:
        parts = [p.strip() for p in scopes_csv.split(",")]
        scopes = [p for p in parts if p]
        if scopes:
            return scopes
    return [
        "https://graph.microsoft.com/User.Read",
        "https://graph.microsoft.com/Files.ReadWrite.All",
        "https://graph.microsoft.com/Sites.ReadWrite.All",
        "offline_access",
    ]


def acquire_access_token(
    *,
    tenant_id: str,
    client_id: str,
    auth_mode: str,
    client_secret: str | None = None,
    cache_path: str | None = None,
    scopes_csv: str | None = None,
    device_message_callback=None,
) -> tuple[str, str | None]:
    authority = f"https://login.microsoftonline.com/{tenant_id}"
    auth_mode = auth_mode.lower().strip()
    scopes = _parse_scopes(scopes_csv, auth_mode)

    if auth_mode == "client_credentials":
        if not client_secret:
            raise ValueError("AZURE_CLIENT_SECRET is required for SP_AUTH_MODE=client_credentials")
        app = msal.ConfidentialClientApplication(
            client_id=client_id,
            authority=authority,
            client_credential=client_secret,
        )
        token = app.acquire_token_for_client(scopes=scopes)
        if "access_token" not in token:
            raise RuntimeError(token.get("error_description") or json.dumps(token))
        return token["access_token"], None

    cache_path = cache_path or _default_cache_path()
    cache = msal.SerializableTokenCache()
    if os.path.exists(cache_path):
        with open(cache_path, "r", encoding="utf-8") as f:
            cache.deserialize(f.read())

    app = msal.PublicClientApplication(
        client_id=client_id,
        authority=authority,
        token_cache=cache,
    )

    device_message = None
    result = None
    accounts = app.get_accounts()
    if accounts:
        result = app.acquire_token_silent(scopes=scopes, account=accounts[0])

    if not result:
        flow = app.initiate_device_flow(scopes=scopes)
        if "user_code" not in flow:
            raise RuntimeError(flow.get("error") or json.dumps(flow))
        device_message = flow.get("message")
        if device_message and device_message_callback:
            try:
                device_message_callback(device_message)
            except Exception:
                pass
        result = app.acquire_token_by_device_flow(flow)

    if "access_token" not in result:
        raise RuntimeError(result.get("error_description") or json.dumps(result))

    if cache.has_state_changed:
        with open(cache_path, "w", encoding="utf-8") as f:
            f.write(cache.serialize())

    return result["access_token"], device_message


def _graph_request(
    method: str,
    url: str,
    token: str,
    *,
    json_body: dict | None = None,
    data: bytes | None = None,
    headers: dict | None = None,
    timeout_s: int = 60,
) -> requests.Response:
    h = {"Authorization": f"Bearer {token}"}
    if headers:
        h.update(headers)
    return requests.request(method, url, headers=h, json=json_body, data=data, timeout=timeout_s)


def _graph_json_or_error(resp: requests.Response) -> dict:
    try:
        payload = resp.json()
    except Exception:
        payload = {"raw": resp.text}

    if 200 <= resp.status_code < 300:
        return payload

    if isinstance(payload, dict):
        err = payload.get("error") or {}
        msg = err.get("message") or payload.get("raw") or "Request failed"
    else:
        msg = "Request failed"
    raise RuntimeError(f"{resp.status_code} {resp.reason}: {msg}")


def resolve_site_id(site_url: str, token: str) -> str:
    parsed = urlparse(site_url)
    if not parsed.netloc:
        raise ValueError("SP_SITE_URL must be a full URL like https://contoso.sharepoint.com/sites/CSR")
    if not parsed.path or parsed.path == "/":
        raise ValueError("SP_SITE_URL must include a site path like /sites/CSR")

    url = f"{GRAPH_BASE_URL}/sites/{parsed.netloc}:{parsed.path}"
    resp = _graph_request("GET", url, token)
    payload = _graph_json_or_error(resp)
    site_id = payload.get("id")
    if not site_id:
        raise RuntimeError("Could not resolve SharePoint site id")
    return site_id


def resolve_drive_id(site_id: str, token: str) -> str:
    url = f"{GRAPH_BASE_URL}/sites/{site_id}/drive"
    resp = _graph_request("GET", url, token)
    payload = _graph_json_or_error(resp)
    drive_id = payload.get("id")
    if not drive_id:
        raise RuntimeError("Could not resolve SharePoint drive id")
    return drive_id


def _normalize_folder_path(folder_path: str) -> str:
    p = (folder_path or "").strip().replace("\\", "/")
    p = p.strip("/")
    return p


def _build_drive_item_path(folder_path: str, filename: str) -> str:
    folder_path = _normalize_folder_path(folder_path)
    if not folder_path:
        return filename
    return f"{folder_path}/{filename}"


def _simple_upload(*, drive_id: str, token: str, local_path: str, remote_path: str) -> dict:
    encoded = quote(remote_path, safe="/")
    url = f"{GRAPH_BASE_URL}/drives/{drive_id}/root:/{encoded}:/content"
    with open(local_path, "rb") as f:
        data = f.read()
    resp = _graph_request("PUT", url, token, data=data, headers={"Content-Type": "application/octet-stream"}, timeout_s=120)
    return _graph_json_or_error(resp)


def _create_upload_session(*, drive_id: str, token: str, remote_path: str) -> str:
    encoded = quote(remote_path, safe="/")
    url = f"{GRAPH_BASE_URL}/drives/{drive_id}/root:/{encoded}:/createUploadSession"
    resp = _graph_request(
        "POST",
        url,
        token,
        json_body={"item": {"@microsoft.graph.conflictBehavior": "replace"}},
        timeout_s=60,
    )
    payload = _graph_json_or_error(resp)
    upload_url = payload.get("uploadUrl")
    if not upload_url:
        raise RuntimeError("Could not create upload session")
    return upload_url


def _chunked_upload(*, upload_url: str, local_path: str) -> dict:
    size = os.path.getsize(local_path)
    chunk_size = 320 * 1024 * 10
    with open(local_path, "rb") as f:
        start = 0
        while start < size:
            end = min(start + chunk_size, size)
            length = end - start
            f.seek(start)
            chunk = f.read(length)
            headers = {
                "Content-Length": str(length),
                "Content-Range": f"bytes {start}-{end - 1}/{size}",
            }
            resp = requests.put(upload_url, headers=headers, data=chunk, timeout=180)
            if resp.status_code in (200, 201):
                return resp.json()
            if resp.status_code != 202:
                try:
                    payload = resp.json()
                    err = (payload.get("error") or {}).get("message") or resp.text
                except Exception:
                    err = resp.text
                raise RuntimeError(f"{resp.status_code} {resp.reason}: {err}")
            start = end
    raise RuntimeError("Upload session did not complete")


def upload_file_to_sharepoint(
    *,
    local_path: str,
    site_url: str,
    folder_path: str,
    tenant_id: str,
    client_id: str,
    auth_mode: str = "device_code",
    client_secret: str | None = None,
    drive_id: str | None = None,
    cache_path: str | None = None,
    scopes_csv: str | None = None,
    device_message_callback=None,
) -> tuple[UploadResult, str | None]:
    if not os.path.isfile(local_path):
        return UploadResult(ok=False, message="Local file not found"), None

    token, device_message = acquire_access_token(
        tenant_id=tenant_id,
        client_id=client_id,
        auth_mode=auth_mode,
        client_secret=client_secret,
        cache_path=cache_path,
        scopes_csv=scopes_csv,
        device_message_callback=device_message_callback,
    )

    site_id = resolve_site_id(site_url, token)
    drive_id = drive_id or resolve_drive_id(site_id, token)

    filename = os.path.basename(local_path)
    remote_path = _build_drive_item_path(folder_path, filename)

    size = os.path.getsize(local_path)
    if size <= 3_500_000:
        item = _simple_upload(drive_id=drive_id, token=token, local_path=local_path, remote_path=remote_path)
    else:
        upload_url = _create_upload_session(drive_id=drive_id, token=token, remote_path=remote_path)
        item = _chunked_upload(upload_url=upload_url, local_path=local_path)

    remote_url = item.get("webUrl")
    name = item.get("name") or filename
    if remote_url:
        return UploadResult(ok=True, message="Uploaded to SharePoint", remote_name=name, remote_url=remote_url), device_message
    return UploadResult(ok=True, message="Uploaded to SharePoint", remote_name=name), device_message


def upload_from_env(local_path: str, *, device_message_callback=None) -> tuple[UploadResult, str | None]:
    cfg = read_sharepoint_config_from_env()
    if not cfg["enabled"]:
        return UploadResult(ok=False, message="SharePoint auto upload disabled"), None

    missing = []
    for k in ("site_url", "tenant_id", "client_id"):
        if not cfg.get(k):
            missing.append(k)
    if missing:
        return UploadResult(ok=False, message=f"Missing SharePoint config: {', '.join(missing)}"), None

    return upload_file_to_sharepoint(
        local_path=local_path,
        site_url=cfg["site_url"],
        folder_path=cfg["folder_path"],
        tenant_id=cfg["tenant_id"],
        client_id=cfg["client_id"],
        auth_mode=cfg["auth_mode"],
        client_secret=cfg["client_secret"],
        drive_id=cfg["drive_id"],
        cache_path=cfg["cache_path"],
        scopes_csv=cfg["scopes"],
        device_message_callback=device_message_callback,
    )


def _cli() -> int:
    import sys

    if len(sys.argv) != 2:
        print("Usage: python -m sharepoint_uploader <local_path>")
        return 2

    result, device_message = upload_from_env(sys.argv[1])
    if device_message:
        print(device_message)
    if result.remote_url:
        print(result.remote_url)
    print(result.message)
    return 0 if result.ok else 1


if __name__ == "__main__":
    raise SystemExit(_cli())
