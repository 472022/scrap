
CSR Event Attendance Generator (Professional Version)

Features:
- Modern UI
- RFID matching
- Duplicate removal
- Event details input
- Generates formatted attendance sheet

Run:
pip install -r requirements.txt
python app.py

SharePoint Auto-Upload Setup:
1. Copy `.env.template` to `.env`
2. Fill in the SharePoint and Azure AD details in `.env`
3. Set `SP_AUTO_UPLOAD=1` to enable the feature
4. The first upload will trigger a Microsoft Sign-in dialog (Device Code flow)
