
import os
import threading
from dotenv import load_dotenv
import customtkinter as ctk
from tkinter import filedialog, messagebox
import pandas as pd

load_dotenv()

ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

attendance_file = None
master_file = None

def _is_sharepoint_auto_upload_enabled():
    return (os.environ.get("SP_AUTO_UPLOAD") or "").strip() == "1"

def _set_status(text, *, color=None):
    def _apply():
        if "status_label" in globals():
            status_label.configure(text=text)
            if color:
                status_label.configure(text_color=color)
    if "app" in globals():
        app.after(0, _apply)

def _set_controls_enabled(enabled: bool):
    state = "normal" if enabled else "disabled"
    def _apply():
        if "att_btn" in globals():
            att_btn.configure(state=state)
        if "master_btn" in globals():
            master_btn.configure(state=state)
        if "generate_btn" in globals():
            generate_btn.configure(state=state)
    if "app" in globals():
        app.after(0, _apply)

def start_sharepoint_upload(local_path: str):
    _set_controls_enabled(False)
    _set_status("Uploading to SharePoint…", color="#475569")

    def show_device_message(msg: str):
        def _show():
            messagebox.showinfo("Microsoft Sign-in", msg)
        app.after(0, _show)

    def worker():
        try:
            from sharepoint_uploader import upload_from_env
        except Exception as e:
            def _done():
                _set_controls_enabled(True)
                _set_status("SharePoint upload unavailable", color="#dc2626")
                messagebox.showerror("SharePoint Upload Failed", str(e))
            app.after(0, _done)
            return

        try:
            result, _ = upload_from_env(local_path, device_message_callback=show_device_message)
        except Exception as e:
            result = None
            err = str(e)

            def _done():
                _set_controls_enabled(True)
                _set_status("SharePoint upload failed", color="#dc2626")
                messagebox.showerror("SharePoint Upload Failed", err)
            app.after(0, _done)
            return

        def _done():
            _set_controls_enabled(True)
            if result.ok:
                _set_status("Uploaded to SharePoint", color="#16a34a")
                if result.remote_url:
                    messagebox.showinfo("Upload Complete", f"Uploaded: {result.remote_name}\n{result.remote_url}")
                else:
                    messagebox.showinfo("Upload Complete", f"Uploaded: {result.remote_name}")
            else:
                _set_status(result.message, color="#dc2626")
                messagebox.showerror("SharePoint Upload Failed", result.message)

        app.after(0, _done)

    threading.Thread(target=worker, daemon=True).start()

def detect_column(df, keywords):
    for col in df.columns:
        for k in keywords:
            if k in col.lower():
                return col
    return df.columns[0]

def upload_attendance():
    global attendance_file
    attendance_file = filedialog.askopenfilename(filetypes=[("Excel files","*.xlsx *.xls")])
    if attendance_file:
        att_label.configure(text=os.path.basename(attendance_file))

def upload_master():
    global master_file
    master_file = filedialog.askopenfilename(filetypes=[("Excel files","*.xlsx *.xls")])
    if master_file:
        master_label.configure(text=os.path.basename(master_file))

def generate():
    if not attendance_file or not master_file:
        messagebox.showerror("Error","Upload both Excel files")
        return

    try:
        att = pd.read_excel(attendance_file)
        master = pd.read_excel(master_file)

        att_col = detect_column(att, ["rfid","card","id","number"])
        master_col = detect_column(master, ["rfid","card","id","number"])

        scanned = att[att_col].drop_duplicates()

        matched = master[master[master_col].isin(scanned)].copy()

        matched["Activity Name"] = activity_name.get()
        matched["Activity Location"] = activity_location.get()
        matched["Pillar"] = pillar.get()
        matched["Date"] = event_date.get()
        matched["Volunteer Hours"] = volunteer_hours.get()

        matched.insert(0,"Sl.No", range(1,len(matched)+1))

        save_path = filedialog.asksaveasfilename(defaultextension=".xlsx")

        if save_path:
            matched.to_excel(save_path, index=False)
            if _is_sharepoint_auto_upload_enabled():
                messagebox.showinfo("Saved", f"Attendance Generated\nTotal Volunteers: {len(matched)}\n\nUploading to SharePoint…")
                start_sharepoint_upload(save_path)
            else:
                messagebox.showinfo("Success", f"Attendance Generated\nTotal Volunteers: {len(matched)}")

    except Exception as e:
        messagebox.showerror("Error", str(e))

app = ctk.CTk()
app.title("CSR Event Attendance Generator")
app.geometry("920x640")
app.minsize(820, 600)
app.configure(fg_color="#eef3ff")
app.grid_columnconfigure(0, weight=1)
app.grid_rowconfigure(0, weight=1)

shadow = ctk.CTkFrame(app, corner_radius=22, fg_color="#d9e2f5")
shadow.grid(row=0, column=0, padx=34, pady=34, sticky="nsew")

root_container = ctk.CTkFrame(
    app,
    corner_radius=22,
    fg_color="#ffffff",
    border_width=1,
    border_color="#d3def2",
)
root_container.grid(row=0, column=0, padx=28, pady=28, sticky="nsew")
root_container.grid_columnconfigure(0, weight=1)
root_container.grid_rowconfigure(1, weight=1)

header = ctk.CTkFrame(root_container, fg_color="transparent")
header.grid(row=0, column=0, padx=28, pady=(26, 12), sticky="ew")
header.grid_columnconfigure(0, weight=1)

title = ctk.CTkLabel(
    header,
    text="CSR Event Attendance Manager",
    font=("Segoe UI", 26, "bold"),
    text_color="#0f172a",
)
title.grid(row=0, column=0, sticky="ew")

subtitle = ctk.CTkLabel(
    header,
    text="Generate attendance Excel by matching RFID scans with the master employee list",
    font=("Segoe UI", 12),
    text_color="#475569",
)
subtitle.grid(row=1, column=0, pady=(6, 0), sticky="ew")

content = ctk.CTkFrame(root_container, fg_color="transparent")
content.grid(row=1, column=0, padx=28, pady=(6, 18), sticky="nsew")
content.grid_columnconfigure(0, weight=1)
content.grid_rowconfigure(2, weight=1)

form = ctk.CTkFrame(
    content,
    corner_radius=18,
    fg_color="#f6f8ff",
    border_width=1,
    border_color="#d3def2",
)
form.grid(row=0, column=0, sticky="ew")
form.grid_columnconfigure(0, weight=1)

entry_cfg = {
    "height": 44,
    "corner_radius": 10,
    "fg_color": "#ffffff",
    "border_color": "#c8d4ee",
    "border_width": 1,
    "text_color": "#0f172a",
    "placeholder_text_color": "#64748b",
    "font": ("Segoe UI", 12),
}

activity_name = ctk.CTkEntry(form, placeholder_text="Activity Name", **entry_cfg)
activity_name.grid(row=0, column=0, padx=18, pady=(18, 10), sticky="ew")

activity_location = ctk.CTkEntry(form, placeholder_text="Activity Location", **entry_cfg)
activity_location.grid(row=1, column=0, padx=18, pady=10, sticky="ew")

pillar = ctk.CTkEntry(form, placeholder_text="Pillar (Example: Employability)", **entry_cfg)
pillar.grid(row=2, column=0, padx=18, pady=10, sticky="ew")

date_row = ctk.CTkFrame(form, fg_color="transparent")
date_row.grid(row=3, column=0, padx=18, pady=10, sticky="ew")
date_row.grid_columnconfigure(0, weight=1)

event_date = ctk.CTkEntry(date_row, placeholder_text="Event Date (dd/mm/yyyy)", **entry_cfg)
event_date.grid(row=0, column=0, sticky="ew")

date_icon = ctk.CTkButton(
    date_row,
    text="🗓",
    width=44,
    height=44,
    corner_radius=10,
    fg_color="#ffffff",
    hover_color="#eef2ff",
    border_width=1,
    border_color="#c8d4ee",
    text_color="#334155",
    font=("Segoe UI", 14),
    command=lambda: event_date.focus_set(),
)
date_icon.grid(row=0, column=1, padx=(10, 0), sticky="e")

volunteer_hours = ctk.CTkEntry(form, placeholder_text="Volunteer Hours", **entry_cfg)
volunteer_hours.grid(row=4, column=0, padx=18, pady=(10, 18), sticky="ew")

uploads = ctk.CTkFrame(content, fg_color="transparent")
uploads.grid(row=1, column=0, pady=(18, 0), sticky="ew")
uploads.grid_columnconfigure(0, weight=1)
uploads.grid_columnconfigure(1, weight=1)

panel_cfg = {
    "corner_radius": 18,
    "fg_color": "#f6f8ff",
    "border_width": 1,
    "border_color": "#d3def2",
}

att_panel = ctk.CTkFrame(uploads, **panel_cfg)
att_panel.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
att_panel.grid_columnconfigure(0, weight=1)

att_btn = ctk.CTkButton(
    att_panel,
    text="📄  Upload RFID Attendance Sheet",
    height=44,
    corner_radius=12,
    fg_color="#2563eb",
    hover_color="#1d4ed8",
    text_color="#ffffff",
    font=("Segoe UI", 12, "bold"),
    command=upload_attendance,
)
att_btn.grid(row=0, column=0, padx=18, pady=(18, 10), sticky="ew")

att_label = ctk.CTkLabel(
    att_panel,
    text="No file selected",
    font=("Segoe UI", 11),
    text_color="#64748b",
    justify="center",
    wraplength=360,
)
att_label.grid(row=1, column=0, padx=18, pady=(0, 18), sticky="ew")

master_panel = ctk.CTkFrame(uploads, **panel_cfg)
master_panel.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
master_panel.grid_columnconfigure(0, weight=1)

master_btn = ctk.CTkButton(
    master_panel,
    text="📄  Upload Master Employee Table",
    height=44,
    corner_radius=12,
    fg_color="#2563eb",
    hover_color="#1d4ed8",
    text_color="#ffffff",
    font=("Segoe UI", 12, "bold"),
    command=upload_master,
)
master_btn.grid(row=0, column=0, padx=18, pady=(18, 10), sticky="ew")

master_label = ctk.CTkLabel(
    master_panel,
    text="No file selected",
    font=("Segoe UI", 11),
    text_color="#64748b",
    justify="center",
    wraplength=360,
)
master_label.grid(row=1, column=0, padx=18, pady=(0, 18), sticky="ew")

actions = ctk.CTkFrame(content, fg_color="transparent")
actions.grid(row=2, column=0, pady=(22, 0), sticky="ew")
actions.grid_columnconfigure(0, weight=1)

generate_btn = ctk.CTkButton(
    actions,
    text="Generate Final Attendance Excel",
    height=52,
    width=380,
    corner_radius=14,
    fg_color="#1d4ed8",
    hover_color="#1e40af",
    text_color="#ffffff",
    font=("Segoe UI", 13, "bold"),
    command=generate,
)
generate_btn.grid(row=0, column=0)

status_label = ctk.CTkLabel(
    actions,
    text="",
    font=("Segoe UI", 11),
    text_color="#64748b",
)
status_label.grid(row=1, column=0, pady=(10, 0))

footer = ctk.CTkLabel(
    root_container,
    text="Professional CSR Attendance Tool",
    font=("Segoe UI", 11),
    text_color="#64748b",
)
footer.grid(row=2, column=0, pady=(0, 18))

layout_mode = None
resize_job = None

def apply_responsive_layout():
    global layout_mode

    w = root_container.winfo_width()
    if w <= 0:
        return

    next_mode = "stack" if w < 860 else "split"
    if next_mode != layout_mode:
        att_panel.grid_forget()
        master_panel.grid_forget()

        if next_mode == "stack":
            att_panel.grid(row=0, column=0, columnspan=2, padx=0, pady=(0, 16), sticky="ew")
            master_panel.grid(row=1, column=0, columnspan=2, padx=0, sticky="ew")
        else:
            att_panel.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
            master_panel.grid(row=0, column=1, padx=(10, 0), sticky="nsew")

        layout_mode = next_mode

    pad = 28 if w < 860 else 120
    generate_btn.grid_configure(padx=pad, sticky="ew")

    if "status_label" in globals():
        status_label.configure(wraplength=max(320, w - 120))

    att_wrap = max(240, att_panel.winfo_width() - 36)
    master_wrap = max(240, master_panel.winfo_width() - 36)
    att_label.configure(wraplength=att_wrap)
    master_label.configure(wraplength=master_wrap)

def on_root_resize(event):
    global resize_job
    if resize_job is not None:
        app.after_cancel(resize_job)
    resize_job = app.after(60, apply_responsive_layout)

app.bind("<Configure>", on_root_resize)
app.after(0, apply_responsive_layout)

app.mainloop()
