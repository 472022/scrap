import fs from 'fs';
import * as xlsxModule from 'xlsx';

const xlsx = xlsxModule.default || xlsxModule;
const buffer = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const workbook = xlsx.read(buffer, { type: 'buffer', cellDates: true, raw: false });

console.log('=== INVENTORY SHEETS ===');
const invSheets = workbook.SheetNames.filter(s => s.toLowerCase().includes('inventory'));
console.log('Inventory Sheets:', invSheets);

invSheets.forEach(sName => {
  console.log(`\n================ SHEET: "${sName}" ================`);
  const ws = workbook.Sheets[sName];
  const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
  rows.forEach((r, idx) => {
    if (r && r.length > 0) {
      console.log(`Row ${idx}:`, JSON.stringify(r));
    }
  });
});
