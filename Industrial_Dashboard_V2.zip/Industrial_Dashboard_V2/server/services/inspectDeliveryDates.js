import { querySql, getSql } from '../db.js';

async function main() {
  const dates = await querySql(`
    SELECT DISTINCT record_date, year, month, fiscal_year 
    FROM performance_data 
    WHERE module = 'delivery' 
    ORDER BY record_date ASC
  `);
  console.log('--- Delivery Record Dates ---');
  console.table(dates);

  const sampleMetrics = await querySql(`
    SELECT metric_id, record_date, target_value, actual_value 
    FROM performance_data 
    WHERE module = 'delivery' AND metric_id IN ('otif_dom', 'prod_dom', 'disp_tot')
    ORDER BY metric_id, record_date ASC
  `);
  console.log('--- Sample Metrics (otif_dom, prod_dom, disp_tot) ---');
  console.table(sampleMetrics);

  const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  console.log('Current reporting date in config:', reportingConfig);
}

main().catch(console.error);
