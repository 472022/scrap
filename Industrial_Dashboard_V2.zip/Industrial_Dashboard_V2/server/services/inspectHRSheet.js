import fs from 'fs';
import { parseDatasetFile } from './parserService.js';
import { seedInitialPerformanceData } from '../seedData.js';
import { querySql, getSql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

const excelPath = 'C:/Users/usp/Downloads/Daily Report.xlsx';

async function testParsedHR() {
  const buffer = fs.readFileSync(excelPath);
  const { records } = parseDatasetFile(buffer, 'Daily Report.xlsx');
  const hrRecords = records.filter(r => r.module === 'hr');
  console.log('\n================ PARSED HR RECORDS FROM PARSERSERVICE ================');
  console.table(hrRecords);

  await seedInitialPerformanceData(true);
  const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  console.log('\nReporting Date:', reportingConfig.value);

  const hrMetrics = await querySql("SELECT * FROM metric_definitions WHERE module = 'hr' ORDER BY metric_id ASC");
  console.log(`\n================ HR METRICS CALCULATED VALUES (FTM & YTD) ================`);
  for (const m of hrMetrics) {
    const ftm = await getMetricValuesForPeriod(m.metric_id, 'ftm', { reportingDate: reportingConfig.value });
    const ytd = await getMetricValuesForPeriod(m.metric_id, 'ytd', { reportingDate: reportingConfig.value });
    console.log(`ID: ${m.metric_id.padEnd(22)} | Name: ${m.metric_name.padEnd(35)} | FTM Tgt/Act: ${String(ftm.target).padEnd(8)} / ${String(ftm.actual).padEnd(8)} | YTD Tgt/Act: ${String(ytd.target).padEnd(8)} / ${String(ytd.actual).padEnd(8)}`);
  }

  console.log('\n================ RAW DB PERFORMANCE DATA FOR HR ================');
  const dbHR = await querySql("SELECT metric_id, record_date, target_value, actual_value FROM performance_data WHERE module = 'hr' ORDER BY metric_id, record_date ASC");
  console.table(dbHR);
}

testParsedHR().catch(console.error);
