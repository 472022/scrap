import { querySql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

async function checkAllDelivery() {
  const rRow = await querySql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  const reportingDate = (rRow && rRow.value) ? rRow.value : '2026-12-31';

  const rawProd = await querySql("SELECT metric_id, record_date, target_value, actual_value FROM performance_data WHERE metric_id IN ('prod_dom', 'prod_int')");
  console.log('--- Raw prod_dom and prod_int in DB ---', rawProd);
  const defs = await querySql("SELECT metric_id, metric_name, unit, aggregation_type FROM metric_definitions WHERE module = 'delivery'");
  console.log(`Total Delivery Metrics defined: ${defs.length}`);

  console.log(`\n================ MONTHLY (FTM) CALCULATED VALUES (${reportingDate}) ================`);
  for (const d of defs) {
    const res = await getMetricValuesForPeriod(d.metric_id, 'ftm', { reportingDate });
    console.log(`${d.metric_id.padEnd(20)} | Name: ${d.metric_name.padEnd(32)} | Target: ${String(res.target).padEnd(8)} | Actual: ${String(res.actual).padEnd(8)} | Status: ${res.status}`);
  }

  console.log(`\n================ YTD CALCULATED VALUES (Up to ${reportingDate}) ================`);
  for (const d of defs) {
    const res = await getMetricValuesForPeriod(d.metric_id, 'ytd', { reportingDate });
    console.log(`${d.metric_id.padEnd(20)} | Name: ${d.metric_name.padEnd(32)} | Target: ${String(res.target).padEnd(8)} | Actual: ${String(res.actual).padEnd(8)} | Status: ${res.status}`);
  }
}

checkAllDelivery().catch(console.error);
