import * as xlsxModule from 'xlsx';
const xlsx = xlsxModule.default || xlsxModule;


function parsePeriod(str) {
  if (!str) return null;
  const s = String(str).trim();
  const m = s.match(/(Jan|Feb|Mar|Apr|May|Jun|June|Jul|July|Aug|Sep|Oct|Nov|Dec)[^\d]*(\d{2,4})?/i);
  if (m) {
    const monthNames = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06', june: '06',
      jul: '07', july: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
    };
    const mo = monthNames[m[1].toLowerCase()];
    let yr = m[2];
    if (!yr) yr = '2026';
    else if (yr.length === 2) yr = '20' + yr;
    return `${yr}-${mo}-01`;
  }
  return null;
}

export function testParseWorkbook(filePath) {
  const wb = xlsx.readFile(filePath);
  const records = [];

  // 1. Parse Summary Sheets
  const summarySheets = wb.SheetNames.filter(s => s.toLowerCase().includes('summary'));
  summarySheets.forEach(sheetName => {
    const ws = wb.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
    if (!rows || rows.length < 2) return;

    let headerIdx = -1;
    for (let i = 0; i < Math.min(rows.length, 5); i++) {
      const row = rows[i].map(c => String(c).toLowerCase().trim());
      if (row.includes('target') && row.includes('actual')) {
        headerIdx = i;
        break;
      }
    }
    if (headerIdx === -1) headerIdx = 0;

    const headers = rows[headerIdx].map(c => String(c).toLowerCase().trim());
    const targetCol = headers.findIndex(h => h.includes('target'));
    const actualCol = headers.findIndex(h => h.includes('actual'));
    const unitCol = headers.findIndex(h => h.includes('uom') || h.includes('unit'));

    for (let r = headerIdx + 1; r < rows.length; r++) {
      const row = rows[r];
      if (!row || row.length === 0) continue;

      let metricName = '';
      if (row[1] && String(row[1]).trim()) metricName = String(row[1]).trim();
      else if (row[0] && typeof row[0] === 'string' && row[0].trim()) metricName = row[0].trim();

      if (!metricName || metricName.toLowerCase() === 'total' || metricName.toLowerCase() === 'sl.no') continue;

      const targetVal = targetCol !== -1 && row[targetCol] !== undefined && row[targetCol] !== null && row[targetCol] !== '' ? parseFloat(row[targetCol]) : null;
      const actualVal = actualCol !== -1 && row[actualCol] !== undefined && row[actualCol] !== null && row[actualCol] !== '' ? parseFloat(row[actualCol]) : null;
      const unitVal = unitCol !== -1 ? String(row[unitCol] || '').trim() : '';

      if (actualVal !== null && !isNaN(actualVal)) {
        records.push({
          source: 'summary',
          sheet: sheetName.trim(),
          metric_name: metricName,
          record_date: '2026-07-01',
          target_value: isNaN(targetVal) ? null : targetVal,
          actual_value: actualVal,
          unit: unitVal
        });
      }
    }
  });

  // 2. Parse Detailed Monthly Sheets
  const detailedSheets = wb.SheetNames.filter(s => !s.toLowerCase().includes('summary') && s !== 'IGNITER Projects');
  detailedSheets.forEach(sheetName => {
    const ws = wb.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
    if (!rows || rows.length === 0) return;

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row) continue;

      const monthCols = [];
      row.forEach((cell, colIdx) => {
        const pDate = parsePeriod(cell);
        if (pDate) {
          monthCols.push({ colIdx, periodDate: pDate, label: String(cell).trim() });
        }
      });

      if (monthCols.length >= 2) {
        for (let r = i + 1; r < Math.min(i + 15, rows.length); r++) {
          const nextRow = rows[r];
          if (!nextRow || nextRow.length === 0) continue;

          let label = String(nextRow[0] || nextRow[1] || '').trim();
          if (!label) continue;

          const isPlan = label.toLowerCase().includes('plan') || label.toLowerCase().includes('target');
          const isActual = label.toLowerCase().includes('actual') || label.toLowerCase().includes('act');

          if (isPlan || isActual) {
            let parentMetric = '';
            for (let parentR = r - 1; parentR >= Math.max(0, r - 4); parentR--) {
              const pCell = String(rows[parentR][0] || rows[parentR][1] || '').trim();
              if (pCell && !pCell.toLowerCase().includes('month') && !pCell.toLowerCase().includes('plan') && !pCell.toLowerCase().includes('actual') && !pCell.toLowerCase().includes('%')) {
                parentMetric = pCell;
                break;
              }
            }

            const metricName = parentMetric ? `${parentMetric} - ${label}` : label;
            monthCols.forEach(mCol => {
              const val = parseFloat(nextRow[mCol.colIdx]);
              if (!isNaN(val)) {
                records.push({
                  source: 'detailed',
                  sheet: sheetName.trim(),
                  metric_name: metricName,
                  record_date: mCol.periodDate,
                  type: isPlan ? 'target' : 'actual',
                  value: val
                });
              }
            });
          }
        }
      }
    }
  });

  return records;
}

const records = testParseWorkbook('C:/Users/usp/Downloads/Daily Report.xlsx');
console.log('Total extracted records:', records.length);
console.log('Sample Summary Records:', JSON.stringify(records.filter(r => r.source === 'summary').slice(0, 8), null, 2));
console.log('Sample Detailed Records:', JSON.stringify(records.filter(r => r.source === 'detailed').slice(0, 8), null, 2));
