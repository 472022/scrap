import fs from 'fs';
import { parseDatasetFile } from './parserService.js';

const buffer = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const { records, summary } = parseDatasetFile(buffer, 'Daily Report.xlsx');

console.log('Summary:', summary);

const deliveryRecs = records.filter(r => r.module === 'delivery');
console.log(`Total delivery records: ${deliveryRecs.length}`);

const otifDom = deliveryRecs.filter(r => r.metric_id === 'otif_dom');
console.log('--- otif_dom records ---');
console.table(otifDom);

const prodDom = deliveryRecs.filter(r => r.metric_id === 'prod_dom');
console.log('--- prod_dom records ---');
console.table(prodDom);

const prodTot = deliveryRecs.filter(r => r.metric_id === 'prod_tot');
console.log('--- prod_tot records ---');
console.table(prodTot);

const dispTot = deliveryRecs.filter(r => r.metric_id === 'disp_tot');
console.log('--- disp_tot records ---');
console.table(dispTot);
