import { getMetricValuesForPeriod } from './calculationEngine.js';

async function test() {
  const metrics = [
    'otif_dom', 'prod_l2', 'prod_l3', 'prod_tot',
    'disp_tmbsl', 'disp_acgl', 'disp_tot',
    'bus_4spcr_nac', 'bus_4spcr_ac', 'bus_maxicab_nac', 'bus_tot'
  ];

  console.log('=== CALCULATIONS FOR REPORTING DATE 2026-07-31 ===');
  for (const m of metrics) {
    const ftm = await getMetricValuesForPeriod(m, 'ftm', { reportingDate: '2026-07-31' });
    const lm = await getMetricValuesForPeriod(m, 'last_month', { reportingDate: '2026-07-31' });
    const ytd = await getMetricValuesForPeriod(m, 'ytd', { reportingDate: '2026-07-31' });
    console.log(`=== METRIC: ${m} ===`);
    console.log('  FTM (July 2026):', ftm);
    console.log('  Last Month (June 2026):', lm);
    console.log('  YTD (Apr-July 2026):', ytd);
  }

  console.log('\n=== CALCULATIONS FOR REPORTING DATE 2026-12-31 ===');
  for (const m of ['bus_4spcr_nac', 'bus_4spcr_ac', 'bus_maxicab_nac', 'bus_tot']) {
    const ftm = await getMetricValuesForPeriod(m, 'ftm', { reportingDate: '2026-12-31' });
    const lm = await getMetricValuesForPeriod(m, 'last_month', { reportingDate: '2026-12-31' });
    const ytd = await getMetricValuesForPeriod(m, 'ytd', { reportingDate: '2026-12-31' });
    console.log(`=== METRIC: ${m} ===`);
    console.log('  FTM (Dec 2026):', ftm);
    console.log('  Last Month (Nov 2026):', lm);
    console.log('  YTD (Apr-Dec 2026):', ytd);
  }
}

test();
