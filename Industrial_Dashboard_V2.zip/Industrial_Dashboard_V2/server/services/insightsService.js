// Dynamic Strengths and Top Focus Areas Engine

import { querySql, getSql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

export async function generateDashboardInsights(periodMode = 'monthly') {
  let kpis = await querySql('SELECT metric_id as id, metric_name as name, module, unit, section FROM metric_definitions');
  
  const strengths = [];
  const focusAreas = [];


  for (const kpi of kpis) {
    // Exclude sub-lines
    if (kpi.id.includes('_l1') || kpi.id.includes('_l2') || kpi.id.includes('_l3')) continue;

    const valObj = await getMetricValuesForPeriod(kpi.id, periodMode);
    const target = valObj.count > 0 ? valObj.target : (kpi.target || 0);
    const actual = valObj.count > 0 ? valObj.actual : (kpi.actual || 0);
    const ach = valObj.achievement;
    const lower = valObj.lowerBetter;
    const status = valObj.status;

    // Check for Strength: target met, high achievement
    if (status === 'Green' || ach >= 98) {
      let desc = '';
      if (target === 0 && actual === 0) {
        desc = `${kpi.name} Target Achieved (Zero Incidents / Defects)`;
      } else if (lower) {
        desc = `${kpi.name} Target Achieved (${actual} ${kpi.unit || ''} vs ${target} target)`;
      } else {
        desc = `${kpi.name} Target Met (${ach}% achieved, ${actual} / ${target} ${kpi.unit || ''})`;
      }
      strengths.push({
        metric_id: kpi.id,
        name: kpi.name,
        module: kpi.module,
        actual,
        target,
        unit: kpi.unit,
        achievement: ach,
        desc
      });
    }

    // Check for Focus Area: gap or red/yellow status
    if (status === 'Red' || status === 'Yellow' || ach < 95) {
      let gap = 0;
      let desc = '';
      if (target === 0 && actual > 0) {
        gap = actual * 20;
        desc = `Reduce ${kpi.name} (${actual} ${kpi.unit || ''} recorded, target is 0)`;
      } else if (lower && actual > target) {
        gap = ((actual - target) / (target || 1)) * 100;
        desc = `Reduce ${kpi.name} (${actual} ${kpi.unit || ''} vs ${target} target)`;
      } else {
        gap = 100 - ach;
        desc = `Improve ${kpi.name} (${ach}% achieved, ${actual} / ${target} ${kpi.unit || ''})`;
      }

      focusAreas.push({
        metric_id: kpi.id,
        name: kpi.name,
        module: kpi.module,
        actual,
        target,
        unit: kpi.unit,
        gap: Math.max(gap, status === 'Red' ? 50 : 20),
        desc
      });
    }
  }

  // Sort strengths by achievement descending
  strengths.sort((a, b) => b.achievement - a.achievement);

  // Sort focus areas by gap descending
  focusAreas.sort((a, b) => b.gap - a.gap);

  return {
    period: periodMode,
    strengths: strengths.slice(0, 5).map(s => s.desc),
    focusAreas: focusAreas.slice(0, 4).map(f => f.desc),
    detailedStrengths: strengths.slice(0, 5),
    detailedFocusAreas: focusAreas.slice(0, 4)
  };
}

export async function getTopStrengths(reportingDate, limit = 5) {
  const result = await generateDashboardInsights('monthly');
  return result.strengths.slice(0, limit);
}

export async function getTopFocusAreas(reportingDate, limit = 4) {
  const result = await generateDashboardInsights('monthly');
  return result.focusAreas.slice(0, limit);
}

