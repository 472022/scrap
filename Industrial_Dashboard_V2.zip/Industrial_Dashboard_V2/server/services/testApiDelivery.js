import { getMetricValuesForPeriod } from './calculationEngine.js';

async function testDeliveryApi() {
  const metrics = ['otif_dom', 'otif_ib', 'otif_spares', 'spd', 'mape_dom_ilmcv', 'prod_tot', 'disp_tot', 'bus_tot'];
  console.log('=== DELIVERY API CALCULATED VALUES FOR 2026-07-31 ===');
  for (const mId of metrics) {
    const ftm = await getMetricValuesForPeriod(mId, 'ftm', { reportingDate: '2026-07-31' });
    const lastMonth = await getMetricValuesForPeriod(mId, 'last_month', { reportingDate: '2026-07-31' });
    const ytd = await getMetricValuesForPeriod(mId, 'ytd', { reportingDate: '2026-07-31' });
    console.log(`Metric: ${mId}`);
    console.log('  FTM:       ', ftm);
    console.log('  Last Month:', lastMonth);
    console.log('  YTD:       ', ytd);
  }
}

testDeliveryApi().catch(console.error);
