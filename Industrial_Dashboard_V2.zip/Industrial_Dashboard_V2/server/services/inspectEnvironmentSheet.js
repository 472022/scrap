import fs from 'fs';
import * as xlsxModule from 'xlsx';

const xlsx = xlsxModule.default || xlsxModule;
const buffer = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const workbook = xlsx.read(buffer, { type: 'buffer', cellDates: true, raw: false });

console.log('=== ENVIRONMENT SHEETS ===');
const envSheets = workbook.SheetNames.filter(s => s.toLowerCase().includes('envir') || s.toLowerCase().includes('environ'));
console.log('Environment Sheets:', envSheets);

envSheets.forEach(sName => {
  console.log(`\n================ SHEET: "${sName}" ================`);
  const ws = workbook.Sheets[sName];
  const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
  rows.forEach((r, idx) => {
    if (r && r.length > 0) {
      console.log(`Row ${idx}:`, JSON.stringify(r));
    }
  });
});
