import fs from 'fs';
import * as xlsxModule from 'xlsx';
import { parseDatasetFile } from './parserService.js';

const buffer = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const { records } = parseDatasetFile(buffer, 'Daily Report.xlsx');

const envRecs = records.filter(r => r.module === 'environment');
console.log('--- ALL ENVIRONMENT RECORDS PARSED ---');
console.table(envRecs.map(r => ({
  period_date: r.period_date,
  metric_id: r.metric_id,
  metric_name: r.metric_name,
  target_value: r.target_value,
  actual_value: r.actual_value
})));
