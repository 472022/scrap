import { seedInitialPerformanceData } from '../seedData.js';
import { querySql, getSql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

async function main() {
  console.log('--- Reseeding Database ---');
  await seedInitialPerformanceData(true);

  const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  console.log('Reporting Date after reseed:', reportingConfig);

  const deliveryMetrics = await querySql("SELECT * FROM metric_definitions WHERE module = 'delivery' ORDER BY metric_id ASC");
  
  console.log('\n================ MONTHLY (FTM) CALCULATED VALUES ================');
  for (const m of deliveryMetrics) {
    const val = await getMetricValuesForPeriod(m.metric_id, 'ftm', { reportingDate: reportingConfig.value });
    console.log(`${m.metric_id.padEnd(20)} | Name: ${m.metric_name.padEnd(38)} | Target: ${String(val.target).padEnd(8)} | Actual: ${String(val.actual).padEnd(8)} | Status: ${val.status}`);
  }

  console.log('\n================ YTD CALCULATED VALUES ================');
  for (const m of deliveryMetrics) {
    const val = await getMetricValuesForPeriod(m.metric_id, 'ytd', { reportingDate: reportingConfig.value });
    console.log(`${m.metric_id.padEnd(20)} | Name: ${m.metric_name.padEnd(38)} | Target: ${String(val.target).padEnd(8)} | Actual: ${String(val.actual).padEnd(8)} | Status: ${val.status}`);
  }
}

main().catch(console.error);
