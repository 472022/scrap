import { seedInitialPerformanceData } from '../seedData.js';
import { querySql, getSql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

async function main() {
  console.log('--- Reseeding Database with Updated Parser ---');
  await seedInitialPerformanceData(true);

  const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  console.log('Reporting Date:', reportingConfig.value);

  const envMetrics = await querySql("SELECT * FROM metric_definitions WHERE module = 'environment' ORDER BY metric_id ASC");
  console.log(`Total Environment Metrics defined: ${envMetrics.length}`);

  console.log('\n================ MONTHLY (FTM) CALCULATED VALUES ================');
  for (const m of envMetrics) {
    const val = await getMetricValuesForPeriod(m.metric_id, 'ftm', { reportingDate: reportingConfig.value });
    console.log(`${m.metric_id.padEnd(20)} | Name: ${m.metric_name.padEnd(30)} | Target: ${String(val.target).padEnd(8)} | Actual: ${String(val.actual).padEnd(8)} | Status: ${val.status}`);
  }

  console.log('\n================ YTD CALCULATED VALUES ================');
  for (const m of envMetrics) {
    const val = await getMetricValuesForPeriod(m.metric_id, 'ytd', { reportingDate: reportingConfig.value });
    console.log(`${m.metric_id.padEnd(20)} | Name: ${m.metric_name.padEnd(30)} | Target: ${String(val.target).padEnd(8)} | Actual: ${String(val.actual).padEnd(8)} | Status: ${val.status}`);
  }

  console.log('\n--- RAW PERFORMANCE DATA FOR ENVIRONMENT ---');
  const raw = await querySql("SELECT metric_id, record_date, target_value, actual_value FROM performance_data WHERE module = 'environment' ORDER BY metric_id, record_date ASC");
  console.table(raw);
}

main().catch(console.error);
