import { querySql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

async function checkOtif() {
  const rows = await querySql("SELECT metric_id, record_date, target_value, actual_value FROM performance_data WHERE metric_id IN ('otif_dom', 'otif_ib', 'otif_spares', 'spd')");
  console.log('--- OTIF Raw Records in DB ---');
  console.table(rows);

  const dates = ['2026-07-31', '2026-09-30', '2026-12-31'];
  for (const rDate of dates) {
    console.log(`\n=== Calculated OTIF for Reporting Date: ${rDate} ===`);
    for (const mId of ['otif_dom', 'otif_ib', 'otif_spares', 'spd']) {
      const ftm = await getMetricValuesForPeriod(mId, 'ftm', { reportingDate: rDate });
      const lm = await getMetricValuesForPeriod(mId, 'last_month', { reportingDate: rDate });
      const ytd = await getMetricValuesForPeriod(mId, 'ytd', { reportingDate: rDate });
      console.log(`[${mId}] FTM:`, ftm, ' LastMonth:', lm, ' YTD:', ytd);
    }
  }
}

checkOtif().catch(console.error);
