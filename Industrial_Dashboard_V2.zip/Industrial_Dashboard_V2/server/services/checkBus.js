import { querySql } from '../db.js';

async function checkBus() {
  const rows = await querySql("SELECT metric_id, record_date, target_value, actual_value FROM performance_data WHERE metric_id LIKE 'bus_%'");
  console.log('Bus Records in DB count:', rows.length);
  console.log('Sample Bus Records:', rows.slice(0, 15));
}

checkBus().catch(console.error);
