import fs from 'fs';
import { parseDatasetFile } from './parserService.js';

const buffer = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const { records, summary } = parseDatasetFile(buffer, 'Daily Report.xlsx');

const invRecs = records.filter(r => r.module === 'inventory');
console.log(`Total inventory records extracted: ${invRecs.length}`);

console.log('\n--- ALL PARSED INVENTORY RECORDS ---');
console.table(invRecs.map(r => ({
  period_date: r.period_date,
  metric_id: r.metric_id,
  metric_name: r.metric_name,
  target_value: r.target_value,
  actual_value: r.actual_value,
  unit: r.unit,
  section: r.section
})));
