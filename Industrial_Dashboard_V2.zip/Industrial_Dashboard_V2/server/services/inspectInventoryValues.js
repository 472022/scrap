import fs from 'fs';
import * as xlsxModule from 'xlsx';

const xlsx = xlsxModule.default || xlsxModule;
const buffer = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const workbook = xlsx.read(buffer, { type: 'buffer', cellDates: true, raw: false });

console.log('=== ALL SHEETS IN DAILY REPORT.XLSX ===');
console.log(workbook.SheetNames);

workbook.SheetNames.forEach(sheetName => {
  if (sheetName.toLowerCase().includes('inventory')) {
    console.log(`\n================ SHEET: "${sheetName}" ================`);
    const ws = workbook.Sheets[sheetName];
    const rows = xlsx.utils.sheet_to_json(ws, { header: 1 });
    rows.forEach((r, idx) => {
      console.log(`Row ${idx}:`, JSON.stringify(r));
    });
  }
});
