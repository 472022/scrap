// Calculation Engine for FTM, Last Month, YTD, Achievement Scores & Module Summaries

import { querySql, getSql } from '../db.js';

// Helper to determine if a metric is lower-is-better
export function isLowerBetter(metricDef, kpiId = '') {
  if (metricDef && metricDef.direction) {
    return metricDef.direction === 'lower_better';
  }
  const id = kpiId.toLowerCase();
  if (id.includes('lti') || id.includes('mtc') || id.includes('rwc') || id.includes('fac') || id.includes('trcfr')) return true;
  if (id.includes('payout') || id.includes('warranty') || id.includes('visit') || id.includes('lost') || id.includes('absenteeism')) return true;
  if (id.includes('cost') || id.includes('repro') || id.includes('vcc') || id.includes('ofe')) return true;
  if (id.includes('inv_') || id.includes('days') || id.includes('fuel') || id.includes('power') || id.includes('water')) return true;
  return false;
}

// Compute target achievement score (0 - 100%)
export function calculateAchievement(target, actual, lowerBetter = false) {
  const tgt = (target === null || target === undefined || isNaN(target)) ? 0 : Number(target);
  const act = (actual === null || actual === undefined || isNaN(actual)) ? 0 : Number(actual);

  if (act === tgt) return 100;

  if (lowerBetter) {
    if (tgt === 0) return act === 0 ? 100 : 0;
    if (act <= tgt) return 100;
    if (act === 0) return 100;
    const ach = (tgt / act) * 100;
    return Math.min(100, Math.max(0, parseFloat(ach.toFixed(1))));
  }

  if (tgt === 0) return act === 0 ? 100 : 0;
  const ach = (act / tgt) * 100;
  return Math.min(100, Math.max(0, parseFloat(ach.toFixed(1))));
}

// Determine RAG Status (Green, Yellow, Red)
export function calculateStatus(target, actual, lowerBetter = false) {
  const tgt = (target === null || target === undefined || isNaN(target)) ? 0 : Number(target);
  const act = (actual === null || actual === undefined || isNaN(actual)) ? 0 : Number(actual);

  if (act === tgt) return 'Green';

  if (lowerBetter) {
    return act <= tgt ? 'Green' : 'Red';
  }

  const ach = calculateAchievement(tgt, act, false);
  if (ach >= 95) return 'Green';
  if (ach >= 80) return 'Yellow';
  return 'Red';
}

// Calculate Fiscal Year integer for a date string (e.g. FY27 for April 2026 - March 2027)
export function getFiscalYear(dateStr, fyStartMonth = 4) {
  const d = new Date(dateStr);
  const year = d.getFullYear();
  const month = d.getMonth() + 1; // 1-12
  if (month >= fyStartMonth) {
    return year + 1;
  }
  return year;
}

// Main calculation engine service function
export async function getMetricValuesForPeriod(metricId, periodMode = 'monthly', options = {}) {
  const fyStartConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'fiscal_year_start_month'");
  const fyStartMonth = fyStartConfig ? parseInt(fyStartConfig.value) : 4;

  const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  const reportingDateStr = (options.reportingDate || (reportingConfig ? reportingConfig.value : '2026-09-30'));
  
  const d = new Date(reportingDateStr);
  const targetYear = d.getFullYear();
  const targetMonth = d.getMonth() + 1; // 1-12
  const targetFiscalYear = getFiscalYear(reportingDateStr, fyStartMonth);

  // Fetch metric definition
  const def = await getSql('SELECT * FROM metric_definitions WHERE metric_id = ?', [metricId]);
  const aggType = def ? def.aggregation_type : 'sum';
  const lower = isLowerBetter(def, metricId);

  let rows = [];

  if (periodMode === 'monthly' || periodMode === 'ftm') {
    // Current reporting month records
    const query = `
      SELECT target_value, actual_value, record_date
      FROM performance_data
      WHERE metric_id = ? AND year = ? AND month = ?
      ORDER BY record_date DESC
    `;
    const params = [metricId, targetYear, targetMonth];
    rows = await querySql(query, params);

    // CLOSEST PREVIOUS MONTH LOGIC:
    // If no row exists for current month OR if actual_value === 0 while target_value > 0 (unfinalized active month),
    // automatically fallback to the closest previous month in the fiscal year with actual_value > 0
    const hasValidActual = rows && rows.length > 0 && rows.some(r => r.actual_value !== null && r.actual_value !== undefined && (r.actual_value > 0 || (r.target_value === 0 && r.actual_value === 0)));

    if (!hasValidActual) {
      const fbQuery = `
        SELECT target_value, actual_value, record_date
        FROM performance_data
        WHERE metric_id = ? AND record_date <= ? AND (actual_value > 0 OR target_value > 0)
        ORDER BY record_date DESC
        LIMIT 1
      `;
      const fbRows = await querySql(fbQuery, [metricId, reportingDateStr]);
      if (fbRows && fbRows.length > 0) {
        rows = fbRows;
      }
    }
  } else if (periodMode === 'last_month') {
    // Previous calendar month
    let lmYear = targetYear;
    let lmMonth = targetMonth - 1;
    if (lmMonth < 1) {
      lmMonth = 12;
      lmYear -= 1;
    }
    const query = `
      SELECT target_value, actual_value, record_date
      FROM performance_data
      WHERE metric_id = ? AND year = ? AND month = ?
      ORDER BY record_date DESC
    `;
    const params = [metricId, lmYear, lmMonth];
    rows = await querySql(query, params);

    // Fallback: if no direct row for last month, search prior months in fiscal year with actual_value > 0
    if (!rows || rows.length === 0 || !rows.some(r => r.actual_value > 0)) {
      const lmDateStr = `${lmYear}-${String(lmMonth).padStart(2, '0')}-01`;
      const fbQuery = `
        SELECT target_value, actual_value, record_date
        FROM performance_data
        WHERE metric_id = ? AND fiscal_year = ? AND record_date < ? AND actual_value > 0
        ORDER BY record_date DESC
        LIMIT 1
      `;
      const fbRows = await querySql(fbQuery, [metricId, targetFiscalYear, lmDateStr]);
      if (fbRows && fbRows.length > 0) {
        rows = fbRows;
      }
    }
  } else if (periodMode === 'ytd') {
    // Fiscal Year to Date records up to reporting date
    const query = `
      SELECT target_value, actual_value, record_date
      FROM performance_data
      WHERE metric_id = ? AND fiscal_year = ? AND record_date <= ?
      ORDER BY record_date ASC
    `;
    const params = [metricId, targetFiscalYear, reportingDateStr];
    rows = await querySql(query, params);
  }

  if (!rows || rows.length === 0) {
    return { target: 0, actual: 0, count: 0, achievement: 100, status: 'Green', lowerBetter: lower };
  }

  let finalTarget = 0;
  let finalActual = 0;

  if (metricId === 'hr_pcvh') {
    const rawTarget = (rows[0] && rows[0].target_value) ? rows[0].target_value : 48;
    const rawActual = (rows[0] && rows[0].actual_value) ? rows[0].actual_value : 20.38;
    const elapsedMonths = Math.max(1, Math.min(12, targetMonth >= 4 ? targetMonth - 3 : targetMonth + 9));

    if (periodMode === 'monthly' || periodMode === 'ftm') {
      finalTarget = parseFloat((rawTarget / 12).toFixed(2));
      finalActual = parseFloat((rawActual / elapsedMonths).toFixed(2));
    } else {
      finalTarget = parseFloat((rawTarget * (elapsedMonths / 12)).toFixed(2));
      finalActual = rawActual;
    }
  } else if (aggType === 'latest') {
    finalTarget = rows[0].target_value || 0;
    finalActual = rows[0].actual_value || 0;
  } else if (aggType === 'avg') {
    // Filter out unfinalized zero-actual rows for YTD/monthly average calculations
    const nonZeroActualRows = rows.filter(r => r.actual_value !== null && !isNaN(r.actual_value) && (r.actual_value > 0 || (r.target_value === 0 && r.actual_value === 0)));
    const activeRows = nonZeroActualRows.length > 0 ? nonZeroActualRows : rows;

    const validT = activeRows.map(r => r.target_value).filter(v => v !== null && !isNaN(v));
    const validA = activeRows.map(r => r.actual_value).filter(v => v !== null && !isNaN(v));
    finalTarget = validT.length > 0 ? parseFloat((validT.reduce((a, b) => a + b, 0) / validT.length).toFixed(2)) : 0;
    finalActual = validA.length > 0 ? parseFloat((validA.reduce((a, b) => a + b, 0) / validA.length).toFixed(2)) : 0;
  } else {
    // SUM aggregation
    // Filter out unfinalized zero-actual rows for YTD sum calculations (don't add zero actuals or unentered months)
    const validRows = periodMode === 'ytd'
      ? rows.filter(r => r.actual_value !== null && !isNaN(r.actual_value) && (r.actual_value > 0 || (r.target_value === 0 && r.actual_value === 0)))
      : rows;
    const activeRows = validRows.length > 0 ? validRows : rows;

    finalTarget = parseFloat(activeRows.reduce((acc, r) => acc + (r.target_value || 0), 0).toFixed(2));
    finalActual = parseFloat(activeRows.reduce((acc, r) => acc + (r.actual_value || 0), 0).toFixed(2));
  }

  const ach = calculateAchievement(finalTarget, finalActual, lower);
  const status = calculateStatus(finalTarget, finalActual, lower);

  return {
    target: finalTarget,
    actual: finalActual,
    count: rows.length,
    achievement: ach,
    status,
    lowerBetter: lower
  };
}
