import { querySql, getSql } from '../db.js';
import { getMetricValuesForPeriod } from './calculationEngine.js';

async function checkPcvh() {
  const rows = await querySql("SELECT * FROM performance_data WHERE metric_id = 'hr_pcvh' ORDER BY record_date ASC");
  console.log('--- ALL PERFORMANCE DATA ROWS FOR hr_pcvh ---');
  console.table(rows);

  const reportingConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'current_reporting_date'");
  console.log('\nCurrent Reporting Date:', reportingConfig.value);

  const ftm = await getMetricValuesForPeriod('hr_pcvh', 'ftm', { reportingDate: reportingConfig.value });
  const ytd = await getMetricValuesForPeriod('hr_pcvh', 'ytd', { reportingDate: reportingConfig.value });

  console.log('\nFTM Calculated:', ftm);
  console.log('YTD Calculated:', ytd);
}

checkPcvh().catch(console.error);
