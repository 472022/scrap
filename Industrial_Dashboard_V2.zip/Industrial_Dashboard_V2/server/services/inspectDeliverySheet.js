import fs from 'fs';
import * as xlsxModule from 'xlsx';

const xlsx = xlsxModule.default || xlsxModule;

const buf = fs.readFileSync('C:/Users/usp/Downloads/Daily Report.xlsx');
const wb = xlsx.read(buf, { type: 'buffer' });

console.log('=== ALL SHEET NAMES ===');
console.log(wb.SheetNames);

wb.SheetNames.forEach(sName => {
  const cleanName = sName.trim();
  if (cleanName === 'Delivery Summary' || cleanName === 'Delivery') {
    console.log(`\n================ SHEET: "${sName}" ================`);
    const rows = xlsx.utils.sheet_to_json(wb.Sheets[sName], { header: 1 });
    rows.slice(0, 40).forEach((r, idx) => {
      if (r && r.length > 0) {
        console.log(`Row ${idx}:`, JSON.stringify(r.slice(0, 10)));
      }
    });
  }
});
