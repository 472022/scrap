import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { runSql, getSql, querySql } from '../db.js';
import { calculateFileHash, parseDatasetFile } from '../services/parserService.js';
import { getFiscalYear } from '../services/calculationEngine.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '../..');
const uploadDir = path.join(projectRoot, 'uploads');

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB limit
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (['.csv', '.xlsx', '.xls'].includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file format. Only .csv, .xlsx, and .xls files are supported.'));
    }
  }
});

const router = express.Router();

/**
 * POST /api/upload - Multipart dataset upload handler
 */
router.post('/upload', upload.single('dataset'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded.' });
    }

    const fileBuffer = fs.readFileSync(req.file.path);
    const fileHash = calculateFileHash(fileBuffer);
    const forceUpload = req.body.force === 'true';

    // Check for duplicate upload hash
    const existingUpload = await getSql('SELECT upload_id, file_name, upload_timestamp FROM uploads WHERE file_hash = ?', [fileHash]);
    if (existingUpload && !forceUpload) {
      // Remove temporary file
      fs.unlinkSync(req.file.path);
      return res.status(409).json({
        warning: 'Duplicate file upload detected.',
        existingUpload: {
          upload_id: existingUpload.upload_id,
          file_name: existingUpload.file_name,
          upload_timestamp: existingUpload.upload_timestamp
        },
        message: 'This exact file has already been uploaded previously. Send force=true to bypass.'
      });
    }

    // Parse dataset file
    const parseResult = parseDatasetFile(fileBuffer, req.file.originalname);
    const { records, summary } = parseResult;

    if (records.length === 0) {
      fs.unlinkSync(req.file.path);
      return res.status(422).json({
        error: 'No valid data records could be extracted from the file.',
        summary
      });
    }

    const uploadId = 'up_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const timestamp = new Date().toISOString();
    const fyStartConfig = await getSql("SELECT value FROM dashboard_config WHERE key = 'fiscal_year_start_month'");
    const fyStartMonth = fyStartConfig ? parseInt(fyStartConfig.value) : 4;

    // Transactional DB save
    await runSql('BEGIN TRANSACTION');

    try {
      // Save upload record
      await runSql(`
        INSERT INTO uploads (upload_id, file_name, file_hash, file_format, upload_timestamp, reporting_period, total_rows, valid_rows, rejected_rows, status, summary_json)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        uploadId,
        req.file.originalname,
        fileHash,
        path.extname(req.file.originalname).replace('.', '').toLowerCase(),
        timestamp,
        records[0].period_date || '2025-08',
        summary.totalParsedRows,
        records.length,
        summary.rejected_rows || 0,
        'completed',
        JSON.stringify(summary)
      ]);

      // Insert performance data records
      for (const rec of records) {
        let pDate = rec.period_date || '2026-07-01';
        if (pDate.length === 7) {
          pDate = pDate + '-01';
        }
        const dObj = new Date(pDate);
        const yr = !isNaN(dObj.getFullYear()) ? dObj.getFullYear() : 2026;
        const mo = !isNaN(dObj.getMonth()) ? dObj.getMonth() + 1 : 7;
        const fy = getFiscalYear(pDate, fyStartMonth) || (mo >= 4 ? yr + 1 : yr);

        await runSql(`
          INSERT INTO performance_data (upload_id, record_date, year, month, fiscal_year, plant, department, module, category, metric_id, target_value, actual_value, unit)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          uploadId,
          pDate,
          yr,
          mo,
          fy,
          'Dharwad Plant',
          rec.department || 'General',
          rec.module || 'general',
          rec.section || '',
          rec.metric_id,
          rec.target_value !== undefined ? rec.target_value : null,
          rec.actual_value !== undefined ? rec.actual_value : 0,
          rec.unit || ''
        ]);
      }

      // Update current reporting date in config if latest record date is newer
      const maxDateRow = await getSql("SELECT MAX(record_date) as max_date FROM performance_data WHERE upload_id = ? AND record_date <= '2026-12-31'", [uploadId]);
      const activeDate = (maxDateRow && maxDateRow.max_date) ? maxDateRow.max_date : records[0].period_date;
      if (activeDate) {
        await runSql("INSERT OR REPLACE INTO dashboard_config (key, value) VALUES ('current_reporting_date', ?)", [activeDate]);
      }

      await runSql('COMMIT');

      // Log success
      await runSql(`
        INSERT INTO processing_logs (upload_id, stage, status, message, timestamp)
        VALUES (?, 'parse_and_insert', 'success', ?, ?)
      `, [uploadId, `Successfully processed ${records.length} performance records.`, timestamp]);

      return res.status(200).json({
        success: true,
        upload_id: uploadId,
        file_name: req.file.originalname,
        processed_records: records.length,
        reporting_period: records[0].period_date,
        summary
      });
    } catch (dbErr) {
      await runSql('ROLLBACK');
      if (fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      console.error('[Upload DB Error]', dbErr);
      return res.status(500).json({ error: 'Database transaction failed during file import.', details: dbErr.message });
    }
  } catch (err) {
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
    console.error('[Upload Handler Error]', err);
    return res.status(500).json({ error: 'File upload processing failed.', details: err.message });
  }
});

export default router;
