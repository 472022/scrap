import fs from 'fs';
import path from 'path';
import { runSql, getSql } from './db.js';
import { parseDatasetFile } from './services/parserService.js';
import { getFiscalYear } from './services/calculationEngine.js';

export async function seedInitialPerformanceData(force = false) {
  if (force) {
    console.log('[Seed] Force clearing existing performance_data...');
    await runSql("DELETE FROM performance_data");
  } else {
    const existingCount = await getSql('SELECT COUNT(*) as cnt FROM performance_data');
    if (existingCount && existingCount.cnt > 0) {
      // If existing records were synthetic, clear them and seed real dataset
      const seedInitCount = await getSql("SELECT COUNT(*) as cnt FROM performance_data WHERE upload_id = 'seed_init'");
      if (!seedInitCount || seedInitCount.cnt === 0) {
        console.log(`[Seed] performance_data already contains ${existingCount.cnt} real user records. Skipping seed.`);
        return;
      }
      // Clear synthetic seed records to replace with real Dharwad dataset
      await runSql("DELETE FROM performance_data WHERE upload_id = 'seed_init'");
    }
  }

  console.log('[Seed] Seeding Dharwad Plant performance dataset into SQLite...');

  const samplePath = 'C:/Users/usp/Downloads/Daily Report.xlsx';
  if (fs.existsSync(samplePath)) {
    try {
      const buffer = fs.readFileSync(samplePath);
      const { records, summary } = parseDatasetFile(buffer, 'Daily Report.xlsx');

      await runSql('BEGIN TRANSACTION');

      for (const rec of records) {
        const pDate = rec.period_date || '2026-07-01';
        const dObj = new Date(pDate);
        const yr = dObj.getFullYear() || 2026;
        const mo = dObj.getMonth() + 1 || 7;
        const fy = getFiscalYear(pDate, 4);

        await runSql(`
          INSERT INTO performance_data (upload_id, record_date, year, month, fiscal_year, plant, department, module, category, metric_id, target_value, actual_value, unit)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          'dharwad_daily_report',
          pDate,
          yr,
          mo,
          fy,
          'Dharwad Plant',
          rec.department || 'General',
          rec.module || 'general',
          rec.section || '',
          rec.metric_id,
          rec.target_value !== undefined ? rec.target_value : null,
          rec.actual_value !== undefined ? rec.actual_value : 0,
          rec.unit || ''
        ]);
      }

      // Dynamically update current reporting date to max date in performance_data
      const maxRow = await getSql("SELECT MAX(record_date) as max_date FROM performance_data WHERE target_value > 0 OR actual_value > 0");
      const latestDateStr = (maxRow && maxRow.max_date) ? maxRow.max_date : '2026-12-31';
      const reportingDateStr = latestDateStr.length === 10 ? latestDateStr.replace(/-01$/, '-28') : '2026-12-31';

      await runSql("INSERT OR REPLACE INTO dashboard_config (key, value) VALUES ('current_reporting_date', ?)", [reportingDateStr]);

      await runSql('COMMIT');
      console.log(`[Seed] Successfully seeded ${records.length} records from Dharwad Daily Report.xlsx!`);
      return;
    } catch (err) {
      await runSql('ROLLBACK');
      console.error('[Seed Excel Parsing Error]', err);
    }
  }

  // Fallback synthetic seed if file not found
  console.log('[Seed] Seeding fallback baseline performance data...');
  const periods = ['2026-04-01', '2026-05-01', '2026-06-01', '2026-07-01'];
  await runSql('BEGIN TRANSACTION');
  for (const def of DEFAULT_METRIC_DEFINITIONS) {
    for (const pDate of periods) {
      const dObj = new Date(pDate);
      const yr = dObj.getFullYear();
      const mo = dObj.getMonth() + 1;
      const fy = getFiscalYear(pDate, 4);
      await runSql(`
        INSERT INTO performance_data (upload_id, record_date, year, month, fiscal_year, plant, department, module, category, metric_id, target_value, actual_value, unit)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, ['seed_fallback', pDate, yr, mo, fy, 'Dharwad Plant', 'General', def.module, def.section || '', def.metric_id, 100, 95, def.unit || '']);
    }
  }
  await runSql("INSERT OR REPLACE INTO dashboard_config (key, value) VALUES ('current_reporting_date', '2026-07-31')");
  await runSql('COMMIT');
}
