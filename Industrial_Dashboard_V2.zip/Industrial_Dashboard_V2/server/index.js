import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase } from './db.js';
import apiRouter from './routes/api.js';
import uploadRouter from './routes/upload.js';
import authRouter from './routes/auth.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '..');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Register API Routes
app.use('/api', authRouter);
app.use('/api', uploadRouter);
app.use('/api', apiRouter);

// Serve Static Uploads
app.use('/uploads', express.static(path.join(projectRoot, 'uploads')));

// Serve Production Frontend Dist if built
const distPath = path.join(projectRoot, 'dist');
app.use(express.static(distPath));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString(), service: 'Industrial Dashboard Backend V2' });
});

// Fallback for SPA routing
app.use((req, res) => {
  const indexPath = path.join(distPath, 'index.html');
  if (req.accepts('html') && !req.path.startsWith('/api')) {
    res.sendFile(indexPath, (err) => {
      if (err) {
        res.status(200).send('Industrial Dashboard API backend running. Frontend client available via Vite dev server.');
      }
    });
  } else {
    res.status(404).json({ error: 'Endpoint not found.' });
  }
});

// Initialize database and start server
async function startServer() {
  try {
    await initDatabase();
    app.listen(PORT, () => {
      console.log(`====================================================`);
      console.log(` INDUSTRIAL DASHBOARD V2 BACKEND SERVER STARTED    `);
      console.log(` Server URL: http://localhost:${PORT}              `);
      console.log(` Health Check: http://localhost:${PORT}/api/health `);
      console.log(` Database: SQLite (data/industrial_dashboard.db)   `);
      console.log(`====================================================`);
    });
  } catch (err) {
    console.error('[Server Start Error]', err);
    process.exit(1);
  }
}

startServer();
