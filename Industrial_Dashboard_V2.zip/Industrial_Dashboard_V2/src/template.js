// Excel/CSV Template Downloader and Exporter

import { INITIAL_KPIS } from './state.js';

export function downloadCSVTemplate() {
  const headers = ['KPI ID', 'KPI Name', 'Target', 'Actual', 'Unit', 'Section'];
  
  const rows = INITIAL_KPIS.map(kpi => [
    kpi.id,
    kpi.name,
    kpi.target,
    kpi.actual,
    kpi.unit,
    kpi.section
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(val => {
      // Escape commas and quotes in values if any
      const strVal = String(val);
      if (strVal.includes(',') || strVal.includes('"') || strVal.includes('\n')) {
        return `"${strVal.replace(/"/g, '""')}"`;
      }
      return strVal;
    }).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'safety_dashboard_template.csv');
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Function to export current dashboard data as CSV
export function exportCurrentData(kpis) {
  const headers = ['KPI ID', 'KPI Name', 'Target', 'Actual', 'Unit', 'Section'];
  
  const rows = kpis.map(kpi => [
    kpi.id,
    kpi.name,
    kpi.target,
    kpi.actual,
    kpi.unit,
    kpi.section
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(val => {
      const strVal = String(val);
      if (strVal.includes(',') || strVal.includes('"') || strVal.includes('\n')) {
        return `"${strVal.replace(/"/g, '""')}"`;
      }
      return strVal;
    }).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'current_safety_data.csv');
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
