import { getAchievement, getStatus, getKpiForMode, renderDirectionBadge } from '../state.js';

// Helper to format values dynamically (retains percentage/ratio formatting, limiting to 2 decimal places)
function formatKpiValue(val, unit) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  if (unit === 'percent' || unit === 'Paercentage' || unit === '%') {
    let rawPct = val;
    if (val <= 1.0) {
      rawPct = val * 100;
    }
    return `${parseFloat(rawPct.toFixed(2))}%`;
  }
  if (unit === 'ratio') {
    return `${parseFloat((val * 100).toFixed(2))}%`;
  }
  
  return parseFloat(val.toFixed(2));
}

export function renderKpiTable(kpis, activeModule, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const moduleKpis = kpis.filter(k => 
    k.module === activeModule && 
    (activeModule !== 'safety' || k.section === 'safety_dashboard')
  );

  let capitalizedTitle = activeModule.charAt(0).toUpperCase() + activeModule.slice(1) + ' Dashboard';
  if (activeModule === 'safety' && mode) {
    capitalizedTitle = mode === 'monthly' ? 'Monthly Safety Parameters' : 'YTD Safety Parameters';
  }

  let html = `
    <div class="card table-card">
      <div class="card-header">${capitalizedTitle}</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th class="col-kpi" style="width: 34%;">KPI</th>
              <th class="col-measure" style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th class="col-target" style="width: 13%;">Target</th>
              <th class="col-actual" style="width: 13%;">Actual</th>
              <th class="col-status" style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  moduleKpis.forEach((kpi, idx) => {
    let target = kpi.target;
    let actual = kpi.actual;
    if (mode) {
      const valObj = getKpiForMode(kpi, mode);
      target = valObj.target;
      actual = valObj.actual;
    }

    const ach = parseFloat(getAchievement(kpi, mode).toFixed(2));
    const status = getStatus(kpi, mode);
    const statusClass = `status-${status.toLowerCase()}`;
    
    // Formatting values with dynamic UoM
    const targetVal = formatKpiValue(target, kpi.unit);
    const actualVal = formatKpiValue(actual, kpi.unit);
    const cleanName = (kpi.name || '').replace(/^\d+\.\s*/, '');
    
    html += `
      <tr>
        <td class="col-kpi">${idx + 1}. ${cleanName}</td>
        <td class="col-measure" style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${targetVal}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${actualVal}</td>
        <td class="col-status cell-status ${statusClass}">
          <span class="status-pill">${ach}%</span>
        </td>
      </tr>
    `;

    if (kpi.id === 'sif_derisking') {
      const p2 = kpis.find(k => k.id === 'phase_2');
      const p3 = kpis.find(k => k.id === 'phase_3');
      
      [p2, p3].forEach((subKpi, subIdx) => {
        if (!subKpi) return;
        let subTarget = subKpi.target;
        let subActual = subKpi.actual;
        if (mode) {
          const subValObj = getKpiForMode(subKpi, mode);
          subTarget = subValObj.target;
          subActual = subValObj.actual;
        }
        
        const subAch = parseFloat(getAchievement(subKpi, mode).toFixed(2));
        const subStatus = getStatus(subKpi, mode);
        const subStatusClass = `status-${subStatus.toLowerCase()}`;
        
        const subTargetVal = formatKpiValue(subTarget, subKpi.unit);
        const subActualVal = formatKpiValue(subActual, subKpi.unit);
        const subLetter = subIdx === 0 ? 'a' : 'b';
        
        html += `
          <tr class="nested-row" style="background-color: #f8fafc;">
            <td class="col-kpi" style="padding-left: 32px; font-size: 12px; color: #475569;">${subLetter}. ${subKpi.name}</td>
            <td class="col-measure" style="text-align: center;">${renderDirectionBadge(subKpi)}</td>
            <td class="col-uom" style="font-size: 12px; color: #475569;">${subKpi.unit || '-'}</td>
            <td class="col-target" style="font-weight: 600; color: #475569; font-size: 12px;">${subTargetVal}</td>
            <td class="col-actual" style="font-weight: 700; color: #475569; font-size: 12px;">${subActualVal}</td>
            <td class="col-status cell-status ${subStatusClass}" style="padding: 4px 8px;">
              <span class="status-pill" style="font-size: 10px; padding: 2px 6px;">${subAch}%</span>
            </td>
          </tr>
        `;
      });
    }
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}
