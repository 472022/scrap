// Incident Cards Component

import { state, getStatus, getAchievement } from '../state.js';

export function renderIncidentCards(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const getLatestVal = (arr) => {
    if (!arr || arr.length === 0) return 0;
    for (let i = arr.length - 1; i >= 0; i--) {
      const val = arr[i];
      if (val !== null && val !== undefined && !isNaN(val)) return val;
    }
    return 0;
  };

  const getMetricData = (id) => {
    const kpi = kpis.find(k => k.id === id);
    let name = kpi ? kpi.name : id.toUpperCase();
    let unit = kpi ? (kpi.unit || 'incidents') : 'incidents';
    
    let monthlyActual = 0;
    let monthlyTarget = kpi ? kpi.target : 0;
    let ytdActual = 0;
    let ytdTarget = kpi ? kpi.target : 0;

    const smd = state.safetyMonthlyData || {};
    const fyData = smd.fyData || {};

    if (id === 'lti') {
      name = 'LTI';
      unit = 'incidents';
      monthlyActual = smd.ltaObj ? smd.ltaObj.ftm : (smd.lta ? getLatestVal(smd.lta) : (kpi ? kpi.actual : 0));
      monthlyTarget = 0;
      ytdActual = smd.ltaObj ? smd.ltaObj.ytd : ((fyData.lta && fyData.lta.ytd !== undefined) ? fyData.lta.ytd : monthlyActual);
      ytdTarget = 0;
    } else if (id === 'rwc') {
      name = 'RWC';
      unit = 'incidents';
      monthlyActual = smd.rwcObj ? smd.rwcObj.ftm : (smd.rwc ? getLatestVal(smd.rwc) : (kpi ? kpi.actual : 0));
      monthlyTarget = 0;
      ytdActual = smd.rwcObj ? smd.rwcObj.ytd : ((fyData.rwc && fyData.rwc.ytd !== undefined) ? fyData.rwc.ytd : monthlyActual);
      ytdTarget = 0;
    } else if (id === 'mtc') {
      name = 'MTC';
      unit = 'incidents';
      monthlyActual = smd.mtcObj ? smd.mtcObj.ftm : (smd.mtc ? getLatestVal(smd.mtc) : (kpi ? kpi.actual : 0));
      monthlyTarget = 0;
      ytdActual = smd.mtcObj ? smd.mtcObj.ytd : ((fyData.mtc && fyData.mtc.ytd !== undefined) ? fyData.mtc.ytd : monthlyActual);
      ytdTarget = 0;
    } else if (id === 'fac') {
      name = 'FAC';
      unit = 'incidents';
      monthlyActual = smd.facObj ? smd.facObj.ftm : (smd.fac ? getLatestVal(smd.fac) : (kpi ? kpi.actual : 0));
      monthlyTarget = 0;
      ytdActual = smd.facObj ? smd.facObj.ytd : ((fyData.fac && fyData.fac.ytd !== undefined) ? fyData.fac.ytd : monthlyActual);
      ytdTarget = 0;
    } else if (id === 'psi_1') {
      name = 'PSI I';
      unit = 'score';
      monthlyActual = smd.psi1Obj ? (smd.psi1Obj.actuals.length > 0 ? smd.psi1Obj.actuals[smd.psi1Obj.actuals.length - 1] : 0) : (smd.psi1 ? getLatestVal(smd.psi1) : (kpi ? kpi.actual : 0));
      monthlyTarget = smd.psi1Targets ? getLatestVal(smd.psi1Targets) : 95;
      ytdActual = smd.psi1Obj ? smd.psi1Obj.ytdActual : ((fyData.psi1 && fyData.psi1.ytd !== undefined) ? fyData.psi1.ytd : monthlyActual);
      ytdTarget = monthlyTarget;
    } else if (id === 'psi_2') {
      name = 'PSI II';
      unit = 'score';
      monthlyActual = smd.psi2Obj ? (smd.psi2Obj.actuals.length > 0 ? smd.psi2Obj.actuals[smd.psi2Obj.actuals.length - 1] : 0) : (smd.psi2 ? getLatestVal(smd.psi2) : (kpi ? kpi.actual : 0));
      monthlyTarget = smd.psi2Targets ? getLatestVal(smd.psi2Targets) : 100;
      ytdActual = smd.psi2Obj ? smd.psi2Obj.ytdActual : ((fyData.psi2 && fyData.psi2.ytd !== undefined) ? fyData.psi2.ytd : monthlyActual);
      ytdTarget = monthlyTarget;
    } else if (id === 'trcfr') {
      name = 'TRCFR';
      unit = 'rate';
      monthlyActual = smd.trcfrObj ? (smd.trcfrObj.actuals.length > 0 ? smd.trcfrObj.actuals[smd.trcfrObj.actuals.length - 1] : 0) : (smd.trcfr ? getLatestVal(smd.trcfr) : (kpi ? kpi.actual : 0));
      monthlyTarget = smd.trcfrTargets ? getLatestVal(smd.trcfrTargets) : 0.31;
      ytdActual = smd.trcfrObj ? smd.trcfrObj.ytdActual : ((fyData.trcfr && fyData.trcfr.ytd !== undefined) ? fyData.trcfr.ytd : monthlyActual);
      ytdTarget = monthlyTarget;
    }

    return { name, unit, monthlyActual, monthlyTarget, ytdActual, ytdTarget };
  };

  const getStatusClasses = (id, actual, target) => {
    const act = (actual === null || actual === undefined || isNaN(actual)) ? 0 : Number(actual);
    const tgt = (target === null || target === undefined || isNaN(target)) ? 0 : Number(target);

    let isGreen = true;
    if (act === tgt) {
      isGreen = true;
    } else if (id === 'lti' || id === 'rwc' || id === 'mtc' || id === 'fac' || id === 'trcfr') {
      isGreen = (act <= tgt);
    } else if (id === 'psi_1' || id === 'psi_2') {
      isGreen = (act >= tgt);
    } else {
      isGreen = (act >= tgt);
    }

    return {
      textClass: isGreen ? 'text-green' : 'text-red',
      borderClass: isGreen ? 'card-border-green' : 'card-border-red'
    };
  };

  const formatVal = (val, unit) => {
    if (val === null || val === undefined || isNaN(val)) return '0';
    const num = Number(val);
    return (unit === 'rate') ? num.toFixed(2) : num.toString();
  };

  const incidentIds = ['lti', 'rwc', 'mtc', 'fac'];
  const scoreIds = ['psi_1', 'psi_2', 'trcfr'];

  const makeCardRowHtml = (ids, type) => {
    let rowHtml = '';
    ids.forEach(id => {
      const data = getMetricData(id);
      const val = (type === 'monthly') ? data.monthlyActual : data.ytdActual;
      const target = (type === 'monthly') ? data.monthlyTarget : data.ytdTarget;
      const { textClass, borderClass } = getStatusClasses(id, val, target);
      const displayVal = formatVal(val, data.unit);
      const displayTarget = formatVal(target, data.unit);

      rowHtml += `
        <div class="incident-subcard ${borderClass}" style="flex: 1 1 0%; min-width: 0; padding: 14px 6px; border-radius: 8px; text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
          <div class="incident-title" style="white-space: nowrap; font-size: 14px; font-weight: 900; color: #0f172a; text-align: center; width: 100%;">${data.name}</div>
          <div class="incident-value ${textClass}" style="font-size: 28px; font-weight: 900; margin: 6px 0; display: flex; align-items: baseline; justify-content: center; width: 100%; text-align: center;">${displayVal} <span class="incident-unit" style="font-size: 13px; font-weight: 800; margin-left: 4px; color: #334155;">${data.unit}</span></div>
          <div class="incident-target" style="font-size: 13px; font-weight: 800; color: #0f172a; text-align: center; width: 100%;">Target: <strong style="font-weight: 900; color: #0f172a;">${displayTarget}</strong></div>
        </div>
      `;
    });
    return rowHtml;
  };

  let html = '';
  if (mode === 'monthly' || !mode) {
    html += `
      <!-- Monthly Card Group -->
      <div class="card incidents-card" style="${!mode ? 'margin-bottom: 15px;' : ''}">
        <div class="card-header" style="font-weight: 800; font-size: 13px; text-transform: uppercase; background: linear-gradient(135deg, var(--primary-navy) 0%, #1e40af 100%); color: white; padding: 10px 15px;">Monthly Safety Performance (FTM)</div>
        <div class="card-body" style="padding: 12px; display: flex; flex-direction: column; gap: 10px;">
          <!-- Monthly Incidents Row (LTI, RWC, MTC, FAC) -->
          <div class="cards-flex-container" style="display: flex; gap: 8px; flex-wrap: nowrap;">
            ${makeCardRowHtml(incidentIds, 'monthly')}
          </div>
          <!-- Monthly Scores Row (PSI I, PSI II, TRCFR) -->
          <div class="cards-flex-container" style="display: flex; gap: 8px; flex-wrap: nowrap;">
            ${makeCardRowHtml(scoreIds, 'monthly')}
          </div>
        </div>
      </div>
    `;
  }
  if (mode === 'ytd' || !mode) {
    html += `
      <!-- YTD Card Group -->
      <div class="card incidents-card">
        <div class="card-header" style="font-weight: 800; font-size: 13px; text-transform: uppercase; background: linear-gradient(135deg, var(--primary-navy) 0%, #1e40af 100%); color: white; padding: 10px 15px;">YTD Safety Performance (YTD)</div>
        <div class="card-body" style="padding: 12px; display: flex; flex-direction: column; gap: 10px;">
          <!-- YTD Incidents Row (LTI, RWC, MTC, FAC) -->
          <div class="cards-flex-container" style="display: flex; gap: 8px; flex-wrap: nowrap;">
            ${makeCardRowHtml(incidentIds, 'ytd')}
          </div>
          <!-- YTD Scores Row (PSI I, PSI II, TRCFR) -->
          <div class="cards-flex-container" style="display: flex; gap: 8px; flex-wrap: nowrap;">
            ${makeCardRowHtml(scoreIds, 'ytd')}
          </div>
        </div>
      </div>
    `;
  }

  container.innerHTML = html;
}
