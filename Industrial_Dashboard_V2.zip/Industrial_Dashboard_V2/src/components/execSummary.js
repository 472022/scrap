// Executive Summary and Focus Areas Component

import { state, calculateOverallScore, getKpiStatusCounts, getFocusAreas } from '../state.js';

export function renderExecSummary(containerId, focusContainerId, mode) {
  const score = calculateOverallScore(mode);
  const { green, yellow, red } = getKpiStatusCounts(mode);
  const focusAreas = getFocusAreas(mode);
  const capitalizedModule = state.currentModule.charAt(0).toUpperCase() + state.currentModule.slice(1);

  // Count total active parameters under management for the active module
  const totalParams = green + yellow + red;

  // Determine score status text and color class
  let statusText = 'Excellent';
  let scoreClass = 'score-green';
  if (score < 80) {
    statusText = 'Needs Attention';
    scoreClass = 'score-orange';
  } else if (score < 95) {
    statusText = 'Satisfactory';
    scoreClass = 'score-yellow';
  }

  // Render Executive Summary Card
  const summaryContainer = document.getElementById(containerId);
  if (summaryContainer) {
    summaryContainer.innerHTML = `
      <div class="card exec-card">
        <div class="card-header">Executive Summary</div>
        <div class="card-body exec-flex-container">
          <!-- Card 1: Overall Score -->
          <div class="exec-subcard overall-score-card">
            <div class="exec-title">Overall ${capitalizedModule} Score</div>
            <div class="exec-value ${scoreClass}">${score}%</div>
            <div class="exec-subtitle ${scoreClass}">${statusText}</div>
          </div>
          <!-- Card 2: Total Parameters in Dataset -->
          <div class="exec-subcard total-params-card" style="border-left: 4px solid var(--primary-navy);">
            <div class="exec-title" style="color: var(--primary-navy);">Total Parameters</div>
            <div class="exec-value" style="color: var(--primary-navy); margin-bottom: 0;">${totalParams}</div>
          </div>
          <!-- Card 3: Green KPIs -->
          <div class="exec-subcard green-kpis-card">
            <div class="exec-title text-green">Green (100%)</div>
            <div class="exec-value text-green" style="margin-bottom: 0;">${green}</div>
          </div>
          <!-- Card 4: Yellow KPIs -->
          <div class="exec-subcard yellow-kpis-card">
            <div class="exec-title text-yellow">Yellow (80-99%)</div>
            <div class="exec-value text-yellow" style="margin-bottom: 0;">${yellow}</div>
          </div>
          <!-- Card 5: Red KPIs -->
          <div class="exec-subcard red-kpis-card">
            <div class="exec-title text-red">Red (<80%)</div>
            <div class="exec-value text-red" style="margin-bottom: 0;">${red}</div>
          </div>
        </div>
      </div>
    `;
  }

  // Render Top 4 Focus Areas Card
  const focusContainer = document.getElementById(focusContainerId);
  if (focusContainer) {
    let focusHtml = `
      <div class="card focus-card">
        <div class="card-header">Top Focus Area</div>
        <div class="card-body">
          <ul class="focus-list">
    `;

    focusAreas.forEach(item => {
      focusHtml += `
        <li>
          <span class="focus-dot">🔴</span>
          <span class="focus-text">${item}</span>
        </li>
      `;
    });

    if (focusAreas.length === 0) {
      focusHtml += `<li class="no-focus-msg">✔ All targets are achieved! No current focus areas.</li>`;
    }

    focusHtml += `
          </ul>
        </div>
      </div>
    `;
    focusContainer.innerHTML = focusHtml;
  }
}
