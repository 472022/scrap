import { Chart, registerables } from 'chart.js';
import { state, getAchievement, getStatus, getKpiForMode, renderMiniGauge, renderDirectionBadge, isLowerBetter } from '../state.js';

Chart.register(...registerables);

const datalabelsPlugin = {
  id: 'datalabels',
  afterDatasetsDraw(chart) {
    const { ctx } = chart;
    ctx.save();
    ctx.font = 'bold 10px Outfit, Inter, sans-serif';
    ctx.fillStyle = '#1e2d5a';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';

    chart.data.datasets.forEach((dataset, datasetIndex) => {
      const meta = chart.getDatasetMeta(datasetIndex);
      meta.data.forEach((element, index) => {
        const val = dataset.data[index];
        if (val !== null && val !== undefined) {
          const label = `${Math.round(val)}%`;
          ctx.fillText(label, element.x, element.y - 4);
        }
      });
    });
    ctx.restore();
  }
};

// Helper to format values with their UoM dynamically
function formatValue(val, unit) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  if (unit === '%') {
    if (val <= 1.0) {
      return `${parseFloat((val * 100).toFixed(2))}%`;
    }
    return `${parseFloat(val.toFixed(2))}%`;
  }
  const formattedNum = parseFloat(val.toFixed(2));
  return `${formattedNum} ${unit || ''}`.trim();
}

// Helper to format values without appending their unit (useful for table columns with UoM)
function formatValueNoUnit(val, unit) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  if (unit === '%') {
    if (val <= 1.0) {
      return `${parseFloat((val * 100).toFixed(2))}%`;
    }
    return `${parseFloat(val.toFixed(2))}%`;
  }
  return parseFloat(val.toFixed(2));
}

// Group 1: Render DRR Grouped Matrix Box Layout representing Line 1, Line 2, and Line 3 performance
export function renderDrrMeters(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const resolvedMode = typeof mode === 'string' ? mode : (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const getKpi = (id) => kpis.find(k => k.id === id);

  const getCellData = (lineNum) => {
    return [1, 2, 4].map(drrNum => {
      const kpiId = `drr_${drrNum}_l${lineNum}`;
      const kpi = getKpi(kpiId);
      if (!kpi) {
        return {
          actual: 0,
          target: 95,
          isMonitored: true,
          boxBg: '#fef2f2',
          boxBorder: '1px solid #fecaca',
          textColor: '#b91c1c',
          progressColor: '#ef4444'
        };
      }
      
      const valObj = getKpiForMode(kpi, resolvedMode);
      let act = (valObj.actual !== undefined && valObj.actual !== null && !isNaN(valObj.actual)) ? valObj.actual : 0;
      let tgt = (valObj.target !== undefined && valObj.target !== null && !isNaN(valObj.target)) ? valObj.target : 0;
      if (act <= 1.0 && act > 0) act = act * 100;
      if (tgt <= 1.0 && tgt > 0) tgt = tgt * 100;
      
      const actualVal = parseFloat((Number(act) || 0).toFixed(1));
      const targetVal = parseFloat((Number(tgt) || 0).toFixed(1));
      
      const isMonitored = targetVal > 0;
      const met = isMonitored ? (actualVal >= targetVal) : false;
      
      let boxBg = '#f8fafc'; // Neutral grey for unmonitored
      let boxBorder = '1px solid #e2e8f0';
      let textColor = '#64748b';
      let progressColor = '#cbd5e1';
      
      if (isMonitored) {
        if (met) {
          boxBg = '#f0fdf4'; // Light green
          boxBorder = '1px solid #bbf7d0';
          textColor = '#15803d';
          progressColor = '#10b981';
        } else {
          boxBg = '#fef2f2'; // Light red
          boxBorder = '1px solid #fecaca';
          textColor = '#b91c1c';
          progressColor = '#ef4444';
        }
      }
      
      return {
        actual: actualVal,
        target: targetVal,
        isMonitored: isMonitored,
        boxBg: boxBg,
        boxBorder: boxBorder,
        textColor: textColor,
        progressColor: progressColor
      };
    });
  };

  const drrNames = ['1. DRR 1 (Vehicle)', '2. DRR 2 (Commercial)', '4. DRR 4 (DRR Off-Track)'];

  let html = `
    <div class="card drr-matrix-card" style="margin-bottom: 20px;">
      <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <span>Direct Run Rate (DRR) Performance Matrix</span>
        <span style="font-size: 11px; font-weight: 600; color: #cbd5e1;">Target vs Actual (%)</span>
      </div>
      <div class="card-body scrollable-table-container" style="padding: 16px;">
        <table class="drr-matrix-table" style="width: 100%; border-collapse: separate; border-spacing: 12px; margin-top: -10px;">
          <thead>
            <tr>
              <th style="text-align: left; padding-left: 8px; width: 28%; font-size: 13px; font-weight: 700; color: var(--primary-navy);">DRR Parameter</th>
              <th style="text-align: center; width: 24%; font-size: 13px; font-weight: 700; color: var(--primary-navy);">Line 1</th>
              <th style="text-align: center; width: 24%; font-size: 13px; font-weight: 700; color: var(--primary-navy);">Line 2</th>
              <th style="text-align: center; width: 24%; font-size: 13px; font-weight: 700; color: var(--primary-navy);">Line 3</th>
            </tr>
          </thead>
          <tbody>
  `;

  const l1Data = getCellData(1);
  const l2Data = getCellData(2);
  const l3Data = getCellData(3);

  for (let i = 0; i < 3; i++) {
    const name = drrNames[i];
    const c1 = l1Data[i];
    const c2 = l2Data[i];
    const c3 = l3Data[i];

    const renderCellContent = (cell) => {
      if (!cell.isMonitored) {
        return `<span style="font-size: 12px; font-weight: 600; color: #94a3b8;">Not Monitored</span>`;
      }
      const actPct = Math.min(100, Math.max(0, cell.actual));
      const arcLength = Math.PI * 34; // approx 106.814
      const strokeDashoffset = (arcLength - (actPct / 100) * arcLength).toFixed(2);
      const actRad = (1 - (actPct / 100)) * Math.PI;
      const nx = (50 + 29 * Math.cos(actRad)).toFixed(2);
      const ny = (42 - 29 * Math.sin(actRad)).toFixed(2);

      const ticksHtml = [0, 0.25, 0.5, 0.75, 1.0].map(t => {
        const rad = (1 - t) * Math.PI;
        const x1 = (50 + 37 * Math.cos(rad)).toFixed(2);
        const y1 = (42 - 37 * Math.sin(rad)).toFixed(2);
        const x2 = (50 + 40 * Math.cos(rad)).toFixed(2);
        const y2 = (42 - 40 * Math.sin(rad)).toFixed(2);
        return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#cbd5e1" stroke-width="1.5" />`;
      }).join('');

      return `
        <div style="display: flex; flex-direction: column; align-items: center; width: 100%;">
          <svg viewBox="0 0 100 50" style="width: 105px; height: 52px; overflow: visible;">
            <!-- Background arc -->
            <path d="M 16 42 A 34 34 0 0 1 84 42" fill="none" stroke="#e2e8f0" stroke-width="7" stroke-linecap="round" />
            <!-- Progress arc -->
            <path d="M 16 42 A 34 34 0 0 1 84 42" fill="none" stroke="${cell.progressColor}" stroke-width="7" stroke-linecap="round" stroke-dasharray="${arcLength.toFixed(2)}" stroke-dashoffset="${strokeDashoffset}" />
            <!-- Gauge Ticks -->
            ${ticksHtml}
            <!-- Needle -->
            <line x1="50" y1="42" x2="${nx}" y2="${ny}" stroke="#1e293b" stroke-width="2.5" stroke-linecap="round" />
            <circle cx="50" cy="42" r="3.5" fill="#1e293b" />
          </svg>
          <div style="display: flex; justify-content: space-between; align-items: center; width: 100%; margin-top: 4px;">
            <span style="font-size: 11px; font-weight: 700; color: #475569;">Tgt: <strong>${cell.target}%</strong></span>
            <span style="font-size: 15px; font-weight: 900; color: ${cell.textColor};">${cell.actual}%</span>
          </div>
        </div>
      `;
    };

    html += `
      <tr>
        <td style="font-weight: 800; font-size: 13px; color: #0f172a; vertical-align: middle; padding-left: 8px;">${name}</td>
        
        <td style="background: ${c1.boxBg}; border: ${c1.boxBorder}; border-radius: 8px; padding: 10px 12px; vertical-align: middle; box-shadow: 0 1px 3px rgba(0,0,0,0.02);">
          ${renderCellContent(c1)}
        </td>
        
        <td style="background: ${c2.boxBg}; border: ${c2.boxBorder}; border-radius: 8px; padding: 10px 12px; vertical-align: middle; box-shadow: 0 1px 3px rgba(0,0,0,0.02);">
          ${renderCellContent(c2)}
        </td>
        
        <td style="background: ${c3.boxBg}; border: ${c3.boxBorder}; border-radius: 8px; padding: 10px 12px; vertical-align: middle; box-shadow: 0 1px 3px rgba(0,0,0,0.02);">
          ${renderCellContent(c3)}
        </td>
      </tr>
    `;
  }

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}

// Group 2: Project Charters (VC Charter / Product Charter)
export function renderChartersSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const resolvedMode = typeof mode === 'string' ? mode : (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const charters = kpis.filter(k => k.id === 'vc_charter' || k.id === 'product_charter');

  let html = `
    <div class="card charters-card" style="margin-bottom: 20px;">
      <div class="card-header">Charter Compliance</div>
      <div class="card-body flex-column-gap">
  `;

  charters.forEach((kpi, idx) => {
    const valObj = getKpiForMode(kpi, resolvedMode);
    const ach = getAchievement(kpi, resolvedMode);
    const status = getStatus(kpi, resolvedMode);
    
    html += `
      <div class="charter-progress-row">
        <div class="charter-row-header">
          <span class="charter-name">${idx + 1}. ${kpi.name}</span>
          <span class="charter-badge badge-${status.toLowerCase()}">${ach}%</span>
        </div>
        <div class="charter-progress-track">
          <div class="charter-progress-fill fill-${status.toLowerCase()}" style="width: ${ach}%"></div>
        </div>
        <div class="charter-row-footer">Target: <strong>${formatValue(valObj.target, kpi.unit)}</strong> | Actual: <strong>${formatValue(valObj.actual, kpi.unit)}</strong></div>
      </div>
    `;
  });

  html += `
      </div>
    </div>
  `;

  container.innerHTML = html;
}

export const renderQualityCharters = renderChartersSection;

// Group 3: Warranty Net Payout, IPTV & UPV (Customer visits)
export function renderWarrantySection(kpis, containerId, mode, append = false) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const resolvedMode = typeof mode === 'string' ? mode : (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const charters = kpis.filter(k => k.id === 'vc_charter' || k.id === 'product_charter');
  const warranty = kpis.find(k => k.id === 'warranty_payout');
  const iptvs = kpis.filter(k => k.id === 'comp_iptv' || k.id === 'iptv_3');
  const visits = kpis.filter(k => k.id === 'visit_24' || k.id === 'visit_12');

  let html = `
    <div class="card warranty-card" style="margin-bottom: 20px;">
      <div class="card-header">Warranty & Customer Alert Metrics</div>
      <div class="card-body scrollable-table-container" style="padding: 15px;">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Quality Parameter</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  // Row 1 & 2: Charters (VC Charter / Product Charter)
  charters.forEach((kpi, idx) => {
    const valObj = getKpiForMode(kpi, resolvedMode);
    const status = getStatus(kpi, resolvedMode);
    const ach = getAchievement(kpi, resolvedMode);
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 1}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '%'}</td>
        <td style="font-weight: 700; color: #000000;">${formatValueNoUnit(valObj.target, kpi.unit)}</td>
        <td style="font-weight: 800; color: #000000;">${formatValueNoUnit(valObj.actual, kpi.unit)}</td>
        <td class="cell-status" style="padding: 4px 0 !important; vertical-align: middle;">${renderMiniGauge(ach, status)}</td>
      </tr>
    `;
  });

  // Row 3: Warranty Net Payout
  if (warranty) {
    const valObj = getKpiForMode(warranty, resolvedMode);
    const status = getStatus(warranty, resolvedMode);
    const ach = getAchievement(warranty, resolvedMode);
    html += `
      <tr>
        <td style="text-align: left; font-weight: 600; color: var(--primary-navy);">3. ${warranty.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(warranty)}</td>
        <td class="col-uom">${warranty.unit}</td>
        <td style="font-weight: 700; color: #000000;">${formatValueNoUnit(valObj.target, warranty.unit)}</td>
        <td style="font-weight: 800; color: #000000;">${formatValueNoUnit(valObj.actual, warranty.unit)}</td>
        <td class="cell-status" style="padding: 4px 0 !important; vertical-align: middle;">${renderMiniGauge(ach, status)}</td>
      </tr>
    `;
  }

  // IPTV items (Rows 4 & 5)
  iptvs.forEach((kpi, idx) => {
    const valObj = getKpiForMode(kpi, resolvedMode);
    const status = getStatus(kpi, resolvedMode);
    const ach = getAchievement(kpi, resolvedMode);
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 4}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || 'IPTV'}</td>
        <td style="font-weight: 700; color: #000000;">${formatValueNoUnit(valObj.target, kpi.unit)}</td>
        <td style="font-weight: 800; color: #000000;">${formatValueNoUnit(valObj.actual, kpi.unit)}</td>
        <td class="cell-status" style="padding: 4px 0 !important; vertical-align: middle;">${renderMiniGauge(ach, status)}</td>
      </tr>
    `;
  });

  // UPV items (Rows 6 & 7)
  visits.forEach((kpi, idx) => {
    const valObj = getKpiForMode(kpi, resolvedMode);
    const status = getStatus(kpi, resolvedMode);
    const ach = getAchievement(kpi, resolvedMode);
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 6}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || 'Index'}</td>
        <td style="font-weight: 700; color: #000000;">${formatValueNoUnit(valObj.target, kpi.unit)}</td>
        <td style="font-weight: 800; color: #000000;">${formatValueNoUnit(valObj.actual, kpi.unit)}</td>
        <td class="cell-status" style="padding: 4px 0 !important; vertical-align: middle;">${renderMiniGauge(ach, status)}</td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  if (append) {
    container.innerHTML += html;
  } else {
    container.innerHTML = html;
  }
}

// Group 5: Composite Index & Launch Quality & Audits Controls (Merged Box)
export function renderCompositeQualitySection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';
  const resolvedMode = typeof mode === 'string' ? mode : suffix;

  const kpiIptv = kpis.find(k => k.id === 'comp_quality_iptv');
  const kpiEpv = kpis.find(k => k.id === 'comp_quality_epv');
  const kpiVisits = kpis.find(k => k.id === 'comp_quality_visits');
  const kpiNoTouch = kpis.find(k => k.id === 'comp_quality_notouch');
  const kpiLaunch = kpis.find(k => k.id === 'launch_quality');
  const kpiLaunchUvpv = kpis.find(k => k.id === 'launch_uvpv');

  let html = `
    <div class="card composite-index-card" style="margin-bottom: 20px;">
      <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <span>Audits, Project Controls & Composite Quality</span>
        <span class="direction-badge lower-better">↓ Lower Better</span>
      </div>
      <div class="card-body" style="padding: 15px;">

        <!-- Top Section: Audits & Project Controls Table -->
        <div style="font-size: 13px; font-weight: 700; color: var(--primary-navy); margin-bottom: 10px;">
          Audits & Project Controls
        </div>

        <div class="scrollable-table-container">
          <table class="dashboard-table">
            <thead>
              <tr>
                <th style="text-align: left; width: 34%;">Audit Parameter</th>
                <th style="text-align: center; width: 20%;">Measure</th>
                <th class="col-uom" style="width: 10%;">UoM</th>
                <th style="width: 13%;">Target</th>
                <th style="width: 13%;">Actual</th>
                <th style="width: 10%;">Status</th>
              </tr>
            </thead>
            <tbody>
  `;

  const auditIds = ['l3_control', 'cpa_score', 'layer_audit', 'cimple_project'];
  let rowIdx = 8;
  auditIds.forEach((id) => {
    const kpi = kpis.find(k => k.id === id);
    if (!kpi) return;

    const valObj = getKpiForMode(kpi, resolvedMode);
    const rawAch = getAchievement(kpi, resolvedMode);
    const ach = parseFloat((Number(rawAch) || 0).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;

    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${rowIdx}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit === 'percent' ? '%' : kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${formatValueNoUnit(valObj.target, kpi.unit)}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${formatValueNoUnit(valObj.actual, kpi.unit)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
    rowIdx++;
  });

  html += `
            </tbody>
          </table>
        </div>

        <!-- Divider -->
        <div style="border-top: 2px dashed #cbd5e1; margin: 20px 0 15px 0;"></div>

        <!-- Row 1: 3-column grid for IPTV, EPV, Launch UVPV -->
        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-bottom: 15px; width: 100%; box-sizing: border-box;">
  `;

  const row1Features = [
    { kpi: kpiIptv, shortName: 'Delta Composite IPTV', canvasId: `quality-feat-iptv-${suffix}`, type: 'bar', title: 'a) Delta Composite IPTV' },
    { kpi: kpiEpv, shortName: 'EPV', canvasId: `quality-feat-epv-${suffix}`, type: 'horizontalBar', title: 'b) EPV (Delta)' },
    { kpi: kpiLaunchUvpv, shortName: 'Launch UVPV', canvasId: `quality-feat-launchuvpv-${suffix}`, type: 'bar', title: 'f) Launch UVPV' }
  ];

  const row2Features = [
    { kpi: kpiVisits, shortName: 'Unscheduled Visits per vehicle', canvasId: `quality-feat-visits-${suffix}`, type: 'horizontalBar', title: 'c) Unscheduled Visits' },
    { kpi: kpiNoTouch, shortName: 'No Touch DRR', canvasId: `quality-feat-notouch-${suffix}`, type: 'concentric', title: 'd) No Touch DRR' }
  ];

  row1Features.forEach(feat => {
    const valObj = feat.kpi ? getKpiForMode(feat.kpi, resolvedMode) : { target: 0, actual: 0 };
    const tVal = valObj.target;
    const aVal = valObj.actual;
    const unit = feat.kpi ? feat.kpi.unit : '';

    html += `
      <div class="quality-feature-box" style="display: flex; flex-direction: column; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 8px 10px; background-color: #ffffff; min-height: 140px; justify-content: space-between; box-shadow: 0 2px 6px rgba(0,0,0,0.03); min-width: 0; box-sizing: border-box; width: 100%;">
        <div class="feature-label-col" style="width: 100%; border-bottom: 1.5px dashed #cbd5e1; padding-bottom: 5px; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 11.5px; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: 0.2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${feat.shortName}">${feat.shortName}</span>
          <span class="direction-badge lower-better" style="font-size: 9px; padding: 2px 6px;">↓ Lower Better</span>
        </div>
        <div style="width: 100%; height: 95px; position: relative;">
          <canvas id="${feat.canvasId}"></canvas>
        </div>
      </div>
    `;
  });

  html += `
        </div> <!-- End of Row 1 -->

        <!-- Row 2: 2-column grid for Unscheduled Visits & No Touch DRR -->
        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 15px; width: 100%; box-sizing: border-box;">
  `;

  row2Features.forEach(feat => {
    const valObj = feat.kpi ? getKpiForMode(feat.kpi, resolvedMode) : { target: 0, actual: 0 };
    const tVal = valObj.target;
    const aVal = valObj.actual;
    const unit = feat.kpi ? feat.kpi.unit : '';
    const isGood = feat.kpi ? (isLowerBetter(feat.kpi) ? (tVal === 0 ? aVal === 0 : aVal <= tVal) : (tVal === 0 ? aVal === 0 : aVal >= tVal)) : true;
    const actTextColor = isGood ? '#10b981' : '#ef4444';
    const showTargetActualText = feat.kpi && feat.kpi.id === 'comp_quality_notouch';

    html += `
      <div class="quality-feature-box" style="display: flex; flex-direction: column; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 8px 10px; background-color: #ffffff; min-height: 140px; justify-content: space-between; box-shadow: 0 2px 6px rgba(0,0,0,0.03); min-width: 0; box-sizing: border-box; width: 100%;">
        <div class="feature-label-col" style="width: 100%; border-bottom: 1.5px dashed #cbd5e1; padding-bottom: 5px; margin-bottom: 4px; display: flex; justify-content: space-between; align-items: center;">
          <span style="font-size: 11.5px; font-weight: 900; color: #0f172a; text-transform: uppercase; letter-spacing: 0.2px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="${feat.shortName}">${feat.shortName}</span>
          <span class="direction-badge lower-better" style="font-size: 9px; padding: 2px 6px;">↓ Lower Better</span>
        </div>
        ${showTargetActualText ? `
          <div style="width: 100%; height: 95px; display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; flex-direction: column; justify-content: center; gap: 6px; padding-left: 8px; padding-right: 4px; min-width: 90px;">
              <div style="font-size: 11px; font-weight: 700; color: #475569; white-space: nowrap;">Target: <strong style="font-size: 12px; font-weight: 900; color: #0f172a;">${formatValueNoUnit(tVal, unit)}</strong></div>
              <div style="font-size: 11px; font-weight: 700; color: #475569; white-space: nowrap;">Actual: <strong style="font-size: 13px; font-weight: 900; color: ${actTextColor};">${formatValueNoUnit(aVal, unit)}</strong></div>
            </div>
            <div style="flex-grow: 1; height: 95px; position: relative;">
              <canvas id="${feat.canvasId}"></canvas>
            </div>
          </div>
        ` : `
          <div style="width: 100%; height: 95px; position: relative;">
            <canvas id="${feat.canvasId}"></canvas>
          </div>
        `}
      </div>
    `;
  });

  html += `
        </div> <!-- End of Row 2 -->

        <!-- Row 3: Full-width Large Feature Box for Launch Quality -->
  `;

  const featLaunch = { kpi: kpiLaunch, shortName: 'Launch Quality [IPTV- 3,6,9 MIS]', canvasId: `quality-feat-launch-${suffix}`, type: 'gauge', title: 'e) Launch Quality Composite' };
  const launchValObj = featLaunch.kpi ? getKpiForMode(featLaunch.kpi, resolvedMode) : { target: 0, actual: 0 };
  const tVal = launchValObj.target;
  const aVal = launchValObj.actual;
  const unit = featLaunch.kpi ? featLaunch.kpi.unit : '';
  const sub3 = kpis.find(k => k.id === 'launch_3mis');
  const sub3Val = sub3 ? getKpiForMode(sub3, resolvedMode) : { target: 53, actual: 51 };
  const sub3_6 = kpis.find(k => k.id === 'launch_3_6mis');
  const sub3_6Val = sub3_6 ? getKpiForMode(sub3_6, resolvedMode) : { target: 99, actual: 93 };
  const sub6_12 = kpis.find(k => k.id === 'launch_6_12mis');
  const sub6_12Val = sub6_12 ? getKpiForMode(sub6_12, resolvedMode) : { target: 274, actual: 320 };

  html += `
    <div class="quality-feature-box launch-quality-box" style="display: flex; flex-direction: column; border: 1.5px solid #cbd5e1; border-radius: 10px; padding: 16px; background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%); min-height: 185px; width: 100%; box-shadow: 0 4px 12px rgba(0,0,0,0.04);">
      <div style="font-size: 16px; font-weight: 900; color: #0f172a; text-transform: uppercase; border-bottom: 1.5px dashed #cbd5e1; padding-bottom: 8px; margin-bottom: 12px; width: 100%; letter-spacing: 0.5px; display: flex; justify-content: space-between; align-items: center;">
        <span>${featLaunch.shortName}</span>
        <span class="direction-badge lower-better">↓ Lower Better</span>
      </div>
      <div style="display: flex; align-items: center; width: 100%; flex-grow: 1;">
        <!-- Left: Gauge -->
        <div style="width: 45%; height: 120px; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; border-right: 1.5px dashed #cbd5e1; padding-right: 12px;">
          <div style="width: 100%; height: 95px; position: relative;">
            <canvas id="${featLaunch.canvasId}"></canvas>
          </div>
          <span style="font-size: 13px; font-weight: 900; color: #0f172a; margin-top: -4px;">Target: ${formatValueNoUnit(tVal, unit)}%</span>
        </div>
        <!-- Right: Sub-metrics table -->
        <div style="width: 55%; padding-left: 18px; display: flex; flex-direction: column; justify-content: center; height: 100%;">
          <table style="width: 100%; border-collapse: collapse; font-size: 13px;">
            <thead>
              <tr style="color: #0f172a; font-weight: 900; border-bottom: 2px solid #cbd5e1; font-size: 13px;">
                <th style="text-align: left; padding: 6px 0;">Metric</th>
                <th style="text-align: center; padding: 6px 0;">UOM</th>
                <th style="text-align: right; padding: 6px 0;">Target</th>
                <th style="text-align: right; padding: 6px 0;">Actual</th>
              </tr>
            </thead>
            <tbody>
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="text-align: left; padding: 8px 0; font-weight: 900; color: #0f172a; font-size: 14px;">3 MIS</td>
                <td style="text-align: center; padding: 8px 0; color: #475569; font-weight: 700; font-size: 13px;">Nos.</td>
                <td style="text-align: right; padding: 8px 0; color: #334155; font-weight: 800; font-size: 15px;">${formatValueNoUnit(sub3Val.target, '')}</td>
                <td style="text-align: right; padding: 8px 0; color: #0f172a; font-weight: 900; font-size: 17px;">${formatValueNoUnit(sub3Val.actual, '')}</td>
              </tr>
              <tr style="border-bottom: 1px solid #e2e8f0;">
                <td style="text-align: left; padding: 8px 0; font-weight: 900; color: #0f172a; font-size: 14px;">3-6 MIS</td>
                <td style="text-align: center; padding: 8px 0; color: #475569; font-weight: 700; font-size: 13px;">Nos.</td>
                <td style="text-align: right; padding: 8px 0; color: #334155; font-weight: 800; font-size: 15px;">${formatValueNoUnit(sub3_6Val.target, '')}</td>
                <td style="text-align: right; padding: 8px 0; color: #0f172a; font-weight: 900; font-size: 17px;">${formatValueNoUnit(sub3_6Val.actual, '')}</td>
              </tr>
              <tr>
                <td style="text-align: left; padding: 8px 0; font-weight: 900; color: #0f172a; font-size: 14px;">6-12 MIS</td>
                <td style="text-align: center; padding: 8px 0; color: #475569; font-weight: 700; font-size: 13px;">Nos.</td>
                <td style="text-align: right; padding: 8px 0; color: #334155; font-weight: 800; font-size: 15px;">${formatValueNoUnit(sub6_12Val.target, '')}</td>
                <td style="text-align: right; padding: 8px 0; color: #0f172a; font-weight: 900; font-size: 17px;">${formatValueNoUnit(sub6_12Val.actual, '')}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;

  const features = [...row1Features, ...row2Features, featLaunch];

  html += `
        </div> <!-- End of 6 mini-charts grid -->
      </div>
    </div>
  `;

  container.innerHTML = html;

  const isQualityGood = (kpi) => {
    if (!kpi) return true;
    const valObj = getKpiForMode(kpi, resolvedMode);
    const lower = isLowerBetter(kpi);
    const target = valObj.target;
    const actual = valObj.actual;
    if (target === 0) return actual === 0;

    if (kpi.id === 'launch_quality' || kpi.id === 'vc_charter' || kpi.id === 'product_charter') {
      return actual >= target;
    }

    return lower ? actual <= target : actual >= target;
  };

  // Render comparative bar graphs on the next tick
  setTimeout(() => {
    features.forEach(feat => {
      const canvas = document.getElementById(feat.canvasId);
      if (!canvas || !feat.kpi) return;

      const valObj = getKpiForMode(feat.kpi, resolvedMode);
      const tVal = parseFloat((valObj.target || 0).toFixed(2));
      const aVal = parseFloat((valObj.actual || 0).toFixed(2));
      const isGood = isQualityGood(feat.kpi);
      const actColor = isGood ? '#10b981' : '#ef4444';

      // Clear previous instance if any
      const oldChart = Chart.getChart(canvas);
      if (oldChart) oldChart.destroy();

      // Retrieve monthly trend data if available (for Line/Area charts)
      const monthlyData = state.qualityMonthlyData[feat.kpi.id] || {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets: [tVal, tVal, tVal, tVal],
        actuals: [aVal, aVal, aVal, aVal]
      };

      if (feat.type === 'line' || feat.type === 'area') {
        // Curve Line/Area Chart format for IPTV and Visits
        const isArea = feat.type === 'area';
        new Chart(canvas, {
          type: 'line',
          data: {
            labels: monthlyData.months,
            datasets: [
              {
                label: 'Plan',
                data: monthlyData.targets,
                borderColor: '#94a3b8',
                borderWidth: 2,
                borderDash: [3, 3],
                fill: false,
                pointRadius: 0,
                tension: 0.3
              },
              {
                label: 'Actual',
                data: monthlyData.actuals,
                borderColor: actColor,
                backgroundColor: isArea ? 'rgba(16, 185, 129, 0.08)' : 'transparent',
                borderWidth: 3,
                fill: isArea,
                pointRadius: 2,
                pointBackgroundColor: actColor,
                tension: 0.3
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: { display: false },
              tooltip: { enabled: true }
            },
            scales: {
              y: {
                display: false,
                grid: { display: false }
              },
              x: {
                grid: { display: false },
                ticks: { font: { size: 7, weight: 'bold' } }
              }
            }
          }
        });

      } else if (feat.type === 'horizontalBar') {
        // Horizontal Bar Chart format for EPV
        const hBarPlugin = {
          id: `hlabel_${feat.canvasId}`,
          afterDatasetsDraw(chart) {
            const { ctx } = chart;
            ctx.save();
            ctx.font = '900 11.5px Outfit, Inter, sans-serif';
            ctx.fillStyle = '#0f172a';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            chart.data.datasets.forEach((dataset, datasetIndex) => {
              const meta = chart.getDatasetMeta(datasetIndex);
              meta.data.forEach((element, index) => {
                const val = dataset.data[index];
                if (val !== null && val !== undefined) {
                  const label = formatValueNoUnit(val, feat.kpi.unit);
                  ctx.fillText(label, element.x + 5, element.y);
                }
              });
            });
            ctx.restore();
          }
        };

        new Chart(canvas, {
          type: 'bar',
          data: {
            labels: ['Target', 'Actual'],
            datasets: [{
              data: [tVal, aVal],
              backgroundColor: ['#3b82f6', actColor],
              borderRadius: 4,
              barThickness: 16
            }]
          },
          options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            layout: {
              padding: {
                right: 48,
                top: 4,
                bottom: 4,
                left: 0
              }
            },
            plugins: {
              legend: { display: false },
              tooltip: { enabled: true }
            },
            scales: {
              x: {
                display: false,
                grid: { display: false },
                max: Math.max(tVal, aVal) * 1.22
              },
              y: {
                grid: { display: false },
                ticks: { font: { size: 11, weight: 'bold' }, color: '#0f172a' }
              }
            }
          },
          plugins: [hBarPlugin]
        });

      } else if (feat.type === 'concentric') {
        // Concentric Doughnut Progress Rings for No Touch
        const achVal = getAchievement(feat.kpi);
        const concentricPlugin = {
          id: `cring_${feat.canvasId}`,
          beforeDraw(chart) {
            const { width, height, ctx } = chart;
            ctx.restore();
            ctx.font = '900 16px Outfit, Inter, sans-serif';
            ctx.fillStyle = '#0f172a';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(`${formatValueNoUnit(aVal, feat.kpi.unit)}`, width / 2, height / 2);
            ctx.save();
          }
        };

        new Chart(canvas, {
          type: 'doughnut',
          data: {
            datasets: [
              {
                data: [achVal, Math.max(0, 100 - achVal)],
                backgroundColor: [actColor, '#f1f5f9'],
                borderWidth: 0,
                weight: 1.2
              },
              {
                data: [tVal, Math.max(0, 100 - tVal)],
                backgroundColor: ['#cbd5e1', '#f8fafc'],
                borderWidth: 0,
                weight: 0.8
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '72%',
            plugins: {
              legend: { display: false },
              tooltip: {
                callbacks: {
                  label: (context) => {
                    const ringIdx = context.datasetIndex;
                    if (ringIdx === 0) {
                      return `Achievement: ${achVal}% (Actual: ${formatValueNoUnit(aVal, feat.kpi.unit)})`;
                    }
                    return `Target: ${formatValueNoUnit(tVal, feat.kpi.unit)}`;
                  }
                }
              }
            }
          },
          plugins: [concentricPlugin]
        });

      } else if (feat.type === 'gauge') {
        // Semi-circular Speedometer Gauge for Launch Quality
        const gaugePlugin = {
          id: `gauge_${feat.canvasId}`,
          beforeDraw(chart) {
            const { width, height, ctx } = chart;
            ctx.restore();
            ctx.font = '900 22px Outfit, Inter, sans-serif';
            ctx.fillStyle = '#0f172a';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            ctx.fillText(`${formatValueNoUnit(aVal, feat.kpi.unit)}%`, width / 2, height - 4);
            ctx.save();
          }
        };

        new Chart(canvas, {
          type: 'doughnut',
          data: {
            datasets: [{
              data: [aVal, Math.max(0, 100 - aVal)],
              backgroundColor: [actColor, '#f1f5f9'],
              borderWidth: 0
            }]
          },
          options: {
            rotation: -90,
            circumference: 180,
            cutout: '75%',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: { display: false },
              tooltip: { enabled: false }
            }
          },
          plugins: [gaugePlugin]
        });

      } else {
        // Vertical Bar Chart for Launch UVPV and Delta Composite IPTV
        const customDatalabelsPlugin = {
          id: `vlabel_${feat.canvasId}`,
          afterDatasetsDraw(chart) {
            const { ctx } = chart;
            ctx.save();
            ctx.font = '900 11.5px Outfit, Inter, sans-serif';
            ctx.fillStyle = '#0f172a';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';
            chart.data.datasets.forEach((dataset, datasetIndex) => {
              const meta = chart.getDatasetMeta(datasetIndex);
              meta.data.forEach((element, index) => {
                const val = dataset.data[index];
                if (val !== null && val !== undefined) {
                  const label = formatValueNoUnit(val, feat.kpi.unit);
                  ctx.fillText(label, element.x, element.y - 4);
                }
              });
            });
            ctx.restore();
          }
        };

        new Chart(canvas, {
          type: 'bar',
          data: {
            labels: ['Target', 'Actual'],
            datasets: [{
              data: [tVal, aVal],
              backgroundColor: ['#3b82f6', actColor],
              borderRadius: 4,
              barThickness: 16
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
              padding: {
                top: 16,
                bottom: 0,
                left: 6,
                right: 6
              }
            },
            plugins: {
              legend: { display: false },
              tooltip: { enabled: true }
            },
            scales: {
              y: {
                display: false,
                grid: { display: false },
                max: Math.max(tVal, aVal) * 1.35
              },
              x: {
                grid: { display: false },
                ticks: { font: { size: 11, weight: 'bold' }, color: '#0f172a' }
              }
            }
          },
          plugins: [customDatalabelsPlugin]
        });
      }
    });
  }, 0);
}

// Group 4: Layer Audit, CPA, L3 Control, Cimple Project
export function renderQualityAudits(kpis, containerId, mode, append = false) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const resolvedMode = typeof mode === 'string' ? mode : (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const isAppend = typeof mode === 'boolean' ? mode : append;

  const auditIds = ['l3_control', 'cpa_score', 'layer_audit', 'cimple_project'];

  let html = `
    <div class="card audits-card" style="margin-bottom: 20px;">
      <div class="card-header">Audits & Project Controls</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Audit Parameter</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  let rowIdx = 8;
  auditIds.forEach((id) => {
    const kpi = kpis.find(k => k.id === id);
    if (!kpi) return;

    const valObj = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;

    html += `
      <tr>
        <td style="text-align: left;">${rowIdx}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit === 'percent' ? '%' : kpi.unit || '-'}</td>
        <td style="font-weight: 700; color: #000000;">${formatValueNoUnit(valObj.target, kpi.unit)}</td>
        <td style="font-weight: 800; color: #000000;">${formatValueNoUnit(valObj.actual, kpi.unit)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
    rowIdx++;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  if (isAppend) {
    container.innerHTML += html;
  } else {
    container.innerHTML = html;
  }
}
