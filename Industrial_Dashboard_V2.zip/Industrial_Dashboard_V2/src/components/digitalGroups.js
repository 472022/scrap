// Digital Dashboard Groupings Component

import { getAchievement, getStatus, getKpiForMode, renderDirectionBadge } from '../state.js';

// Helper to format values dynamically (keeping max 2 decimals, without appending unit suffix)
function formatValue(val) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  return parseFloat(val.toFixed(2));
}

// Global View Switcher for Digital Projects Section
if (typeof window !== 'undefined') {
  window.toggleDigitalProjectView = function(suffix, view) {
    const streamEl = document.getElementById(`dig-stream-${suffix}`);
    const tableEl = document.getElementById(`dig-table-${suffix}`);
    const btnStream = document.getElementById(`btn-dig-stream-${suffix}`);
    const btnTable = document.getElementById(`btn-dig-table-${suffix}`);

    if (view === 'stream') {
      if (streamEl) streamEl.style.display = 'grid';
      if (tableEl) tableEl.style.display = 'none';
      if (btnStream) btnStream.classList.add('active');
      if (btnTable) btnTable.classList.remove('active');
    } else {
      if (streamEl) streamEl.style.display = 'none';
      if (tableEl) tableEl.style.display = 'block';
      if (btnStream) btnStream.classList.remove('active');
      if (btnTable) btnTable.classList.add('active');
    }
  };
}

// Master layout orchestrator for Digital module
export function renderDigitalDashboard(kpis, tableContainerId, workplaceContainerId, mode) {
  const suffix = tableContainerId.endsWith('-ytd') ? 'ytd' : 'monthly';
  const resolvedMode = mode || suffix;
  renderDigitalInfrastructureSection(kpis, tableContainerId, resolvedMode);
  renderDigitalProjectsSection(kpis, workplaceContainerId, resolvedMode);
}

// Group 1: Digital Infrastructure & Compliance
export function renderDigitalInfrastructureSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const infraIds = ['dig_cctv', 'dig_energy_meter', 'dig_water_meter', 'dig_andon_updation', 'dig_qualix_compliance', 'dig_kitting_adherence'];
  const groupKpis = kpis.filter(k => infraIds.includes(k.id));

  let html = `
    <div class="card dig-infra-card" style="margin-bottom: 20px;">
      <div class="card-header">Digital Infrastructure & Operations</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Infrastructure Parameter</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 1}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit}</td>
        <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target)}</td>
        <td style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  container.innerHTML = html;
}

// Helper to render radial SVG meter ring
function renderRadialSvgMeter(ach, color, size = 64) {
  const r = (size / 2) - 6;
  const circ = 2 * Math.PI * r;
  const clampedAch = Math.min(100, Math.max(0, ach));
  const offset = circ - (circ * clampedAch) / 100;

  return `
    <div style="position: relative; width: ${size}px; height: ${size}px; flex-shrink: 0;">
      <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
        <circle cx="${size/2}" cy="${size/2}" r="${r}" stroke="#e2e8f0" stroke-width="6" fill="transparent" />
        <circle cx="${size/2}" cy="${size/2}" r="${r}" stroke="${color}" stroke-width="6" fill="transparent"
                stroke-dasharray="${circ}" stroke-dashoffset="${offset}" stroke-linecap="round"
                transform="rotate(-90 ${size/2} ${size/2})" style="transition: stroke-dashoffset 0.8s ease-in-out;" />
      </svg>
      <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 11px; font-weight: 800; color: #0f172a;">
        ${ach}%
      </div>
    </div>
  `;
}

// Group 2: Smart Factory Projects (3-Pillar Transformation Pipeline with SVG Circular Meters)
export function renderDigitalProjectsSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';

  // Group projects into 3 Functional Pillars
  const pillars = [
    {
      id: 'it',
      title: 'Enterprise IT & OS Modernization',
      icon: '💻',
      color: '#2563eb',
      bgLight: '#eff6ff',
      projectIds: ['dig_project_cmdb', 'dig_project_win10_script', 'dig_project_windows_upgrade']
    },
    {
      id: 'automation',
      title: 'Assembly Line (LGA) Automation',
      icon: '🤖',
      color: '#059669',
      bgLight: '#ecfdf5',
      projectIds: ['dig_project_lga_battery', 'dig_project_lga_egp', 'dig_project_lga_carddel']
    },
    {
      id: 'logistics',
      title: 'Smart Logistics & Plant Display (LB2)',
      icon: '🏭',
      color: '#d97706',
      bgLight: '#fffbeb',
      projectIds: ['dig_project_lb2_gangway', 'dig_project_lb2_navigation', 'dig_project_lb2_smart_display']
    }
  ];

  const allProjectIds = pillars.flatMap(p => p.projectIds);
  const groupKpis = kpis.filter(k => allProjectIds.includes(k.id));

  // Calculate Portfolio Completion
  let completedCount = 0;
  groupKpis.forEach(kpi => {
    const { actual, target } = getKpiForMode(kpi, resolvedMode);
    if (target > 0 && actual >= target) completedCount++;
  });
  const portfolioPct = parseFloat(((completedCount / (groupKpis.length || 1)) * 100).toFixed(1));

  // 1. Generate 3-Pillar Pipeline Stream HTML
  let streamHtml = `<div class="dig-pipeline-grid" id="dig-stream-${suffix}">`;

  pillars.forEach((pillar) => {
    const pillarKpis = kpis.filter(k => pillar.projectIds.includes(k.id));
    
    // Pillar completion stats
    let pillarCompleted = 0;
    pillarKpis.forEach(k => {
      const { actual, target } = getKpiForMode(k, resolvedMode);
      if (target > 0 && actual >= target) pillarCompleted++;
    });

    streamHtml += `
      <div class="dig-pillar-col" style="border-top: 4px solid ${pillar.color};">
        <div class="dig-pillar-header" style="background: ${pillar.bgLight};">
          <div class="dig-pillar-icon" style="color: ${pillar.color};">${pillar.icon}</div>
          <div class="dig-pillar-title-wrap">
            <div class="dig-pillar-title" style="color: ${pillar.color};">${pillar.title}</div>
            <div class="dig-pillar-subtitle">${pillarCompleted} of ${pillarKpis.length} Projects Done</div>
          </div>
        </div>
        <div class="dig-pillar-body">
    `;

    pillarKpis.forEach((kpi) => {
      const globalIdx = groupKpis.findIndex(g => g.id === kpi.id) + 7;
      const { target, actual } = getKpiForMode(kpi, resolvedMode);
      const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));
      const status = getStatus(kpi, resolvedMode);
      const statusClass = `status-${status.toLowerCase()}`;
      
      let badgeLabel = 'PLANNED';
      let badgeBg = '#f1f5f9';
      let badgeColor = '#475569';
      if (ach >= 100) { badgeLabel = 'DONE'; badgeBg = '#dcfce7'; badgeColor = '#15803d'; }
      else if (ach > 0) { badgeLabel = 'IN PROGRESS'; badgeBg = '#dbeafe'; badgeColor = '#1d4ed8'; }

      streamHtml += `
        <div class="dig-stream-card">
          <div class="dig-stream-card-left">
            ${renderRadialSvgMeter(ach, pillar.color, 56)}
          </div>
          <div class="dig-stream-card-right">
            <div class="dig-stream-num-title">
              <span class="dig-stream-num">${globalIdx}.</span>
              <span class="dig-stream-title">${kpi.name}</span>
            </div>
            <div class="dig-stream-metrics">
              <span class="dig-stream-actual">${formatValue(actual)}</span>
              <span class="dig-stream-target">/ ${formatValue(target)} ${kpi.unit}</span>
              <span class="dig-stream-tag" style="background: ${badgeBg}; color: ${badgeColor};">${badgeLabel}</span>
            </div>
          </div>
        </div>
      `;
    });

    streamHtml += `
        </div>
      </div>
    `;
  });

  streamHtml += `</div>`;

  // 2. Generate Refined Table View HTML (for Table View toggle)
  let tableHtml = `
    <div class="scrollable-table-container" id="dig-table-${suffix}" style="display: none;">
      <table class="dashboard-table">
        <thead>
          <tr>
            <th style="text-align: left; width: 34%;">Smart Project</th>
            <th style="text-align: center; width: 20%;">Measure</th>
            <th class="col-uom" style="width: 10%;">UoM</th>
            <th style="width: 13%;">Target</th>
            <th style="width: 13%;">Actual</th>
            <th style="width: 10%;">Status</th>
          </tr>
        </thead>
        <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;

    tableHtml += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 7}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit}</td>
        <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target)}</td>
        <td style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  tableHtml += `
        </tbody>
      </table>
    </div>
  `;

  // Master Card Container with Tech Header
  let html = `
    <div class="card dig-projects-card">
      <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; padding: 14px 18px; border-bottom: 1px solid rgba(226, 232, 240, 0.8);">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 42px; height: 42px; border-radius: 50%; background: #eff6ff; border: 2px solid #3b82f6; display: flex; align-items: center; justify-content: center; font-size: 18px;">
            ⚡
          </div>
          <div>
            <div style="font-weight: 800; font-size: 15px; color: var(--primary-navy, #1e2d5a);">Digital Transformation & Smart Factory Pipeline</div>
            <div style="font-size: 11.5px; color: #475569; font-weight: 700; margin-top: 2px;">
              Smart Factory Readiness: <strong style="color: #2563eb;">${portfolioPct}%</strong> (${completedCount} of ${groupKpis.length} Projects Live)
            </div>
          </div>
        </div>
        <div class="dig-view-toggle" style="display: flex; gap: 8px; align-items: center;">
          <button class="dig-toggle-btn active" id="btn-dig-stream-${suffix}" onclick="window.toggleDigitalProjectView('${suffix}', 'stream')">
            ⚡ Tech Pipeline View
          </button>
          <button class="dig-toggle-btn" id="btn-dig-table-${suffix}" onclick="window.toggleDigitalProjectView('${suffix}', 'table')">
            ☰ Table View
          </button>
        </div>
      </div>
      <div class="card-body" style="padding: 18px;">
        ${streamHtml}
        ${tableHtml}
      </div>
    </div>
  `;

  container.innerHTML = html;
}
