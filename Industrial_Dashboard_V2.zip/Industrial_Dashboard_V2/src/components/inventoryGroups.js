// Inventory Dashboard Groupings Component

import { getAchievement, getStatus, getKpiForMode, renderDirectionBadge } from '../state.js';

// Helper to format values dynamically
function formatValue(val) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  return parseFloat(val.toFixed(2));
}

// Global View Switcher for Ageing Inventory Section
if (typeof window !== 'undefined') {
  window.toggleAgeingInventoryView = function(suffix, view) {
    const visualEl = document.getElementById(`inv-ageing-visual-${suffix}`);
    const tableEl = document.getElementById(`inv-ageing-table-${suffix}`);
    const btnVisual = document.getElementById(`btn-inv-visual-${suffix}`);
    const btnTable = document.getElementById(`btn-inv-table-${suffix}`);

    if (view === 'visual') {
      if (visualEl) visualEl.style.display = 'flex';
      if (tableEl) tableEl.style.display = 'none';
      if (btnVisual) btnVisual.classList.add('active');
      if (btnTable) btnTable.classList.remove('active');
    } else {
      if (visualEl) visualEl.style.display = 'none';
      if (tableEl) tableEl.style.display = 'block';
      if (btnVisual) btnVisual.classList.remove('active');
      if (btnTable) btnTable.classList.add('active');
    }
  };
}

// Group 1: Inventory Value & Coverage
export function renderInventoryValueSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const rows = [
    { id: 'inv_tml', label: 'TML', type: 'data' },
    { id: 'inv_tmbsl', label: 'TMBSL', type: 'data' },
    { id: 'inv_overall', label: 'Total', type: 'total' },
    { id: 'inv_no_of_days', label: 'Inventory - No of Days', type: 'data' }
  ];

  let html = `
    <!-- Card 1: Inventory Value & Coverage -->
    <div class="card inv-value-card">
      <div class="card-header">Inventory Value & Coverage</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Inventory Category</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  let dataIndex = 0;
  rows.forEach(row => {
    const kpi = kpis.find(k => k.id === row.id);
    if (!kpi) return;

    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    
    const targetVal = formatValue(target);
    const actualVal = formatValue(actual);
    
    const rowClass = row.type === 'total' ? 'table-total-row' : '';
    const nameStyle = row.type === 'total' ? 'font-weight: 700;' : 'font-weight: 500;';
    const bgStyle = row.type === 'total' ? 'background-color: #f1f5f9;' : '';

    if (row.type !== 'total') {
      dataIndex++;
    }
    const displayName = row.type === 'total' ? row.label : `${dataIndex}. ${row.label}`;

    html += `
      <tr class="${rowClass}" style="${bgStyle}">
        <td style="text-align: left; ${nameStyle}">${displayName}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${targetVal}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${actualVal}</td>
        <td class="cell-status ${statusClass}">
          <span class="status-pill">${ach}%</span>
        </td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}

// Group 2: Ageing Inventory & Other Metrics (Redesigned Intuitive Visual UI)
export function renderInventoryAgeingSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';

  // Ageing Category Definitions
  const ageingKpis = [
    { id: 'ageing_gt_180', label: '>180 Days Stock', num: '4', icon: '⏳', desc: 'Critical Long-Term Stock' },
    { id: 'ageing_gt_90', label: '>90 Days Stock', num: '5', icon: '⚠️', desc: 'Watchlist Inventory' },
    { id: 'machinery_spares', label: 'Machinery Spares', num: '6', icon: '⚙️', desc: 'Plant Spares Capital' },
    { id: 'tools_idm', label: 'Tools & IDM', num: '7', icon: '🛠️', desc: 'Tooling & Consumables' }
  ];

  const totalKpi = kpis.find(k => k.id === 'ageing_tot');
  const totalData = totalKpi ? getKpiForMode(totalKpi, resolvedMode) : { target: 80.5, actual: 91.43 };
  const totalAch = totalKpi ? parseFloat(getAchievement(totalKpi, resolvedMode).toFixed(1)) : 88.0;
  const totalStatus = totalKpi ? getStatus(totalKpi, resolvedMode) : 'RED';
  const totalStatusClass = `status-${totalStatus.toLowerCase()}`;
  const totalVariance = parseFloat((totalData.actual - totalData.target).toFixed(2));
  const isTotalOver = totalVariance > 0;

  // Build rows for single integrated visual matrix table
  let matrixRowsHtml = '';
  ageingKpis.forEach(item => {
    const kpi = kpis.find(k => k.id === item.id);
    if (!kpi) return;

    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    const variance = parseFloat((actual - target).toFixed(2));
    const isOver = variance > 0;
    
    const maxVal = Math.max(target, actual) || 1;
    const actualPct = Math.min(100, Math.max(0, (actual / maxVal) * 100));

    let varBadge = '';
    if (variance === 0) {
      varBadge = `<span class="matrix-var-badge var-on-target">✓ Exact Target Limit</span>`;
    } else if (isOver) {
      varBadge = `<span class="matrix-var-badge var-over">⚠️ +₹${Math.abs(variance)} Crs Over Target</span>`;
    } else {
      varBadge = `<span class="matrix-var-badge var-under">✓ -₹${Math.abs(variance)} Crs Within Limit</span>`;
    }

    const barColor = isOver ? 'linear-gradient(90deg, #f87171, #ef4444)' : 'linear-gradient(90deg, #34d399, #10b981)';

    matrixRowsHtml += `
      <tr class="matrix-row">
        <!-- Col 1: Ageing Category & Subtitle -->
        <td class="matrix-cell-name">
          <div class="matrix-name-wrapper">
            <span class="matrix-icon">${item.icon}</span>
            <div>
              <div class="matrix-title">${item.num}. ${kpi.name}</div>
              <div class="matrix-subtitle">${item.desc}</div>
            </div>
          </div>
        </td>

        <!-- Col 2: Target vs Actual Figures -->
        <td class="matrix-cell-vals">
          <div class="matrix-vals-box">
            <div class="matrix-actual-num">₹${formatValue(actual)} <span class="matrix-uom">Crs</span></div>
            <div class="matrix-target-num">Target Limit: ₹${formatValue(target)} Crs</div>
          </div>
        </td>

        <!-- Col 3: Visual Budget Track & Variance Badge -->
        <td class="matrix-cell-gauge">
          <div class="matrix-gauge-container">
            <div class="matrix-gauge-header">
              ${varBadge}
            </div>
            <div class="matrix-bullet-track">
              <div class="matrix-bullet-fill" style="width: ${actualPct}%; background: ${barColor};"></div>
            </div>
          </div>
        </td>

        <!-- Col 4: Measure -->
        <td class="matrix-cell-measure">
          ${renderDirectionBadge(kpi)}
        </td>

        <!-- Col 5: Status Achievement -->
        <td class="matrix-cell-status ${statusClass}">
          <span class="status-pill">${ach}%</span>
        </td>
      </tr>
    `;
  });

  // Total Summary Row at bottom of matrix
  const totalBarColor = isTotalOver ? 'linear-gradient(90deg, #f87171, #ef4444)' : 'linear-gradient(90deg, #34d399, #10b981)';
  const totalVarBadge = isTotalOver
    ? `<span class="matrix-var-badge var-over">⚠️ Exceeded Target Budget by +₹${Math.abs(totalVariance)} Crs</span>`
    : `<span class="matrix-var-badge var-under">✓ Within Target Limit (-₹${Math.abs(totalVariance)} Crs)</span>`;

  const totalRowHtml = `
    <tr class="matrix-row matrix-total-row">
      <td class="matrix-cell-name">
        <div class="matrix-name-wrapper">
          <span class="matrix-icon" style="font-size: 20px; background: #e2e8f0;">📦</span>
          <div>
            <div class="matrix-title" style="font-size: 14.5px; font-weight: 800;">Total Ageing Inventory</div>
            <div class="matrix-subtitle" style="font-weight: 600; color: #475569;">Cumulative Capital Lock-up</div>
          </div>
        </div>
      </td>
      <td class="matrix-cell-vals">
        <div class="matrix-vals-box">
          <div class="matrix-actual-num" style="font-size: 16px; font-weight: 900; color: var(--primary-navy, #1e2d5a);">₹${formatValue(totalData.actual)} <span class="matrix-uom">Crs</span></div>
          <div class="matrix-target-num" style="font-weight: 700; color: #475569;">Target Limit: ₹${formatValue(totalData.target)} Crs</div>
        </div>
      </td>
      <td class="matrix-cell-gauge">
        <div class="matrix-gauge-container">
          <div class="matrix-gauge-header">
            ${totalVarBadge}
          </div>
          <div class="matrix-bullet-track" style="height: 9px;">
            <div class="matrix-bullet-fill" style="width: ${Math.min(100, Math.max(0, (totalData.actual / (Math.max(totalData.target, totalData.actual) || 1)) * 100))}%; background: ${totalBarColor};"></div>
          </div>
        </div>
      </td>
      <td class="matrix-cell-measure">
        ${totalKpi ? renderDirectionBadge(totalKpi) : '<span class="direction-badge lower"><span class="badge-arrow">↓</span> Lower Better</span>'}
      </td>
      <td class="matrix-cell-status ${totalStatusClass}">
        <span class="status-pill" style="font-size: 13.5px; font-weight: 800; padding: 6px 12px;">${totalAch}%</span>
      </td>
    </tr>
  `;

  let html = `
    <!-- Master Single Integrated Component: Ageing Inventory Visual Risk Matrix -->
    <div class="card inv-ageing-card" style="margin-bottom: 22px;">
      <!-- Integrated Header Bar -->
      <div class="inv-ageing-matrix-header">
        <div class="inv-header-left">
          <div class="inv-header-icon">⏳</div>
          <div>
            <div class="inv-header-title">Ageing Inventory Overview</div>
            <div class="inv-header-subtitle">Capital Lock-up & Breakdown Analysis • Unit: Rs in Crs</div>
          </div>
        </div>
        <div class="inv-header-right">
          <span class="inv-header-badge-rule">↓ Lower Better</span>
        </div>
      </div>

      <!-- Unified Matrix Table Container -->
      <div class="inv-matrix-container">
        <table class="inv-matrix-table">
          <thead>
            <tr>
              <th style="width: 27%; text-align: left;">Ageing Category</th>
              <th style="width: 17%; text-align: left;">Target vs Actual</th>
              <th style="width: 36%; text-align: left;">Budget Variance & Visual Bullet Track</th>
              <th style="width: 10%; text-align: center;">Measure</th>
              <th style="width: 10%; text-align: center;">Status</th>
            </tr>
          </thead>
          <tbody>
            ${matrixRowsHtml}
            ${totalRowHtml}
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Card 3: Operations & IFLT Inventory
  const otherRows = [
    { id: 'ops_inv_days', label: 'Operations Inventory No: of Days', type: 'data' },
    { id: 'inv_rs_crs_wo', label: 'Inventory in Rs Crs (W/o IFLT)', type: 'data' },
    { id: 'inv_rs_crs_w', label: 'Inventory in Rs Crs (with IFLT)', type: 'data' }
  ];

  html += `
    <!-- Card 3: Operations & IFLT Inventory -->
    <div class="card inv-other-card">
      <div class="card-header">Operations & IFLT Inventory</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Inventory Parameter</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  let otherIndex = 7;
  otherRows.forEach(row => {
    const kpi = kpis.find(k => k.id === row.id);
    if (!kpi) return;

    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    
    const targetVal = formatValue(target);
    const actualVal = formatValue(actual);
    
    const rowClass = row.type === 'total' ? 'table-total-row' : '';
    const nameStyle = row.type === 'total' ? 'font-weight: 700;' : 'font-weight: 500;';
    const bgStyle = row.type === 'total' ? 'background-color: #f1f5f9;' : '';

    if (row.type !== 'total') {
      otherIndex++;
    }
    const displayName = row.type === 'total' ? row.label : `${otherIndex}. ${row.label}`;

    html += `
      <tr class="${rowClass}" style="${bgStyle}">
        <td style="text-align: left; ${nameStyle}">${displayName}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${targetVal}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${actualVal}</td>
        <td class="cell-status ${statusClass}">
          <span class="status-pill">${ach}%</span>
        </td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}
