// HR Dashboard Groupings Component

import { Chart, registerables } from 'chart.js';
import { getAchievement, getStatus, getKpiForMode, renderDirectionBadge } from '../state.js';

Chart.register(...registerables);

const hrAbsenteeismChartInstance = {};

// Helper to format values dynamically (keeping max 2 decimals, without appending unit suffix)
function formatValue(val) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  return parseFloat(val.toFixed(2));
}

// Master layout orchestrator for HR module
export function renderHrDashboard(kpis, tableContainerId, workplaceContainerId, mode) {
  const suffix = tableContainerId.endsWith('-ytd') ? 'ytd' : 'monthly';
  const resolvedMode = mode || suffix;
  renderHrTablesSection(kpis, tableContainerId, resolvedMode);
  renderHrVisualsSection(kpis, workplaceContainerId, suffix, resolvedMode);
  
  setTimeout(() => {
    renderHrAbsenteeismChart(kpis, suffix, resolvedMode);
  }, 0);
}

// Renders IVDP, CSR Parameters + PCVH Gauge (side-by-side), and Welfare tables
export function renderHrTablesSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const ivdpKpi = kpis.find(k => k.id === 'hr_lives_ivdp');
  
  const livesIds = ['hr_lives_env', 'hr_lives_health', 'hr_lives_edu', 'hr_lives_emp'];
  const livesKpis = kpis.filter(k => livesIds.includes(k.id));

  const welfareIds = ['hr_skip_level', 'hr_er_index', 'hr_legatrix'];
  const welfareKpis = kpis.filter(k => welfareIds.includes(k.id));

  // PCVH Gauge Card side-by-side calculations
  const pcvhKpi = kpis.find(k => k.id === 'hr_pcvh');
  let pcvhGaugeCardHtml = '';

  if (pcvhKpi) {
    const pcvhVals = getKpiForMode(pcvhKpi, resolvedMode);
    const pcvhTarget = pcvhVals.target;
    const pcvhActual = pcvhVals.actual;
    const pcvhAch = parseFloat(getAchievement(pcvhKpi, resolvedMode).toFixed(1));
    const annualProgress = parseFloat(((pcvhVals.ytdActual || 20.38) / (pcvhVals.annualTarget || 48) * 100).toFixed(1));
    
    const r = 65;
    const circ = 2 * Math.PI * r;
    const strokeDashoffset = circ - (circ * Math.min(100, pcvhAch)) / 100;
    const isGood = pcvhAch >= 95;

    pcvhGaugeCardHtml = `
      <div class="card hr-pcvh-gauge-card" style="flex: 0 0 240px; width: 240px; text-align: center; padding: 16px 12px; display: flex; flex-direction: column; justify-content: space-between; margin-bottom: 0; box-sizing: border-box;">
        <div class="card-header" style="text-align: left; padding: 0; border-bottom: none; font-weight: 700; background: transparent; color: var(--primary-navy); font-size: 15px; line-height: 1.3;">PCVH Volunteering Analytics</div>
        <div style="position: relative; width: 130px; height: 130px; margin: 12px auto;">
          <svg width="130" height="130" viewBox="0 0 160 160">
            <defs>
              <linearGradient id="pcvhGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="${isGood ? '#10b981' : '#8b5cf6'}" />
                <stop offset="100%" stop-color="${isGood ? '#34d399' : '#3b82f6'}" />
              </linearGradient>
            </defs>
            <circle cx="80" cy="80" r="65" stroke="#f1f5f9" stroke-width="14" fill="transparent" />
            <circle cx="80" cy="80" r="65" stroke="url(#pcvhGrad)" stroke-width="14" fill="transparent"
                    stroke-dasharray="408.4" stroke-dashoffset="${strokeDashoffset}" stroke-linecap="round"
                    transform="rotate(-90 80 80)" style="transition: stroke-dashoffset 0.8s ease-in-out;" />
          </svg>
          <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
            <div style="font-size: 22px; font-weight: 800; color: var(--primary-navy);">${formatValue(pcvhActual)}</div>
            <div style="font-size: 11px; color: #475569; font-weight: 700; margin-top: 1px;">of ${formatValue(pcvhTarget)} target</div>
          </div>
        </div>
        <div>
          <div style="font-size: 16px; font-weight: 800; color: ${isGood ? '#10b981' : '#3b82f6'};">${pcvhAch}% Achievement</div>
          <div style="font-size: 11px; color: #64748b; margin-top: 3px; font-weight: 700;">Per Capita Volunteering Hours</div>
          <div style="font-size: 10px; color: #475569; margin-top: 6px; font-weight: 700; background: #f8fafc; padding: 4px 8px; border-radius: 6px; border: 1px solid #e2e8f0;">
            Annual Goal: 48.0 Hrs (${annualProgress}% YTD)
          </div>
        </div>
      </div>
    `;
  }

  let html = '';

  // Render standalone IVDP box if it exists
  if (ivdpKpi) {
    const { target, actual } = getKpiForMode(ivdpKpi, resolvedMode);
    const ach = parseFloat(getAchievement(ivdpKpi, resolvedMode).toFixed(2));
    const status = getStatus(ivdpKpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    html += `
      <!-- IVDP Standalone Table Card -->
      <div class="card hr-ivdp-card" style="margin-bottom: 20px;">
        <div class="card-header">IVDP (Lives Touched)</div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table">
            <thead>
              <tr>
                <th style="text-align: left; width: 34%;">CSR Parameter</th>
                <th style="text-align: center; width: 20%;">Measure</th>
                <th class="col-uom" style="width: 10%;">UoM</th>
                <th style="width: 13%;">Target</th>
                <th style="width: 13%;">Actual</th>
                <th style="width: 10%;">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="text-align: left; font-weight: 700;">1. ${ivdpKpi.name}</td>
                <td style="text-align: center;">${renderDirectionBadge(ivdpKpi)}</td>
                <td class="col-uom">${ivdpKpi.unit}</td>
                <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target)}</td>
                <td style="font-weight: 700; color: var(--primary-navy); font-size: 13px;">${formatValue(actual)}</td>
                <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  // Side-by-side flex container for CSR Parameters and PCVH Volunteering Analytics
  html += `
    <div style="display: flex; gap: 20px; width: 100%; flex-wrap: wrap; align-items: stretch; margin-bottom: 20px;">
      <!-- CSR Parameters Table -->
      <div class="card hr-lives-card" style="flex: 1; min-width: 0; margin-bottom: 0; display: flex; flex-direction: column;">
        <div class="card-header">CSR Parameters</div>
        <div class="card-body scrollable-table-container" style="flex-grow: 1;">
          <table class="dashboard-table">
            <thead>
              <tr>
                <th style="text-align: left; width: 34%;">CSR Parameter</th>
                <th style="text-align: center; width: 20%;">Measure</th>
                <th class="col-uom" style="width: 10%;">UoM</th>
                <th style="width: 13%;">Target</th>
                <th style="width: 13%;">Actual</th>
                <th style="width: 10%;">Status</th>
              </tr>
            </thead>
            <tbody>
  `;

  livesKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    html += `
      <tr>
        <td style="text-align: left; font-weight: 700;">${idx + 2}. ${kpi.name.replace('No. of Lives Touched - ', '')}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit}</td>
        <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target)}</td>
        <td style="font-weight: 700; color: var(--primary-navy); font-size: 13px;">${formatValue(actual)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
            </tbody>
          </table>
        </div>
      </div>

      <!-- PCVH Volunteering Analytics Gauge Card -->
      ${pcvhGaugeCardHtml}
    </div>

    <!-- Employee Welfare & Compliance Table -->
    <div class="card hr-welfare-card" style="margin-bottom: 20px;">
      <div class="card-header">Employee Welfare & Compliance</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Welfare Parameter</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  welfareKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    html += `
      <tr>
        <td style="text-align: left; font-weight: 700;">${idx + 6}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit}</td>
        <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target)}</td>
        <td style="font-weight: 700; color: var(--primary-navy); font-size: 13px;">${formatValue(actual)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}

// Renders the PCVH Gauge
export function renderHrVisualsSection(kpis, containerId, suffix) {
  const container = document.getElementById(containerId);
  if (container) {
    container.innerHTML = '';
    container.style.display = 'none';
  }
}

const hrDatalabelsPlugin = {
  id: 'hrDatalabels',
  afterDatasetsDraw(chart) {
    const { ctx } = chart;
    ctx.save();
    ctx.font = 'bold 9px Inter, system-ui, sans-serif';
    ctx.fillStyle = '#1e2d5a';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    chart.data.datasets.forEach((dataset, i) => {
      chart.getDatasetMeta(i).data.forEach((datapoint, index) => {
        const value = dataset.data[index];
        if (value !== null && value !== undefined) {
          ctx.fillText(value + '%', datapoint.x, datapoint.y - 4);
        }
      });
    });
    ctx.restore();
  }
};

// Renders the Comparison bar chart for Line 2 and Line 3 Absenteeism
function renderHrAbsenteeismChart(kpis, suffix) {
  const canvas = document.getElementById(`hr-absenteeism-chart-canvas-${suffix}`);
  if (!canvas) return;

  if (hrAbsenteeismChartInstance[suffix]) {
    hrAbsenteeismChartInstance[suffix].destroy();
    hrAbsenteeismChartInstance[suffix] = null;
  }

  const l2Kpi = kpis.find(k => k.id === 'hr_absenteeism_l2');
  const l3Kpi = kpis.find(k => k.id === 'hr_absenteeism_l3');

  const l2Target = l2Kpi ? l2Kpi.target : 5.0;
  const l2Actual = l2Kpi ? l2Kpi.actual : 4.2;
  const l3Target = l3Kpi ? l3Kpi.target : 5.0;
  const l3Actual = l3Kpi ? l3Kpi.actual : 5.8;

  hrAbsenteeismChartInstance[suffix] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: ['Line 2 Absenteeism', 'Line 3 Absenteeism'],
      datasets: [
        {
          label: 'Target Limit',
          data: [l2Target, l3Target],
          backgroundColor: '#cbd5e1', // Light slate
          borderRadius: 6,
          barThickness: 24
        },
        {
          label: 'Actual Rate',
          data: [l2Actual, l3Actual],
          backgroundColor: [
            l2Actual <= l2Target ? '#10b981' : '#ef4444', // Green if meets target limit, Red if exceeds
            l3Actual <= l3Target ? '#10b981' : '#ef4444'
          ],
          borderRadius: 6,
          barThickness: 24
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: true,
          position: 'bottom',
          align: 'start',
          labels: {
            boxWidth: 12,
            font: { size: 10, weight: 'bold' }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: (() => {
            const maxVal = Math.max(l2Target, l2Actual, l3Target, l3Actual);
            if (maxVal <= 0) return 1.0;
            // Pad by 25% to leave sufficient space for the labels at the top of the chart
            return parseFloat((maxVal * 1.25).toFixed(2));
          })(),
          ticks: {
            font: { size: 9, weight: 'bold' },
            callback: v => v + '%'
          }
        },
        x: {
          ticks: {
            font: { size: 9, weight: 'bold' }
          }
        }
      }
    },
    plugins: [hrDatalabelsPlugin]
  });
}
