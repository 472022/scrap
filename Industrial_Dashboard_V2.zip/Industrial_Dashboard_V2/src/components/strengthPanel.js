// Strengths Panel Component

import { state, getStrengths } from '../state.js';

export function renderStrengthPanel(containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const strengths = getStrengths(mode);

  let html = `
    <div class="card strengths-card">
      <div class="card-header">Strengths</div>
      <div class="card-body">
        <ul class="strengths-list">
  `;

  if (strengths.length === 0) {
    html += `<li class="no-strengths-msg">No current targets met. Keep focusing on ${state.currentModule} improvements!</li>`;
  } else {
    strengths.forEach(str => {
      html += `
        <li>
          <span class="checkmark-icon">✔</span>
          <span class="strength-text">${str}</span>
        </li>
      `;
    });
  }

  html += `
        </ul>
      </div>
    </div>
  `;

  container.innerHTML = html;
}
