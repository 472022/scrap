// Cost Dashboard Groupings Component

import { state, getAchievement, getStatus, getKpiForMode, renderDirectionBadge, isLowerBetter } from '../state.js';

// Helper to format values to exactly 1 decimal place
function formatValue(val) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  return val.toFixed(1);
}

// Group 1: Material Cost & Operations Fixed Expenses (OFE)
export function renderCostMaterialSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const resolvedMode = (typeof mode === 'string' && mode) ? mode : (containerId.toLowerCase().includes('ytd') ? 'ytd' : 'monthly');

  const directIds = ['repro', 'dmc', 'vcc'];
  const directKpis = kpis.filter(k => directIds.includes(k.id));
  const ofeKpi = kpis.find(k => k.id === 'ofe');

  let html = `
    <!-- Card 1: Direct Material Cost -->
    <div class="card cost-direct-card" style="margin-bottom: 20px;">
      <div class="card-header">Cost Parameters</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Cost Parameter</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  directKpis.forEach((kpi, idx) => {
    let target = kpi.target;
    let actual = kpi.actual;
    if (resolvedMode) {
      const valObj = getKpiForMode(kpi, resolvedMode);
      target = valObj.target;
      actual = valObj.actual;
    }

    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    const lower = isLowerBetter(kpi);
    const actualColor = lower ? (actual <= target ? '#10b981' : '#ef4444') : (actual >= target ? '#10b981' : '#ef4444');
    html += `
      <tr>
        <td style="text-align: left; font-weight: 900; color: #0f172a;">${idx + 1}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '-'}</td>
        <td style="font-weight: 800; color: #000000; font-size: 14px;">${formatValue(target)}</td>
        <td style="font-weight: 900; color: ${actualColor}; font-size: 14px;">${formatValue(actual)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  // Append Operations Fixed Expenses
  if (ofeKpi) {
    let target = ofeKpi.target;
    let actual = ofeKpi.actual;
    if (resolvedMode) {
      const valObj = getKpiForMode(ofeKpi, resolvedMode);
      target = valObj.target;
      actual = valObj.actual;
    }

    const ach = parseFloat(getAchievement(ofeKpi, resolvedMode).toFixed(2));
    const status = getStatus(ofeKpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    
    html += `
      <div class="card cost-ofe-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Operations Fixed Expenses (OFE)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table">
            <thead>
              <tr>
                <th style="text-align: left; width: 34%;">Expense Parameter</th>
                <th style="text-align: center; width: 20%;">Measure</th>
                <th class="col-uom" style="width: 10%;">UoM</th>
                <th style="width: 13%;">Target</th>
                <th style="width: 13%;">Actual</th>
                <th style="width: 10%;">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style="text-align: left; font-weight: 900; color: #0f172a;">4. ${ofeKpi.name}</td>
                <td style="text-align: center;">${renderDirectionBadge(ofeKpi)}</td>
                <td class="col-uom">${ofeKpi.unit || '-'}</td>
                <td style="font-weight: 800; color: #000000; font-size: 14px;">${formatValue(target)}</td>
                <td style="font-weight: 900; color: ${actual > target ? '#ef4444' : '#10b981'}; font-size: 14px;">${formatValue(actual)}</td>
                <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  container.innerHTML = html;
}

// Group 2: Controllable Ledger Expenses (CLT)
// Helper to format values dynamically for table cells
function formatCellVal(name, val) {
  if (val === undefined || val === null || val === 0) {
    if (name === "Rs/Eq Veh" || name === "Savings (Target vs Actual)") return "";
    if (name === "PTP" || name === "Spares" || name === "Power" || name === "Fuel") {
      return "0";
    }
    return "-";
  }
  if (typeof val !== 'number') return val;
  if (name.toLowerCase().includes("eq no")) {
    return Math.round(val).toString();
  }
  if (val % 1 === 0) {
    return val.toString();
  }
  return val.toFixed(1);
}

// Group 2: VCC, OFE and CLT side-specific tables
export function renderCostCltSection(kpis, containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const isYtd = containerId.toLowerCase().includes('ytd');
  let html = '';

  // 1. OFE Breakdown Table
  const ofeList = state.costOfeBreakdown || [];
  if (ofeList.length > 0) {
    html += `
      <div class="card cost-ofe-table-card" style="width: 100%;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>OFE Breakdown (CLT Summary) - ${isYtd ? 'YTD Performance' : 'Month Performance'}</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table cost-ofe-table" style="border-collapse: collapse; width: 100%;">
            <thead>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">OFE Category</th>
                ${isYtd ? `
                  <th colspan="3" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy);">YTD (Rs Crs)</th>
                ` : `
                  <th colspan="3" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0;">Month (Rs Crs)</th>
                `}
              </tr>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">TC Tgt.</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">SC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; ${isYtd ? '' : 'border-right: 1px solid #e2e8f0;'}">Act.</th>
              </tr>
            </thead>
            <tbody>
    `;

    ofeList.forEach((item) => {
      const lowerName = item.name.toLowerCase();
      const isSubtotal = lowerName.includes('clt - ofc') || lowerName.includes('insurance & treasury') || lowerName.includes('ofe excl it') || lowerName.includes('total ofc');
      const rowClass = isSubtotal ? 'font-bold' : '';
      const rowBg = isSubtotal ? 'background-color: #f8fafc;' : 'background-color: #ffffff;';
      const borderTop = isSubtotal ? 'border-top: 2px solid #cbd5e1;' : 'border-top: 1px solid #f1f5f9;';
      
      const targetVal = isYtd ? item.ytdTarget : item.mtdTarget;
      const scVal = isYtd ? item.ytdSc : item.mtdSc;
      const actualVal = isYtd ? item.ytdActual : item.mtdActual;

      const scCompareVal = scVal !== undefined && scVal !== 0 ? scVal : targetVal;
      const actualColor = actualVal > scCompareVal ? '#ef4444' : '#10b981';

      html += `
        <tr class="${rowClass}" style="${rowBg} ${borderTop} border-bottom: 1px solid #f1f5f9; transition: background-color 0.2s;">
          <td style="text-align: left; padding: 10px 16px; ${isSubtotal ? 'font-weight: 700; color: var(--primary-navy);' : 'font-weight: 500; color: #334155;'} border-right: 1px solid #e2e8f0;">${item.name}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: #000000; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, targetVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, scVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 800; color: ${actualColor}; ${isYtd ? '' : 'border-right: 1px solid #e2e8f0;'}">${formatCellVal(item.name, actualVal)}</td>
        </tr>
      `;
    });

    html += `
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  // 2. VCC Breakdown Table
  const vccList = state.costVccBreakdown || [];
  if (vccList.length > 0) {
    if (!isYtd) {
      // Month side: keep August'26
      html += `
      <div class="card cost-vcc-table-card" style="width: 100%; margin-top: 25px;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>VCC Breakdown (Rs/Veh) - Month Performance</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table cost-vcc-table" style="border-collapse: collapse; width: 100%;">
            <thead>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">Particulars</th>
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">VCC's</th>
                <th colspan="3" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy); border-bottom: 1px solid #e2e8f0;">FTM August'26</th>
              </tr>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">TC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">SC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569;">Act</th>
              </tr>
            </thead>
            <tbody>
      `;

      vccList.forEach((item) => {
        const lowerName = item.name.toLowerCase();
        const isHeader = lowerName.includes('rs/eq veh');
        const isSubtotal = lowerName === 'total' || lowerName.includes('freight');
        const isGrandTotal = lowerName.includes('grand total');
        
        const rowClass = isHeader ? 'font-bold bg-slate-100' : (isSubtotal ? 'font-bold bg-slate-50' : (isGrandTotal ? 'font-bold bg-slate-100' : ''));
        const rowBg = isHeader ? 'background-color: #f1f5f9;' : (isSubtotal ? 'background-color: #f8fafc;' : (isGrandTotal ? 'background-color: #e2e8f0;' : 'background-color: #ffffff;'));
        const borderTop = (isSubtotal || isGrandTotal) ? 'border-top: 2px solid #cbd5e1;' : 'border-top: 1px solid #f1f5f9;';

        const monthData = item.aug || item.jul;
        const getActColor = (act, sc, tc) => {
          if (isHeader || act === 0 || lowerName.includes("eq no")) return '#000000';
          const compareVal = sc !== 0 ? sc : tc;
          return act > compareVal ? '#ef4444' : '#10b981';
        };

        html += `
          <tr class="${rowClass}" style="${rowBg} ${borderTop} border-bottom: 1px solid #f1f5f9; transition: background-color 0.2s;">
            <td style="text-align: left; padding: 10px 16px; ${isHeader || isSubtotal || isGrandTotal ? 'font-weight: 700; color: var(--primary-navy);' : 'font-weight: 500; color: #334155;'} border-right: 1px solid #e2e8f0;">${item.name}</td>
            <td style="text-align: left; padding: 10px 16px; font-weight: 500; color: #475569; border-right: 1px solid #e2e8f0;">${item.group || ''}</td>
            
            <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: #000000; border-right: 1px solid #f1f5f9;">${isHeader ? '' : formatCellVal(item.name, monthData.tc)}</td>
            <td style="text-align: center; padding: 10px 8px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">${isHeader ? '' : formatCellVal(item.name, monthData.sc)}</td>
            <td style="text-align: center; padding: 10px 8px; font-weight: 800; color: ${getActColor(monthData.act, monthData.sc, monthData.tc)};">${isHeader ? '' : formatCellVal(item.name, monthData.act)}</td>
          </tr>
        `;
      });

      html += `
              </tbody>
            </table>
          </div>
        </div>
      `;
    } else {
      // YTD side: July'27 & Mar'27
      html += `
      <div class="card cost-vcc-table-card" style="width: 100%; margin-top: 25px;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>VCC Breakdown (Rs/Veh) - YTD Performance</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table cost-vcc-table" style="border-collapse: collapse; width: 100%;">
            <thead>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">Particulars</th>
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">VCC's</th>
                <th colspan="3" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0;">YTD July'27</th>
                <th colspan="2" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy); border-bottom: 1px solid #e2e8f0;">YTD Mar'27</th>
              </tr>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">TC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">SC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #e2e8f0;">Act</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">Saving TC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569;">Saving SC</th>
              </tr>
            </thead>
            <tbody>
      `;

      vccList.forEach((item) => {
        const lowerName = item.name.toLowerCase();
        const isHeader = lowerName.includes('rs/eq veh');
        const isSubtotal = lowerName === 'total' || lowerName.includes('freight');
        const isGrandTotal = lowerName.includes('grand total');
        
        const rowClass = isHeader ? 'font-bold bg-slate-100' : (isSubtotal ? 'font-bold bg-slate-50' : (isGrandTotal ? 'font-bold bg-slate-100' : ''));
        const rowBg = isHeader ? 'background-color: #f1f5f9;' : (isSubtotal ? 'background-color: #f8fafc;' : (isGrandTotal ? 'background-color: #e2e8f0;' : 'background-color: #ffffff;'));
        const borderTop = (isSubtotal || isGrandTotal) ? 'border-top: 2px solid #cbd5e1;' : 'border-top: 1px solid #f1f5f9;';

        const ytdCompareVal = item.ytdJuly27.sc !== 0 ? item.ytdJuly27.sc : item.ytdJuly27.tc;
        let actualColor = '#000000';
        if (!isHeader && item.ytdJuly27.act !== 0 && !lowerName.includes("eq no")) {
          actualColor = item.ytdJuly27.act > ytdCompareVal ? '#ef4444' : '#10b981';
        }

        const savingTcVal = item.ytdMar27.savingTc;
        const savingScVal = item.ytdMar27.savingSc;

        const savingTcColor = savingTcVal < 0 ? '#ef4444' : (savingTcVal > 0 ? '#10b981' : '#000000');
        const savingScColor = savingScVal < 0 ? '#ef4444' : (savingScVal > 0 ? '#10b981' : '#000000');

        html += `
          <tr class="${rowClass}" style="${rowBg} ${borderTop} border-bottom: 1px solid #f1f5f9; transition: background-color 0.2s;">
            <td style="text-align: left; padding: 10px 16px; ${isHeader || isSubtotal || isGrandTotal ? 'font-weight: 700; color: var(--primary-navy);' : 'font-weight: 500; color: #334155;'} border-right: 1px solid #e2e8f0;">${item.name}</td>
            <td style="text-align: left; padding: 10px 16px; font-weight: 500; color: #475569; border-right: 1px solid #e2e8f0;">${item.group || ''}</td>
            
            <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: #000000; border-right: 1px solid #f1f5f9;">${isHeader ? '' : formatCellVal(item.name, item.ytdJuly27.tc)}</td>
            <td style="text-align: center; padding: 10px 8px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">${isHeader ? '' : formatCellVal(item.name, item.ytdJuly27.sc)}</td>
            <td style="text-align: center; padding: 10px 8px; font-weight: 800; color: ${actualColor}; border-right: 1px solid #e2e8f0;">${isHeader ? '' : formatCellVal(item.name, item.ytdJuly27.act)}</td>
            
            <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: ${savingTcColor}; border-right: 1px solid #f1f5f9;">${isHeader ? '' : formatCellVal(item.name, savingTcVal)}</td>
            <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: ${savingScColor};">${isHeader ? '' : formatCellVal(item.name, savingScVal)}</td>
          </tr>
        `;
      });

      html += `
              </tbody>
            </table>
          </div>
        </div>
      `;
    }
  }

  // 3. CLT Performance Grid Table
  const cltList = state.costCltBreakdown || [];
  if (cltList.length > 0) {
    html += `
      <div class="card cost-clt-table-card" style="width: 100%; margin-top: 25px;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>CLT Breakdown - ${isYtd ? 'YTD Performance' : 'Month Performance'}</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table cost-clt-table" style="border-collapse: collapse; width: 100%;">
            <thead>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">CLT Category</th>
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">Lead Person</th>
                <th colspan="5" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy);">${isYtd ? 'YTD (Rs Crs)' : 'Month (Rs Crs)'}</th>
              </tr>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">TC Tgt.</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">SC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">Act.</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">Saving vs TC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569;">Savings vs SC</th>
              </tr>
            </thead>
            <tbody>
    `;

    cltList.forEach((item) => {
      const lowerName = item.name.toLowerCase();
      const isSubtotal = lowerName === 'total' || lowerName.includes('savings');
      const rowClass = isSubtotal ? 'font-bold' : '';
      const rowBg = isSubtotal ? 'background-color: #f8fafc;' : 'background-color: #ffffff;';
      const borderTop = isSubtotal ? 'border-top: 2px solid #cbd5e1;' : 'border-top: 1px solid #f1f5f9;';
      
      const targetVal = isYtd ? item.ytdTarget : item.mtdTarget;
      const scVal = isYtd ? item.ytdSc : item.mtdSc;
      const actualVal = isYtd ? item.ytdActual : item.mtdActual;
      const savingTcVal = isYtd ? item.ytdSavingTc : item.mtdSavingTc;
      const savingScVal = isYtd ? item.ytdSavingSc : item.mtdSavingSc;

      const scCompareVal = scVal !== undefined && scVal !== 0 ? scVal : targetVal;
      let actualColor = '#000000';
      if (!isSubtotal) {
        actualColor = actualVal > scCompareVal ? '#ef4444' : '#10b981';
      }

      // Format Savings colors (Green for positive savings > 0, Red for negative savings < 0)
      const savingTcColor = savingTcVal < 0 ? '#ef4444' : (savingTcVal > 0 ? '#10b981' : '#000000');
      const savingScColor = savingScVal < 0 ? '#ef4444' : (savingScVal > 0 ? '#10b981' : '#000000');

      html += `
        <tr class="${rowClass}" style="${rowBg} ${borderTop} border-bottom: 1px solid #f1f5f9; transition: background-color 0.2s;">
          <td style="text-align: left; padding: 10px 16px; ${isSubtotal ? 'font-weight: 700; color: var(--primary-navy);' : 'font-weight: 500; color: #334155;'} border-right: 1px solid #e2e8f0;">${item.name}</td>
          <td style="text-align: left; padding: 10px 16px; font-weight: 500; color: #475569; border-right: 1px solid #e2e8f0;">${item.lead || ''}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: #000000; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, targetVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, scVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 800; color: ${actualColor}; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, actualVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: ${savingTcColor}; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, savingTcVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: ${savingScColor};">${formatCellVal(item.name, savingScVal)}</td>
        </tr>
      `;
    });

    html += `
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  // 4. Plant Cost Breakdown Table (INR Lacs)
  const plantList = state.costPlantBreakdown || [];
  if (plantList.length > 0) {
    const periodHeader = isYtd ? "YTD July'26" : "July'26";
    html += `
      <div class="card cost-plant-table-card" style="width: 100%; margin-top: 25px;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Plant Cost Breakdown (INR Lacs) - ${isYtd ? 'YTD Performance' : 'Month Performance'}</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body scrollable-table-container">
          <table class="dashboard-table cost-plant-table" style="border-collapse: collapse; width: 100%;">
            <thead>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th rowspan="2" style="text-align: left; vertical-align: middle; padding: 12px 16px; font-weight: 700; color: var(--primary-navy); border-right: 1px solid #e2e8f0;">Group Heads (Plant Controllable)</th>
                <th colspan="5" style="text-align: center; padding: 8px; font-weight: 700; color: var(--primary-navy);">${periodHeader}</th>
              </tr>
              <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">TC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">SC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">Act.</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">Saving vs TC</th>
                <th style="text-align: center; padding: 8px; font-size: 11px; font-weight: 600; color: #475569;">Savings vs SC</th>
              </tr>
            </thead>
            <tbody>
    `;

    plantList.forEach((item) => {
      const lowerName = item.name.toLowerCase();
      const isSubtotal = lowerName.includes('total') || lowerName.includes('grand total');
      const rowClass = isSubtotal ? 'font-bold' : '';
      const rowBg = isSubtotal ? 'background-color: #f1f5f9;' : 'background-color: #ffffff;';
      const borderTop = isSubtotal ? 'border-top: 2px solid #cbd5e1;' : 'border-top: 1px solid #f1f5f9;';

      const targetVal = isYtd ? item.ytdTarget : item.mtdTarget;
      const scVal = isYtd ? item.ytdSc : item.mtdSc;
      const actualVal = isYtd ? item.ytdActual : item.mtdActual;
      const savingTcVal = isYtd ? item.ytdSavingTc : item.mtdSavingTc;
      const savingScVal = isYtd ? item.ytdSavingSc : item.mtdSavingSc;

      const scCompareVal = scVal !== 0 ? scVal : targetVal;
      let actualColor = '#000000';
      if (!isSubtotal) {
        actualColor = actualVal > scCompareVal ? '#ef4444' : '#10b981';
      }

      const savingTcColor = savingTcVal < 0 ? '#ef4444' : (savingTcVal > 0 ? '#10b981' : '#000000');
      const savingScColor = savingScVal < 0 ? '#ef4444' : (savingScVal > 0 ? '#10b981' : '#000000');

      html += `
        <tr class="${rowClass}" style="${rowBg} ${borderTop} border-bottom: 1px solid #f1f5f9; transition: background-color 0.2s;">
          <td style="text-align: left; padding: 10px 16px; ${isSubtotal ? 'font-weight: 700; color: var(--primary-navy);' : 'font-weight: 500; color: #334155;'} border-right: 1px solid #e2e8f0;">${item.name}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: #000000; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, targetVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 600; color: #475569; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, scVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 800; color: ${actualColor}; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, actualVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: ${savingTcColor}; border-right: 1px solid #f1f5f9;">${formatCellVal(item.name, savingTcVal)}</td>
          <td style="text-align: center; padding: 10px 8px; font-weight: 700; color: ${savingScColor};">${formatCellVal(item.name, savingScVal)}</td>
        </tr>
      `;
    });

    html += `
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  container.innerHTML = html;
}
