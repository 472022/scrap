// Chart.js Component Manager

import { Chart, registerables } from 'chart.js';
import { state } from '../state.js';

Chart.register(...registerables);

// Linear regression prediction helper
function predictNextValue(values) {
  if (!values || values.length === 0) return 0;
  if (values.length === 1) return values[0];

  const n = values.length;
  let sumW = 0;
  let sumWX = 0;
  let sumWY = 0;
  let sumWXX = 0;
  let sumWXY = 0;

  for (let i = 0; i < n; i++) {
    const w = i + 1; // Linear weight: recent months are weighted higher
    const x = i;
    const y = values[i];

    sumW += w;
    sumWX += w * x;
    sumWY += w * y;
    sumWXX += w * x * x;
    sumWXY += w * x * y;
  }

  const denominator = (sumW * sumWXX - sumWX * sumWX);
  if (denominator === 0) {
    return values[values.length - 1];
  }

  const m = (sumW * sumWXY - sumWX * sumWY) / denominator;
  const c = (sumWY - m * sumWX) / sumW;

  return m * n + c;
}

// Helper to get next month label
function getNextMonthLabel(lastLabel) {
  if (!lastLabel) return "Next Month";
  const shortMonths = ["Apr", "May", "June", "July", "Aug", "Sep", "Oct", "Nov", "Dec", "Jan", "Feb", "Mar"];
  const fullMonths = ["April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March"];
  
  const matchShort = lastLabel.match(/^([A-Za-z]+)(['\-\s]*\d*)$/);
  if (matchShort) {
    const monthStr = matchShort[1];
    const yearStr = matchShort[2];
    
    let idx = shortMonths.findIndex(m => monthStr.toLowerCase().startsWith(m.toLowerCase()));
    if (idx === -1) {
      idx = fullMonths.findIndex(m => monthStr.toLowerCase().startsWith(m.toLowerCase()));
    }
    
    if (idx !== -1) {
      const nextIdx = (idx + 1) % 12;
      let nextMonthName = shortMonths[nextIdx];
      if (fullMonths[idx].toLowerCase() === monthStr.toLowerCase()) {
        nextMonthName = fullMonths[nextIdx];
      } else if (monthStr.length > 3 && shortMonths[idx].length <= 3) {
        if (nextIdx === 4) nextMonthName = "August";
        else if (nextIdx === 5) nextMonthName = "September";
        else if (nextIdx === 6) nextMonthName = "October";
        else if (nextIdx === 7) nextMonthName = "November";
        else if (nextIdx === 8) nextMonthName = "December";
        else if (nextIdx === 9) nextMonthName = "January";
        else if (nextIdx === 10) nextMonthName = "February";
        else if (nextIdx === 11) nextMonthName = "March";
      }
      
      let updatedYearStr = yearStr;
      if (idx === 8 && yearStr) {
        const yearMatch = yearStr.match(/\d+/);
        if (yearMatch) {
          const yearVal = parseInt(yearMatch[0], 10);
          const nextYearVal = yearVal + 1;
          updatedYearStr = yearStr.replace(/\d+/, nextYearVal);
        }
      }
      return `${nextMonthName}${updatedYearStr}`;
    }
  }
  return "Next Month";
}

// Datalabels alignment helpers to prevent overlaps dynamically
function getDatalabelAlign(context) {
  const ds = context.dataset;
  if (!ds.isLine) return 'top';
  
  const idx = context.dataIndex;
  const val = ds.data[idx];
  if (val === null || val === undefined) return 'top';
  
  const chart = context.chart;
  const otherDs = chart.data.datasets.find(o => o.isLine && o !== ds);
  if (!otherDs) {
    return ds.isTarget ? 'top' : 'bottom';
  }
  
  const otherVal = otherDs.data[idx];
  if (otherVal === null || otherVal === undefined) {
    return ds.isTarget ? 'top' : 'bottom';
  }
  
  if (val !== otherVal) {
    return val > otherVal ? 'top' : 'bottom';
  }
  
  return ds.isTarget ? 'bottom' : 'top';
}

function getDatalabelAnchor(context) {
  const align = getDatalabelAlign(context);
  return align === 'top' ? 'end' : 'start';
}

function getDatalabelOffset(context) {
  const align = getDatalabelAlign(context);
  return align === 'top' ? 4 : 6;
}

// Chart instances
let trendChartInstance = null;
let incidentChartInstance = null;
let safetyPsi1Chart = null;
let safetyPsi2Chart = null;
let safetyFacChart = null;
let safetyLtaChart = null;
let safetyMtcChart = null;
let safetyRwcChart = null;
let hpev3ChartInstance = null;
let hpev4ChartInstance = null;
let cpevChartInstance = null;
let deliveryOtifChart = null;
let deliveryProdChart = null;
let deliveryProdL2Chart = null;
let deliveryProdL3Chart = null;
let costDmcChart = null;
let costReproChart = null;
let costVccChart = null;
let costOfeChart = null;
let envPowerChart = null;
let envFuelChart = null;
let envGhgChart = null;
let envWaterChart = null;
let hrIvdpChart = null;
let hrCsrChart = null;
let hrCsrEnvChart = null;
let hrCsrHealthChart = null;
let hrCsrEduChart = null;
let hrCsrEmpChart = null;

let qualityProductCharterChart = null;
let qualityCompIptvChart = null;
let qualityCompEpvChart = null;
let qualityCompVisitsChart = null;
let qualityCompNoTouchChart = null;
let qualityLaunchQualityChart = null;
let qualityLaunchUvpvChart = null;
let qualityLayerAuditChart = null;
let qualityCimpleProjectChart = null;

let invOpsDaysChart = null;
let invWoChart = null;
let invWithChart = null;
let invTmlChart = null;
let invTmbslChart = null;
let digBudgetChart = null;
let digQualixChart = null;

function destroyAllCharts() {
  if (safetyPsi1Chart) { safetyPsi1Chart.destroy(); safetyPsi1Chart = null; }
  if (safetyPsi2Chart) { safetyPsi2Chart.destroy(); safetyPsi2Chart = null; }
  if (safetyFacChart) { safetyFacChart.destroy(); safetyFacChart = null; }
  if (safetyLtaChart) { safetyLtaChart.destroy(); safetyLtaChart = null; }
  if (safetyMtcChart) { safetyMtcChart.destroy(); safetyMtcChart = null; }
  if (safetyRwcChart) { safetyRwcChart.destroy(); safetyRwcChart = null; }
  if (hpev3ChartInstance) { hpev3ChartInstance.destroy(); hpev3ChartInstance = null; }
  if (hpev4ChartInstance) { hpev4ChartInstance.destroy(); hpev4ChartInstance = null; }
  if (cpevChartInstance) { cpevChartInstance.destroy(); cpevChartInstance = null; }
  if (trendChartInstance) { trendChartInstance.destroy(); trendChartInstance = null; }
  if (incidentChartInstance) { incidentChartInstance.destroy(); incidentChartInstance = null; }
  if (deliveryOtifChart) { deliveryOtifChart.destroy(); deliveryOtifChart = null; }
  if (deliveryProdChart) { deliveryProdChart.destroy(); deliveryProdChart = null; }
  if (deliveryProdL2Chart) { deliveryProdL2Chart.destroy(); deliveryProdL2Chart = null; }
  if (deliveryProdL3Chart) { deliveryProdL3Chart.destroy(); deliveryProdL3Chart = null; }
  if (costDmcChart) { costDmcChart.destroy(); costDmcChart = null; }
  if (costReproChart) { costReproChart.destroy(); costReproChart = null; }
  if (costVccChart) { costVccChart.destroy(); costVccChart = null; }
  if (costOfeChart) { costOfeChart.destroy(); costOfeChart = null; }
  if (envPowerChart) { envPowerChart.destroy(); envPowerChart = null; }
  if (envFuelChart) { envFuelChart.destroy(); envFuelChart = null; }
  if (envGhgChart) { envGhgChart.destroy(); envGhgChart = null; }
  if (envWaterChart) { envWaterChart.destroy(); envWaterChart = null; }
  if (hrIvdpChart) { hrIvdpChart.destroy(); hrIvdpChart = null; }
  if (hrCsrChart) { hrCsrChart.destroy(); hrCsrChart = null; }
  if (hrCsrEnvChart) { hrCsrEnvChart.destroy(); hrCsrEnvChart = null; }
  if (hrCsrHealthChart) { hrCsrHealthChart.destroy(); hrCsrHealthChart = null; }
  if (hrCsrEduChart) { hrCsrEduChart.destroy(); hrCsrEduChart = null; }
  if (hrCsrEmpChart) { hrCsrEmpChart.destroy(); hrCsrEmpChart = null; }

  if (qualityProductCharterChart) { qualityProductCharterChart.destroy(); qualityProductCharterChart = null; }
  if (qualityCompIptvChart) { qualityCompIptvChart.destroy(); qualityCompIptvChart = null; }
  if (qualityCompEpvChart) { qualityCompEpvChart.destroy(); qualityCompEpvChart = null; }
  if (qualityCompVisitsChart) { qualityCompVisitsChart.destroy(); qualityCompVisitsChart = null; }
  if (qualityCompNoTouchChart) { qualityCompNoTouchChart.destroy(); qualityCompNoTouchChart = null; }
  if (qualityLaunchQualityChart) { qualityLaunchQualityChart.destroy(); qualityLaunchQualityChart = null; }
  if (qualityLaunchUvpvChart) { qualityLaunchUvpvChart.destroy(); qualityLaunchUvpvChart = null; }
  if (qualityLayerAuditChart) { qualityLayerAuditChart.destroy(); qualityLayerAuditChart = null; }
  if (qualityCimpleProjectChart) { qualityCimpleProjectChart.destroy(); qualityCimpleProjectChart = null; }

  if (invOpsDaysChart) { invOpsDaysChart.destroy(); invOpsDaysChart = null; }
  if (invWoChart) { invWoChart.destroy(); invWoChart = null; }
  if (invWithChart) { invWithChart.destroy(); invWithChart = null; }
  if (invTmlChart) { invTmlChart.destroy(); invTmlChart = null; }
  if (invTmbslChart) { invTmbslChart.destroy(); invTmbslChart = null; }
  if (digBudgetChart) { digBudgetChart.destroy(); digBudgetChart = null; }
  if (digQualixChart) { digQualixChart.destroy(); digQualixChart = null; }
}

// 3D Shadow plugin for hardware-accelerated 3D depth effect on charts
const threeDShadowPlugin = {
  id: 'threeDShadow',
  beforeDatasetDraw(chart, args) {
    const { ctx } = chart;
    const meta = chart.getDatasetMeta(args.index);
    ctx.save();
    if (meta.type === 'bar') {
      ctx.shadowColor = 'rgba(15, 23, 42, 0.22)';
      ctx.shadowBlur = 8;
      ctx.shadowOffsetY = 4;
      ctx.shadowOffsetX = 2;
    } else if (meta.type === 'line') {
      const ds = chart.data.datasets[args.index];
      if (ds && ds.isActual) {
        ctx.shadowColor = ds.borderColor || 'rgba(59, 130, 246, 0.4)';
        ctx.shadowBlur = 10;
        ctx.shadowOffsetY = 4;
      }
    }
  },
  afterDatasetDraw(chart) {
    chart.ctx.restore();
  }
};
Chart.register(threeDShadowPlugin);

// Custom plugin to show 3D callout datalabels on top of bars and line points
const datalabelsPlugin = {
  id: 'datalabels',
  afterDatasetsDraw(chart, args, options) {
    const { ctx } = chart;
    ctx.save();

    chart.data.datasets.forEach((dataset, datasetIndex) => {
      const meta = chart.getDatasetMeta(datasetIndex);
      if (meta.hidden) return;

      const isLine = dataset.type === 'line' || meta.type === 'line' || dataset.isLine;

      meta.data.forEach((element, index) => {
        const val = dataset.data[index];
        if (val === null || val === undefined) return;

        // Skip 0 values for bar charts to avoid clutter
        if (!isLine && val === 0) return;

        let labelStr = typeof val === 'number' ? (val % 1 === 0 ? Math.round(val) : parseFloat(val.toFixed(1))) : val;
        if (chart.scales.y && chart.scales.y.options.max === 100) {
          labelStr = `${labelStr}%`;
        }

        if (isLine) {
          const otherLineDs = chart.data.datasets.find(d => d !== dataset && (d.type === 'line' || d.isLine));
          let isHigher = true;
          if (otherLineDs) {
            const otherVal = otherLineDs.data[index];
            if (otherVal !== null && otherVal !== undefined) {
              if (val !== otherVal) {
                isHigher = val > otherVal;
              } else {
                isHigher = !dataset.isTarget;
              }
            } else {
              isHigher = dataset.isTarget;
            }
          } else {
            isHigher = dataset.isTarget;
          }

          const angle = isHigher ? -30 : 30;
          const theta = angle * Math.PI / 180;
          const cos = Math.cos(theta);
          const sin = Math.sin(theta);

          const rStart = (dataset.pointRadius || 5) + 2;
          const rEnd = 16;
          const rText = 20;

          const x1 = element.x + cos * rStart;
          const y1 = element.y + sin * rStart;
          const x2 = element.x + cos * rEnd;
          const y2 = element.y + sin * rEnd;

          // 3D Connector line shadow
          ctx.save();
          ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
          ctx.shadowBlur = 4;
          ctx.shadowOffsetY = 2;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.strokeStyle = dataset.borderColor || '#64748b';
          ctx.lineWidth = 1.5;
          ctx.stroke();
          ctx.restore();

          const isPrediction = (dataset.isActual && dataset.lastNonNullIdx !== undefined && dataset.lastNonNullIdx !== -1 && index === dataset.spacerCount + dataset.lastNonNullIdx + 1);
          // Display only the predicted numeric value without emoji or (P) suffix

          const labelX = element.x + cos * rText;
          const labelY = element.y + sin * rText;

          // Draw 3D callout pill background for predictions
          if (isPrediction) {
            ctx.save();
            ctx.font = 'bold 10px Outfit, Inter, sans-serif';
            const textWidth = ctx.measureText(labelStr).width;
            ctx.shadowColor = 'rgba(59, 130, 246, 0.4)';
            ctx.shadowBlur = 8;
            ctx.shadowOffsetY = 3;
            ctx.fillStyle = '#1e3a8a';
            ctx.beginPath();
            ctx.roundRect(labelX - 4, labelY - 8, textWidth + 8, 16, 8);
            ctx.fill();
            ctx.fillStyle = '#ffffff';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(labelStr, labelX, labelY);
            ctx.restore();
          } else {
            ctx.font = 'bold 10px Outfit, Inter, sans-serif';
            ctx.fillStyle = '#0f172a';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(labelStr, labelX, labelY);
          }
        } else {
          // Bar dataset - draw centered above bar with subtle 3D shadow
          ctx.font = 'bold 10px Outfit, Inter, sans-serif';
          ctx.fillStyle = '#1e2d5a';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
          ctx.fillText(labelStr, element.x, element.y - 6);
        }
      });
    });
    ctx.restore();
  }
};

export function renderCharts(historyData, activeModule) {
  const chartsGrid = document.getElementById('charts-grid-container');
  if (!chartsGrid) return;

  if (activeModule === 'safety') {
    chartsGrid.classList.remove('other-module');
    // 1. Build Safety Dashboard 4-Chart Grid HTML
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>PSI I Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="safety-psi1-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>PSI II Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="safety-psi2-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>FAC (First Aid Cases) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="safety-fac-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>LTI (Lost Time Injury) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="safety-lta-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>MTC (Medical Treatment Cases) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="safety-mtc-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>RWC (Restricted Work Cases) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="safety-rwc-canvas"></canvas>
        </div>
      </div>
    `;

    // Destroy other module instances
    destroyAllCharts();

    // Retrieve monthly safety data directly from state and sync dynamically with active KPI values
    const safetyLabels = (state.safetyMonthlyData.labels && state.safetyMonthlyData.labels.length > 0)
      ? state.safetyMonthlyData.labels
      : (state.safetyMonthlyData.facObj?.months || state.safetyMonthlyData.psi1Obj?.months || ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"]);
    const psi1Data = Array.isArray(state.safetyMonthlyData.psi1) ? [...state.safetyMonthlyData.psi1] : [];
    const psi2Data = Array.isArray(state.safetyMonthlyData.psi2) ? [...state.safetyMonthlyData.psi2] : [];
    const facData = Array.isArray(state.safetyMonthlyData.fac) ? [...state.safetyMonthlyData.fac] : [];
    const ltaData = Array.isArray(state.safetyMonthlyData.lta) ? [...state.safetyMonthlyData.lta] : [];
    const mtcData = Array.isArray(state.safetyMonthlyData.mtc) ? [...state.safetyMonthlyData.mtc] : [];
    const rwcData = Array.isArray(state.safetyMonthlyData.rwc) ? [...state.safetyMonthlyData.rwc] : [];

    const facKpi = state.kpis.find(k => k.id === 'fac');
    const ltaKpi = state.kpis.find(k => k.id === 'lti');
    const mtcKpi = state.kpis.find(k => k.id === 'mtc');
    const rwcKpi = state.kpis.find(k => k.id === 'rwc');
    const psi1Kpi = state.kpis.find(k => k.id === 'psi_1');
    const psi2Kpi = state.kpis.find(k => k.id === 'psi_2');

    const N = safetyLabels.length;

    // Note: Do not overwrite Safety trends with active state KPIs, as safety cards show cumulative YTD sums while trends show month-by-month counts.

    // Retrieve active targets dynamically from state
    const psi1TargetVal = psi1Kpi ? psi1Kpi.target : 95;
    const psi2TargetVal = psi2Kpi ? psi2Kpi.target : 100;

    // Create target lines matching history length
    const psi1TargetLine = Array(N).fill(psi1TargetVal);
    const psi2TargetLine = Array(N).fill(psi2TargetVal);

    const psi1Targets = state.safetyMonthlyData.psi1Targets && state.safetyMonthlyData.psi1Targets.length > 0 ? [...state.safetyMonthlyData.psi1Targets] : psi1TargetLine;
    const psi1ScTargets = state.safetyMonthlyData.psi1ScTargets && state.safetyMonthlyData.psi1ScTargets.length > 0 ? [...state.safetyMonthlyData.psi1ScTargets] : psi1Targets;

    const psi2Targets = state.safetyMonthlyData.psi2Targets && state.safetyMonthlyData.psi2Targets.length > 0 ? [...state.safetyMonthlyData.psi2Targets] : psi2TargetLine;
    const psi2ScTargets = state.safetyMonthlyData.psi2ScTargets && state.safetyMonthlyData.psi2ScTargets.length > 0 ? [...state.safetyMonthlyData.psi2ScTargets] : psi2Targets;

    // Initializing Safety specific line charts (only monthly data)
    setTimeout(() => {
      // PSI I Line Graph
      const ctxPsi1 = document.getElementById('safety-psi1-canvas');
      if (ctxPsi1) {
        if (safetyPsi1Chart) safetyPsi1Chart.destroy();
        safetyPsi1Chart = renderComboTrendChart('safety-psi1-canvas', safetyLabels, [
          {
            label: 'PSI I',
            targets: psi1Targets,
            scTargets: psi1ScTargets,
            actuals: psi1Data,
            fyData: state.safetyMonthlyData.fyData?.psi1,
            color: '#3b82f6'
          }
        ], {
          y: { min: 0, max: 110, ticks: { callback: v => `${v}%` } }
        });
      }

      // PSI II Line Graph
      const ctxPsi2 = document.getElementById('safety-psi2-canvas');
      if (ctxPsi2) {
        if (safetyPsi2Chart) safetyPsi2Chart.destroy();
        safetyPsi2Chart = renderComboTrendChart('safety-psi2-canvas', safetyLabels, [
          {
            label: 'PSI II',
            targets: psi2Targets,
            scTargets: psi2ScTargets,
            actuals: psi2Data,
            fyData: state.safetyMonthlyData.fyData?.psi2,
            color: '#10b981'
          }
        ], {
          y: { min: 0, max: 110, ticks: { callback: v => `${v}%` } }
        });
      }

      // FAC Line Graph
      const ctxFac = document.getElementById('safety-fac-canvas');
      if (ctxFac) {
        if (safetyFacChart) safetyFacChart.destroy();
        safetyFacChart = renderComboTrendChart('safety-fac-canvas', safetyLabels, [
          {
            label: 'FAC',
            actuals: facData,
            fyData: state.safetyMonthlyData.fyData?.fac,
            color: '#f59e0b'
          }
        ]);
      }

      // LTA Line Graph
      const ctxLta = document.getElementById('safety-lta-canvas');
      if (ctxLta) {
        if (safetyLtaChart) safetyLtaChart.destroy();
        safetyLtaChart = renderComboTrendChart('safety-lta-canvas', safetyLabels, [
          {
            label: 'LTA',
            actuals: ltaData,
            fyData: state.safetyMonthlyData.fyData?.lta,
            color: '#ef4444'
          }
        ]);
      }

      // MTC Line Graph
      const ctxMtc = document.getElementById('safety-mtc-canvas');
      if (ctxMtc) {
        if (safetyMtcChart) safetyMtcChart.destroy();
        safetyMtcChart = renderComboTrendChart('safety-mtc-canvas', safetyLabels, [
          {
            label: 'MTC',
            actuals: mtcData,
            fyData: state.safetyMonthlyData.fyData?.mtc,
            color: '#8b5cf6'
          }
        ]);
      }

      // RWC Line Graph
      const ctxRwc = document.getElementById('safety-rwc-canvas');
      if (ctxRwc) {
        if (safetyRwcChart) safetyRwcChart.destroy();
        safetyRwcChart = renderComboTrendChart('safety-rwc-canvas', safetyLabels, [
          {
            label: 'RWC',
            actuals: rwcData,
            fyData: state.safetyMonthlyData.fyData?.rwc,
            color: '#06b6d4'
          }
        ]);
      }
    }, 0);

  } else if (activeModule === 'productivity') {
    chartsGrid.classList.remove('other-module');
    // Render HPeV(L3), HPeV(L4) and CPeV in the Monthly Analytics & Trends container
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>HPeV (L3) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="prod-hpev3-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>HPeV (L4) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="prod-hpev4-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>CPeV Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="prod-cpev-canvas"></canvas>
        </div>
      </div>
    `;

    // Clean up safety/trend chart instances
    destroyAllCharts();

    setTimeout(() => {
      renderProductivityTrendCharts();
    }, 0);

  } else if (activeModule === 'delivery') {
    chartsGrid.classList.remove('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>OTIF Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="delivery-otif-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Production Total Monthly Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="delivery-prod-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Production - Line 2 Monthly Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="delivery-prod-l2-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Production - Line 3 Monthly Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="delivery-prod-l3-canvas"></canvas>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderDeliveryTrendCharts();
    }, 0);
  } else if (activeModule === 'cost') {
    chartsGrid.classList.remove('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Direct Material Cost (DMC) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="cost-dmc-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Repro Cost Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="cost-repro-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Variable Cost/Vehicle (VCC) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="cost-vcc-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>OFE Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="cost-ofe-canvas"></canvas>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderCostTrendCharts();
    }, 0);
  } else if (activeModule === 'hr') {
    chartsGrid.classList.remove('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>IVDP Lives Touched Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="hr-ivdp-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>CSR Lives Touched Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="hr-csr-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card" style="grid-column: span 2;">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>CSR Projects Monthly Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container" style="height: auto; min-height: 520px; display: grid; grid-template-columns: repeat(2, 1fr); gap: 0; padding: 24px;">
          <div style="height: 220px; position: relative; padding-right: 24px; padding-bottom: 24px; border-right: 1px solid #000205; border-bottom: 1px solid #000205;">
            <div style="font-size: 18px; font-weight: bold; color: var(--text-dark); margin-bottom: 6px; display: flex; justify-content: space-between;">
              <span>Environment (No. of Lives Touched)</span>
              <span style="color: #10b981; font-weight: bold;">Environment</span>
            </div>
            <canvas id="hr-csr-env-canvas"></canvas>
          </div>
          <div style="height: 220px; position: relative; padding-left: 24px; padding-bottom: 24px; border-bottom: 1px solid #000205;">
            <div style="font-size: 18px; font-weight: bold; color: var(--text-dark); margin-bottom: 6px; display: flex; justify-content: space-between;">
              <span>Health (No. of Lives Touched)</span>
              <span style="color: #f59e0b; font-weight: bold;">Health</span>
            </div>
            <canvas id="hr-csr-health-canvas"></canvas>
          </div>
          <div style="height: 220px; position: relative; padding-top: 24px; padding-right: 24px; border-right: 1px solid #000205;">
            <div style="font-size: 18px; font-weight: bold; color: var(--text-dark); margin-bottom: 6px; display: flex; justify-content: space-between;">
              <span>Education (No. of Lives Touched)</span>
              <span style="color: #3b82f6; font-weight: bold;">Education</span>
            </div>
            <canvas id="hr-csr-edu-canvas"></canvas>
          </div>
          <div style="height: 220px; position: relative; padding-top: 24px; padding-left: 24px;">
            <div style="font-size: 18px; font-weight: bold; color: var(--text-dark); margin-bottom: 6px; display: flex; justify-content: space-between;">
              <span>Employability (No. of Lives Touched)</span>
              <span style="color: #8b5cf6; font-weight: bold;">Employability</span>
            </div>
            <canvas id="hr-csr-emp-canvas"></canvas>
          </div>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderHrTrendCharts();
    }, 0);
  } else if (activeModule === 'quality') {
    chartsGrid.classList.remove('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>VC Charter (C2) Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-product-charter-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Delta Composite IPTV (Index) Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-comp-iptv-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>EPV (Expense per vehicle) Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-comp-epv-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Unscheduled visits per vehicle Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-comp-visits-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>No Touch DRR Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-comp-notouch-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Launch Quality Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-launch-quality-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Launch UVPV Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-launch-uvpv-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Layer Audit Compliance (%) Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-layer-audit-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Cimple Project Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="quality-cimple-project-canvas"></canvas>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderQualityTrendCharts();
    }, 0);
  } else if (activeModule === 'environment') {
    chartsGrid.classList.remove('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Power Consumption (KWh/EU) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="environment-power-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Fuel Consumption (Unit/EU) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="environment-fuel-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>GHG Emissions (kG CO2e/EU) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="environment-ghg-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Water Positive (Ratio) Monthly Trend (Target vs Actual)</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="environment-water-canvas"></canvas>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderEnvironmentTrendCharts();
    }, 0);
  } else if (activeModule === 'inventory') {
    chartsGrid.classList.remove('other-module');
    let innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Operations Inventory (Days) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="inventory-opsdays-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Inventory W/o IFLT (Rs Cr) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="inventory-wo-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Inventory With IFLT (Rs Cr) Monthly Trend</span>
          <span class="direction-badge lower-better">↓ Lower Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="inventory-with-canvas"></canvas>
        </div>
      </div>
    `;
    if (state.hasTml) {
      innerHTML += `
        <div class="card chart-card">
          <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <span>TML (Rs Cr) Monthly Trend</span>
            <span class="direction-badge lower-better">↓ Lower Better</span>
          </div>
          <div class="card-body chart-body-container">
            <canvas id="inventory-tml-canvas"></canvas>
          </div>
        </div>
        <div class="card chart-card">
          <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
            <span>TMBSL (Rs Cr) Monthly Trend</span>
            <span class="direction-badge lower-better">↓ Lower Better</span>
          </div>
          <div class="card-body chart-body-container">
            <canvas id="inventory-tmbsl-canvas"></canvas>
          </div>
        </div>
      `;
    }
    chartsGrid.innerHTML = innerHTML;
    destroyAllCharts();
    setTimeout(() => {
      renderInventoryTrendCharts();
    }, 0);
  } else if (activeModule === 'digital') {
    chartsGrid.classList.remove('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Industry 4.0 Budget RFQ (%) Monthly Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="digital-budget-canvas"></canvas>
        </div>
      </div>
      <div class="card chart-card">
        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
          <span>Qualix IQMS Deployment (Lines) Monthly Trend</span>
          <span class="direction-badge higher-better">↑ Higher Better</span>
        </div>
        <div class="card-body chart-body-container">
          <canvas id="digital-qualix-canvas"></canvas>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderDigitalTrendCharts();
    }, 0);
  } else {
    chartsGrid.classList.add('other-module');
    chartsGrid.innerHTML = `
      <div class="card chart-card" id="trend-chart-card">
        <div class="card-header" id="trend-chart-header">Trend Chart</div>
        <div class="card-body chart-body-container">
          <canvas id="trend-chart-canvas"></canvas>
        </div>
      </div>
    `;
    destroyAllCharts();
    setTimeout(() => {
      renderStandardTrendChart(historyData, activeModule);
    }, 0);
  }
}

// Line Chart options helper
function getLineChartOptions(maxVal = null, showLegend = false) {
  const scalesY = {
    grid: { color: 'rgba(243, 244, 246, 0.8)' },
    ticks: {
      font: { family: 'Outfit, Inter, sans-serif' },
      color: '#4b5563'
    }
  };
  if (maxVal !== null) {
    scalesY.min = 0;
    scalesY.max = maxVal;
    scalesY.ticks.callback = v => `${v}%`;
  }

  return {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { 
        display: showLegend,
        position: 'bottom',
        align: 'start',
        labels: {
          boxWidth: 10,
          padding: 10,
          color: '#000000',
          font: { family: 'Outfit, Inter, sans-serif', size: 11.5, weight: 'bold' }
        }
      },
      tooltip: {
        backgroundColor: '#111827',
        titleFont: { family: 'Outfit, Inter, sans-serif' },
        bodyFont: { family: 'Outfit, Inter, sans-serif' }
      }
    },
    scales: {
      y: scalesY,
      x: {
        grid: { display: false },
        ticks: {
          font: { family: 'Outfit, Inter, sans-serif' },
          color: '#4b5563'
        }
      }
    }
  };
}

// Helper to render combination bar-and-line trend charts
export function renderComboTrendChart(canvasId, months, datasets, chartOptionsExtra = {}) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return null;

  const hideHistory = chartOptionsExtra.hideHistory || false;

  // Historical FY columns are unconditionally shown for consistent dashboard layout
  const activeFys = hideHistory ? [] : ["FY24", "FY25", "FY26"];

  // 1. Scan all input datasets to find the maximum index containing actual data (excluding null/undefined)
  let globalLastNonNullIdx = -1;
  let globalMaxLen = 0;
  datasets.forEach(d => {
    if (d.actuals && d.actuals.length > globalMaxLen) globalMaxLen = d.actuals.length;
    if (d.actuals) {
      for (let i = 0; i < d.actuals.length; i++) {
        if (d.actuals[i] !== null && d.actuals[i] !== undefined) {
          if (i > globalLastNonNullIdx) globalLastNonNullIdx = i;
        }
      }
    }
  });

  // If the last non-null actual is the very last element of the months list, we must extend months by one!
  let extendedMonths = [...months];
  let needsExtension = (globalLastNonNullIdx !== -1 && globalLastNonNullIdx === globalMaxLen - 1 && months.length < 12);
  if (needsExtension && months.length > 0) {
    const nextLabel = getNextMonthLabel(months[months.length - 1]);
    extendedMonths.push(nextLabel);
  }

  const historyLabels = [...activeFys];
  const historySpacer = hideHistory ? [] : [""];
  const targetLabels = hideHistory ? [] : ["TC target", "SC target"];
  const spacer1 = hideHistory ? [] : [""];
  const monthlyLabels = [...extendedMonths];
  const spacer2 = [""];
  const ytdLabel = ["YTD"];

  const combinedLabels = [...historyLabels, ...historySpacer, ...targetLabels, ...spacer1, ...monthlyLabels, ...spacer2, ...ytdLabel];

  const spacerCount = historyLabels.length + historySpacer.length + targetLabels.length + spacer1.length; // history + historySpacer + TC/SC targets + spacer1 = 7

  const chartDatasets = [];

  datasets.forEach(d => {
    let alignedBarActualData, alignedBarTargetData, alignedBarScTargetData, alignedTargetData, alignedScTargetData, alignedActualData;
    
    // Find YTD target and actual values
    let ytdTarget = (d.fyData && d.fyData.ytdTarget !== undefined && d.fyData.ytdTarget !== 0) ? d.fyData.ytdTarget : 0;
    if (ytdTarget === 0 && d.targets && d.targets.length > 0) {
      for (let i = d.targets.length - 1; i >= 0; i--) {
        if (d.targets[i] !== null && d.targets[i] !== undefined) {
          ytdTarget = d.targets[i];
          break;
        }
      }
    }
    
    let ytdScTarget = (d.fyData && d.fyData.ytdSc !== undefined && d.fyData.ytdSc !== 0) ? d.fyData.ytdSc : ytdTarget;
    if (ytdScTarget === ytdTarget && d.scTargets && d.scTargets.length > 0) {
      for (let i = d.scTargets.length - 1; i >= 0; i--) {
        if (d.scTargets[i] !== null && d.scTargets[i] !== undefined) {
          ytdScTarget = d.scTargets[i];
          break;
        }
      }
    }
    
    const ytdActual = d.fyData?.ytd !== undefined ? d.fyData.ytd : (d.actuals[d.actuals.length - 1] || 0);

    const actualTargets = d.targets ? (needsExtension ? [...d.targets, null] : d.targets) : null;
    const actualScTargets = d.scTargets ? (needsExtension ? [...d.scTargets, null] : d.scTargets) : (d.targets ? (needsExtension ? [...d.targets, null] : d.targets) : null);
    const actualActuals = needsExtension ? [...d.actuals, null] : d.actuals;

    const historyActuals = [];
    if (!hideHistory) {
      activeFys.forEach(fy => {
        if (fy === "FY24") historyActuals.push(d.fyData?.fy24 || 0);
        if (fy === "FY25") historyActuals.push(d.fyData?.fy25 || 0);
        if (fy === "FY26") historyActuals.push(d.fyData?.fy26 || 0);
      });
    }

    if (hideHistory) {
      alignedBarActualData = [
        ...extendedMonths.map(() => null),
        null,
        ytdActual
      ];

      alignedBarTargetData = [
        ...extendedMonths.map(() => null),
        null,
        ytdTarget
      ];

      alignedBarScTargetData = [
        ...extendedMonths.map(() => null),
        null,
        null
      ];
    } else {
      alignedBarActualData = [
        ...historyActuals, // e.g. indices 0, 1, 2
        null,              // index 3 (historySpacer)
        null,              // index 4 (TC Target)
        null,              // index 5 (SC Target)
        null,              // index 6 (spacer 1)
        ...extendedMonths.map(() => null), // indices 7 to (7 + extendedMonths.length - 1)
        null,              // index (7 + extendedMonths.length)
        ytdActual          // index (7 + extendedMonths.length + 1)
      ];

      alignedBarTargetData = [
        ...historyActuals.map(() => null), // indices 0, 1, 2
        null,              // index 3 (historySpacer)
        ytdTarget,         // index 4 (TC Target)
        null,              // index 5 (SC Target)
        null,              // index 6 (spacer 1)
        ...extendedMonths.map(() => null),
        null,
        ytdTarget          // index (7 + extendedMonths.length + 1)
      ];

      alignedBarScTargetData = [
        ...historyActuals.map(() => null), // indices 0, 1, 2
        null,              // index 3 (historySpacer)
        null,              // index 4 (TC Target)
        ytdScTarget,       // index 5 (SC Target)
        null,              // index 6 (spacer 1)
        ...extendedMonths.map(() => null),
        null,
        null               // index (7 + extendedMonths.length + 1)
      ];
    }

    alignedTargetData = actualTargets ? [...Array(spacerCount).fill(null), ...actualTargets, null, null] : null;
    alignedScTargetData = actualScTargets ? [...Array(spacerCount).fill(null), ...actualScTargets, null, null] : null;
    alignedActualData = [...Array(spacerCount).fill(null), ...actualActuals, null, null];

    // Add TC target bar dataset with 3D rounded corners
    chartDatasets.push({
      type: 'bar',
      label: datasets.length > 1 ? `${d.label} TC Target (Annual/YTD)` : 'TC Target Annual / YTD',
      data: alignedBarTargetData,
      backgroundColor: '#cbd5e1',
      borderColor: '#94a3b8',
      borderWidth: 1.5,
      borderRadius: { topLeft: 6, topRight: 6 },
      barThickness: datasets.length > 1 ? undefined : 18,
      maxBarThickness: 26,
      barPercentage: 0.9,
      categoryPercentage: 0.9,
      order: 2,
      datalabels: {
        anchor: 'end',
        align: 'top',
        offset: 2,
        font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
        formatter: (val) => (val === null || val === undefined || val === 0) ? '' : parseFloat(val.toFixed(1))
      }
    });

    // Add SC target bar dataset with 3D rounded corners
    chartDatasets.push({
      type: 'bar',
      label: datasets.length > 1 ? `${d.label} SC Target` : 'SC Target',
      data: alignedBarScTargetData,
      backgroundColor: '#94a3b8',
      borderColor: '#64748b',
      borderWidth: 1.5,
      borderRadius: { topLeft: 6, topRight: 6 },
      barThickness: datasets.length > 1 ? undefined : 18,
      maxBarThickness: 26,
      barPercentage: 0.9,
      categoryPercentage: 0.9,
      order: 2,
      datalabels: {
        anchor: 'end',
        align: 'top',
        offset: 2,
        font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
        formatter: (val) => (val === null || val === undefined || val === 0) ? '' : parseFloat(val.toFixed(1))
      }
    });

    // Add actual bar dataset with 3D gradient fill & rounded top corners
    chartDatasets.push({
      type: 'bar',
      label: datasets.length > 1 ? `${d.label} Actual (Annual/YTD)` : 'Actual Annual / YTD',
      data: alignedBarActualData,
      backgroundColor: (context) => {
        const chart = context.chart;
        const { ctx, chartArea } = chart;
        if (!chartArea) return `${d.color}dd`;
        const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
        gradient.addColorStop(0, `${d.color}ff`);
        gradient.addColorStop(0.7, `${d.color}cc`);
        gradient.addColorStop(1, `${d.color}88`);
        return gradient;
      },
      borderColor: d.color,
      borderWidth: 1.5,
      borderRadius: { topLeft: 6, topRight: 6 },
      barThickness: datasets.length > 1 ? undefined : 18,
      maxBarThickness: 26,
      barPercentage: 0.9,
      categoryPercentage: 0.9,
      order: 2,
      datalabels: {
        anchor: 'end',
        align: 'top',
        offset: 2,
        font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
        formatter: (val) => (val === null || val === undefined || val === 0) ? '' : parseFloat(val.toFixed(1))
      }
    });

    // Add TC target line dataset (if targets exist)
    if (alignedTargetData) {
      chartDatasets.push({
        type: 'line',
        label: datasets.length > 1 ? `${d.label} TC Target` : 'TC Target Plan',
        data: alignedTargetData,
        borderColor: '#94a3b8',
        borderDash: [5, 5],
        borderWidth: 2,
        fill: false,
        tension: 0.35,
        pointRadius: 4,
        pointBackgroundColor: '#ffffff',
        pointBorderColor: '#94a3b8',
        pointBorderWidth: 2,
        order: 1,
        isLine: true,
        isTarget: true
      });
    }

    // Calculate prediction for the next month based on actuals
    let lastNonNullIdx = -1;
    for (let i = 0; i < d.actuals.length; i++) {
      if (d.actuals[i] !== null && d.actuals[i] !== undefined) {
        lastNonNullIdx = i;
      }
    }

    let predictedValue = null;
    if (lastNonNullIdx !== -1 && (lastNonNullIdx < d.actuals.length - 1 || needsExtension)) {
      const historicalValues = d.actuals.slice(0, lastNonNullIdx + 1).map(val => val === null ? 0 : val);
      predictedValue = predictNextValue(historicalValues);
      
      const maxHist = Math.max(...historicalValues);
      if (maxHist <= 100) {
        predictedValue = Math.min(100, Math.max(0, predictedValue));
      } else {
        predictedValue = Math.max(0, predictedValue);
      }
    }

    if (predictedValue !== null && lastNonNullIdx !== -1) {
      alignedActualData[spacerCount + lastNonNullIdx + 1] = predictedValue;
    }

    // Add 3D floating actual line dataset with volumetric area gradient & orb nodes
    chartDatasets.push({
      type: 'line',
      label: datasets.length > 1 ? `${d.label} Monthly` : d.label,
      data: alignedActualData,
      borderColor: d.color,
      borderWidth: 3.5,
      backgroundColor: (context) => {
        const chart = context.chart;
        const { ctx, chartArea } = chart;
        if (!chartArea) return `${d.color}1a`;
        const gradient = ctx.createLinearGradient(0, chartArea.top, 0, chartArea.bottom);
        gradient.addColorStop(0, `${d.color}44`);
        gradient.addColorStop(0.5, `${d.color}1a`);
        gradient.addColorStop(1, `${d.color}00`);
        return gradient;
      },
      fill: true,
      tension: 0.35,
      pointRadius: 6,
      pointHoverRadius: 9,
      pointBackgroundColor: '#ffffff',
      pointBorderColor: d.color,
      pointBorderWidth: 3.5,
      order: 0,
      segment: {
        borderDash: (ctx) => {
          if (lastNonNullIdx !== -1 && ctx.p1DataIndex === spacerCount + lastNonNullIdx + 1) {
            return [5, 5];
          }
          return undefined;
        }
      },
      isLine: true,
      isActual: true,
      lastNonNullIdx: lastNonNullIdx,
      spacerCount: spacerCount
    });
  });

  // Add Predicted legend indicator dataset
  chartDatasets.push({
    type: 'line',
    label: 'Predicted',
    data: [],
    borderColor: '#64748b',
    borderWidth: 2,
    borderDash: [4, 4],
    pointRadius: 4,
    pointBackgroundColor: '#64748b',
    pointBorderColor: '#64748b',
    order: 0
  });

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'bottom',
        align: 'start',
        labels: {
          boxWidth: 10,
          padding: 10,
          color: '#000000',
          font: { family: 'Outfit, Inter, sans-serif', size: 11.5, weight: 'bold' },
          filter: (item) => {
            if (item.text.includes('(Predicted)')) return false;
            if (datasets.length > 1) {
              return item.text.includes('Monthly') || item.text.includes('Actual') || item.text === 'Predicted';
            }
            return true;
          }
        }
      },
      datalabels: {
        display: (context) => {
          const val = context.dataset.data[context.dataIndex];
          return val !== null && val !== undefined;
        },
        anchor: getDatalabelAnchor,
        align: getDatalabelAlign,
        offset: getDatalabelOffset,
        font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' },
        color: '#000000',
        formatter: (val, context) => {
          if (val === null || val === undefined) return '';
          if (val === 0 && context.dataset.type === 'bar') return '';
          const ds = context.dataset;
          const formattedVal = val % 1 === 0 ? Math.round(val) : parseFloat(val.toFixed(1));
          if (ds.isLine && ds.isActual) {
            if (ds.lastNonNullIdx !== undefined && ds.lastNonNullIdx !== -1 && context.dataIndex === ds.spacerCount + ds.lastNonNullIdx + 1) {
              return formattedVal;
            }
          }
          return formattedVal;
        }
      }
    },
    scales: {
      y: {
        ...chartOptionsExtra.y,
        ticks: {
          color: '#000000',
          font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' },
          ...(chartOptionsExtra.y ? chartOptionsExtra.y.ticks : {})
        },
        grid: { color: '#f1f5f9', ...(chartOptionsExtra.y ? chartOptionsExtra.y.grid : {}) }
      },
      x: {
        ...chartOptionsExtra.x,
        ticks: {
          color: '#000000',
          font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' },
          ...(chartOptionsExtra.x ? chartOptionsExtra.x.ticks : {})
        },
        grid: { display: false, ...(chartOptionsExtra.x ? chartOptionsExtra.x.grid : {}) }
      }
    }
  };

  return new Chart(ctx, {
    type: 'bar',
    data: {
      labels: combinedLabels,
      datasets: chartDatasets
    },
    options: options,
    plugins: [datalabelsPlugin]
  });
}

// Standard Trend Chart renderer
function renderStandardTrendChart(historyData, activeModule) {
  const ctx = document.getElementById('trend-chart-canvas');
  if (!ctx) return;

  const capitalizedModule = activeModule.charAt(0).toUpperCase() + activeModule.slice(1);
  const header = document.getElementById('trend-chart-header');
  if (header) {
    header.textContent = `${capitalizedModule} Score Monthly Trend`;
  }

  const labels = historyData.map(d => d.month);
  const data = historyData.map(d => d.overallScore);
  const targets = Array(labels.length).fill(100);

  if (trendChartInstance) trendChartInstance.destroy();
  trendChartInstance = renderComboTrendChart('trend-chart-canvas', labels, [
    {
      label: `Overall ${capitalizedModule} Score (%)`,
      targets: targets,
      actuals: data,
      color: '#1e2d5a'
    }
  ], {
    y: {
      min: 0,
      max: 100,
      ticks: { callback: v => `${v}%` }
    }
  });
}

// Renders HPeV(L3), HPeV(L4), and CPeV monthly line charts in charts section
function renderProductivityTrendCharts() {
  const pData = state.productivityMonthlyData;
  const labels = pData.labels;

  // 1. HPeV L3 Chart
  const ctxH3 = document.getElementById('prod-hpev3-canvas');
  if (ctxH3 && pData.hpev3) {
    if (hpev3ChartInstance) hpev3ChartInstance.destroy();
    hpev3ChartInstance = renderComboTrendChart('prod-hpev3-canvas', pData.hpev3.months || labels, [
      {
        label: 'HPeV (L3)',
        targets: pData.hpev3.targets,
        scTargets: pData.hpev3.scTargets,
        actuals: pData.hpev3.actuals,
        fyData: pData.hpev3.fyData,
        color: '#2563eb'
      }
    ]);
  }

  // 2. HPeV L4 Chart
  const ctxH4 = document.getElementById('prod-hpev4-canvas');
  if (ctxH4 && pData.hpev4) {
    if (hpev4ChartInstance) hpev4ChartInstance.destroy();
    hpev4ChartInstance = renderComboTrendChart('prod-hpev4-canvas', pData.hpev4.months || labels, [
      {
        label: 'HPeV (L4)',
        targets: pData.hpev4.targets,
        scTargets: pData.hpev4.scTargets,
        actuals: pData.hpev4.actuals,
        fyData: pData.hpev4.fyData,
        color: '#10b981'
      }
    ]);
  }

  // 3. CPeV Chart
  const ctxCpev = document.getElementById('prod-cpev-canvas');
  if (ctxCpev && pData.cpev) {
    if (cpevChartInstance) cpevChartInstance.destroy();
    cpevChartInstance = renderComboTrendChart('prod-cpev-canvas', pData.cpev.months || labels, [
      {
        label: 'CPeV',
        targets: pData.cpev.targets,
        scTargets: pData.cpev.scTargets,
        actuals: pData.cpev.actuals,
        fyData: pData.cpev.fyData,
        color: '#f59e0b'
      }
    ]);
  }
}

// Renders Delivery OTIF & Production trend lines
function renderDeliveryTrendCharts() {
  const delData = state.deliveryMonthlyData;
  const labels = delData.labels;

  const l2Targets = delData.line2.targets;
  const l2Actuals = delData.line2.actuals;
  const l3Targets = delData.line3.targets;
  const l3Actuals = delData.line3.actuals;
  const monthsList = delData.line2.months || labels;

  let activeIdx = l2Actuals.length - 1;
  for (let idx = l2Actuals.length - 1; idx >= 0; idx--) {
    const val = l2Actuals[idx];
    if (val !== undefined && val !== null && val !== 0 && !isNaN(val)) {
      activeIdx = idx;
      break;
    }
  }

  const l2MonthTarget = l2Targets[activeIdx] || 0;
  const l2MonthActual = l2Actuals[activeIdx] || 0;
  const l3MonthTarget = l3Targets[activeIdx] || 0;
  const l3MonthActual = l3Actuals[activeIdx] || 0;
  const totMonthTarget = l2MonthTarget + l3MonthTarget;
  const totMonthActual = l2MonthActual + l3MonthActual;

  let l2YtdTarget = 0, l2YtdActual = 0;
  let l3YtdTarget = 0, l3YtdActual = 0;
  for (let idx = 0; idx <= activeIdx; idx++) {
    l2YtdTarget += l2Targets[idx] || 0;
    l2YtdActual += l2Actuals[idx] || 0;
    l3YtdTarget += l3Targets[idx] || 0;
    l3YtdActual += l3Actuals[idx] || 0;
  }
  const totYtdTarget = l2YtdTarget + l3YtdTarget;
  const totYtdActual = l2YtdActual + l3YtdActual;

  const ctxOtif = document.getElementById('delivery-otif-canvas');
  if (ctxOtif) {
    if (deliveryOtifChart) deliveryOtifChart.destroy();
    deliveryOtifChart = renderComboTrendChart('delivery-otif-canvas', delData.otif.months || labels, [
      {
        label: 'OTIF (%)',
        targets: delData.otif.targets,
        actuals: delData.otif.actuals,
        fyData: delData.otif.fyData,
        color: '#2563eb'
      }
    ], {
      y: { min: 0, max: 110, ticks: { callback: v => `${v}%` } }
    });
  }

  const ctxProd = document.getElementById('delivery-prod-canvas');
  if (ctxProd) {
    if (deliveryProdChart) deliveryProdChart.destroy();

    // We represent Month and YTD values side-by-side for Total
    const barLabels = ["Total MTD", "", "Total YTD"];
    const spacerCount = barLabels.length + 1; // 4

    let globalMaxLen = 0;
    let globalLastNonNullIdx = -1;
    [l2Actuals, l3Actuals].forEach(arr => {
      if (arr.length > globalMaxLen) globalMaxLen = arr.length;
      for (let i = 0; i < arr.length; i++) {
        if (arr[i] !== null && arr[i] !== undefined && arr[i] !== 0) {
          if (i > globalLastNonNullIdx) globalLastNonNullIdx = i;
        }
      }
    });

    let extendedMonths = [...monthsList];
    let needsExtension = (globalLastNonNullIdx !== -1 && globalLastNonNullIdx === globalMaxLen - 1 && monthsList.length < 12);
    if (needsExtension && monthsList.length > 0) {
      const nextLabel = getNextMonthLabel(monthsList[monthsList.length - 1]);
      extendedMonths.push(nextLabel);
    }

    const combinedLabels = [...barLabels, "", ...extendedMonths];

    const barTargetData = [
      totMonthTarget,
      null, // spacer
      totYtdTarget,
      null, // spacer
      ...extendedMonths.map(() => null)
    ];

    const barActualData = [
      totMonthActual,
      null, // spacer
      totYtdActual,
      null, // spacer
      ...extendedMonths.map(() => null)
    ];

    const barTargetColors = [
      '#bfdbfe', // Total MTD target (light blue)
      '#ffffff', // spacer
      '#bfdbfe', // Total YTD target (light blue)
      '#ffffff'  // spacer
    ];

    const barActualColors = [
      '#3b82f6', // Total MTD actual
      '#ffffff', // spacer
      '#3b82f6', // Total YTD actual
      '#ffffff'  // spacer
    ];

    const actualL2Targets = needsExtension ? [...l2Targets, null] : l2Targets;
    const actualL2Actuals = needsExtension ? [...l2Actuals, null] : l2Actuals;
    const actualL3Targets = needsExtension ? [...l3Targets, null] : l3Targets;
    const actualL3Actuals = needsExtension ? [...l3Actuals, null] : l3Actuals;

    const line2TargetData = [...Array(spacerCount).fill(null), ...actualL2Targets];
    const line2ActualData = [...Array(spacerCount).fill(null), ...actualL2Actuals];
    const line3TargetData = [...Array(spacerCount).fill(null), ...actualL3Targets];
    const line3ActualData = [...Array(spacerCount).fill(null), ...actualL3Actuals];

    let l2LastNonNullIdx = -1;
    for (let i = 0; i < l2Actuals.length; i++) {
      if (l2Actuals[i] !== null && l2Actuals[i] !== undefined && l2Actuals[i] !== 0) {
        l2LastNonNullIdx = i;
      }
    }
    let l2PredictedValue = null;
    if (l2LastNonNullIdx !== -1 && (l2LastNonNullIdx < l2Actuals.length - 1 || needsExtension)) {
      const historicalValues = l2Actuals.slice(0, l2LastNonNullIdx + 1).map(val => val === null ? 0 : val);
      l2PredictedValue = predictNextValue(historicalValues);
      l2PredictedValue = Math.max(0, l2PredictedValue);
    }
    if (l2PredictedValue !== null && l2LastNonNullIdx !== -1) {
      line2ActualData[spacerCount + l2LastNonNullIdx + 1] = l2PredictedValue;
    }

    let l3LastNonNullIdx = -1;
    for (let i = 0; i < l3Actuals.length; i++) {
      if (l3Actuals[i] !== null && l3Actuals[i] !== undefined && l3Actuals[i] !== 0) {
        l3LastNonNullIdx = i;
      }
    }
    let l3PredictedValue = null;
    if (l3LastNonNullIdx !== -1 && (l3LastNonNullIdx < l3Actuals.length - 1 || needsExtension)) {
      const historicalValues = l3Actuals.slice(0, l3LastNonNullIdx + 1).map(val => val === null ? 0 : val);
      l3PredictedValue = predictNextValue(historicalValues);
      l3PredictedValue = Math.max(0, l3PredictedValue);
    }
    if (l3PredictedValue !== null && l3LastNonNullIdx !== -1) {
      line3ActualData[spacerCount + l3LastNonNullIdx + 1] = l3PredictedValue;
    }

    deliveryProdChart = new Chart(ctxProd, {
      type: 'bar',
      data: {
        labels: combinedLabels,
        datasets: [
          // Dummy datasets for clean legend colored indicators
          {
            type: 'bar',
            label: 'Line 2',
            data: [],
            backgroundColor: '#10b981',
            borderColor: '#10b981'
          },
          {
            type: 'bar',
            label: 'Line 3',
            data: [],
            backgroundColor: '#f59e0b',
            borderColor: '#f59e0b'
          },
          {
            type: 'bar',
            label: 'Total',
            data: [],
            backgroundColor: '#3b82f6',
            borderColor: '#3b82f6'
          },
          // Main target values bar chart
          {
            type: 'bar',
            label: 'Target',
            data: barTargetData,
            backgroundColor: barTargetColors,
            borderColor: '#94a3b8',
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 24,
            maxBarThickness: 35,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            order: 2,
            datalabels: {
              anchor: 'end',
              align: 'top',
              offset: 2,
              font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
              formatter: (val) => (val === null || val === undefined || val === 0) ? '' : Math.round(val)
            }
          },
          // Main actual values bar chart
          {
            type: 'bar',
            label: 'Actual',
            data: barActualData,
            backgroundColor: barActualColors,
            borderColor: '#3b82f6',
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 24,
            maxBarThickness: 35,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            order: 2,
            datalabels: {
              anchor: 'end',
              align: 'top',
              offset: 2,
              font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
              formatter: (val) => (val === null || val === undefined || val === 0) ? '' : Math.round(val)
            }
          },
          // Monthly trend lines
          {
            type: 'line',
            label: 'Line 2 Target',
            data: line2TargetData,
            borderColor: '#cbd5e1',
            borderWidth: 1.5,
            borderDash: [3, 3],
            fill: false,
            pointRadius: 0,
            order: 1,
            isLine: true,
            isTarget: true
          },
          {
            type: 'line',
            label: 'Line 2 Monthly',
            data: line2ActualData,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.05)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: '#10b981',
            order: 0,
            segment: {
              borderDash: (ctx) => {
                if (l2LastNonNullIdx !== -1 && ctx.p1DataIndex === spacerCount + l2LastNonNullIdx + 1) {
                  return [4, 4];
                }
                return undefined;
              }
            },
            isLine: true,
            isActual: true,
            lastNonNullIdx: l2LastNonNullIdx,
            spacerCount: spacerCount
          },
          {
            type: 'line',
            label: 'Line 3 Target',
            data: line3TargetData,
            borderColor: '#e2e8f0',
            borderWidth: 1.5,
            borderDash: [3, 3],
            fill: false,
            pointRadius: 0,
            order: 1,
            isLine: true,
            isTarget: true
          },
          {
            type: 'line',
            label: 'Line 3 Monthly',
            data: line3ActualData,
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.05)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: '#f59e0b',
            order: 0,
            segment: {
              borderDash: (ctx) => {
                if (l3LastNonNullIdx !== -1 && ctx.p1DataIndex === spacerCount + l3LastNonNullIdx + 1) {
                  return [4, 4];
                }
                return undefined;
              }
            },
            isLine: true,
            isActual: true,
            lastNonNullIdx: l3LastNonNullIdx,
            spacerCount: spacerCount
          },
          {
            type: 'line',
            label: 'Predicted',
            data: [],
            borderColor: '#64748b',
            borderWidth: 2,
            borderDash: [4, 4],
            pointRadius: 4,
            pointBackgroundColor: '#64748b',
            pointBorderColor: '#64748b',
            order: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            align: 'start',
            labels: {
              boxWidth: 10,
              padding: 10,
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 11.5, weight: 'bold' },
              filter: (item) => {
                // Show Line 2, Line 3, Total, and Predicted in the legend
                return item.text === 'Line 2' || item.text === 'Line 3' || item.text === 'Total' || item.text === 'Predicted';
              }
            }
          },
          datalabels: {
            display: (context) => {
              const val = context.dataset.data[context.dataIndex];
              return val !== null && val !== undefined;
            },
            anchor: getDatalabelAnchor,
            align: getDatalabelAlign,
            offset: getDatalabelOffset,
            font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' },
            color: '#000000',
            formatter: (val, context) => {
              if (val === null || val === undefined) return '';
              if (val === 0 && context.dataset.type === 'bar') return '';
              const ds = context.dataset;
              const formattedVal = val % 1 === 0 ? Math.round(val) : parseFloat(val.toFixed(1));
              if (ds.isLine && ds.isActual) {
                if (ds.lastNonNullIdx !== undefined && ds.lastNonNullIdx !== -1 && context.dataIndex === ds.spacerCount + ds.lastNonNullIdx + 1) {
                  return formattedVal;
                }
              }
              return formattedVal;
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' }
            },
            grid: { color: '#f1f5f9' }
          },
          x: {
            ticks: {
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 9, weight: 'bold' }
            },
            grid: { display: false }
          }
        }
      },
      plugins: [datalabelsPlugin]
    });
  }

  // Line 2 individual chart
  const ctxL2 = document.getElementById('delivery-prod-l2-canvas');
  if (ctxL2) {
    if (deliveryProdL2Chart) deliveryProdL2Chart.destroy();

    const barLabels = ["YTD"];
    const spacerCount = barLabels.length + 1; // 2

    let l2MaxLen = l2Actuals.length;
    let l2LastNonNullIdx = -1;
    for (let i = 0; i < l2Actuals.length; i++) {
      if (l2Actuals[i] !== null && l2Actuals[i] !== undefined && l2Actuals[i] !== 0) {
        l2LastNonNullIdx = i;
      }
    }

    let extendedMonths = [...monthsList];
    let needsExtension = (l2LastNonNullIdx !== -1 && l2LastNonNullIdx === l2MaxLen - 1 && monthsList.length < 12);
    if (needsExtension && monthsList.length > 0) {
      const nextLabel = getNextMonthLabel(monthsList[monthsList.length - 1]);
      extendedMonths.push(nextLabel);
    }

    const combinedLabels = [...barLabels, "", ...extendedMonths];

    const barTargetData = [l2YtdTarget, null, ...extendedMonths.map(() => null)];
    const barActualData = [l2YtdActual, null, ...extendedMonths.map(() => null)];

    const actualL2Targets = needsExtension ? [...l2Targets, null] : l2Targets;
    const actualL2Actuals = needsExtension ? [...l2Actuals, null] : l2Actuals;

    const lineTargetData = [...Array(spacerCount).fill(null), ...actualL2Targets];
    const lineActualData = [...Array(spacerCount).fill(null), ...actualL2Actuals];

    let l2PredictedValue = null;
    if (l2LastNonNullIdx !== -1 && (l2LastNonNullIdx < l2Actuals.length - 1 || needsExtension)) {
      const historicalValues = l2Actuals.slice(0, l2LastNonNullIdx + 1).map(val => val === null ? 0 : val);
      l2PredictedValue = predictNextValue(historicalValues);
      l2PredictedValue = Math.max(0, l2PredictedValue);
    }
    if (l2PredictedValue !== null && l2LastNonNullIdx !== -1) {
      lineActualData[spacerCount + l2LastNonNullIdx + 1] = l2PredictedValue;
    }

    deliveryProdL2Chart = new Chart(ctxL2, {
      type: 'bar',
      data: {
        labels: combinedLabels,
        datasets: [
          {
            type: 'bar',
            label: 'YTD Target',
            data: barTargetData,
            backgroundColor: '#cbd5e1', // slate-300
            borderColor: '#94a3b8',
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 24,
            maxBarThickness: 35,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            order: 2
          },
          {
            type: 'bar',
            label: 'YTD Actual',
            data: barActualData,
            backgroundColor: '#10b981',
            borderColor: '#10b981',
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 24,
            maxBarThickness: 35,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            order: 2
          },
          {
            type: 'line',
            label: 'Target Trend',
            data: lineTargetData,
            borderColor: '#cbd5e1',
            borderWidth: 1.5,
            borderDash: [3, 3],
            fill: false,
            pointRadius: 0,
            order: 1,
            isLine: true,
            isTarget: true
          },
          {
            type: 'line',
            label: 'Actual Trend',
            data: lineActualData,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.05)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: '#10b981',
            order: 0,
            segment: {
              borderDash: (ctx) => {
                if (l2LastNonNullIdx !== -1 && ctx.p1DataIndex === spacerCount + l2LastNonNullIdx + 1) {
                  return [4, 4];
                }
                return undefined;
              }
            },
            isLine: true,
            isActual: true,
            lastNonNullIdx: l2LastNonNullIdx,
            spacerCount: spacerCount
          },
          {
            type: 'line',
            label: 'Predicted',
            data: [],
            borderColor: '#64748b',
            borderWidth: 2,
            borderDash: [4, 4],
            pointRadius: 4,
            pointBackgroundColor: '#10b981',
            pointBorderColor: '#10b981',
            order: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            align: 'start',
            labels: {
              boxWidth: 10,
              padding: 10,
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 11.5, weight: 'bold' }
            }
          },
          datalabels: {
            display: (context) => {
              const val = context.dataset.data[context.dataIndex];
              return val !== null && val !== undefined;
            },
            anchor: getDatalabelAnchor,
            align: getDatalabelAlign,
            offset: getDatalabelOffset,
            font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' },
            color: '#000000',
            formatter: (val, context) => {
              if (val === null || val === undefined) return '';
              if (val === 0 && context.dataset.type === 'bar') return '';
              const ds = context.dataset;
              const formattedVal = val % 1 === 0 ? Math.round(val) : parseFloat(val.toFixed(1));
              if (ds.isLine && ds.isActual) {
                if (ds.lastNonNullIdx !== undefined && ds.lastNonNullIdx !== -1 && context.dataIndex === ds.spacerCount + ds.lastNonNullIdx + 1) {
                  return formattedVal;
                }
              }
              return formattedVal;
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' }
            },
            grid: { color: '#f1f5f9' }
          },
          x: {
            ticks: {
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 9, weight: 'bold' }
            },
            grid: { display: false }
          }
        }
      },
      plugins: [datalabelsPlugin]
    });
  }

  // Line 3 individual chart
  const ctxL3 = document.getElementById('delivery-prod-l3-canvas');
  if (ctxL3) {
    if (deliveryProdL3Chart) deliveryProdL3Chart.destroy();

    const barLabels = ["YTD"];
    const spacerCount = barLabels.length + 1; // 2

    let l3MaxLen = l3Actuals.length;
    let l3LastNonNullIdx = -1;
    for (let i = 0; i < l3Actuals.length; i++) {
      if (l3Actuals[i] !== null && l3Actuals[i] !== undefined && l3Actuals[i] !== 0) {
        l3LastNonNullIdx = i;
      }
    }

    let extendedMonths = [...monthsList];
    let needsExtension = (l3LastNonNullIdx !== -1 && l3LastNonNullIdx === l3MaxLen - 1 && monthsList.length < 12);
    if (needsExtension && monthsList.length > 0) {
      const nextLabel = getNextMonthLabel(monthsList[monthsList.length - 1]);
      extendedMonths.push(nextLabel);
    }

    const combinedLabels = [...barLabels, "", ...extendedMonths];

    const barTargetData = [l3YtdTarget, null, ...extendedMonths.map(() => null)];
    const barActualData = [l3YtdActual, null, ...extendedMonths.map(() => null)];

    const actualL3Targets = needsExtension ? [...l3Targets, null] : l3Targets;
    const actualL3Actuals = needsExtension ? [...l3Actuals, null] : l3Actuals;

    const lineTargetData = [...Array(spacerCount).fill(null), ...actualL3Targets];
    const lineActualData = [...Array(spacerCount).fill(null), ...actualL3Actuals];

    let l3PredictedValue = null;
    if (l3LastNonNullIdx !== -1 && (l3LastNonNullIdx < l3Actuals.length - 1 || needsExtension)) {
      const historicalValues = l3Actuals.slice(0, l3LastNonNullIdx + 1).map(val => val === null ? 0 : val);
      l3PredictedValue = predictNextValue(historicalValues);
      l3PredictedValue = Math.max(0, l3PredictedValue);
    }
    if (l3PredictedValue !== null && l3LastNonNullIdx !== -1) {
      lineActualData[spacerCount + l3LastNonNullIdx + 1] = l3PredictedValue;
    }

    deliveryProdL3Chart = new Chart(ctxL3, {
      type: 'bar',
      data: {
        labels: combinedLabels,
        datasets: [
          {
            type: 'bar',
            label: 'YTD Target',
            data: barTargetData,
            backgroundColor: '#cbd5e1', // slate-300
            borderColor: '#e2e8f0',
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 24,
            maxBarThickness: 35,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            order: 2,
            order: 2
          },
          {
            type: 'bar',
            label: 'YTD Actual',
            data: barActualData,
            backgroundColor: '#f59e0b',
            borderColor: '#f59e0b',
            borderWidth: 1,
            borderRadius: 4,
            barThickness: 24,
            maxBarThickness: 35,
            barPercentage: 0.9,
            categoryPercentage: 0.9,
            order: 2
          },
          {
            type: 'line',
            label: 'Target Trend',
            data: lineTargetData,
            borderColor: '#e2e8f0',
            borderWidth: 1.5,
            borderDash: [3, 3],
            fill: false,
            pointRadius: 0,
            order: 1,
            isLine: true,
            isTarget: true
          },
          {
            type: 'line',
            label: 'Actual Trend',
            data: lineActualData,
            borderColor: '#f59e0b',
            backgroundColor: 'rgba(245, 158, 11, 0.05)',
            borderWidth: 2.5,
            fill: true,
            tension: 0.3,
            pointRadius: 4,
            pointBackgroundColor: '#f59e0b',
            order: 0,
            segment: {
              borderDash: (ctx) => {
                if (l3LastNonNullIdx !== -1 && ctx.p1DataIndex === spacerCount + l3LastNonNullIdx + 1) {
                  return [4, 4];
                }
                return undefined;
              }
            },
            isLine: true,
            isActual: true,
            lastNonNullIdx: l3LastNonNullIdx,
            spacerCount: spacerCount
          },
          {
            type: 'line',
            label: 'Predicted',
            data: [],
            borderColor: '#64748b',
            borderWidth: 2,
            borderDash: [4, 4],
            pointRadius: 4,
            pointBackgroundColor: '#f59e0b',
            pointBorderColor: '#f59e0b',
            order: 0
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            align: 'start',
            labels: {
              boxWidth: 10,
              padding: 10,
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 11.5, weight: 'bold' }
            }
          },
          datalabels: {
            display: (context) => {
              const val = context.dataset.data[context.dataIndex];
              return val !== null && val !== undefined;
            },
            anchor: getDatalabelAnchor,
            align: getDatalabelAlign,
            offset: getDatalabelOffset,
            font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' },
            color: '#000000',
            formatter: (val, context) => {
              if (val === null || val === undefined) return '';
              if (val === 0 && context.dataset.type === 'bar') return '';
              const ds = context.dataset;
              const formattedVal = val % 1 === 0 ? Math.round(val) : parseFloat(val.toFixed(1));
              if (ds.isLine && ds.isActual) {
                if (ds.lastNonNullIdx !== undefined && ds.lastNonNullIdx !== -1 && context.dataIndex === ds.spacerCount + ds.lastNonNullIdx + 1) {
                  return formattedVal;
                }
              }
              return formattedVal;
            }
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 10, weight: 'bold' }
            },
            grid: { color: '#f1f5f9' }
          },
          x: {
            ticks: {
              color: '#000000',
              font: { family: 'Outfit, Inter, sans-serif', size: 9, weight: 'bold' }
            },
            grid: { display: false }
          }
        }
      },
      plugins: [datalabelsPlugin]
    });
  }
}

// Renders Cost DMC & Repro trend lines
function renderCostTrendCharts() {
  const costData = state.costMonthlyData;
  const labels = costData.labels;

  const ctxDmc = document.getElementById('cost-dmc-canvas');
  if (ctxDmc && costData.dmc) {
    if (costDmcChart) costDmcChart.destroy();
    const dmcKpi = state.kpis.find(k => k.id === 'dmc');
    const actuals = [...costData.dmc.actuals];
    const targets = [...costData.dmc.targets];
    const scTargets = costData.dmc.scTargets ? [...costData.dmc.scTargets] : targets;
    const N = (costData.dmc.months || labels).length;
    if (dmcKpi && N > 0) {
      if (actuals[N - 1] === 0 || actuals[N - 1] === null) actuals[N - 1] = dmcKpi.actual;
      if (targets[N - 1] === 0 || targets[N - 1] === null) targets[N - 1] = dmcKpi.target;
      if (scTargets[N - 1] === 0 || scTargets[N - 1] === null) scTargets[N - 1] = dmcKpi.target;
    }

    costDmcChart = renderComboTrendChart('cost-dmc-canvas', costData.dmc.months || labels, [
      {
        label: 'DMC',
        targets: targets,
        scTargets: scTargets,
        actuals: actuals,
        fyData: costData.dmc.fyData,
        color: '#ef4444'
      }
    ]);
  }

  const ctxRepro = document.getElementById('cost-repro-canvas');
  if (ctxRepro && costData.repro) {
    if (costReproChart) costReproChart.destroy();
    const reproKpi = state.kpis.find(k => k.id === 'repro');
    const actuals = [...costData.repro.actuals];
    const targets = [...costData.repro.targets];
    const scTargets = costData.repro.scTargets ? [...costData.repro.scTargets] : targets;
    const N = (costData.repro.months || labels).length;
    if (reproKpi && N > 0) {
      if (actuals[N - 1] === 0 || actuals[N - 1] === null) actuals[N - 1] = reproKpi.actual;
      if (targets[N - 1] === 0 || targets[N - 1] === null) targets[N - 1] = reproKpi.target;
      if (scTargets[N - 1] === 0 || scTargets[N - 1] === null) scTargets[N - 1] = reproKpi.target;
    }

    costReproChart = renderComboTrendChart('cost-repro-canvas', costData.repro.months || labels, [
      {
        label: 'Repro',
        targets: targets,
        scTargets: scTargets,
        actuals: actuals,
        fyData: costData.repro.fyData,
        color: '#3b82f6'
      }
    ]);
  }

  const ctxVcc = document.getElementById('cost-vcc-canvas');
  if (ctxVcc && costData.vcc) {
    if (costVccChart) costVccChart.destroy();
    const vccKpi = state.kpis.find(k => k.id === 'vcc');
    const actuals = [...costData.vcc.actuals];
    const targets = [...costData.vcc.targets];
    const scTargets = costData.vcc.scTargets ? [...costData.vcc.scTargets] : targets;
    const N = (costData.vcc.months || labels).length;
    if (vccKpi && N > 0) {
      if (actuals[N - 1] === 0 || actuals[N - 1] === null) actuals[N - 1] = vccKpi.actual;
      if (targets[N - 1] === 0 || targets[N - 1] === null) targets[N - 1] = vccKpi.target;
      if (scTargets[N - 1] === 0 || scTargets[N - 1] === null) scTargets[N - 1] = vccKpi.target;
    }

    costVccChart = renderComboTrendChart('cost-vcc-canvas', costData.vcc.months || labels, [
      {
        label: 'VCC',
        targets: targets,
        scTargets: scTargets,
        actuals: actuals,
        fyData: costData.vcc.fyData,
        color: '#10b981'
      }
    ]);
  }

  const ctxOfe = document.getElementById('cost-ofe-canvas');
  if (ctxOfe && costData.ofe) {
    if (costOfeChart) costOfeChart.destroy();
    const ofeKpi = state.kpis.find(k => k.id === 'ofe');
    const actuals = [...costData.ofe.actuals];
    const targets = [...costData.ofe.targets];
    const scTargets = costData.ofe.scTargets ? [...costData.ofe.scTargets] : targets;
    const N = (costData.ofe.months || labels).length;
    if (ofeKpi && N > 0) {
      if (actuals[N - 1] === 0 || actuals[N - 1] === null) actuals[N - 1] = ofeKpi.actual;
      if (targets[N - 1] === 0 || targets[N - 1] === null) targets[N - 1] = ofeKpi.target;
      if (scTargets[N - 1] === 0 || scTargets[N - 1] === null) scTargets[N - 1] = ofeKpi.target;
    }

    costOfeChart = renderComboTrendChart('cost-ofe-canvas', costData.ofe.months || labels, [
      {
        label: 'OFE',
        targets: targets,
        scTargets: scTargets,
        actuals: actuals,
        fyData: costData.ofe.fyData,
        color: '#f59e0b'
      }
    ], {
      y: {
        title: { display: true, text: 'Rs Crs', font: { size: 10, weight: 'bold' } }
      }
    });
  }
}

// Renders HR IVDP & CSR Lives Touched trend lines
function renderHrTrendCharts() {
  const hrData = state.hrMonthlyData;
  const labels = hrData.labels;

  const ctxIvdp = document.getElementById('hr-ivdp-canvas');
  if (ctxIvdp) {
    if (hrIvdpChart) hrIvdpChart.destroy();
    hrIvdpChart = renderComboTrendChart('hr-ivdp-canvas', hrData.ivdp.months || labels, [
      {
        label: 'IVDP',
        targets: hrData.ivdp.targets,
        actuals: hrData.ivdp.actuals,
        fyData: hrData.ivdp.fyData,
        color: '#8b5cf6'
      }
    ]);
  }

  const ctxCsr = document.getElementById('hr-csr-canvas');
  if (ctxCsr) {
    if (hrCsrChart) hrCsrChart.destroy();
    hrCsrChart = renderComboTrendChart('hr-csr-canvas', hrData.csr.months || labels, [
      {
        label: 'CSR',
        targets: hrData.csr.targets,
        actuals: hrData.csr.actuals,
        fyData: hrData.csr.fyData,
        color: '#ec4899'
      }
    ]);
  }

  const months = hrData.environment.months || labels;

  // Environment Chart
  const ctxEnv = document.getElementById('hr-csr-env-canvas');
  if (ctxEnv && hrData.environment) {
    if (hrCsrEnvChart) hrCsrEnvChart.destroy();
    hrCsrEnvChart = renderComboTrendChart('hr-csr-env-canvas', months, [
      {
        label: 'Environment',
        targets: hrData.environment.targets,
        actuals: hrData.environment.actuals,
        fyData: hrData.environment.fyData,
        color: '#10b981'
      }
    ], { hideHistory: true });
  }

  // Health Chart
  const ctxHealth = document.getElementById('hr-csr-health-canvas');
  if (ctxHealth && hrData.health) {
    if (hrCsrHealthChart) hrCsrHealthChart.destroy();
    hrCsrHealthChart = renderComboTrendChart('hr-csr-health-canvas', months, [
      {
        label: 'Health',
        targets: hrData.health.targets,
        actuals: hrData.health.actuals,
        fyData: hrData.health.fyData,
        color: '#f59e0b'
      }
    ], { hideHistory: true });
  }

  // Education Chart
  const ctxEdu = document.getElementById('hr-csr-edu-canvas');
  if (ctxEdu && hrData.education) {
    if (hrCsrEduChart) hrCsrEduChart.destroy();
    hrCsrEduChart = renderComboTrendChart('hr-csr-edu-canvas', months, [
      {
        label: 'Education',
        targets: hrData.education.targets,
        actuals: hrData.education.actuals,
        fyData: hrData.education.fyData,
        color: '#3b82f6'
      }
    ], { hideHistory: true });
  }

  // Employability Chart
  const ctxEmp = document.getElementById('hr-csr-emp-canvas');
  if (ctxEmp && hrData.employability) {
    if (hrCsrEmpChart) hrCsrEmpChart.destroy();
    hrCsrEmpChart = renderComboTrendChart('hr-csr-emp-canvas', months, [
      {
        label: 'Employability',
        targets: hrData.employability.targets,
        actuals: hrData.employability.actuals,
        fyData: hrData.employability.fyData,
        color: '#8b5cf6'
      }
    ], { hideHistory: true });
  }
}

// Renders Quality monthly trend lines for the 9 new metrics
function renderQualityTrendCharts() {
  const qData = state.qualityMonthlyData;
  
  // Defensive initialization of vc_charter to support older localStorage cache
  if (qData && !qData.vc_charter) {
    qData.vc_charter = {
      months: qData.labels || ["Apr'26", "May'26", "June'26", "July'26"],
      targets: [90, 90, 90, 90],
      actuals: [82, 82, 82, 82],
      fyData: { fy24: 0, fy25: 0, fy26: 0 }
    };
  }

  const labels = qData.labels || ["Apr'26", "May'26", "June'26", "July'26"];

  const renderQChart = (canvasId, key, chartColor, labelText, options = {}) => {
    const ctx = document.getElementById(canvasId);
    if (!ctx) return null;

    const item = qData[key];
    if (!item) return null;

    return renderComboTrendChart(canvasId, item.months || labels, [
      {
        label: labelText,
        targets: item.targets,
        scTargets: item.scTargets,
        actuals: item.actuals,
        fyData: item.fyData,
        color: chartColor
      }
    ], options);
  };

  const getPercentageOptions = () => ({
    y: { min: 0, max: 110, ticks: { callback: v => `${v}%` } }
  });

  if (qualityProductCharterChart) qualityProductCharterChart.destroy();
  qualityProductCharterChart = renderQChart('quality-product-charter-canvas', 'vc_charter', '#3b82f6', 'VC Charter (C2)', getPercentageOptions());

  if (qualityCompIptvChart) qualityCompIptvChart.destroy();
  qualityCompIptvChart = renderQChart('quality-comp-iptv-canvas', 'comp_quality_iptv', '#ef4444', 'Delta Composite IPTV (Index)');

  if (qualityCompEpvChart) qualityCompEpvChart.destroy();
  qualityCompEpvChart = renderQChart('quality-comp-epv-canvas', 'comp_quality_epv', '#f59e0b', 'EPV (Expense per vehicle)');

  if (qualityCompVisitsChart) qualityCompVisitsChart.destroy();
  qualityCompVisitsChart = renderQChart('quality-comp-visits-canvas', 'comp_quality_visits', '#10b981', 'Unscheduled visits per vehicle');

  if (qualityCompNoTouchChart) qualityCompNoTouchChart.destroy();
  qualityCompNoTouchChart = renderQChart('quality-comp-notouch-canvas', 'comp_quality_notouch', '#6366f1', 'No Touch DRR', getPercentageOptions());

  if (qualityLaunchQualityChart) qualityLaunchQualityChart.destroy();
  qualityLaunchQualityChart = renderQChart('quality-launch-quality-canvas', 'launch_quality', '#ec4899', 'Launch Quality Composite IPTV', getPercentageOptions());

  if (qualityLaunchUvpvChart) qualityLaunchUvpvChart.destroy();
  qualityLaunchUvpvChart = renderQChart('quality-launch-uvpv-canvas', 'launch_uvpv', '#8b5cf6', 'Launch UVPV');

  if (qualityLayerAuditChart) qualityLayerAuditChart.destroy();
  qualityLayerAuditChart = renderQChart('quality-layer-audit-canvas', 'layer_audit', '#14b8a6', 'Layer Audit Compliance (%)', getPercentageOptions());

  if (qualityCimpleProjectChart) qualityCimpleProjectChart.destroy();
  qualityCimpleProjectChart = renderQChart('quality-cimple-project-canvas', 'cimple_project', '#f97316', 'Cimple Project (Off track)');
}

// Renders Environment monthly trend lines
function renderEnvironmentTrendCharts() {
  const envData = state.environmentMonthlyData;
  const labels = envData.labels;

  const getKpi = (id) => state.kpis.find(k => k.id === id);

  const renderEnvChart = (canvasId, key, kpiId, chartColor, labelText) => {
    const kpi = getKpi(kpiId);
    const actuals = [...envData[key].actuals];
    const targets = [...envData[key].targets];

    if (kpi) {
      if (actuals[3] === 0 || actuals[3] === null) actuals[3] = kpi.actual;
      if (targets[3] === 0 || targets[3] === null) targets[3] = kpi.target;
    }

    return renderComboTrendChart(canvasId, envData[key].months || labels, [
      {
        label: labelText,
        targets: targets,
        actuals: actuals,
        fyData: envData[key].fyData,
        color: chartColor
      }
    ]);
  };

  if (envPowerChart) envPowerChart.destroy();
  envPowerChart = renderEnvChart('environment-power-canvas', 'power', 'power_kwh', '#ef4444', 'Power Consumption (KWh/EU)');

  if (envFuelChart) envFuelChart.destroy();
  envFuelChart = renderEnvChart('environment-fuel-canvas', 'fuel', 'fuel_unit', '#f59e0b', 'Fuel (Unit/EU)');

  if (envGhgChart) envGhgChart.destroy();
  envGhgChart = renderEnvChart('environment-ghg-canvas', 'ghg', 'ghg', '#10b981', 'GHG Emissions (kG CO2e/EU)');

  if (envWaterChart) envWaterChart.destroy();
  envWaterChart = renderEnvChart('environment-water-canvas', 'water', 'env_water_ratio', '#3b82f6', 'Water Positive (Ratio)');
}

export function renderInventoryTrendCharts() {
  const invData = state.inventoryMonthlyData;
  if (!invData) return;

  const labels = invData.labels || ["Apr'26", "May'26", "June'26", "July'26"];
  
  const opsDaysKpi = state.kpis.find(k => k.id === 'ops_inv_days');
  const invWoKpi = state.kpis.find(k => k.id === 'inv_rs_crs_wo');
  const invWithKpi = state.kpis.find(k => k.id === 'inv_rs_crs_w');

  const opsDaysActuals = [...(invData.opsDays?.actuals || [])];
  const opsDaysTargets = [...(invData.opsDays?.targets || [])];
  const opsDaysScTargets = [...(invData.opsDays?.scTargets || opsDaysTargets)];
  const invWoActuals = [...(invData.invWo?.actuals || [])];
  const invWoTargets = [...(invData.invWo?.targets || [])];
  const invWithActuals = [...(invData.invWith?.actuals || [])];
  const invWithTargets = [...(invData.invWith?.targets || [])];

  const N = labels.length;
  // Sync last month actuals with active KPI state
  if (opsDaysKpi && N > 0) {
    if (opsDaysActuals[N - 1] === null || opsDaysActuals[N - 1] === 0 || opsDaysActuals[N - 1] === undefined) {
      opsDaysActuals[N - 1] = opsDaysKpi.actual;
    }
  }
  if (invWoKpi && N > 0) {
    if (invWoActuals[N - 1] === null || invWoActuals[N - 1] === 0 || invWoActuals[N - 1] === undefined) {
      invWoActuals[N - 1] = invWoKpi.actual;
    }
  }
  if (invWithKpi && N > 0) {
    if (invWithActuals[N - 1] === null || invWithActuals[N - 1] === 0 || invWithActuals[N - 1] === undefined) {
      invWithActuals[N - 1] = invWithKpi.actual;
    }
  }

  if (invOpsDaysChart) invOpsDaysChart.destroy();
  invOpsDaysChart = renderComboTrendChart('inventory-opsdays-canvas', labels, [
    {
      label: 'Operations Inventory (Days)',
      targets: opsDaysTargets,
      scTargets: opsDaysScTargets,
      actuals: opsDaysActuals,
      fyData: invData.opsDays?.fyData,
      color: '#ef4444'
    }
  ]);

  if (invWoChart) invWoChart.destroy();
  invWoChart = renderComboTrendChart('inventory-wo-canvas', labels, [
    {
      label: 'Inventory W/o IFLT (Rs Cr)',
      targets: invWoTargets,
      actuals: invWoActuals,
      fyData: invData.invWo?.fyData,
      color: '#f59e0b'
    }
  ]);

  if (invWithChart) invWithChart.destroy();
  invWithChart = renderComboTrendChart('inventory-with-canvas', labels, [
    {
      label: 'Inventory With IFLT (Rs Cr)',
      targets: invWithTargets,
      actuals: invWithActuals,
      fyData: invData.invWith?.fyData,
      color: '#10b981'
    }
  ]);

  if (state.hasTml) {
    if (invTmlChart) invTmlChart.destroy();
    const tmlKpi = state.kpis.find(k => k.id === 'inv_tml');
    const tmlActuals = [...(invData.tml?.actuals || [])];
    const tmlTargets = [...(invData.tml?.targets || [])];
    if (tmlKpi && N > 0 && invData.tml?.actuals[N - 1] !== null) {
      tmlActuals[N - 1] = tmlKpi.actual;
      tmlTargets[N - 1] = tmlKpi.target;
    }
    invTmlChart = renderComboTrendChart('inventory-tml-canvas', labels, [
      {
        label: 'TML (Rs Cr)',
        targets: tmlTargets,
        actuals: tmlActuals,
        fyData: invData.tml?.fyData,
        color: '#3b82f6'
      }
    ]);

    if (invTmbslChart) invTmbslChart.destroy();
    const tmbslKpi = state.kpis.find(k => k.id === 'inv_tmbsl');
    const tmbslActuals = [...(invData.tmbsl?.actuals || [])];
    const tmbslTargets = [...(invData.tmbsl?.targets || [])];
    if (tmbslKpi && N > 0 && invData.tmbsl?.actuals[N - 1] !== null) {
      tmbslActuals[N - 1] = tmbslKpi.actual;
      tmbslTargets[N - 1] = tmbslKpi.target;
    }
    invTmbslChart = renderComboTrendChart('inventory-tmbsl-canvas', labels, [
      {
        label: 'TMBSL (Rs Cr)',
        targets: tmbslTargets,
        actuals: tmbslActuals,
        fyData: invData.tmbsl?.fyData,
        color: '#f59e0b'
      }
    ]);
  }
}

export function renderDigitalTrendCharts() {
  const digData = state.digitalMonthlyData;
  if (!digData) return;

  const labels = digData.labels || ["Apr'26", "May'26", "June'26", "July'26"];

  const budgetRfqActuals = [...(digData.budgetRfq?.actuals || [])];
  const budgetRfqTargets = [...(digData.budgetRfq?.targets || [])];
  const qualixIqmsActuals = [...(digData.qualixIqms?.actuals || [])];
  const qualixIqmsTargets = [...(digData.qualixIqms?.targets || [])];

  if (digBudgetChart) digBudgetChart.destroy();
  digBudgetChart = renderComboTrendChart('digital-budget-canvas', labels, [
    {
      label: 'Industry 4.0 Budget RFQ (%)',
      targets: budgetRfqTargets,
      actuals: budgetRfqActuals,
      fyData: digData.budgetRfq?.fyData,
      color: '#3b82f6'
    }
  ], {
    y: { min: 0, max: 110, ticks: { callback: v => `${v}%` } }
  });

  if (digQualixChart) digQualixChart.destroy();
  digQualixChart = renderComboTrendChart('digital-qualix-canvas', labels, [
    {
      label: 'Qualix IQMS Deployments (Lines)',
      targets: qualixIqmsTargets,
      actuals: qualixIqmsActuals,
      fyData: digData.qualixIqms?.fyData,
      color: '#10b981'
    }
  ]);
}
