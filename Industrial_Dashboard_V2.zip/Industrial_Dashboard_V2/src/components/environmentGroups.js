// Environment Dashboard Groupings Component

import { getAchievement, getStatus, getKpiForMode, renderDirectionBadge } from '../state.js';

// Helper to format values with their UoM dynamically (keeping max 2 decimals)
function formatValue(val, unit) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  if (unit === 'percent' || unit === 'Paercentage' || unit === '%') {
    let rawPct = val;
    if (val <= 1.0) {
      rawPct = val * 100;
    }
    return `${parseFloat(rawPct.toFixed(2))}%`;
  }
  if (unit === 'ratio') {
    return `${parseFloat((val * 100).toFixed(2))}%`;
  }
  return parseFloat(val.toFixed(2));
}

// Global View Switcher for Sustainability Section
if (typeof window !== 'undefined') {
  window.toggleSustainView = function(suffix, view) {
    const cardsEl = document.getElementById(`sustain-cards-${suffix}`);
    const tableEl = document.getElementById(`sustain-table-${suffix}`);
    const btnCards = document.getElementById(`btn-cards-${suffix}`);
    const btnTable = document.getElementById(`btn-table-${suffix}`);

    if (view === 'cards') {
      if (cardsEl) cardsEl.style.display = 'grid';
      if (tableEl) tableEl.style.display = 'none';
      if (btnCards) btnCards.classList.add('active');
      if (btnTable) btnTable.classList.remove('active');
    } else {
      if (cardsEl) cardsEl.style.display = 'none';
      if (tableEl) tableEl.style.display = 'block';
      if (btnCards) btnCards.classList.remove('active');
      if (btnTable) btnTable.classList.add('active');
    }
  };
}

// Group 1: Energy & Resource Consumption
export function renderEnvironmentResourcesSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const resourceIds = ['power_kwh', 'fuel_unit', 'env_water_ratio'];
  const groupKpis = kpis.filter(k => resourceIds.includes(k.id));

  let html = `
    <div class="card env-resources-card">
      <div class="card-header">Energy & Resource Consumption</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Resource Metric</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th style="width: 13%;">Target</th>
              <th style="width: 13%;">Actual</th>
              <th style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 1}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit === 'percent' ? '%' : kpi.unit || '-'}</td>
        <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target, kpi.unit)}</td>
        <td style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual, kpi.unit)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}

// Group 2: Sustainability & Decarbonization (Redesigned Creative Eco Matrix)
export function renderEnvironmentDecarbonizationSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';

  const sustainIds = ['ghg', 'zero_waste', 're_100', 'env_scope1', 'env_circular', 'env_biodiversity'];
  const groupKpis = kpis.filter(k => sustainIds.includes(k.id));

  // Visual Theme Map
  const metaMap = {
    ghg: { icon: '💨', color: '#10b981', gradient: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', bgLight: 'rgba(16, 185, 129, 0.1)' },
    zero_waste: { icon: '♻️', color: '#0ea5e9', gradient: 'linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%)', bgLight: 'rgba(14, 165, 233, 0.1)' },
    re_100: { icon: '⚡', color: '#8b5cf6', gradient: 'linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)', bgLight: 'rgba(139, 92, 246, 0.1)' },
    env_scope1: { icon: '🔥', color: '#f59e0b', gradient: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', bgLight: 'rgba(245, 158, 11, 0.1)' },
    env_circular: { icon: '🔄', color: '#06b6d4', gradient: 'linear-gradient(135deg, #06b6d4 0%, #0891b2 100%)', bgLight: 'rgba(6, 182, 212, 0.1)' },
    env_biodiversity: { icon: '🌿', color: '#14b8a6', gradient: 'linear-gradient(135deg, #14b8a6 0%, #0d9488 100%)', bgLight: 'rgba(20, 184, 166, 0.1)' }
  };

  // 1. Generate Creative Eco Cards HTML
  let cardsHtml = `<div class="sustain-grid" id="sustain-cards-${suffix}">`;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;
    const meta = metaMap[kpi.id] || { icon: '🌱', color: '#10b981', gradient: 'linear-gradient(135deg, #10b981, #059669)', bgLight: 'rgba(16, 185, 129, 0.1)' };
    const clampedAch = Math.min(100, Math.max(0, ach));
    const uomStr = kpi.unit === 'percent' ? '%' : (kpi.unit || '-');

    cardsHtml += `
      <div class="sustain-tile-card" style="border-top: 4px solid ${meta.color};">
        <div class="sustain-tile-header">
          <div class="sustain-tile-icon" style="background: ${meta.bgLight}; color: ${meta.color};">
            ${meta.icon}
          </div>
          <div class="sustain-tile-title">
            <span class="sustain-tile-num">${idx + 4}.</span> ${kpi.name}
          </div>
          <div class="sustain-tile-badge">
            ${renderDirectionBadge(kpi)}
          </div>
        </div>

        <div class="sustain-tile-body">
          <div class="sustain-val-box">
            <div class="sustain-actual-val">${formatValue(actual, kpi.unit)}</div>
            <div class="sustain-target-chip">Target: ${formatValue(target, kpi.unit)}</div>
          </div>
          <div class="sustain-status-chip ${statusClass}">
            <span class="status-pill">${ach}%</span>
          </div>
        </div>

        <div class="sustain-progress-wrapper">
          <div class="sustain-progress-bar">
            <div class="sustain-progress-fill" style="width: ${clampedAch}%; background: ${meta.gradient};"></div>
          </div>
          <div class="sustain-progress-label">
            <span>UoM: <strong>${uomStr}</strong></span>
            <span>Target Achieved: <strong>${ach}%</strong></span>
          </div>
        </div>
      </div>
    `;
  });
  cardsHtml += `</div>`;

  // 2. Generate Refined Modern Table HTML (for Table View toggle)
  let tableHtml = `
    <div class="scrollable-table-container" id="sustain-table-${suffix}" style="display: none;">
      <table class="dashboard-table">
        <thead>
          <tr>
            <th style="text-align: left; width: 34%;">Sustainability KPI</th>
            <th style="text-align: center; width: 20%;">Measure</th>
            <th class="col-uom" style="width: 10%;">UoM</th>
            <th style="width: 13%;">Target</th>
            <th style="width: 13%;">Actual</th>
            <th style="width: 10%;">Status</th>
          </tr>
        </thead>
        <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
    const status = getStatus(kpi, resolvedMode);
    const statusClass = `status-${status.toLowerCase()}`;

    tableHtml += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 4}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit === 'percent' ? '%' : kpi.unit || '-'}</td>
        <td style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target, kpi.unit)}</td>
        <td style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual, kpi.unit)}</td>
        <td class="cell-status ${statusClass}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  tableHtml += `
        </tbody>
      </table>
    </div>
  `;

  // Combine into Master Card with Header Controls
  let html = `
    <div class="card env-sustain-card">
      <div class="card-header" style="display: flex; justify-content: space-between; align-items: center; padding: 12px 18px; border-bottom: 1px solid rgba(226, 232, 240, 0.8);">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="font-size: 18px;">🌱</span>
          <span style="font-weight: 700; font-size: 15px; color: var(--primary-navy, #1e2d5a);">Sustainability & Decarbonization</span>
        </div>
        <div class="sustain-view-toggle" style="display: flex; gap: 8px; align-items: center;">
          <button class="sustain-toggle-btn active" id="btn-cards-${suffix}" onclick="window.toggleSustainView('${suffix}', 'cards')">
            ❖ Eco Cards View
          </button>
          <button class="sustain-toggle-btn" id="btn-table-${suffix}" onclick="window.toggleSustainView('${suffix}', 'table')">
            ☰ Table View
          </button>
        </div>
      </div>
      <div class="card-body" style="padding: 18px;">
        ${cardsHtml}
        ${tableHtml}
      </div>
    </div>
  `;

  container.innerHTML = html;
}
