// Safety Dashboard FIC Wise Injuries Component

import { state } from '../state.js';

export function renderSafetyFicTable(containerId, mode = 'ytd') {
  const container = document.getElementById(containerId);
  if (!container) return;

  const data = mode === 'monthly' ? (state.ficWiseInjuries || []) : (state.ficWiseInjuriesYtd || []);
  if (data.length === 0) {
    container.innerHTML = '';
    return;
  }

  const title = mode === 'monthly' ? 'FIC Wise Injuries (Month)' : 'FIC Wise Injuries (YTD)';

  let html = `
    <div class="card safety-fic-card" style="margin-top: 20px;">
      <div class="card-header">${title}</div>
      <div class="card-body scrollable-table-container" style="padding: 0;">
        <table class="dashboard-table safety-fic-table" style="border-collapse: collapse; width: 100%;">
          <thead>
            <tr style="background-color: #f8fafc; border-bottom: 2px solid #e2e8f0;">
              <th style="text-align: left; padding: 10px 12px; font-weight: 700; color: var(--primary-navy);">FIC Category</th>
              <th style="text-align: center; padding: 10px 8px; font-weight: 700; color: var(--primary-navy);">FAC</th>
              <th style="text-align: center; padding: 10px 8px; font-weight: 700; color: var(--primary-navy);">MTC</th>
              <th style="text-align: center; padding: 10px 8px; font-weight: 700; color: var(--primary-navy);">RWC</th>
              <th style="text-align: center; padding: 10px 8px; font-weight: 700; color: var(--primary-navy);">LTI</th>
            </tr>
          </thead>
          <tbody>
  `;

  data.forEach(row => {
    const isTotal = row.name.toUpperCase() === 'TOTAL';
    const rowClass = isTotal ? 'font-bold' : '';
    const rowBg = isTotal ? 'background-color: #f8fafc;' : 'background-color: #ffffff;';
    const borderTop = isTotal ? 'border-top: 2px solid #cbd5e1;' : 'border-top: 1px solid #f1f5f9;';

    const renderCellVal = (val) => {
      const num = parseFloat(val) || 0;
      if (num !== 0) {
        return `<span style="color: #ef4444; font-weight: 800;">${num}</span>`;
      }
      return `<span style="color: #94a3b8; font-weight: 500;">0</span>`;
    };

    html += `
      <tr class="${rowClass}" style="${rowBg} ${borderTop} border-bottom: 1px solid #f1f5f9;">
        <td style="text-align: left; padding: 8px 12px; ${isTotal ? 'font-weight: 700; color: var(--primary-navy);' : 'font-weight: 500; color: #334155;'}">${row.name}</td>
        <td style="text-align: center; padding: 8px; font-weight: 600;">${renderCellVal(row.fac)}</td>
        <td style="text-align: center; padding: 8px; font-weight: 600;">${renderCellVal(row.mtc)}</td>
        <td style="text-align: center; padding: 8px; font-weight: 600;">${renderCellVal(row.rwc)}</td>
        <td style="text-align: center; padding: 8px; font-weight: 600;">${renderCellVal(row.lti)}</td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;

  container.innerHTML = html;
}
