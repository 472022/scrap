import { Chart, registerables } from 'chart.js';
import { getAchievement, getStatus, getKpiForMode, renderDirectionBadge } from '../state.js';

Chart.register(...registerables);

const datalabelsPlugin = {
  id: 'datalabels',
  afterDatasetsDraw(chart) {
    const { ctx } = chart;
    ctx.save();
    ctx.font = 'bold 9px Outfit, Inter, sans-serif';
    ctx.fillStyle = '#475569'; // slate-600
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';

    chart.data.datasets.forEach((dataset, datasetIndex) => {
      const meta = chart.getDatasetMeta(datasetIndex);
      meta.data.forEach((element, index) => {
        const val = dataset.data[index];
        if (val !== null && val !== undefined) {
          ctx.fillText(val, element.x, element.y - 4);
        }
      });
    });
    ctx.restore();
  }
};

// Helper to format values with their UoM dynamically (keeping max 2 decimals)
function formatValue(val, unit) {
  if (val === undefined || val === null) return '-';
  if (typeof val === 'string') {
    const cleanStr = val.trim();
    if (cleanStr.startsWith('#') || cleanStr === '-' || cleanStr === '') {
      return '-';
    }
    // Attempt parsing
    const parsed = Number(cleanStr.replace(/%/g, '').replace(/,/g, ''));
    if (isNaN(parsed)) return '-';
    val = parsed;
  }
  if (typeof val !== 'number' || isNaN(val)) return '-';
  
  if (unit === 'percent' || unit === 'Paercentage' || unit === '%') {
    let rawPct = val;
    if (val <= 1.0) {
      rawPct = val * 100;
    }
    return `${parseFloat(rawPct.toFixed(2))}%`;
  }
  if (unit === 'ratio') {
    return `${parseFloat((val * 100).toFixed(2))}%`;
  }
  return parseFloat(val.toFixed(2));
}

// Master layout orchestrator for delivery module
export function renderDeliveryDashboard(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';
  const resolvedMode = mode || suffix;

  container.innerHTML = `
    <div class="delivery-dashboard-wrapper" style="display: flex; flex-direction: column; gap: 20px; width: 100%;">
      <div id="otif-section-target-${suffix}"></div>
      <div id="mape-section-target-${suffix}"></div>
      <div id="production-section-target-${suffix}"></div>
      <div id="dispatch-section-target-${suffix}"></div>
      <div id="bus-engine-section-target-${suffix}"></div>
    </div>
  `;

  renderOtifSection(kpis, `otif-section-target-${suffix}`, resolvedMode);
  renderMapeSection(kpis, `mape-section-target-${suffix}`, resolvedMode);
  renderProductionSection(kpis, `production-section-target-${suffix}`, resolvedMode);
  renderDispatchSection(kpis, `dispatch-section-target-${suffix}`, resolvedMode);
  renderBusEngineSection(kpis, `bus-engine-section-target-${suffix}`, resolvedMode);
}

// Group 1: On-Time In-Full (OTIF) & Delivery Compliance
export function renderOtifSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const otifIds = ['otif_dom', 'otif_ib', 'otif_spares', 'spd'];
  const groupKpis = kpis.filter(k => otifIds.includes(k.id));

  let html = `
    <div class="card otif-card" style="height: 100%;">
      <div class="card-header">OTIF & Delivery Compliance</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Compliance Metric</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th class="col-target" style="width: 13%;">Target</th>
              <th class="col-actual" style="width: 13%;">Actual</th>
              <th class="col-status-letter" style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, mode);
    const ach = parseFloat(getAchievement(kpi, mode).toFixed(2));
    const status = getStatus(kpi, mode);
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 1}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit === 'percent' ? '%' : kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target, kpi.unit)}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual, kpi.unit)}</td>
        <td class="cell-status status-${status.toLowerCase()}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  container.innerHTML = html;
}

// Group 2: Demand Planning Accuracy (1-MAPE)
export function renderMapeSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const mapeIds = ['mape_dom_ilmcv', 'mape_dom_hcv', 'mape_dom_cvp', 'mape_ib'];
  const groupKpis = kpis.filter(k => mapeIds.includes(k.id));

  let html = `
    <div class="card mape-card" style="height: 100%;">
      <div class="card-header">Demand Planning Accuracy (1-MAPE)</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Forecast Metric</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th class="col-target" style="width: 13%;">Target</th>
              <th class="col-actual" style="width: 13%;">Actual</th>
              <th class="col-status-letter" style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, mode);
    const ach = parseFloat(getAchievement(kpi, mode).toFixed(2));
    const status = getStatus(kpi, mode);
    html += `
      <tr>
        <td style="text-align: left; font-weight: 500;">${idx + 5}. ${kpi.name}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit === 'percent' ? '%' : kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target, kpi.unit)}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual, kpi.unit)}</td>
        <td class="cell-status status-${status.toLowerCase()}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  container.innerHTML = html;
}

// Group 3: Production Output vs Target
export function renderProductionSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';

  let html = `
    <div class="card production-card" style="height: 100%;">
      <div class="card-header">Production Output vs Target</div>
      <div class="card-body" style="padding: 15px; display: flex; flex-direction: row; gap: 20px; flex-wrap: wrap;">
        
        <!-- Left Plot: Production by Line -->
        <div style="flex: 1 1 280px; display: flex; flex-direction: column; min-height: 250px; position: relative;">
          <div style="font-weight: 700; color: var(--primary-navy); margin-bottom: 6px; font-size: 13px; border-left: 3px solid var(--primary-navy); padding-left: 8px;">Production by Line</div>
          <div style="flex: 1; min-height: 210px; position: relative;">
            <canvas id="delivery-production-line-canvas-${suffix}"></canvas>
          </div>
        </div>

        <!-- Right Plot: Production by Segment -->
        <div style="flex: 1 1 280px; display: flex; flex-direction: column; min-height: 250px; position: relative;">
          <div style="font-weight: 700; color: var(--primary-navy); margin-bottom: 6px; font-size: 13px; border-left: 3px solid var(--primary-navy); padding-left: 8px;">Production by Segment</div>
          <div style="flex: 1; min-height: 210px; position: relative;">
            <canvas id="delivery-production-segment-canvas-${suffix}"></canvas>
          </div>
        </div>

      </div>
    </div>
  `;
  container.innerHTML = html;

  // Render the comparison bar charts
  setTimeout(() => {
    // 1. Production by Line Chart
    const lineCanvas = document.getElementById(`delivery-production-line-canvas-${suffix}`);
    if (lineCanvas) {
      if (window[`deliveryProductionLineChart_${suffix}`]) {
        window[`deliveryProductionLineChart_${suffix}`].destroy();
        window[`deliveryProductionLineChart_${suffix}`] = null;
      }

      const l2 = kpis.find(k => k.id === 'prod_l2');
      const l3 = kpis.find(k => k.id === 'prod_l3');
      const tot = kpis.find(k => k.id === 'prod_tot');

      const l2Val = l2 ? (l2.target !== undefined && l2.actual !== undefined ? { target: l2.target, actual: l2.actual } : getKpiForMode(l2, mode)) : { target: 1404, actual: 1422 };
      const l3Val = l3 ? (l3.target !== undefined && l3.actual !== undefined ? { target: l3.target, actual: l3.actual } : getKpiForMode(l3, mode)) : { target: 644, actual: 525 };
      const totVal = tot && (tot.target !== undefined && tot.actual !== undefined && tot.target > 0)
        ? { target: tot.target, actual: tot.actual }
        : { target: l2Val.target + l3Val.target, actual: l2Val.actual + l3Val.actual };

      let l2Tgt = l2Val.target;
      let l2Act = l2Val.actual;
      let l3Tgt = l3Val.target;
      let l3Act = l3Val.actual;
      let totTgt = totVal.target;
      let totAct = totVal.actual;

      const targets = [l2Tgt, l3Tgt, totTgt];
      const actuals = [l2Act, l3Act, totAct];

      const lineColors = actuals.map((act, idx) => {
        const tgt = targets[idx];
        if (!tgt || tgt === 0) return '#10b981';
        const ach = (act / tgt) * 100;
        if (ach >= 100) return '#10b981'; // green-500
        if (ach >= 80) return '#f59e0b';  // yellow-500
        return '#ef4444';                 // red-500
      });

      window[`deliveryProductionLineChart_${suffix}`] = new Chart(lineCanvas, {
        type: 'bar',
        data: {
          labels: ['Line 2', 'Line 3', 'Total'],
          datasets: [
            {
              label: 'Target',
              data: targets,
              backgroundColor: '#3b82f6', // blue-500
              borderRadius: 4
            },
            {
              label: 'Actual',
              data: actuals,
              backgroundColor: lineColors,
              borderRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          barPercentage: 0.55,
          categoryPercentage: 0.55,
          plugins: {
            legend: {
              display: true,
              position: 'top',
              labels: {
                boxWidth: 8,
                font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' }
              }
            },
            tooltip: {
              backgroundColor: '#111827',
              titleFont: { family: 'Outfit, Inter, sans-serif', size: 10 },
              bodyFont: { family: 'Outfit, Inter, sans-serif', size: 10 },
              callbacks: {
                label: function(context) {
                  return ` ${context.dataset.label}: ${context.raw} Nos`;
                }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
                color: '#4b5563'
              },
              grid: { color: 'rgba(243, 244, 246, 0.8)' }
            },
            x: {
              ticks: {
                font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
                color: '#4b5563'
              },
              grid: { display: false }
            }
          }
        },
        plugins: [datalabelsPlugin]
      });
    }

    // 2. Production by Segment Chart
    const segmentCanvas = document.getElementById(`delivery-production-segment-canvas-${suffix}`);
    if (segmentCanvas) {
      if (window[`deliveryProductionSegmentChart_${suffix}`]) {
        window[`deliveryProductionSegmentChart_${suffix}`].destroy();
        window[`deliveryProductionSegmentChart_${suffix}`] = null;
      }

      const dom = kpis.find(k => k.id === 'prod_dom');
      const ib = kpis.find(k => k.id === 'prod_int');
      const tot = kpis.find(k => k.id === 'prod_tot');

      const domVal = dom ? (dom.target !== undefined && dom.actual !== undefined ? { target: dom.target, actual: dom.actual } : getKpiForMode(dom, mode)) : { target: 1814, actual: 1759 };
      const ibVal = ib ? (ib.target !== undefined && ib.actual !== undefined ? { target: ib.target, actual: ib.actual } : getKpiForMode(ib, mode)) : { target: 234, actual: 188 };
      const totVal = tot && (tot.target !== undefined && tot.actual !== undefined && tot.target > 0)
        ? { target: tot.target, actual: tot.actual }
        : { target: domVal.target + ibVal.target, actual: domVal.actual + ibVal.actual };

      const targets = [
        domVal.target,
        ibVal.target,
        totVal.target
      ];
      const actuals = [
        domVal.actual,
        ibVal.actual,
        totVal.actual
      ];

      const segmentColors = actuals.map((act, idx) => {
        const tgt = targets[idx];
        if (!tgt || tgt === 0) return '#10b981';
        const ach = (act / tgt) * 100;
        if (ach >= 100) return '#10b981'; // green-500
        if (ach >= 80) return '#f59e0b';  // yellow-500
        return '#ef4444';                 // red-500
      });

      window[`deliveryProductionSegmentChart_${suffix}`] = new Chart(segmentCanvas, {
        type: 'bar',
        data: {
          labels: ['Domestic', 'Export', 'Total'],
          datasets: [
            {
              label: 'Target',
              data: targets,
              backgroundColor: '#3b82f6', // blue-500
              borderRadius: 4
            },
            {
              label: 'Actual',
              data: actuals,
              backgroundColor: segmentColors,
              borderRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          barPercentage: 0.55,
          categoryPercentage: 0.55,
          plugins: {
            legend: {
              display: true,
              position: 'top',
              labels: {
                boxWidth: 8,
                font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' }
              }
            },
            tooltip: {
              backgroundColor: '#111827',
              titleFont: { family: 'Outfit, Inter, sans-serif', size: 10 },
              bodyFont: { family: 'Outfit, Inter, sans-serif', size: 10 },
              callbacks: {
                label: function(context) {
                  return ` ${context.dataset.label}: ${context.raw} Nos`;
                }
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
                color: '#4b5563'
              },
              grid: { color: 'rgba(243, 244, 246, 0.8)' }
            },
            x: {
              ticks: {
                font: { size: 9, weight: 'bold', family: 'Outfit, Inter, sans-serif' },
                color: '#4b5563'
              },
              grid: { display: false }
            }
          }
        },
        plugins: [datalabelsPlugin]
      });
    }
  }, 0);
}

// Group 4: Dispatch Operations
export function renderDispatchSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const dispIds = ['disp_tmbsl', 'disp_acgl', 'disp_imac', 'disp_jcbl', 'disp_otherbb', 'disp_direct', 'disp_ev', 'disp_tot'];
  const groupKpis = kpis.filter(k => dispIds.includes(k.id));

  let html = `
    <div class="card dispatch-card" style="height: 100%;">
      <div class="card-header">Dispatch Operations</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Dispatch Destination</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th class="col-target" style="width: 13%;">Target</th>
              <th class="col-actual" style="width: 13%;">Actual</th>
              <th class="col-status-letter" style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, mode);
    const ach = parseFloat(getAchievement(kpi, mode).toFixed(2));
    const status = getStatus(kpi, mode);
    const isTotal = kpi.id === 'disp_tot' ? 'font-bold' : '';
    html += `
      <tr class="${isTotal}">
        <td style="text-align: left; ${kpi.id === 'disp_tot' ? 'font-weight: 700;' : 'font-weight: 500;'}">${idx + 9}. ${kpi.name.replace('Dispatch - ', '')}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target, kpi.unit)}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual, kpi.unit)}</td>
        <td class="cell-status status-${status.toLowerCase()}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  container.innerHTML = html;
}

// Group 5: Bus Engine Dispatches
export function renderBusEngineSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const busIds = [
    'bus_4spcr_nac', 'bus_4spcr_ac', 'bus_maxicab_nac', 'bus_cx2_nac', 
    'bus_10_2_4sp', 'bus_3_3l_nac', 'bus_3_3l_ac', 'bus_ib912_bs3', 
    'bus_ib712_bs3', 'bus_ib712_bs4', 'bus_tot'
  ];
  const groupKpis = kpis.filter(k => busIds.includes(k.id));

  let html = `
    <div class="card bus-engine-card" style="margin-bottom: 20px;">
      <div class="card-header">Bus Engine Dispatches</div>
      <div class="card-body scrollable-table-container">
        <table class="dashboard-table">
          <thead>
            <tr>
              <th style="text-align: left; width: 34%;">Engine Specification</th>
              <th style="text-align: center; width: 20%;">Measure</th>
              <th class="col-uom" style="width: 10%;">UoM</th>
              <th class="col-target" style="width: 13%;">Target</th>
              <th class="col-actual" style="width: 13%;">Actual</th>
              <th class="col-status-letter" style="width: 10%;">Status</th>
            </tr>
          </thead>
          <tbody>
  `;

  groupKpis.forEach((kpi, idx) => {
    const { target, actual } = getKpiForMode(kpi, mode);
    const ach = parseFloat(getAchievement(kpi, mode).toFixed(2));
    const status = getStatus(kpi, mode);
    const isTotal = kpi.id === 'bus_tot' ? 'font-bold' : '';
    html += `
      <tr class="${isTotal}">
        <td style="text-align: left; ${kpi.id === 'bus_tot' ? 'font-weight: 700;' : 'font-weight: 500;'}">${idx + 17}. ${kpi.name.replace('Bus Engine - ', '')}</td>
        <td style="text-align: center;">${renderDirectionBadge(kpi)}</td>
        <td class="col-uom">${kpi.unit || '-'}</td>
        <td class="col-target" style="font-weight: 700; color: #000000; font-size: 13px;">${formatValue(target, kpi.unit)}</td>
        <td class="col-actual" style="font-weight: 800; color: #000000; font-size: 13px;">${formatValue(actual, kpi.unit)}</td>
        <td class="cell-status status-${status.toLowerCase()}"><span class="status-pill">${ach}%</span></td>
      </tr>
    `;
  });

  html += `
          </tbody>
        </table>
      </div>
    </div>
  `;
  
  container.innerHTML = html;
}
