// Data Editor Component

import { state, syncKpiToMonthlyData, updateAllBaseSnapshots } from '../state.js';

export function initDataEditor(onSaveCallback) {
  const drawer = document.getElementById('data-editor-drawer');
  const openBtn = document.getElementById('btn-open-editor');
  const closeBtn = document.getElementById('btn-close-editor');
  const saveBtn = document.getElementById('btn-save-editor');
  const cancelBtn = document.getElementById('btn-cancel-editor');
  const sectionSelect = document.getElementById('editor-section-select');
  const fieldsContainer = document.getElementById('editor-fields-container');

  if (!drawer || !openBtn || !closeBtn || !saveBtn || !cancelBtn || !sectionSelect || !fieldsContainer) {
    return;
  }

  // Open drawer
  openBtn.addEventListener('click', () => {
    updateSectionSelector();
    drawer.classList.add('open');
    renderEditorFields(sectionSelect.value);
  });

  // Close drawer
  const closeDrawer = () => drawer.classList.remove('open');
  closeBtn.addEventListener('click', closeDrawer);
  cancelBtn.addEventListener('click', closeDrawer);

  // Handle section dropdown change
  sectionSelect.addEventListener('change', (e) => {
    renderEditorFields(e.target.value);
  });

  // Dynamically rebuild editor dropdown options based on the active module
  function updateSectionSelector() {
    if (state.currentModule === 'safety') {
      sectionSelect.innerHTML = `
        <option value="safety_dashboard">Safety Dashboard Table</option>
        <option value="meeting_compliance">Meeting Compliance Table</option>
        <option value="horizontal_deployment">Horizontal Deployment</option>
        <option value="workplace_condition">Workplace Condition</option>
        <option value="safety_triangle">Safety Triangle / Incidents</option>
      `;
    } else {
      const cap = state.currentModule.charAt(0).toUpperCase() + state.currentModule.slice(1);
      sectionSelect.innerHTML = `
        <option value="all">All ${cap} KPIs</option>
      `;
    }
  }

  // Render inputs for the selected section
  function renderEditorFields(section) {
    const filteredKpis = section === 'all' 
      ? state.kpis.filter(k => k.module === state.currentModule) 
      : state.kpis.filter(k => k.section === section);
      
    let html = '';

    filteredKpis.forEach(kpi => {
      html += `
        <div class="editor-field-group" data-id="${kpi.id}">
          <label class="field-kpi-name">${kpi.name}</label>
          <div class="field-inputs">
            <div class="input-wrap">
              <span class="input-label">${kpi.targetLabel || 'Target'}</span>
              <input type="number" step="any" class="input-target" value="${kpi.target}">
            </div>
            <div class="input-wrap">
              <span class="input-label">${kpi.actualLabel || 'Actual'}</span>
              <input type="number" step="any" class="input-actual" value="${kpi.actual}">
            </div>
          </div>
        </div>
      `;
    });

    fieldsContainer.innerHTML = html;
  }

  // Save changes
  saveBtn.addEventListener('click', () => {
    const fieldGroups = fieldsContainer.querySelectorAll('.editor-field-group');
    
    fieldGroups.forEach(group => {
      const id = group.getAttribute('data-id');
      const targetInput = group.querySelector('.input-target');
      const actualInput = group.querySelector('.input-actual');
      
      if (targetInput && actualInput) {
        const kpi = state.kpis.find(k => k.id === id);
        if (kpi) {
          kpi.target = parseFloat(targetInput.value) || 0;
          kpi.actual = parseFloat(actualInput.value) || 0;
          syncKpiToMonthlyData(kpi);
        }
      }
    });

    updateAllBaseSnapshots();
    closeDrawer();
    if (typeof onSaveCallback === 'function') {
      onSaveCallback();
    }
  });
}

