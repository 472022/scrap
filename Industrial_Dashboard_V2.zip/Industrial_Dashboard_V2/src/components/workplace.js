// Workplace Condition Component

import { state } from '../state.js';

export function renderWorkplaceSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  let title = 'Workplace Condition';
  if (mode) {
    title = mode === 'monthly' ? 'Monthly Workplace Condition' : 'YTD Workplace Condition';
  }

  const smd = state.safetyMonthlyData || {};
  let ficRows = smd.redBlueCornerFic || [];

  // Fallback initial FIC rows if no dataset Excel file is uploaded yet
  if (!ficRows || ficRows.length === 0) {
    const redKpi = kpis.find(k => k.id === 'red_corner');
    const blueKpi = kpis.find(k => k.id === 'blue_corner');
    const redTarget = redKpi ? redKpi.target : 28;
    const redActual = redKpi ? redKpi.actual : 24;
    const blueTarget = blueKpi ? blueKpi.target : 94;
    const blueActual = blueKpi ? blueKpi.actual : 50;

    ficRows = [
      { name: 'FRM, BIW, APS & CM', redSample: 0, redClosed: 0, blueSample: 0, blueClosed: 0 },
      { name: 'Materials', redSample: 2, redClosed: 2, blueSample: 67, blueClosed: Math.min(67, blueActual) },
      { name: 'Office', redSample: 2, redClosed: 2, blueSample: 2, blueClosed: 2 },
      { name: 'Quality', redSample: 0, redClosed: 0, blueSample: 7, blueClosed: 7 },
      { name: 'Technical Services', redSample: 3, redClosed: 3, blueSample: 0, blueClosed: 0 },
      { name: 'Vehicle Factory', redSample: Math.max(0, redTarget - 7), redClosed: Math.max(0, redActual - 7), blueSample: Math.max(0, blueTarget - 76), blueClosed: Math.max(0, blueActual - 76) }
    ];
  }

  let totRedSample = 0, totRedClosed = 0, totBlueSample = 0, totBlueClosed = 0;
  ficRows.forEach(r => {
    totRedSample += (Number(r.redSample) || 0);
    totRedClosed += (Number(r.redClosed) || 0);
    totBlueSample += (Number(r.blueSample) || 0);
    totBlueClosed += (Number(r.blueClosed) || 0);
  });

  const totRedScore = totRedSample > 0 ? Math.min(100, Math.round((totRedClosed / totRedSample) * 100)) : 100;
  const totBlueScore = totBlueSample > 0 ? Math.min(100, Math.round((totBlueClosed / totBlueSample) * 100)) : 100;

  let html = `
    <div class="card workplace-card">
      <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
        <span>${title}</span>
        <span style="font-size: 11.5px; font-weight: 600; color: #cbd5e1; text-transform: uppercase; letter-spacing: 0.3px;">📍 Red Corner & Blue Corner Telemetry Audit</span>
      </div>
      <div class="card-body" style="padding: 16px;">
        <div class="scrollable-table-container">
          <table class="dashboard-table" style="font-size: 12.5px; border-collapse: separate; border-spacing: 0; border: 1px solid #cbd5e1; border-radius: 8px; overflow: hidden; width: 100%;">
            <thead>
              <tr style="background: #0f172a; color: #ffffff;">
                <th rowspan="2" style="text-align: left; vertical-align: middle; border-right: 1px solid #334155; padding: 10px 14px; font-weight: 800; width: 22%;">FIC</th>
                <th colspan="3" style="text-align: center; border-right: 1px solid #334155; padding: 8px; background: #991b1b; color: #ffffff; font-weight: 800; width: 39%;">RED CORNER</th>
                <th colspan="3" style="text-align: center; padding: 8px; background: #1e40af; color: #ffffff; font-weight: 800; width: 39%;">BLUE CORNER</th>
              </tr>
              <tr style="background: #f8fafc; color: #334155; font-size: 11px; font-weight: 800;">
                <th style="text-align: center; border-right: 1px solid #e2e8f0; border-top: 1px solid #cbd5e1; padding: 7px;">NO. OF RED CORNER SAMPLE</th>
                <th style="text-align: center; border-right: 1px solid #e2e8f0; border-top: 1px solid #cbd5e1; padding: 7px;">NO. OF RED CORNER CLOSED</th>
                <th style="text-align: center; border-right: 1px solid #cbd5e1; border-top: 1px solid #cbd5e1; padding: 7px;">SCORE (%)</th>
                <th style="text-align: center; border-right: 1px solid #e2e8f0; border-top: 1px solid #cbd5e1; padding: 7px;">NO. OF BLUE CORNER SAMPLE</th>
                <th style="text-align: center; border-right: 1px solid #e2e8f0; border-top: 1px solid #cbd5e1; padding: 7px;">NO. OF BLUE CORNER CLOSED</th>
                <th style="text-align: center; border-top: 1px solid #cbd5e1; padding: 7px;">SCORE (%)</th>
              </tr>
            </thead>
            <tbody>
  `;

  ficRows.forEach((r, fIdx) => {
    const rSample = Number(r.redSample) || 0;
    const rClosed = Number(r.redClosed) || 0;
    const bSample = Number(r.blueSample) || 0;
    const bClosed = Number(r.blueClosed) || 0;

    const redScore = rSample > 0 ? Math.min(100, Math.round((rClosed / rSample) * 100)) : 100;
    const blueScore = bSample > 0 ? Math.min(100, Math.round((bClosed / bSample) * 100)) : 100;

    const rowBg = fIdx % 2 === 0 ? '#ffffff' : '#f8fafc';

    html += `
      <tr style="background: ${rowBg}; border-bottom: 1px solid #e2e8f0;">
        <td style="text-align: left; font-weight: 700; color: #0f172a; padding: 9px 14px; border-right: 1px solid #e2e8f0;">${r.name}</td>
        <td style="text-align: center; font-weight: 700; padding: 7px; border-right: 1px solid #e2e8f0; color: #0f172a;">${rSample}</td>
        <td style="text-align: center; font-weight: 800; color: #15803d; padding: 7px; border-right: 1px solid #e2e8f0;">${rClosed}</td>
        <td style="text-align: center; font-weight: 800; color: ${redScore >= 100 ? '#15803d' : (redScore >= 80 ? '#b45309' : '#b91c1c')}; padding: 7px; border-right: 1px solid #cbd5e1; background: ${redScore >= 100 ? '#f0fdf4' : (redScore >= 80 ? '#fef3c7' : '#fef2f2')};">${redScore}%</td>
        <td style="text-align: center; font-weight: 700; padding: 7px; border-right: 1px solid #e2e8f0; color: #0f172a;">${bSample}</td>
        <td style="text-align: center; font-weight: 800; color: #15803d; padding: 7px; border-right: 1px solid #e2e8f0;">${bClosed}</td>
        <td style="text-align: center; font-weight: 800; color: ${blueScore >= 100 ? '#15803d' : (blueScore >= 80 ? '#b45309' : '#b91c1c')}; padding: 7px; background: ${blueScore >= 100 ? '#f0fdf4' : (blueScore >= 80 ? '#fef3c7' : '#fef2f2')};">${blueScore}%</td>
      </tr>
    `;
  });

  html += `
      <tr style="background: #f1f5f9; font-weight: 900; border-top: 2px solid #cbd5e1;">
        <td style="text-align: left; padding: 10px 14px; border-right: 1px solid #cbd5e1; color: #0f172a; font-weight: 900;">Grand Total</td>
        <td style="text-align: center; padding: 8px; border-right: 1px solid #cbd5e1; color: #0f172a; font-weight: 900;">${totRedSample}</td>
        <td style="text-align: center; padding: 8px; border-right: 1px solid #cbd5e1; color: #15803d; font-weight: 900;">${totRedClosed}</td>
        <td style="text-align: center; padding: 8px; border-right: 1px solid #cbd5e1; color: ${totRedScore >= 100 ? '#15803d' : (totRedScore >= 80 ? '#b45309' : '#b91c1c')}; background: ${totRedScore >= 100 ? '#dcfce7' : (totRedScore >= 80 ? '#fef3c7' : '#fee2e2')}; font-weight: 900;">${totRedScore}%</td>
        <td style="text-align: center; padding: 8px; border-right: 1px solid #cbd5e1; color: #0f172a; font-weight: 900;">${totBlueSample}</td>
        <td style="text-align: center; padding: 8px; border-right: 1px solid #cbd5e1; color: #15803d; font-weight: 900;">${totBlueClosed}</td>
        <td style="text-align: center; padding: 8px; color: ${totBlueScore >= 100 ? '#15803d' : (totBlueScore >= 80 ? '#b45309' : '#b91c1c')}; background: ${totBlueScore >= 100 ? '#dcfce7' : (totBlueScore >= 80 ? '#fef3c7' : '#fee2e2')}; font-weight: 900;">${totBlueScore}%</td>
      </tr>
    </tbody>
  </table>
</div>
      </div>
    </div>
  `;

  container.innerHTML = html;
}
