// Compliance and Horizontal Deployment Component

import { getAchievement, getStatus, getSafetyKpiForMode } from '../state.js';

export function renderComplianceSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;

  const deploymentKpis = kpis.filter(k => k.section === 'horizontal_deployment');

  let html = `
    <div class="card compliance-card">
      <div class="card-header">Horizontal Deployment</div>
      <div class="card-body">
        <!-- Horizontal Deployment Progress Chart -->
        <div class="horizontal-deployment-chart" style="margin-top: 0; border-top: none; padding-top: 0;">
          <div class="chart-y-axis">
  `;

  // Render bars from top to bottom (Phase 3 then Phase 2)
  const sortedDeployment = [...deploymentKpis].sort((a, b) => b.name.localeCompare(a.name));

  sortedDeployment.forEach((kpi) => {
    let target = kpi.target;
    let actual = kpi.actual;
    if (mode) {
      const valObj = getSafetyKpiForMode(kpi, mode);
      target = valObj.target;
      actual = valObj.actual;
    }

    const ach = getAchievement(kpi, mode);
    
    // Determine bar color based on phase completion
    let barColorClass = 'bar-yellow';
    if (ach >= 95) {
      barColorClass = 'bar-green';
    } else if (ach < 40) {
      barColorClass = 'bar-red';
    }

    html += `
      <div class="deployment-row">
        <span class="phase-label">${kpi.name}</span>
        <div class="bar-container">
          <div class="progress-bar ${barColorClass}" style="width: ${ach}%"></div>
          <span class="bar-value-label">${Math.round(ach)}%</span>
        </div>
      </div>
    `;
  });

  html += `
          </div>
          <!-- X-Axis Labels -->
          <div class="chart-x-axis" style="margin-top: 8px;">
            <span>0%</span>
            <span>20%</span>
            <span>40%</span>
            <span>60%</span>
            <span>80%</span>
            <span>100%</span>
          </div>
        </div>
      </div>
    </div>
  `;

  container.innerHTML = html;
}
