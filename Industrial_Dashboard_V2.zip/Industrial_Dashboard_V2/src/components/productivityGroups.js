// Productivity Dashboard Groupings Component

import { Chart } from 'chart.js';
import { state, getAchievement, getStatus, getKpiForMode } from '../state.js';

// Chart instances to prevent canvas reuse errors
const chartInstances = {};

// Custom plugin to show datalabels on top of bars and line points (keeping at most 1 decimal place)
const prodDatalabelsPlugin = {
  id: 'prodDatalabels',
  afterDatasetsDraw(chart) {
    const { ctx } = chart;
    ctx.save();
    ctx.font = 'bold 9px Inter, system-ui, sans-serif';
    ctx.fillStyle = '#1e2d5a';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';

    chart.data.datasets.forEach((dataset, datasetIndex) => {
      const meta = chart.getDatasetMeta(datasetIndex);
      meta.data.forEach((element, index) => {
        const val = dataset.data[index];
        if (val !== null && val !== undefined) {
          let label = typeof val === 'number' ? (Number.isInteger(val) ? val : parseFloat(val.toFixed(1))) : val;
          // Format as percentage if it's the Line Performance chart
          if (chart.canvas.id && chart.canvas.id.includes('prod-line-avail-canvas')) {
            label = `${label}%`;
          }
          // Format as currency if it's CPeV and not target label (unless target matches too)
          if (chart.canvas.id && chart.canvas.id.includes('prod-cpev') && val > 1000) {
            label = `Rs. ${Math.round(val).toLocaleString()}`;
          }
          ctx.fillText(label, element.x, element.y - 4);
        }
      });
    });
    ctx.restore();
  }
};

// Helper to format values with UoM dynamically (keeping max 2 decimal digits)
function formatValue(val, unit) {
  if (val === undefined || val === null) return '-';
  if (typeof val !== 'number') return val;
  
  if (unit === 'percent' || unit === 'Paercentage' || unit === '%') {
    let rawPct = val;
    if (val <= 1.0) {
      rawPct = val * 100;
    }
    return `${parseFloat(rawPct.toFixed(2))}%`;
  }
  if (unit === 'ratio') {
    return `${parseFloat((val * 100).toFixed(2))}%`;
  }
  
  const formattedNum = parseFloat(val.toFixed(2));
  return `${formattedNum} ${unit || ''}`.trim();
}

// Group 1: Efficiency (HPeV & CPeV)
export function renderHpevSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const suffix = (typeof mode === 'string' && mode) ? mode : (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');
  const resolvedMode = suffix;
  const isYtd = suffix === 'ytd';

  const formatName = (kpi) => {
    if (!kpi || !kpi.name) return '';
    if (isYtd) {
      return kpi.name.replace(/\(FTM\)/gi, '(YTD)').replace(/\(For The Month\)/gi, '(YTD)');
    }
    return kpi.name;
  };

  const hpev3 = kpis.find(k => k.id === 'hpev_3');
  const hpev4 = kpis.find(k => k.id === 'hpev_4');
  const cpev = kpis.find(k => k.id === 'cpev');

  const hpev3Val = hpev3 ? getKpiForMode(hpev3, resolvedMode) : { target: 45, actual: 42.34 };
  const hpev4Val = hpev4 ? getKpiForMode(hpev4, resolvedMode) : { target: 61.9, actual: 57.37 };
  const cpevVal = cpev ? getKpiForMode(cpev, resolvedMode) : { target: 30710, actual: 25785 };

  let html = `
    <div class="card efficiency-card">
      <div class="card-header">Efficiency (HPeV & CPeV)</div>
      <div class="card-body efficiency-flex">
  `;

  // Render HPeV cards with Canvas for target/actual comparative bar graph
  [hpev3, hpev4].forEach(kpi => {
    if (kpi) {
      const status = getStatus(kpi, resolvedMode);
      html += `
        <div class="eff-metric-box border-${status.toLowerCase()}" style="min-height: 180px; display: flex; flex-direction: column; justify-space-between; padding: 15px;">
          <div class="eff-label" style="font-weight: 700; color: var(--primary-navy);">${formatName(kpi)}</div>
          <div style="width: 100%; max-width: 180px; margin: 10px auto 0 auto; height: 95px; position: relative;">
            <canvas id="prod-${kpi.id}-canvas-${suffix}"></canvas>
          </div>
        </div>
      `;
    }
  });

  // Render CPeV (Cost) card alongside HPEV cards in the same row
  if (cpev) {
    const status = getStatus(cpev, resolvedMode);
    html += `
      <div class="eff-metric-box border-${status.toLowerCase()}" style="min-height: 180px; display: flex; flex-direction: column; justify-content: space-between; padding: 15px;">
        <div class="eff-label" style="font-weight: 700; color: var(--primary-navy);">${formatName(cpev)}</div>
        <div style="width: 100%; max-width: 180px; margin: 10px auto 0 auto; height: 95px; position: relative;">
          <canvas id="prod-cpev-card-canvas-${suffix}"></canvas>
        </div>
      </div>
    `;
  }

  html += `
      </div>
    </div>
  `;

  container.innerHTML = html;

  // Render comparative bar graphs on the next tick
  setTimeout(() => {
    // 1. HPEV 3
    const ctx3 = document.getElementById(`prod-hpev_3-canvas-${suffix}`);
    if (ctx3 && hpev3) {
      if (chartInstances[`hpev3ChartInstance_${suffix}`]) chartInstances[`hpev3ChartInstance_${suffix}`].destroy();
      const tVal = parseFloat(hpev3Val.target.toFixed(2));
      const aVal = parseFloat(hpev3Val.actual.toFixed(2));
      const actColor = aVal > tVal ? '#ef4444' : '#10b981';
      
      chartInstances[`hpev3ChartInstance_${suffix}`] = new Chart(ctx3, {
        type: 'bar',
        data: {
          labels: ['Target', 'Actual'],
          datasets: [{
            data: [tVal, aVal],
            backgroundColor: ['#3b82f6', actColor],
            borderRadius: 4,
            barThickness: 24
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          layout: {
            padding: {
              top: 18,
              bottom: 0,
              left: 4,
              right: 4
            }
          },
          plugins: { legend: { display: false } },
          scales: {
            y: { display: false, max: Math.max(tVal, aVal) * 1.35, grid: { display: false } },
            x: { grid: { display: false }, ticks: { font: { size: 10, weight: 'bold' } } }
          }
        },
        plugins: [prodDatalabelsPlugin]
      });
    }

    // 2. HPEV 4
    const ctx4 = document.getElementById(`prod-hpev_4-canvas-${suffix}`);
    if (ctx4 && hpev4) {
      if (chartInstances[`hpev4ChartInstance_${suffix}`]) chartInstances[`hpev4ChartInstance_${suffix}`].destroy();
      const tVal = parseFloat(hpev4Val.target.toFixed(2));
      const aVal = parseFloat(hpev4Val.actual.toFixed(2));
      const actColor = aVal > tVal ? '#ef4444' : '#10b981';
      
      chartInstances[`hpev4ChartInstance_${suffix}`] = new Chart(ctx4, {
        type: 'bar',
        data: {
          labels: ['Target', 'Actual'],
          datasets: [{
            data: [tVal, aVal],
            backgroundColor: ['#3b82f6', actColor],
            borderRadius: 4,
            barThickness: 24
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          layout: {
            padding: {
              top: 18,
              bottom: 0,
              left: 4,
              right: 4
            }
          },
          plugins: { legend: { display: false } },
          scales: {
            y: { display: false, max: Math.max(tVal, aVal) * 1.35, grid: { display: false } },
            x: { grid: { display: false }, ticks: { font: { size: 10, weight: 'bold' } } }
          }
        },
        plugins: [prodDatalabelsPlugin]
      });
    }

    // 3. CPEV
    const ctxCpev = document.getElementById(`prod-cpev-card-canvas-${suffix}`);
    if (ctxCpev && cpev) {
      if (chartInstances[`cpevChartInstance_${suffix}`]) chartInstances[`cpevChartInstance_${suffix}`].destroy();
      const tVal = parseFloat(cpevVal.target.toFixed(2));
      const aVal = parseFloat(cpevVal.actual.toFixed(2));
      const actColor = aVal > tVal ? '#ef4444' : '#10b981';
      
      chartInstances[`cpevChartInstance_${suffix}`] = new Chart(ctxCpev, {
        type: 'bar',
        data: {
          labels: ['Target', 'Actual'],
          datasets: [{
            data: [tVal, aVal],
            backgroundColor: ['#3b82f6', actColor],
            borderRadius: 4,
            barThickness: 24
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          layout: {
            padding: {
              top: 18,
              bottom: 0,
              left: 4,
              right: 4
            }
          },
          plugins: { legend: { display: false } },
          scales: {
            y: { display: false, max: Math.max(tVal, aVal) * 1.35, grid: { display: false } },
            x: { grid: { display: false }, ticks: { font: { size: 10, weight: 'bold' } } }
          }
        },
        plugins: [prodDatalabelsPlugin]
      });
    }
  }, 0);
}

// Group 4: Kaizen and Productivity Actions
function oldUnusedKaizenSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const kpi = kpis.find(k => k.id === 'kaizen_productivity');
  if (!kpi) return;

  const { target, actual } = getKpiForMode(kpi, resolvedMode);
  const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(2));
  const status = getStatus(kpi, resolvedMode);

  let html = `
    <div class="card kaizen-card" style="margin-top: 20px;">
      <div class="card-header">Kaizen & Productivity Actions</div>
      <div class="card-body">
        <div class="headcount-row">
          <div class="hc-header">
            <span class="hc-name font-semibold">${kpi.name}</span>
            <span class="hc-badge text-${status.toLowerCase()}">Actual: <strong>${formatValue(actual, kpi.unit)}</strong> <span style="color: #000000; font-weight: 700;">| Target: <strong>${formatValue(target, kpi.unit)}</strong></span></span>
          </div>
          <div class="hc-track">
            <div class="hc-fill fill-${status.toLowerCase()}" style="width: ${ach}%"></div>
          </div>
          <div class="hc-footer">Achievement: <strong>${ach}%</strong></div>
        </div>
      </div>
    </div>
  `;

  // Stack under HPeV card
  container.innerHTML += html;
}

// Group 2: Line Operations (Line Wise metrics with Chart.js charts)
export function renderLineOperations(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const suffix = containerId.endsWith('-ytd') ? 'ytd' : 'monthly';
  const resolvedMode = mode || suffix;

  const getValue = (id) => {
    const k = kpis.find(x => x.id === id);
    if (!k) return { val: 0, valStr: '-', status: 'normal', target: 0, targetStr: '-' };
    const { target, actual } = getKpiForMode(k, resolvedMode);
    const stat = getStatus(k, resolvedMode);
    return { 
      val: actual,
      valStr: formatValue(actual, k.unit), 
      status: stat.toLowerCase(), 
      target: target,
      targetStr: formatValue(target, k.unit) 
    };
  };

  const l2_avail = getValue('line_avail_l2');
  const l3_avail = getValue('line_avail_l3');
  const tot_avail = getValue('line_avail_tot');

  const l2_lost = getValue('min_lost_l2');
  const l3_lost = getValue('min_lost_l3');
  const tot_lost = getValue('min_lost_tot');

  const l2_eff = getValue('line_eff_l2');
  const l3_eff = getValue('line_eff_l3');

  const l2_veh = getValue('veh_day_l2');
  const l3_veh = getValue('veh_day_l3');
  const tot_veh = getValue('veh_day_tot');

  const speed = getValue('line_speed');
  const formation = getValue('line_form_ratio');

  const renderCell = (data) => {
    if (!data || data.valStr === '-') {
      return `<td class="text-center font-bold" style="padding: 12px 8px; font-size: 15px; color: #64748b;">-</td>`;
    }
    return `
      <td class="text-center text-${data.status}" style="padding: 12px 8px;">
        <div style="font-size: 14px; font-weight: 900;">Actual: <span style="font-size: 15px; font-weight: 900;">${data.valStr}</span></div>
        <div class="ops-tgt" style="font-size: 12px; color: #475569; font-weight: 800; margin-top: 2px;">
          Target: <strong style="font-weight: 900; color: #0f172a;">${data.targetStr}</strong>
        </div>
      </td>
    `;
  };

  let html = `
    <!-- Card 1: Numeric Table Data -->
    <div class="card line-ops-card" style="margin-bottom: 20px;">
      <div class="card-header">Line Wise Operations Dashboard</div>
      <div class="card-body scrollable-table-container">
        
        <!-- Matrix Table -->
        <table class="line-ops-table" style="width: 100%; border-collapse: collapse; font-size: 14px; margin-bottom: 5px;">
          <thead>
            <tr style="border-bottom: 2px solid #cbd5e1;">
              <th style="padding: 10px 8px; text-align: left; font-size: 13px; font-weight: 900; color: #0f172a; text-transform: uppercase;">Operation Parameter</th>
              <th class="text-center" style="padding: 10px 8px; font-size: 13px; font-weight: 900; color: #0f172a; text-transform: uppercase;">Line 2</th>
              <th class="text-center" style="padding: 10px 8px; font-size: 13px; font-weight: 900; color: #0f172a; text-transform: uppercase;">Line 3</th>
              <th class="text-center font-bold" style="padding: 10px 8px; font-size: 13px; font-weight: 900; color: #0f172a; text-transform: uppercase;">Total / Plant</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td class="font-semibold" style="font-size: 14px; font-weight: 900; color: #0f172a; padding: 12px 8px;">1. Line Availability</td>
              ${renderCell(l2_avail)}
              ${renderCell(l3_avail)}
              ${renderCell(tot_avail)}
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td class="font-semibold" style="font-size: 14px; font-weight: 900; color: #0f172a; padding: 12px 8px;">2. Minutes Lost</td>
              ${renderCell(l2_lost)}
              ${renderCell(l3_lost)}
              ${renderCell(tot_lost)}
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td class="font-semibold" style="font-size: 14px; font-weight: 900; color: #0f172a; padding: 12px 8px;">3. Line Efficiency</td>
              ${renderCell(l2_eff)}
              ${renderCell(l3_eff)}
              ${renderCell(null)}
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td class="font-semibold" style="font-size: 14px; font-weight: 900; color: #0f172a; padding: 12px 8px;">4. Vehicles / Day</td>
              ${renderCell(l2_veh)}
              ${renderCell(l3_veh)}
              ${renderCell(tot_veh)}
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td class="font-semibold" style="font-size: 14px; font-weight: 900; color: #0f172a; padding: 12px 8px;">5. Line Speed %</td>
              ${renderCell(null)}
              ${renderCell(null)}
              ${renderCell(speed)}
            </tr>
            <tr style="border-bottom: 1px solid #e2e8f0;">
              <td class="font-semibold" style="font-size: 14px; font-weight: 900; color: #0f172a; padding: 12px 8px;">6. Line Formation ratio %</td>
              ${renderCell(null)}
              ${renderCell(null)}
              ${renderCell(formation)}
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Card 2: Standing Analytics Charts -->
    <div class="card line-ops-charts-card">
      <div class="card-header">Operations Visual Analytics</div>
      <div class="card-body">
        
        <!-- Row 1: Side by Side Line performance & Vehicles per day -->
        <div class="charts-row-top">
          <div class="line-ops-chart-box">
            <div class="line-chart-lbl">Line Performance (%)</div>
            <div class="line-chart-canvas-wrap">
              <canvas id="prod-line-avail-canvas-${suffix}"></canvas>
            </div>
          </div>
          
          <div class="line-ops-chart-box">
            <div class="line-chart-lbl">Vehicles Output vs Target (Nos)</div>
            <div class="line-chart-canvas-wrap">
              <canvas id="prod-vehicles-canvas-${suffix}"></canvas>
            </div>
          </div>
        </div>

        <!-- Row 2: Full Width Delays -->
        <div class="charts-row-bottom" style="margin-top: 20px;">
          <div class="line-ops-chart-box full-width">
            <div class="line-chart-lbl">Minutes Lost by Line (Mins)</div>
            <div class="line-chart-canvas-wrap-wide">
              <canvas id="prod-minutes-lost-canvas-${suffix}"></canvas>
            </div>
          </div>
        </div>

      </div>
    </div>
  `;

  container.innerHTML = html;

  // Render Chart.js charts on the next event loop tick
  setTimeout(() => {
    // 1. Line Performance Chart
    const ctxAvail = document.getElementById(`prod-line-avail-canvas-${suffix}`);
    if (ctxAvail) {
      if (chartInstances[`availChartInstance_${suffix}`]) chartInstances[`availChartInstance_${suffix}`].destroy();
      chartInstances[`availChartInstance_${suffix}`] = new Chart(ctxAvail, {
        type: 'bar',
        data: {
          labels: ['Line 2', 'Line 3'],
          datasets: [
            {
              label: 'Availability (%)',
              data: [Math.round(l2_avail.val * 100), Math.round(l3_avail.val * 100)],
              backgroundColor: '#3b82f6',
              borderRadius: 4
            },
            {
              label: 'Efficiency (%)',
              data: [Math.round(l2_eff.val * 100), Math.round(l3_eff.val * 100)],
              backgroundColor: '#10b981',
              borderRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { boxWidth: 10, font: { size: 10 } } } },
          scales: { y: { ticks: { font: { size: 9 } } }, x: { ticks: { font: { size: 9 } } } }
        },
        plugins: [prodDatalabelsPlugin]
      });
    }

    // 2. Minutes Lost Chart
    const ctxLost = document.getElementById(`prod-minutes-lost-canvas-${suffix}`);
    if (ctxLost) {
      if (chartInstances[`lostChartInstance_${suffix}`]) chartInstances[`lostChartInstance_${suffix}`].destroy();
      chartInstances[`lostChartInstance_${suffix}`] = new Chart(ctxLost, {
        type: 'bar',
        data: {
          labels: ['Line 2', 'Line 3', 'Total / Plant'],
          datasets: [{
            label: 'Minutes Lost',
            data: [l2_lost.val, l3_lost.val, tot_lost.val],
            backgroundColor: '#ef4444',
            borderRadius: 4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { boxWidth: 10, font: { size: 10 } } } },
          scales: { y: { ticks: { font: { size: 9 } } }, x: { ticks: { font: { size: 9 } } } }
        },
        plugins: [prodDatalabelsPlugin]
      });
    }

    // 3. Vehicles Output Chart
    const ctxVeh = document.getElementById(`prod-vehicles-canvas-${suffix}`);
    if (ctxVeh) {
      if (chartInstances[`vehiclesChartInstance_${suffix}`]) chartInstances[`vehiclesChartInstance_${suffix}`].destroy();
      chartInstances[`vehiclesChartInstance_${suffix}`] = new Chart(ctxVeh, {
        type: 'bar',
        data: {
          labels: ['Line 2', 'Line 3', 'Total'],
          datasets: [
            {
              label: 'Actual Output',
              data: [l2_veh.val, l3_veh.val, tot_veh.val],
              backgroundColor: '#10b981',
              borderRadius: 4
            },
            {
              label: 'Target Output',
              data: [l2_veh.target, l3_veh.target, tot_veh.target],
              backgroundColor: '#1e2d5a',
              borderRadius: 4
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { labels: { boxWidth: 10, font: { size: 10 } } } },
          scales: { y: { ticks: { font: { size: 9 } } }, x: { ticks: { font: { size: 9 } } } }
        },
        plugins: [prodDatalabelsPlugin]
      });
    }
  }, 0);
}

export function renderKaizenSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const kpi = kpis.find(k => k.id === 'kaizen_productivity');
  if (!kpi) return;

  const { target, actual } = getKpiForMode(kpi, resolvedMode);
  const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));

  const getBadgeDetails = (achVal, tVal, aVal) => {
    if (tVal === 0 && aVal === 0) {
      return { label: 'Complete', bg: '#f1f5f9', fg: '#475569', icon: '⚪', grad: 'linear-gradient(90deg, #94a3b8, #64748b)', border: '#cbd5e1' };
    }
    if (achVal >= 100) {
      return { label: 'Achieved', bg: '#dcfce7', fg: '#15803d', icon: '🟢', grad: 'linear-gradient(90deg, #10b981, #059669)', border: '#86efac' };
    }
    if (achVal >= 50) {
      return { label: 'In Progress', bg: '#fef3c7', fg: '#b45309', icon: '🟡', grad: 'linear-gradient(90deg, #f59e0b, #d97706)', border: '#fde68a' };
    }
    return { label: 'Needs Action', bg: '#fee2e2', fg: '#b91c1c', icon: '🔴', grad: 'linear-gradient(90deg, #ef4444, #dc2626)', border: '#fca5a5' };
  };

  const b = getBadgeDetails(ach, target, actual);
  const pctBar = Math.min(100, Math.max(0, ach));

  let html = `
    <div class="card kaizen-card" style="margin-top: 20px; border: 1.5px solid #e2e8f0; border-radius: 14px; box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05); overflow: hidden; background: #ffffff;">
      <div class="card-header" style="background: #0f172a; color: #ffffff; padding: 14px 20px; font-weight: 900; font-size: 15px; letter-spacing: 0.3px; display: flex; justify-content: space-between; align-items: center;">
        <span>⚡ Kaizen & Productivity Actions</span>
        <span style="font-size: 11.5px; font-weight: 700; color: #94a3b8; background: rgba(255,255,255,0.1); padding: 4px 12px; border-radius: 12px;">Continuous Improvement</span>
      </div>
      <div class="card-body" style="padding: 18px 16px;">
        <div style="display: grid; grid-template-columns: 1fr; gap: 16px;">
          <div style="border: 1.5px solid ${b.border}; border-radius: 12px; background: #ffffff; padding: 14px 18px; box-shadow: 0 4px 14px rgba(0,0,0,0.03); position: relative; overflow: hidden; display: flex; flex-direction: column; justify-content: space-between;">
            <div style="position: absolute; top: 0; left: 0; right: 0; height: 4px; background: ${b.grad};"></div>
            <div style="display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 10px;">
              <div>
                <div style="font-size: 9.5px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.8px;">PROJECT</div>
                <div style="font-weight: 900; font-size: 15px; color: #0f172a; margin-top: 2px;">${kpi.name}</div>
              </div>
              <span style="display: inline-flex; align-items: center; gap: 5px; background: ${b.bg}; color: ${b.fg}; padding: 4px 12px; border-radius: 16px; font-weight: 800; font-size: 11.5px; white-space: nowrap; box-shadow: 0 1px 3px rgba(0,0,0,0.05);">
                ${b.icon} ${b.label}
              </span>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px; text-align: center;">
              <div>
                <div style="font-size: 9.5px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">TARGET (NOS)</div>
                <div style="font-weight: 900; font-size: 16px; color: #0f172a; margin-top: 2px;">${target}</div>
              </div>
              <div>
                <div style="font-size: 9.5px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">ACTUAL (NOS)</div>
                <div style="font-weight: 900; font-size: 16px; color: #0f172a; margin-top: 2px;">${actual}</div>
              </div>
              <div>
                <div style="font-size: 9.5px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">ACHIEVEMENT</div>
                <div style="font-weight: 900; font-size: 15px; color: ${b.fg}; margin-top: 2px;">${ach}%</div>
              </div>
            </div>

            <div style="margin-top: 10px; width: 100%; border-radius: 6px; height: 5px; background: #e2e8f0; overflow: hidden;">
              <div style="width: ${pctBar}%; height: 100%; background: ${b.grad}; border-radius: 6px;"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  container.innerHTML = html;
}

// Group 5: Headcount Optimization
export function renderHeadcountSection(kpis, containerId, mode) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const resolvedMode = mode || (containerId.endsWith('-ytd') ? 'ytd' : 'monthly');

  const headcountKpiIds = [
    { id: 'lean_mfg', label: '1. Lean Mfg.' },
    { id: 'automation', label: '2. Automation' },
    { id: 'lotus_3', label: '3. LOTUS 3.0' },
    { id: 'structural_improvements', label: '4. Structural Improvements' },
    { id: 'headcount_opt', label: 'Total Head Count Optimization', isTotal: true }
  ];

  const getBadgeDetails = (achVal, tVal, aVal) => {
    if (tVal === 0 && aVal === 0) {
      return { label: 'Complete', bg: '#f1f5f9', fg: '#475569', icon: '⚪', grad: 'linear-gradient(90deg, #94a3b8, #64748b)', border: '#cbd5e1' };
    }
    if (achVal >= 100) {
      return { label: 'Achieved', bg: '#dcfce7', fg: '#15803d', icon: '🟢', grad: 'linear-gradient(90deg, #10b981, #059669)', border: '#86efac' };
    }
    if (achVal >= 50) {
      return { label: 'In Progress', bg: '#fef3c7', fg: '#b45309', icon: '🟡', grad: 'linear-gradient(90deg, #f59e0b, #d97706)', border: '#fde68a' };
    }
    return { label: 'Needs Action', bg: '#fee2e2', fg: '#b91c1c', icon: '🔴', grad: 'linear-gradient(90deg, #ef4444, #dc2626)', border: '#fca5a5' };
  };

  // 5 Equal-width columns in 1 single horizontal row for 100% space utilization
  let boxesHtml = '<div style="display: grid; grid-template-columns: repeat(5, 1fr); min-width: 900px; gap: 12px; width: 100%;">';

  headcountKpiIds.forEach(item => {
    const kpi = kpis.find(k => k.id === item.id);
    if (!kpi) return;

    const { target, actual } = getKpiForMode(kpi, resolvedMode);
    const ach = parseFloat(getAchievement(kpi, resolvedMode).toFixed(1));
    const b = getBadgeDetails(ach, target, actual);
    const pctBar = Math.min(100, Math.max(0, ach));

    const totalGrad = 'linear-gradient(90deg, #1e2d5a, #3b82f6)';
    const cardBg = item.isTotal ? '#f8fafc' : '#ffffff';
    const cardBorder = item.isTotal ? '2px solid #3b82f6' : `1.5px solid ${b.border}`;

    // Render Box Tile
    boxesHtml += `
      <div style="border: ${cardBorder}; border-radius: 12px; background: ${cardBg}; padding: 14px 12px; box-shadow: 0 4px 14px -2px rgba(15, 23, 42, 0.05); display: flex; flex-direction: column; justify-content: space-between; position: relative; overflow: hidden;">
        <div style="position: absolute; top: 0; left: 0; right: 0; height: 4px; background: ${item.isTotal ? totalGrad : b.grad};"></div>
        
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 6px; margin-bottom: 10px;">
          <div>
            <div style="font-size: 9.5px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.6px;">PROJECT</div>
            <div style="font-weight: 900; font-size: 13px; color: #0f172a; margin-top: 2px; line-height: 1.25; min-height: 32px; display: flex; align-items: center;">${item.label}</div>
          </div>
          <span style="display: inline-flex; align-items: center; gap: 3px; background: ${b.bg}; color: ${b.fg}; padding: 3px 8px; border-radius: 12px; font-weight: 800; font-size: 10.5px; white-space: nowrap; box-shadow: 0 1px 2px rgba(0,0,0,0.04); flex-shrink: 0;">
            ${b.icon} ${b.label}
          </span>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 4px; background: #ffffff; border: 1px solid #e2e8f0; padding: 10px 4px; border-radius: 8px; margin-top: 4px; text-align: center;">
          <div>
            <div style="font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.3px;">TARGET</div>
            <div style="font-weight: 900; font-size: 14.5px; color: #0f172a; margin-top: 2px;">${target}</div>
          </div>
          <div>
            <div style="font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.3px;">ACTUAL</div>
            <div style="font-weight: 900; font-size: 14.5px; color: #0f172a; margin-top: 2px;">${actual}</div>
          </div>
          <div>
            <div style="font-size: 9px; font-weight: 800; color: #64748b; text-transform: uppercase; letter-spacing: 0.3px;">ACHV %</div>
            <div style="font-weight: 900; font-size: 14px; color: ${b.fg}; margin-top: 2px;">${ach}%</div>
          </div>
        </div>

        <div style="margin-top: 10px; width: 100%; border-radius: 6px; height: 5px; background: #e2e8f0; overflow: hidden;">
          <div style="width: ${pctBar}%; height: 100%; background: ${item.isTotal ? totalGrad : b.grad}; border-radius: 6px;"></div>
        </div>
      </div>
    `;
  });

  boxesHtml += '</div>';

  let html = `
    <div class="card headcount-card" style="margin-top: 20px; border: 1.5px solid #e2e8f0; border-radius: 14px; box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05); overflow: hidden; background: #ffffff;">
      <div class="card-header" style="background: #0f172a; color: #ffffff; padding: 14px 20px; font-weight: 900; font-size: 15px; letter-spacing: 0.3px; display: flex; justify-content: space-between; align-items: center;">
        <span>👥 Headcount Optimization</span>
        <span style="font-size: 11.5px; font-weight: 700; color: #94a3b8; background: rgba(255,255,255,0.1); padding: 4px 12px; border-radius: 12px;">Resource Allocation</span>
      </div>
      <div class="card-body" style="padding: 18px 16px; overflow-x: auto;">
        ${boxesHtml}
      </div>
    </div>
  `;

  container.innerHTML += html;
}
