// Auth Gateway Login Modal Component for Industrial Dashboard V2
import { loginApi } from '../api.js';
import { setAuthSession, state } from '../state.js';

let authCallbackOnSuccess = null;

/**
 * Render or attach the full-screen Login Gateway Modal
 * @param {Function} onSuccessCallback Function to invoke after successful authentication
 */
export function initAuthModal(onSuccessCallback) {
  authCallbackOnSuccess = onSuccessCallback;

  let modal = document.getElementById('auth-gateway-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'auth-gateway-modal';
    modal.className = 'auth-gateway-overlay';
    document.body.appendChild(modal);
  }

  modal.innerHTML = `
    <div class="auth-card-backdrop"></div>
    <div class="auth-card">
      <div class="auth-card-header">
        <div class="auth-brand">
          <span class="auth-shield-badge">🛡️ SECURE GATEWAY</span>
          <h2 class="auth-title">Dharwad Operations Gateway</h2>
          <p class="auth-subtitle">Tata Motors Commercial Vehicles Plant - V2 Access</p>
        </div>
      </div>

      <form id="auth-login-form" class="auth-form">
        <div id="auth-error-banner" class="auth-error-banner" style="display: none;"></div>

        <div class="auth-input-group">
          <label for="auth-username" class="auth-label">Username</label>
          <div class="auth-input-wrapper">
            <span class="auth-input-icon">👤</span>
            <input type="text" id="auth-username" class="auth-input" placeholder="e.g. admin or plant_manager" autocomplete="username" required />
          </div>
        </div>

        <div class="auth-input-group">
          <label for="auth-password" class="auth-label">Password</label>
          <div class="auth-input-wrapper">
            <span class="auth-input-icon">🔑</span>
            <input type="password" id="auth-password" class="auth-input" placeholder="Enter password" autocomplete="current-password" required />
            <button type="button" id="auth-toggle-pwd" class="auth-pwd-toggle" title="Toggle password visibility">👁️</button>
          </div>
        </div>

        <button type="submit" id="auth-submit-btn" class="auth-submit-btn">
          <span class="btn-text">Authenticate & Unlock Dashboard</span>
          <span class="btn-spinner" style="display:none;">⌛ Validating...</span>
        </button>
      </form>

      <div class="auth-footer">
        <span>🔒 256-bit PBKDF2 Password Hashing & SQLite Session Control</span>
      </div>
    </div>
  `;

  attachAuthEventListeners();
}

/**
 * Attach form submit, toggle password, and keydown handlers
 */
function attachAuthEventListeners() {
  const form = document.getElementById('auth-login-form');
  const togglePwdBtn = document.getElementById('auth-toggle-pwd');
  const passwordInput = document.getElementById('auth-password');
  const usernameInput = document.getElementById('auth-username');
  const submitBtn = document.getElementById('auth-submit-btn');

  if (togglePwdBtn && passwordInput) {
    togglePwdBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const isPwd = passwordInput.type === 'password';
      passwordInput.type = isPwd ? 'text' : 'password';
      togglePwdBtn.textContent = isPwd ? '🙈' : '👁️';
    });
  }

  const triggerLoginSubmit = (e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    const u = usernameInput ? usernameInput.value.trim() : '';
    const p = passwordInput ? passwordInput.value.trim() : '';
    handleLogin(u, p);
  };

  if (form) {
    form.addEventListener('submit', triggerLoginSubmit);
  }

  if (submitBtn) {
    submitBtn.addEventListener('click', triggerLoginSubmit);
  }

  [usernameInput, passwordInput].forEach(input => {
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          triggerLoginSubmit(e);
        }
      });
    }
  });
}

/**
 * Handle login authentication attempt
 */
async function handleLogin(username, password) {
  const errorBanner = document.getElementById('auth-error-banner');
  const submitBtn = document.getElementById('auth-submit-btn');
  const btnText = submitBtn ? submitBtn.querySelector('.btn-text') : null;
  const btnSpinner = submitBtn ? submitBtn.querySelector('.btn-spinner') : null;

  if (!username || !password) {
    showAuthError('Please enter both username and password.');
    return;
  }

  if (errorBanner) errorBanner.style.display = 'none';
  if (btnText) btnText.style.display = 'none';
  if (btnSpinner) btnSpinner.style.display = 'inline-block';
  if (submitBtn) submitBtn.disabled = true;

  try {
    const res = await loginApi(username, password);

    if (res.ok && res.token && res.user) {
      setAuthSession(res.user, res.token);
      hideAuthModal();
      if (typeof authCallbackOnSuccess === 'function') {
        authCallbackOnSuccess(res.user);
      }
    } else {
      showAuthError(res.error || 'Authentication failed. Please check credentials.');
    }
  } catch (err) {
    showAuthError('Error authenticating with backend server.');
  } finally {
    if (btnText) btnText.style.display = 'inline-block';
    if (btnSpinner) btnSpinner.style.display = 'none';
    if (submitBtn) submitBtn.disabled = false;
  }
}

/**
 * Display authentication error message in banner
 */
function showAuthError(msg) {
  const errorBanner = document.getElementById('auth-error-banner');
  if (errorBanner) {
    errorBanner.textContent = `⚠️ ${msg}`;
    errorBanner.style.display = 'block';
  }
}

/**
 * Show login gateway modal overlay
 */
export function showAuthModal() {
  const modal = document.getElementById('auth-gateway-modal');
  if (modal) {
    modal.classList.add('active');
    document.body.classList.add('auth-locked');
  }
}

/**
 * Hide login gateway modal overlay
 */
export function hideAuthModal() {
  const modal = document.getElementById('auth-gateway-modal');
  if (modal) {
    modal.classList.remove('active');
    document.body.classList.remove('auth-locked');
  }
}
