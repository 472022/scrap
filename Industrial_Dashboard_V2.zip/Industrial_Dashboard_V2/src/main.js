// Main Application Controller for All 7 Modules

import * as XLSX from 'xlsx';
import html2canvas from 'html2canvas';
import { Chart } from 'chart.js';
import { state, resetState, loadHistoryLogs, saveHistoryLog, restoreHistoryLog, deleteHistoryLog, clearHistoryLogs, ensureAllKpisExist, getKpiForMode, getAchievement, getStatus, isLowerBetter, syncStateWithBackend, syncStateToBackend, loadModuleDataFromApi, initAuthSession, clearAuthSession } from './state.js';
import { uploadDatasetFile, fetchSummaryFromApi, fetchModuleFromApi } from './api.js';

import { initAuthModal, showAuthModal, hideAuthModal } from './components/authModal.js';
import { renderKpiTable } from './components/kpiTable.js';


import { renderComplianceSection } from './components/compliance.js';
import { renderWorkplaceSection } from './components/workplace.js';
import { renderIncidentCards } from './components/incidentCards.js';
import { renderExecSummary } from './components/execSummary.js';
import { renderStrengthPanel } from './components/strengthPanel.js';
import { renderSafetyFicTable } from './components/safetyFicTable.js';
import { initDataEditor } from './components/dataEditor.js';
import { renderCharts } from './components/charts.js';
import { downloadCSVTemplate } from './template.js';

// Import Quality and Productivity groups renderers
import { renderDrrMeters, renderQualityCharters, renderWarrantySection, renderQualityAudits, renderCompositeQualitySection } from './components/qualityGroups.js';
import { renderHpevSection, renderLineOperations, renderHeadcountSection, renderKaizenSection } from './components/productivityGroups.js';
import { renderDeliveryDashboard } from './components/deliveryGroups.js';
import { renderCostMaterialSection, renderCostCltSection } from './components/costGroups.js';
import { renderInventoryValueSection, renderInventoryAgeingSection } from './components/inventoryGroups.js';
import { renderEnvironmentResourcesSection, renderEnvironmentDecarbonizationSection } from './components/environmentGroups.js';
import { renderHrDashboard } from './components/hrGroups.js';
import { renderDigitalDashboard } from './components/digitalGroups.js';
import defaultBannerImg from './assets/banner.jpg';
import safetyBannerImg from './assets/safety_banner.jpg';
import qualityBannerImg from './assets/quality_banner.jpg';
import productivityBannerImg from './assets/productivity_banner.jpg';
import deliveryBannerImg from './assets/delivery_banner.jpg';
import costBannerImg from './assets/cost_banner.jpg';
import inventoryBannerImg from './assets/inventory_banner.jpg';
import environmentBannerImg from './assets/environment_banner.jpg';
import hrBannerImg from './assets/hr_banner.jpg';
import digitalBannerImg from './assets/digital_banner.jpg';

const moduleBannerImages = {
  safety: safetyBannerImg,
  quality: qualityBannerImg,
  productivity: productivityBannerImg,
  delivery: deliveryBannerImg,
  cost: costBannerImg,
  inventory: inventoryBannerImg,
  environment: environmentBannerImg,
  hr: hrBannerImg,
  digital: digitalBannerImg
};

const moduleHeaderConfig = {
  safety: { icon: '🦺', name: 'Safety Dashboard', color: '#ef4444', desc: 'Zero Harm Telemetry & Workplace Safety Analytics' },
  quality: { icon: '⭐', name: 'Quality Dashboard', color: '#f59e0b', desc: 'Zero Defect Compliance & Quality Performance Telemetry' },
  productivity: { icon: '⚙', name: 'Productivity Dashboard', color: '#10b981', desc: 'Line Speed & Assembly Efficiency Analytics' },
  delivery: { icon: '🚚', name: 'Delivery Dashboard', color: '#3b82f6', desc: 'On-Time Dispatch & Logistics Adherence Telemetry' },
  cost: { icon: '💰', name: 'Cost Dashboard', color: '#6366f1', desc: 'Financial Optimization & Material Cost Analytics' },
  inventory: { icon: '📦', name: 'Inventory Dashboard', color: '#8b5cf6', desc: 'Material Flow & Valuation Telemetry' },
  environment: { icon: '🌱', name: 'Environment Dashboard', color: '#14b8a6', desc: 'Decarbonization, Resource & Sustainability Analytics' },
  hr: { icon: '👥', name: 'HR Dashboard', color: '#ec4899', desc: 'Workforce Engagement & CSR Parameters' },
  digital: { icon: '💻', name: 'Digital Dashboard', color: '#64748b', desc: 'Industry 4.0 Automation & Smart Factory Telemetry' }
};

// Re-render all dashboard panels
function renderAll(skipApiSync = false) {
  const isOverall = state.currentModule === 'overall';
  const titleContainer = document.getElementById('dashboard-title-container');

  if (titleContainer) {
    if (isOverall) {
      titleContainer.innerHTML = '';
      titleContainer.style.display = 'none';
    } else {
      titleContainer.style.display = 'block';
      const config = moduleHeaderConfig[state.currentModule] || {
        icon: '🏢',
        name: `${state.currentModule.toUpperCase()} DASHBOARD`,
        color: '#3b82f6',
        desc: 'Real-time plant performance telemetry'
      };

      const moduleKpis = state.kpis.filter(k => k.module === state.currentModule && !k.id.includes('_l1') && !k.id.includes('_l2') && !k.id.includes('_l3'));
      let sumScore = 0;
      moduleKpis.forEach(k => {
        const achM = getAchievement(k, 'monthly');
        const achY = getAchievement(k, 'ytd');
        sumScore += (achM + achY) / 2;
      });
      const scoreVal = moduleKpis.length > 0 ? Math.min(100, Math.max(0, parseFloat((sumScore / moduleKpis.length).toFixed(1)))).toFixed(1) : '100.0';

      const bannerImage = moduleBannerImages[state.currentModule] || defaultBannerImg;

      titleContainer.innerHTML = `
        <div class="module-title-banner" style="position: relative; background: linear-gradient(135deg, rgba(15, 23, 42, 0.65) 0%, rgba(30, 58, 138, 0.55) 60%, rgba(15, 23, 42, 0.65) 100%), url('${bannerImage}') center/cover no-repeat; border-radius: 12px; padding: 18px 24px; color: #ffffff; box-shadow: 0 10px 25px rgba(15, 23, 42, 0.25); border: 1px solid rgba(255, 255, 255, 0.18); display: flex; align-items: center; justify-content: center; text-align: center; width: 100%; box-sizing: border-box; overflow: hidden; margin-bottom: 5px;">
          <!-- Center: Title, Tag & Subtitle -->
          <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; gap: 4px; z-index: 2;">
            <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
              <span style="font-size: 10.5px; background: rgba(59, 130, 246, 0.35); border: 1px solid rgba(147, 197, 253, 0.5); padding: 2px 10px; border-radius: 12px; color: #93c5fd; font-weight: 800; letter-spacing: 0.3px;">
                📍 TATA MOTORS — DHARWAD PLANT
              </span>
            </div>
            <h2 style="margin: 4px 0 0 0; font-size: 22px; font-weight: 900; font-family: Outfit, Inter, sans-serif; text-transform: uppercase; letter-spacing: 0.8px; color: #ffffff; text-shadow: 0 2px 6px rgba(0,0,0,0.6); display: flex; align-items: center; justify-content: center; gap: 8px;">
              <span>${config.icon}</span> <span>${config.name}</span>
            </h2>
            <span style="font-size: 12.5px; color: #e2e8f0; font-weight: 600; text-align: center; text-shadow: 0 1px 3px rgba(0,0,0,0.5);">${config.desc}</span>
          </div>
        </div>
      `;
    }
  }

  // Sync DRR Line 1 KPIs from main DRR KPIs before rendering
  ['drr_1', 'drr_2', 'drr_3', 'drr_4'].forEach(id => {
    const mainKpi = state.kpis.find(k => k.id === id);
    const line1Kpi = state.kpis.find(k => k.id === `${id}_l1`);
    if (mainKpi && line1Kpi) {
      line1Kpi.target = mainKpi.target;
      line1Kpi.actual = mainKpi.actual;
    }
  });

  const splitWrapper = document.getElementById('split-dashboards-wrapper');
  const defaultGrid = document.getElementById('default-dashboard-grid');
  const overallWrapper = document.getElementById('overall-dashboard-wrapper');

  if (overallWrapper) {
    overallWrapper.style.display = isOverall ? 'flex' : 'none';
  }
  if (splitWrapper) {
    splitWrapper.style.display = isOverall ? 'none' : 'grid';
  }
  if (defaultGrid) {
    defaultGrid.style.display = 'none'; // Hide the default grid layout permanently
  }

  const chartsSection = document.querySelector('.charts-section');
  if (chartsSection) {
    chartsSection.style.display = isOverall ? 'none' : 'block';
  }

  if (isOverall) {
    renderOverallDashboard();
    addScreenshotButtons();
    setTimeout(() => {
      addScreenshotButtons();
    }, 150);
    return;
  }

  // Dynamic header titles based on active module
  const monthlyHeader = document.getElementById('monthly-section-header');
  const ytdHeader = document.getElementById('ytd-section-header');
  const capitalizedModule = state.currentModule.charAt(0).toUpperCase() + state.currentModule.slice(1);
  if (monthlyHeader) {
    monthlyHeader.innerHTML = `📅 Monthly ${capitalizedModule} Dashboard (FTM)`;
  }
  if (ytdHeader) {
    ytdHeader.innerHTML = `📊 YTD ${capitalizedModule} Dashboard (YTD)`;
  }

  // Construct mode-aware KPI lists
  const monthlyKpis = state.kpis.map(k => {
    const modeVals = getKpiForMode(k, 'monthly');
    return { ...k, target: modeVals.target, actual: modeVals.actual };
  });

  const ytdKpis = state.kpis.map(k => {
    const modeVals = getKpiForMode(k, 'ytd');
    return { ...k, target: modeVals.target, actual: modeVals.actual };
  });

  // Sync section/container visibility dynamically based on active module
  const isSafety = state.currentModule === 'safety';
  const isQuality = state.currentModule === 'quality';
  const isProductivity = state.currentModule === 'productivity';
  const isDelivery = state.currentModule === 'delivery';
  const isCost = state.currentModule === 'cost';
  const isInventory = state.currentModule === 'inventory';
  const isEnvironment = state.currentModule === 'environment';
  const isHr = state.currentModule === 'hr';
  const isDigital = state.currentModule === 'digital';

  const show = (selector, visible) => {
    document.querySelectorAll(selector).forEach(el => {
      el.style.display = visible ? 'block' : 'none';
    });
  };

  // Sync top navigation tab buttons active state with currentModule
  document.querySelectorAll('.module-tabs .tab-btn').forEach(btn => {
    if (btn.id === `tab-${state.currentModule}`) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  show('#incidents-container-monthly', isSafety || isQuality);
  show('#incidents-container-ytd', isSafety || isQuality);

  show('#kpi-table-container-monthly', true); // Show for all (Quality renders DRR matrix here)
  show('#kpi-table-container-ytd', true); // Show for all (Quality renders DRR matrix here)

  show('#workplace-container-monthly', isSafety || isQuality || isProductivity || isCost || isInventory || isEnvironment || isHr || isDigital);
  show('#workplace-container-ytd', isSafety || isQuality || isProductivity || isCost || isInventory || isEnvironment || isHr || isDigital);

  show('#compliance-container-monthly', isProductivity);
  show('#compliance-container-ytd', isProductivity);

  show('#safety-fic-container-monthly', isSafety);
  show('#safety-fic-container-ytd', isSafety);

  // Clear container contents BEFORE rendering active module to prevent ghost/stale HTML from other modules
  const clearContainers = (suffix) => {
    ['incidents-container', 'kpi-table-container', 'workplace-container', 'compliance-container', 'safety-fic-container', 'exec-summary-container', 'strengths-container', 'focus-container'].forEach(baseId => {
      const container = document.getElementById(`${baseId}-${suffix}`);
      if (container) container.innerHTML = '';
    });
  };
  clearContainers('monthly');
  clearContainers('ytd');

  // Helper to render the appropriate dashboard components based on suffix and mode
  const renderModuleComponents = (kpis, suffix, mode) => {
    if (state.currentModule === 'safety') {
      renderKpiTable(kpis, 'safety', `kpi-table-container-${suffix}`, mode);
      renderWorkplaceSection(kpis, `workplace-container-${suffix}`, mode);
      renderIncidentCards(kpis, `incidents-container-${suffix}`, mode);
    } else if (state.currentModule === 'quality') {
      renderDrrMeters(kpis, `workplace-container-${suffix}`, mode);
      renderCompositeQualitySection(kpis, `kpi-table-container-${suffix}`, mode);
      renderWarrantySection(kpis, `incidents-container-${suffix}`, mode);
    } else if (state.currentModule === 'productivity') {
      renderHpevSection(kpis, `kpi-table-container-${suffix}`, mode);
      renderKaizenSection(kpis, `kpi-table-container-${suffix}`, mode);
      renderHeadcountSection(kpis, `workplace-container-${suffix}`, mode);
      renderLineOperations(kpis, `compliance-container-${suffix}`, mode);
    } else if (state.currentModule === 'delivery') {
      renderDeliveryDashboard(kpis, `kpi-table-container-${suffix}`, mode);
    } else if (state.currentModule === 'cost') {
      renderCostMaterialSection(kpis, `kpi-table-container-${suffix}`, mode);
      renderCostCltSection(kpis, `workplace-container-${suffix}`, mode);
    } else if (state.currentModule === 'inventory') {
      renderInventoryValueSection(kpis, `kpi-table-container-${suffix}`, mode);
      renderInventoryAgeingSection(kpis, `workplace-container-${suffix}`, mode);
    } else if (state.currentModule === 'environment') {
      renderEnvironmentResourcesSection(kpis, `kpi-table-container-${suffix}`, mode);
      renderEnvironmentDecarbonizationSection(kpis, `workplace-container-${suffix}`, mode);
    } else if (state.currentModule === 'hr') {
      renderHrDashboard(kpis, `kpi-table-container-${suffix}`, `workplace-container-${suffix}`, mode);
    } else if (state.currentModule === 'digital') {
      renderDigitalDashboard(kpis, `kpi-table-container-${suffix}`, `workplace-container-${suffix}`, mode);
    } else {
      renderKpiTable(kpis, state.currentModule, `kpi-table-container-${suffix}`, mode);
    }
  };

  // Render Monthly on the left, YTD on the right
  renderModuleComponents(monthlyKpis, 'monthly', 'monthly');
  renderModuleComponents(ytdKpis, 'ytd', 'ytd');

  // Render overall scorecard items (Strengths, Focus Areas, Executive Summaries)
  renderStrengthPanel('strengths-container-monthly', 'monthly');
  renderExecSummary('exec-summary-container-monthly', 'focus-container-monthly', 'monthly');

  renderStrengthPanel('strengths-container-ytd', 'ytd');
  renderExecSummary('exec-summary-container-ytd', 'focus-container-ytd', 'ytd');

  if (state.currentModule === 'safety') {
    renderSafetyFicTable('safety-fic-container-monthly', 'monthly');
    renderSafetyFicTable('safety-fic-container-ytd', 'ytd');
  }

  // Render Charts (scoped to active module history)
  renderCharts(state.history[state.currentModule], state.currentModule);

  // Add Copy to Clipboard Screenshot buttons for all cards, tables, and graphs
  addScreenshotButtons();

  // Non-blocking background API sync for real-time backend updates
  if (!skipApiSync && state.currentModule && state.currentModule !== 'overall') {
    const activeMod = state.currentModule;
    loadModuleDataFromApi(activeMod).then(updated => {
      if (updated && state.currentModule === activeMod) {
        renderAll(true);
      }
    }).catch(err => {
      console.warn(`[Module API Sync Error ${activeMod}]`, err);
    });
  }
}

// Dynamic helper to append copy-to-clipboard screenshot buttons to every dashboard card, table, and graph box
export function addScreenshotButtons() {
  const selectorList = [
    '.card',
    '.chart-card',
    '.chart-box',
    '.overall-summary-card',
    '.overall-analytics-card',
    '.overall-hero-banner',
    '.overall-insights-panel',
    '.module-title-banner',
    '.exec-summary-card',
    '.strength-panel-card'
  ];

  const cards = document.querySelectorAll(selectorList.join(', '));
  cards.forEach(card => {
    // Avoid double buttons
    if (card.querySelector('.card-screenshot-btn')) return;

    // Ensure relative positioning on the container
    if (getComputedStyle(card).position === 'static') {
      card.style.position = 'relative';
    }

    const btn = document.createElement('button');
    btn.className = 'card-screenshot-btn';
    btn.setAttribute('title', 'Copy box image to clipboard');
    btn.setAttribute('aria-label', 'Copy to clipboard');
    btn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="display: block;">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
    `;

    btn.addEventListener('click', async (event) => {
      event.stopPropagation();
      event.preventDefault();
      if (btn.classList.contains('copied')) return;

      // Hide the copy button itself so it's not in the screenshot
      btn.style.visibility = 'hidden';

      try {
        const canvas = await html2canvas(card, {
          scale: 2, // High resolution
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#ffffff',
          logging: false
        });

        canvas.toBlob(async (blob) => {
          if (!blob) {
            btn.style.visibility = 'visible';
            return;
          }

          let copiedSuccess = false;

          try {
            if (navigator.clipboard && navigator.clipboard.write) {
              const item = new ClipboardItem({ 'image/png': blob });
              await navigator.clipboard.write([item]);
              copiedSuccess = true;
            }
          } catch (clipErr) {
            console.warn('[Clipboard API Write Error]', clipErr);
          }

          if (!copiedSuccess) {
            try {
              const link = document.createElement('a');
              link.download = `screenshot_${Date.now()}.png`;
              link.href = canvas.toDataURL('image/png');
              link.click();
              copiedSuccess = true;
            } catch (dlErr) {
              console.error('[Download Fallback Error]', dlErr);
            }
          }

          btn.style.visibility = 'visible';
          if (copiedSuccess) {
            btn.classList.add('copied');
            setTimeout(() => {
              btn.classList.remove('copied');
            }, 2000);
          } else {
            alert('Could not copy image. Please ensure clipboard permissions are allowed.');
          }
        }, 'image/png');
      } catch (err) {
        console.error('Canvas generation failed:', err);
        btn.style.visibility = 'visible';
      }
    });

    card.appendChild(btn);
  });
}

// Simulated filter functionality (scales data slightly to demonstrate responsiveness)
function setupFilters() {
  const dateFilter = document.getElementById('filter-date');
  const plantFilter = document.getElementById('filter-plant');
  const deptFilter = document.getElementById('filter-dept');
  const shiftFilter = document.getElementById('filter-shift');

  const handleFilterChange = () => {
    state.filters.date = dateFilter.value;
    state.filters.plant = plantFilter.value;
    state.filters.department = deptFilter.value;
    state.filters.shift = shiftFilter.value;

    // Generate a deterministic scaling factor based on selected filter values
    let hash = 0;
    const combinedString = `${dateFilter.value}-${plantFilter.value}-${deptFilter.value}-${shiftFilter.value}`;
    for (let i = 0; i < combinedString.length; i++) {
      hash = combinedString.charCodeAt(i) + ((hash << 5) - hash);
    }
    
    // Scale value between 0.85 and 1.15
    const scaleFactor = 0.85 + (Math.abs(hash % 30) / 100);

    // Apply scale factor to all KPIs temporarily
    resetState(); // reload clean base state
    
    if (combinedString !== 'All Dates-All Plants-All Departments-All Shifts') {
      state.kpis.forEach(kpi => {
        if (kpi.id === 'lti' || kpi.id === 'rwc' || kpi.id === 'mtc') {
          kpi.actual = Math.round(kpi.actual * (scaleFactor > 1 ? 1.2 : 0.8));
        } else if (kpi.id === 'fac') {
          kpi.actual = Math.round(kpi.actual * (scaleFactor > 1 ? 1.5 : 0.5));
        } else {
          kpi.actual = safeParseFloat(Math.min(kpi.target * 1.05, Math.max(0, kpi.actual * scaleFactor)).toFixed(2));
        }
      });

      // Scale trend chart data for active module
      state.history[state.currentModule].forEach((hist, index) => {
        hist.overallScore = Math.min(100, Math.max(50, Math.round(hist.overallScore * (scaleFactor + (index * 0.02)))));
      });
    }

    renderAll();
  };

  [dateFilter, plantFilter, deptFilter, shiftFilter].forEach(el => {
    if (el) el.addEventListener('change', handleFilterChange);
  });
}

// Helper to identify plant module name from Excel sheet name variations
function getModuleNameFromSheetName(sheetName) {
  if (!sheetName) return null;
  const clean = sheetName.trim().toLowerCase().replace(/[\s\-_]+/g, '');
  if (clean.includes('safety')) return 'safety';
  if (clean.includes('quality') || clean.includes('qulality')) return 'quality';
  if (clean.includes('productivity') || clean.includes('productiv')) return 'productivity';
  if (clean.includes('delivery') || clean.includes('deliv')) return 'delivery';
  if (clean.includes('inventory') || clean.includes('invent')) return 'inventory';
  if (clean.includes('cost')) return 'cost';
  if (clean.includes('environment') || clean.includes('envirnomen') || clean.includes('environ')) return 'environment';
  if (clean.includes('hr') || clean.includes('humanres')) return 'hr';
  if (clean.includes('digital') || clean.includes('digi')) return 'digital';
  return null;
}

// File Upload Handler (Parses multi-sheet Excel files)
function setupFileUploader() {
  const uploader = document.getElementById('file-uploader');
  if (!uploader) return;

  uploader.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Trigger asynchronous upload to SQLite Backend Engine
    try {
      const apiResult = await uploadDatasetFile(file);
      if (apiResult && apiResult.ok) {
        console.log('[SQLite Backend] Dataset successfully ingested and processed:', apiResult.data);
      }
    } catch (apiErr) {
      console.warn('[SQLite Backend] API Upload sync warning:', apiErr);
    }

    const reader = new FileReader();

    const extension = file.name.split('.').pop().toLowerCase();

    reader.onload = (evt) => {
      try {
        let importedKpis = [];
        let loadedSheets = [];
        let hasMonthlyDataImported = false;

        if (extension === 'csv') {
          const text = evt.target.result;
          importedKpis = parseCSVData(text);
          loadedSheets.push('CSV Upload');
        } else if (extension === 'xlsx' || extension === 'xls') {
          const data = new Uint8Array(evt.target.result);
          const workbook = XLSX.read(data, { type: 'array' });
          
          workbook.SheetNames.forEach(sheetName => {
            const moduleName = getModuleNameFromSheetName(sheetName);
            const worksheet = workbook.Sheets[sheetName];
            if (!worksheet) return;

            if (moduleName) {
              // 1. Try parsing as structured summary sheet
              try {
                const rawRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                const sheetKpis = parseStructuredSheet(rawRows, moduleName);
                if (sheetKpis && sheetKpis.length > 0) {
                  importedKpis.push(...sheetKpis);
                  if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                }
              } catch (err) {
                console.warn(`[FileUploader] Failed parsing structured summary sheet '${sheetName}':`, err);
              }

              // 2. Try parsing module-specific detailed sheets & monthly trends
              if (moduleName === 'quality') {
                try {
                  const qualityRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedQuality = parseDetailedQuality(qualityRows);
                  if (parsedDetailedQuality && parsedDetailedQuality.length > 0) {
                    importedKpis.push(...parsedDetailedQuality);
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                  const parsedDetailedQualityMonthly = parseDetailedQualityMonthly(qualityRows);
                  if (parsedDetailedQualityMonthly) {
                    importQualityMonthlyData(parsedDetailedQualityMonthly);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Quality sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'safety') {
                try {
                  const safetyRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedSafety = parseDetailedSafety(safetyRows);
                  if (parsedDetailedSafety) {
                    importSafetyMonthlyData(parsedDetailedSafety);
                    hasMonthlyDataImported = true;

                    const facKpi = state.kpis.find(k => k.id === 'fac');
                    if (facKpi && parsedDetailedSafety.facMtd !== undefined) facKpi.actual = parsedDetailedSafety.facMtd;

                    const ltiKpi = state.kpis.find(k => k.id === 'lti');
                    if (ltiKpi && parsedDetailedSafety.ltiMtd !== undefined) ltiKpi.actual = parsedDetailedSafety.ltiMtd;

                    const rwcKpi = state.kpis.find(k => k.id === 'rwc');
                    if (rwcKpi && parsedDetailedSafety.rwcMtd !== undefined) rwcKpi.actual = parsedDetailedSafety.rwcMtd;

                    const mtcKpi = state.kpis.find(k => k.id === 'mtc');
                    if (mtcKpi && parsedDetailedSafety.mtcMtd !== undefined) mtcKpi.actual = parsedDetailedSafety.mtcMtd;

                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Safety sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'productivity') {
                try {
                  const prodRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedProd = parseDetailedProductivity(prodRows);
                  if (parsedDetailedProd) {
                    importProductivityMonthlyData(parsedDetailedProd);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Productivity sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'delivery') {
                try {
                  const deliveryRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedDelivery = parseDetailedDelivery(deliveryRows);
                  if (parsedDetailedDelivery) {
                    importDeliveryMonthlyData(parsedDetailedDelivery);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Delivery sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'cost') {
                try {
                  const costRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedCost = parseDetailedCost(costRows);
                  if (parsedDetailedCost) {
                    importCostMonthlyData(parsedDetailedCost);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Cost sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'hr') {
                try {
                  const hrRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedHr = parseDetailedHr(hrRows);
                  if (parsedDetailedHr) {
                    importHrMonthlyData(parsedDetailedHr);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed HR sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'environment') {
                try {
                  const envRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedEnv = parseDetailedEnvironment(envRows);
                  if (parsedDetailedEnv) {
                    importEnvironmentMonthlyData(parsedDetailedEnv);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Environment sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'inventory') {
                try {
                  const invRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedInv = parseDetailedInventory(invRows);
                  if (parsedDetailedInv) {
                    state.hasTml = (parsedDetailedInv.tml !== null && parsedDetailedInv.tml !== undefined);
                    importInventoryMonthlyData(parsedDetailedInv);
                    hasMonthlyDataImported = true;

                    const getLatestMonthValue = (parsedParam) => {
                      if (!parsedParam || !parsedParam.actuals || parsedParam.actuals.length === 0) {
                        return { target: 0, actual: 0 };
                      }
                      const target = parsedParam.targets[parsedParam.targets.length - 1] || 0;
                      let actual = 0;
                      for (let idx = parsedParam.actuals.length - 1; idx >= 0; idx--) {
                        const val = parsedParam.actuals[idx];
                        if (val !== undefined && val !== null && val !== 0 && !isNaN(val)) {
                          actual = val;
                          break;
                        }
                      }
                      if (actual === 0) {
                        actual = parsedParam.actuals[0] || 0;
                      }
                      return { target, actual };
                    };

                    const updateKpi = (id, target, actual) => {
                      const kpi = state.kpis.find(k => k.id === id);
                      const imp = importedKpis.find(k => k.id === id);
                      
                      let finalTarget = target;
                      let finalActual = actual;
                      
                      if (imp) {
                        if (imp.target !== 0 && imp.target !== undefined && imp.target !== null && !isNaN(imp.target)) {
                          finalTarget = imp.target;
                        }
                        if (imp.actual !== 0 && imp.actual !== undefined && imp.actual !== null && !isNaN(imp.actual)) {
                          finalActual = imp.actual;
                        }
                      }
                      
                      if (kpi) {
                        kpi.target = finalTarget;
                        kpi.actual = finalActual;
                      }
                      if (imp) {
                        imp.target = finalTarget;
                        imp.actual = finalActual;
                      } else {
                        importedKpis.push({ id, target: finalTarget, actual: finalActual });
                      }
                    };

                    if (parsedDetailedInv.opsDays) {
                      const opsVal = getLatestMonthValue(parsedDetailedInv.opsDays);
                      updateKpi('ops_inv_days', opsVal.target, opsVal.actual);
                    }
                    if (parsedDetailedInv.invWo) {
                      const woVal = getLatestMonthValue(parsedDetailedInv.invWo);
                      updateKpi('inv_rs_crs_wo', woVal.target, woVal.actual);
                    }
                    if (parsedDetailedInv.invWith) {
                      const wVal = getLatestMonthValue(parsedDetailedInv.invWith);
                      updateKpi('inv_rs_crs_w', wVal.target, wVal.actual);
                    }
                    if (parsedDetailedInv.invOverall) {
                      const overallVal = getLatestMonthValue(parsedDetailedInv.invOverall);
                      updateKpi('inv_overall', overallVal.target, overallVal.actual);
                    }
                    if (parsedDetailedInv.invNoOfDays) {
                      const noOfDaysVal = getLatestMonthValue(parsedDetailedInv.invNoOfDays);
                      updateKpi('inv_no_of_days', noOfDaysVal.target, noOfDaysVal.actual);
                    }
                    if (parsedDetailedInv.gt180) {
                      const gt180Val = getLatestMonthValue(parsedDetailedInv.gt180);
                      updateKpi('ageing_gt_180', gt180Val.target, gt180Val.actual);
                    }
                    if (parsedDetailedInv.gt90) {
                      const gt90Val = getLatestMonthValue(parsedDetailedInv.gt90);
                      updateKpi('ageing_gt_90', gt90Val.target, gt90Val.actual);
                    }
                    if (parsedDetailedInv.mach) {
                      const machVal = getLatestMonthValue(parsedDetailedInv.mach);
                      updateKpi('machinery_spares', machVal.target, machVal.actual);
                    }
                    if (parsedDetailedInv.tools) {
                      const toolsVal = getLatestMonthValue(parsedDetailedInv.tools);
                      updateKpi('tools_idm', toolsVal.target, toolsVal.actual);
                    }
                    if (parsedDetailedInv.tml) {
                      const tmlVal = getLatestMonthValue(parsedDetailedInv.tml);
                      updateKpi('inv_tml', tmlVal.target, tmlVal.actual);
                    }
                    if (parsedDetailedInv.tmbsl) {
                      const tmbslVal = getLatestMonthValue(parsedDetailedInv.tmbsl);
                      updateKpi('inv_tmbsl', tmbslVal.target, tmbslVal.actual);
                    }
                    if (parsedDetailedInv.gt180 && parsedDetailedInv.gt90 && parsedDetailedInv.mach && parsedDetailedInv.tools) {
                      const gt180Val = getLatestMonthValue(parsedDetailedInv.gt180);
                      const gt90Val = getLatestMonthValue(parsedDetailedInv.gt90);
                      const machVal = getLatestMonthValue(parsedDetailedInv.mach);
                      const toolsVal = getLatestMonthValue(parsedDetailedInv.tools);
                      const totTarget = gt180Val.target + gt90Val.target + machVal.target + toolsVal.target;
                      const totActual = gt180Val.actual + gt90Val.actual + machVal.actual + toolsVal.actual;
                      updateKpi('ageing_tot', totTarget, totActual);
                    }

                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Inventory sheet '${sheetName}':`, err);
                }
              } else if (moduleName === 'digital') {
                try {
                  const digRows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                  const parsedDetailedDig = parseDetailedDigital(digRows);
                  if (parsedDetailedDig) {
                    importDigitalMonthlyData(parsedDetailedDig);
                    hasMonthlyDataImported = true;
                    if (!loadedSheets.includes(sheetName.trim())) loadedSheets.push(sheetName.trim());
                  }
                } catch (err) {
                  console.warn(`[FileUploader] Failed parsing detailed Digital sheet '${sheetName}':`, err);
                }
              }
            }
          });

          // Fallback if no structured summary sheets or detailed sheets were recognized
          if (importedKpis.length === 0 && !hasMonthlyDataImported && workbook.SheetNames.length > 0) {
            try {
              const firstSheetName = workbook.SheetNames[0];
              const worksheet = workbook.Sheets[firstSheetName];
              if (worksheet) {
                const jsonData = XLSX.utils.sheet_to_json(worksheet);
                const fallbackKpis = parseExcelJSON(jsonData);
                if (fallbackKpis && fallbackKpis.length > 0) {
                  importedKpis.push(...fallbackKpis);
                  loadedSheets.push(firstSheetName);
                }
              }
            } catch (err) {
              console.warn('[FileUploader] Fallback sheet parsing failed:', err);
            }
          }
        }

        if (importedKpis.length > 0 || hasMonthlyDataImported) {
          // Update matching state KPIs (prioritizing ID matches to prevent name-clashes)
          importedKpis.forEach(imp => {
            let match = null;
            if (imp.id) {
              match = state.kpis.find(k => k.id === imp.id);
            }
            if (!match && imp.name) {
              match = state.kpis.find(k => k.name.toLowerCase() === imp.name.toLowerCase());
            }
            
            if (match) {
              if (imp.target !== undefined && imp.target !== null && !isNaN(imp.target)) match.target = imp.target;
              if (imp.actual !== undefined && imp.actual !== null && !isNaN(imp.actual)) match.actual = imp.actual;
              if (imp.unit !== undefined && imp.unit !== null) match.unit = imp.unit;

              if (match.module === 'delivery' && state.deliveryMonthlyData && state.deliveryMonthlyData[match.id]) {
                const delObj = state.deliveryMonthlyData[match.id];
                if (delObj.targets && delObj.targets.length > 0) {
                  delObj.targets[delObj.targets.length - 1] = match.target;
                }
                if (delObj.actuals && delObj.actuals.length > 0) {
                  delObj.actuals[delObj.actuals.length - 1] = match.actual;
                }
                const isSumMetric = (
                  match.id.startsWith('prod_') ||
                  match.id.startsWith('disp_') ||
                  match.id.startsWith('bus_') ||
                  match.id === 'line2' || match.id === 'line3'
                );
                const validTargets = delObj.targets ? delObj.targets.filter(v => v !== null && v !== undefined && !isNaN(v)) : [];
                const validActuals = delObj.actuals ? delObj.actuals.filter(v => v !== null && v !== undefined && !isNaN(v)) : [];
                if (validTargets.length > 0) {
                  delObj.ytdTarget = isSumMetric ? validTargets.reduce((a, b) => a + b, 0) : parseFloat((validTargets.reduce((a, b) => a + b, 0) / validTargets.length).toFixed(1));
                }
                if (validActuals.length > 0) {
                  delObj.ytdActual = isSumMetric ? validActuals.reduce((a, b) => a + b, 0) : parseFloat((validActuals.reduce((a, b) => a + b, 0) / validActuals.length).toFixed(1));
                }
              }
            }
          });

          // Sync other domestic MAPE KPIs with the parsed domestic MAPE
          const domMape = state.kpis.find(k => k.id === 'mape_dom_ilmcv');
          if (domMape) {
            ['mape_dom_hcv', 'mape_dom_cvp'].forEach(id => {
              const match = state.kpis.find(k => k.id === id);
              if (match) {
                match.target = domMape.target;
                match.actual = domMape.actual;
                match.unit = domMape.unit;
              }
            });
          }

          // Save baseline snapshot so filter changes persist these uploaded values as the base state
          state.baseKpis = JSON.parse(JSON.stringify(state.kpis));
          if (state.safetyMonthlyData) state.baseSafetyMonthlyData = JSON.parse(JSON.stringify(state.safetyMonthlyData));
          if (state.productivityMonthlyData) state.baseProductivityMonthlyData = JSON.parse(JSON.stringify(state.productivityMonthlyData));
          if (state.deliveryMonthlyData) state.baseDeliveryMonthlyData = JSON.parse(JSON.stringify(state.deliveryMonthlyData));
          if (state.costMonthlyData) state.baseCostMonthlyData = JSON.parse(JSON.stringify(state.costMonthlyData));
          if (state.hrMonthlyData) state.baseHrMonthlyData = JSON.parse(JSON.stringify(state.hrMonthlyData));
          if (state.qualityMonthlyData) state.baseQualityMonthlyData = JSON.parse(JSON.stringify(state.qualityMonthlyData));
          if (state.environmentMonthlyData) state.baseEnvironmentMonthlyData = JSON.parse(JSON.stringify(state.environmentMonthlyData));
          if (state.inventoryMonthlyData) state.baseInventoryMonthlyData = JSON.parse(JSON.stringify(state.inventoryMonthlyData));
          if (state.digitalMonthlyData) state.baseDigitalMonthlyData = JSON.parse(JSON.stringify(state.digitalMonthlyData));
          if (state.ficWiseInjuries) state.baseFicWiseInjuries = JSON.parse(JSON.stringify(state.ficWiseInjuries));
          if (state.ficWiseInjuriesYtd) state.baseFicWiseInjuriesYtd = JSON.parse(JSON.stringify(state.ficWiseInjuriesYtd));

          // Save a checkpoint of the new data state to history
          saveHistoryLog(`Imported: ${file.name}`);
          
          // Show success alert specifying the sheets parsed
          alert(`Successfully loaded data from sheet(s): [${loadedSheets.join(', ')}]!`);
          renderAll();
        } else {
          alert('No valid KPI or monthly data rows found in the uploaded file. Please verify sheet names or formatting.');
        }
      } catch (err) {
        console.error('File parsing outer exception:', err);
        alert('Error parsing file: ' + (err.message || 'Please verify file formatting.'));
      }
    };

    if (extension === 'csv') {
      reader.readAsText(file);
    } else {
      reader.readAsArrayBuffer(file);
    }
    
    uploader.value = '';
  });
}

// Map structured spreadsheet names (with groups) to state IDs case-insensitively
function mapNameToKpiId(name, moduleName) {
  if (!name) return null;
  const clean = name.trim().toLowerCase().replace(/\s+/g, ' ');

  if (moduleName === 'safety') {
    if (clean.includes('safe session')) return 'safe_session';
    if (clean.includes('visilens')) return 'visilens';
    if (clean.includes('leadership') || clean.includes('leadeship')) return 'floor_leadership';
    if (clean.includes('safety training')) return 'safety_training';
    if (clean.includes('smt coverage')) return 'smt_coverage';
    if (clean.includes('sdt coverage')) return 'sdt_coverage';
    if (clean.includes('sif derisking')) return 'sif_derisking';
    if (clean.includes('bpms')) return 'bpms_rating';
    if (clean.includes('psi ii')) return 'psi_2';
    if (clean.includes('psi i')) return 'psi_1';
    if (clean.includes('fic')) return 'fic';
    if (clean.includes('bbt')) return 'bbt';
    if (clean.includes('sub committee') || clean.includes('subcommittee')) return 'plant_subcommittee';
    if (clean.includes('phase 2')) return 'phase_2';
    if (clean.includes('phase 3')) return 'phase_3';
    if (clean.includes('red corner')) return 'red_corner';
    if (clean.includes('blue corner')) return 'blue_corner';
    if (clean.includes('lti')) return 'lti';
    if (clean.includes('rwc')) return 'rwc';
    if (clean.includes('mtc')) return 'mtc';
    if (clean.includes('fac')) return 'fac';
    if (clean.includes('trcfr')) return 'trcfr';
  }

  if (moduleName === 'quality') {
    if (clean.includes('delta composite iptv')) return 'comp_quality_iptv';
    if (clean.includes('expense per vehicle')) return 'comp_quality_epv';
    if (clean.includes('unscheduled visits per vehicle')) return 'comp_quality_visits';
    if (clean.includes('no touch drr')) return 'comp_quality_notouch';
    if (clean.includes('launch quality')) return 'launch_quality';
    if (clean.includes('launch uvpv')) return 'launch_uvpv';

    if (clean === 'drr 1') return 'drr_1';
    if (clean.includes('drr 1') && clean.includes('line 1')) return 'drr_1_l1';
    if (clean.includes('drr 1') && clean.includes('line 2')) return 'drr_1_l2';
    if (clean.includes('drr 1') && clean.includes('line 3')) return 'drr_1_l3';
    
    if (clean === 'drr 2') return 'drr_2';
    if (clean.includes('drr 2') && clean.includes('line 1')) return 'drr_2_l1';
    if (clean.includes('drr 2') && clean.includes('line 2')) return 'drr_2_l2';
    if (clean.includes('drr 2') && clean.includes('line 3')) return 'drr_2_l3';

    if (clean === 'drr 3') return 'drr_3';
    if (clean.includes('drr 3') && clean.includes('line 1')) return 'drr_3_l1';
    if (clean.includes('drr 3') && clean.includes('line 2')) return 'drr_3_l2';
    if (clean.includes('drr 3') && clean.includes('line 3')) return 'drr_3_l3';

    if (clean === 'drr 4') return 'drr_4';
    if (clean.includes('drr 4') && clean.includes('line 1')) return 'drr_4_l1';
    if (clean.includes('drr 4') && clean.includes('line 2')) return 'drr_4_l2';
    if (clean.includes('drr 4') && clean.includes('line 3')) return 'drr_4_l3';

    if (clean.includes('l3 control')) return 'l3_control';
    if (clean.includes('warranty')) return 'warranty_payout';
    if (clean.includes('cpa score')) return 'cpa_score';
    if (clean.includes('unscheduled visit 24') || clean.includes('visit 24')) return 'visit_24';
    if (clean.includes('unscheduled visit 12') || clean.includes('visit 12')) return 'visit_12';
    if (clean.includes('comp iptv')) return 'comp_iptv';
    if (clean.includes('3 mis iptv') || clean.includes('3mis iptv')) return 'iptv_3';
    if (clean.includes('layer audit')) return 'layer_audit';
    if (clean.includes('vc charter')) return 'vc_charter';
    if (clean.includes('product charter')) return 'product_charter';
    if (clean.includes('composite quality index')) return 'composite_quality_index';
    if (clean.includes('cimple')) return 'cimple_project';
  }

  if (moduleName === 'productivity') {
    if (clean.includes('hpev 3')) return 'hpev_3';
    if (clean.includes('hpev 4')) return 'hpev_4';
    if (clean.includes('cpev')) return 'cpev';
    if (clean.includes('availability') && clean.includes('line 2')) return 'line_avail_l2';
    if (clean.includes('availability') && clean.includes('line 3')) return 'line_avail_l3';
    if (clean.includes('availability') && clean.includes('total')) return 'line_avail_tot';
    if (clean.includes('minutes lost') && clean.includes('line 2')) return 'min_lost_l2';
    if (clean.includes('minutes lost') && clean.includes('line 3')) return 'min_lost_l3';
    if (clean.includes('minutes lost') && clean.includes('total')) return 'min_lost_tot';
    if (clean.includes('line speed')) return 'line_speed';
    if (clean.includes('efficiency') && clean.includes('line 2')) return 'line_eff_l2';
    if (clean.includes('efficiency') && clean.includes('line 3')) return 'line_eff_l3';
    if (clean.includes('formation ratio')) return 'line_form_ratio';
    if (clean.includes('workforce plan') && clean.includes('line 2')) return 'veh_day_l2';
    if (clean.includes('workforce plan') && clean.includes('line 3')) return 'veh_day_l3';
    if (clean.includes('workforce plan') && clean.includes('total')) return 'veh_day_tot';
    
    // Check specific sub-items first to prevent prefix matching from Group name
    if (clean.includes('lean mfg')) return 'lean_mfg';
    if (clean.includes('automation')) return 'automation';
    if (clean.includes('lotus')) return 'lotus_3';
    if (clean.includes('structural')) return 'structural_improvements';
    if (clean.includes('head count optimization') || clean === 'headcount optimization') return 'headcount_opt';
  }

  if (moduleName === 'delivery') {
    // Check specific/sub-items first to prevent prefix matching issues from Group names
    if (clean.includes('otif- ib') || clean.includes('otif ib')) return 'otif_ib';
    if (clean.includes('spares')) return 'otif_spares';
    if (clean.includes('otif- domestic') || clean.includes('otif domestic')) return 'otif_dom';
    if (clean.includes('spd')) return 'spd';
    
    if (clean.includes('1-mape - ib') || clean.includes('mape ib')) return 'mape_ib';
    if (clean.includes('1-mape- domestic ilmcv') || clean.includes('mape domestic ilmcv')) return 'mape_dom_ilmcv';
    if (clean.includes('1-mape- domestic hcv') || clean.includes('mape domestic hcv')) return 'mape_dom_hcv';
    if (clean.includes('1-mape- domestic cvp') || clean.includes('mape domestic cvp')) return 'mape_dom_cvp';
    if (clean.includes('production') && clean.includes('line 2')) return 'prod_l2';
    if (clean.includes('production') && clean.includes('line 3')) return 'prod_l3';
    if (clean.includes('production') && clean.includes('total')) return 'prod_tot';
    if (clean.includes('production') && clean.includes('domestic')) return 'prod_dom';
    if (clean.includes('production') && clean.includes('international')) return 'prod_int';
    
    if (clean.includes('dispatch') && clean.includes('tmbsl')) return 'disp_tmbsl';
    if (clean.includes('dispatch') && clean.includes('acgl')) return 'disp_acgl';
    if (clean.includes('dispatch') && clean.includes('imac')) return 'disp_imac';
    if (clean.includes('dispatch') && clean.includes('jcbl')) return 'disp_jcbl';
    if (clean.includes('dispatch') && clean.includes('other bb')) return 'disp_otherbb';
    if (clean.includes('dispatch') && clean.includes('direct billing')) return 'disp_direct';
    if (clean.includes('dispatch') && (clean.includes('ev bus') || clean.includes('ev bus/truck'))) return 'disp_ev';
    if (clean === 'dispatch total') return 'disp_tot';
    
    if (clean.includes('bus engine') && clean.includes('4 spcr nac')) return 'bus_4spcr_nac';
    if (clean.includes('bus engine') && clean.includes('4 spcr ac')) return 'bus_4spcr_ac';
    if (clean.includes('bus engine') && clean.includes('maxicab nac')) return 'bus_maxicab_nac';
    if (clean.includes('bus engine') && clean.includes('cx2 nac')) return 'bus_cx2_nac';
    if (clean.includes('bus engine') && clean.includes('10.2 4sp')) return 'bus_10_2_4sp';
    if (clean.includes('bus engine') && clean.includes('3.3l nac')) return 'bus_3_3l_nac';
    if (clean.includes('bus engine') && clean.includes('3.3l ac')) return 'bus_3_3l_ac';
    if (clean.includes('bus engine') && clean.includes('ib-912')) return 'bus_ib912_bs3';
    if (clean.includes('bus engine') && clean.includes('ib-712 bs3')) return 'bus_ib712_bs3';
    if (clean.includes('bus engine') && clean.includes('ib-712 bs4')) return 'bus_ib712_bs4';
    if (clean === 'bus engine dispatches total' || clean === 'bus engine total') return 'bus_tot';
  }

  if (moduleName === 'inventory') {
    if (clean.includes('tml')) return 'inv_tml';
    if (clean.includes('tmbsl')) return 'inv_tmbsl';
    if (clean.includes('ageing') && clean.includes('91 to 120')) return 'ageing_90_120';
    if (clean.includes('ageing') && clean.includes('121 to 150')) return 'ageing_121_150';
    if (clean.includes('ageing') && clean.includes('151 to 180')) return 'ageing_151_180';
    if (clean.includes('ageing') && clean.includes('181 to 365')) return 'ageing_181_365';
    if (clean.includes('ageing') && clean.includes('total')) return 'ageing_tot';
    if (clean === 'inventory' || clean === 'inventory total' || clean === 'total') return 'inv_overall';
    if (clean.includes('no of days') && !clean.includes('operations')) return 'inv_no_of_days';
    if (clean.includes('>180')) return 'ageing_gt_180';
    if (clean.includes('>90')) return 'ageing_gt_90';
    if (clean.includes('machinery spares')) return 'machinery_spares';
    if (clean.includes('tools') && clean.includes('idm')) return 'tools_idm';
    if (clean.includes('operations inventory')) return 'ops_inv_days';
    if (clean.includes('w/o iflt')) return 'inv_rs_crs_wo';
    if (clean.includes('with iflt')) return 'inv_rs_crs_w';
    if (clean === 'git') return 'git';
  }

  if (moduleName === 'cost') {
    if (clean.includes('repro')) return 'repro';
    if (clean.includes('dmc')) return 'dmc';
    if (clean.includes('vcc')) return 'vcc';
    if (clean.includes('ofe')) return 'ofe';
    if (clean.includes('clt') && (clean.includes('admin') || clean.includes('ew'))) return 'admin_ew';
    if (clean.includes('clt') && clean.includes('maintenance')) return 'maintenance_services';
    if (clean.includes('clt') && clean.includes('civil')) return 'civil';
    if (clean.includes('clt') && clean.includes('sustainability')) return 'sustainability';
    if (clean.includes('clt') && clean.includes('production')) return 'production_contracts';
    if (clean.includes('clt') && clean.includes('utilities')) return 'utilities';
    if (clean.includes('clt') && clean.includes('vic')) return 'vic_machinery';
    if (clean.includes('clt') && clean.includes('freight')) return 'freight_logistic';
    if (clean.includes('clt') && clean.includes('total')) return 'cost_total';
  }

  if (moduleName === 'environment') {
    if (clean.includes('fuel')) return 'fuel_unit';
    if (clean.includes('ghg')) return 'ghg';
    if (clean.includes('power')) return 'power_kwh';
    if (clean.includes('zero waste')) return 'zero_waste';
    if (clean.includes('re 100')) return 're_100';
    if (clean.includes('scope 1') || clean.includes('decarbonisation')) return 'env_scope1';
    if (clean.includes('net water ratio') || clean.includes('water positive')) return 'env_water_ratio';
    if (clean.includes('circular')) return 'env_circular';
    if (clean.includes('biodiversity')) return 'env_biodiversity';
  }

  if (moduleName === 'hr') {
    if (clean.includes('pcvh')) return 'hr_pcvh';
    if (clean.includes('ivdp')) return 'hr_lives_ivdp';
    if (clean.includes('lives') && clean.includes('envir')) return 'hr_lives_env';
    if (clean.includes('lives') && clean.includes('health')) return 'hr_lives_health';
    if (clean.includes('lives') && clean.includes('educa')) return 'hr_lives_edu';
    if (clean.includes('lives') && clean.includes('employ')) return 'hr_lives_emp';
    if (clean.includes('absentee') && clean.includes('line 2')) return 'hr_absenteeism_l2';
    if (clean.includes('absentee') && clean.includes('line 3')) return 'hr_absenteeism_l3';
    if (clean.includes('skip level')) return 'hr_skip_level';
    if (clean.includes('er index')) return 'hr_er_index';
    if (clean.includes('legatrix')) return 'hr_legatrix';
  }

  if (moduleName === 'digital') {
    if (clean.includes('cctv')) return 'dig_cctv';
    if (clean.includes('energy meter')) return 'dig_energy_meter';
    if (clean.includes('water meter')) return 'dig_water_meter';
    if (clean.includes('andon')) return 'dig_andon_updation';
    if (clean.includes('qualix')) return 'dig_qualix_compliance';
    if (clean.includes('kitting')) return 'dig_kitting_adherence';
    if (clean.includes('cmdb')) return 'dig_project_cmdb';
    if (clean.includes('script running') || clean.includes('win10')) return 'dig_project_win10_script';
    if (clean.includes('windows upgrad')) return 'dig_project_windows_upgrade';
    if (clean.includes('battery cut off')) return 'dig_project_lga_battery';
    if (clean.includes('egp')) return 'dig_project_lga_egp';
    if (clean.includes('carddel')) return 'dig_project_lga_carddel';
    if (clean.includes('material stored in gangway') || clean.includes('gangway')) return 'dig_project_lb2_gangway';
    if (clean.includes('navigation for material')) return 'dig_project_lb2_navigation';
    if (clean.includes('projector') || clean.includes('smart display')) return 'dig_project_lb2_smart_display';
  }

  return null;
}

// Parses worksheet vertically keeping track of parent rows (groups)
function parseStructuredSheet(rawRows, moduleName) {
  const results = [];
  let currentGroup = '';

  rawRows.forEach((row) => {
    if (!row || row.length < 2) return;

    const rawName = row[1];
    if (typeof rawName !== 'string') return;

    // Check if column A is not empty to identify group header changes
    const hasSlNo = row[0] !== undefined && row[0] !== null && row[0] !== '';
    const cleanName = rawName.trim().toLowerCase();

    if (moduleName === 'inventory') {
      if (cleanName.includes('>180') || cleanName.includes('>90') || cleanName.includes('machinery spares') || (cleanName.includes('tools') && cleanName.includes('idm'))) {
        currentGroup = 'ageing';
      }
    }

    let lookupName = cleanName;
    if (hasSlNo) {
      currentGroup = cleanName;
      lookupName = cleanName;
    } else if (currentGroup) {
      lookupName = `${currentGroup} ${cleanName}`;
    }

    const kpiId = mapNameToKpiId(lookupName, moduleName);
    if (kpiId) {
      let targetVal = safeParseFloat(row[2]);
      let actualVal = safeParseFloat(row[3]);
      const unit = row[4] ? String(row[4]).trim() : '';

      const pctKeys = [
        'drr_1', 'drr_1_l1', 'drr_1_l2', 'drr_1_l3',
        'drr_2', 'drr_2_l1', 'drr_2_l2', 'drr_2_l3',
        'drr_3', 'drr_3_l1', 'drr_3_l2', 'drr_3_l3',
        'drr_4', 'drr_4_l1', 'drr_4_l2', 'drr_4_l3',
        'layer_audit', 'vc_charter', 'product_charter', 'comp_quality_notouch', 'launch_quality'
      ];

      if (unit === '%' || (moduleName === 'quality' && pctKeys.includes(kpiId))) {
        if (targetVal > 0 && targetVal <= 1.0) targetVal *= 100;
        if (actualVal > 0 && actualVal <= 1.0) actualVal *= 100;
      }

      const existingKpi = state.kpis.find(k => k.id === kpiId);
      let finalTarget = isNaN(targetVal) || targetVal === 0 ? (existingKpi ? existingKpi.target : 0) : targetVal;
      let finalActual = isNaN(actualVal) || actualVal === 0 ? (existingKpi ? existingKpi.actual : 0) : actualVal;

      results.push({
        id: kpiId,
        name: rawName,
        target: finalTarget,
        actual: finalActual
      });

      if (moduleName === 'quality') {
        if (kpiId === 'drr_1') results.push({ id: 'drr_1_l1', name: rawName + ' Line 1', target: finalTarget, actual: finalActual });
        if (kpiId === 'drr_2') results.push({ id: 'drr_2_l1', name: rawName + ' Line 1', target: finalTarget, actual: finalActual });
        if (kpiId === 'drr_3') results.push({ id: 'drr_3_l1', name: rawName + ' Line 1', target: finalTarget, actual: finalActual });
        if (kpiId === 'drr_4') results.push({ id: 'drr_4_l1', name: rawName + ' Line 1', target: finalTarget, actual: finalActual });
      }
    }
  });

  return results;
}

function parseCornerTableFromSafetySheet(rawRows) {
  let headerIdx = -1;
  let subHeaderIdx = -1;

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const joined = row.map(c => String(c || '').toLowerCase()).join(' ');
    if ((joined.includes('red corner') || joined.includes('blue corner')) && (joined.includes('sample') || joined.includes('closed') || joined.includes('fic'))) {
      headerIdx = i;
      break;
    }
  }

  if (headerIdx === -1) {
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i] || [];
      const joined = row.map(c => String(c || '').toLowerCase()).join(' ');
      if (joined.includes('red corner sample') || joined.includes('blue corner sample')) {
        subHeaderIdx = i;
        headerIdx = Math.max(0, i - 1);
        break;
      }
    }
  } else {
    for (let offset = 0; offset <= 3; offset++) {
      const rIdx = headerIdx + offset;
      if (rIdx >= rawRows.length) break;
      const joined = (rawRows[rIdx] || []).map(c => String(c || '').toLowerCase()).join(' ');
      if (joined.includes('sample') || joined.includes('closed')) {
        subHeaderIdx = rIdx;
        break;
      }
    }
  }

  if (subHeaderIdx === -1) return null;

  const subHeaderRow = rawRows[subHeaderIdx] || [];
  let redSampleCol = -1, redClosedCol = -1, redScoreCol = -1;
  let blueSampleCol = -1, blueClosedCol = -1, blueScoreCol = -1;

  for (let c = 0; c < subHeaderRow.length; c++) {
    const val = String(subHeaderRow[c] || '').trim().toLowerCase();
    if (val.includes('red corner sample') || (val.includes('red') && val.includes('sample'))) {
      redSampleCol = c;
    } else if (val.includes('red corner closed') || (val.includes('red') && val.includes('closed'))) {
      redClosedCol = c;
    } else if (val.includes('score') && redSampleCol !== -1 && redScoreCol === -1) {
      redScoreCol = c;
    } else if (val.includes('blue corner sample') || (val.includes('blue') && val.includes('sample'))) {
      blueSampleCol = c;
    } else if (val.includes('blue corner closed') || (val.includes('blue') && val.includes('closed'))) {
      blueClosedCol = c;
    } else if (val.includes('score') && blueSampleCol !== -1 && blueScoreCol === -1) {
      blueScoreCol = c;
    }
  }

  if (redSampleCol === -1 || redClosedCol === -1 || blueSampleCol === -1 || blueClosedCol === -1) {
    const headerRow = rawRows[headerIdx] || [];
    for (let c = 0; c < headerRow.length; c++) {
      const val = String(headerRow[c] || '').trim().toLowerCase();
      if (val.includes('red corner')) {
        redSampleCol = c;
        redClosedCol = c + 1;
        redScoreCol = c + 2;
      } else if (val.includes('blue corner')) {
        blueSampleCol = c;
        blueClosedCol = c + 1;
        blueScoreCol = c + 2;
      }
    }
  }

  if (redSampleCol === -1 || redClosedCol === -1) return null;

  const ficRows = [];
  let grandTotalRow = null;

  for (let offset = 1; offset <= 15; offset++) {
    const rIdx = subHeaderIdx + offset;
    if (rIdx >= rawRows.length) break;
    const row = rawRows[rIdx] || [];
    const col0 = String(row[0] || '').trim();
    const col1 = String(row[1] || '').trim();
    const name = col0 || col1;

    if (!name || name.toLowerCase().includes('target') || name.toLowerCase().includes('due date')) continue;

    const redSample = safeParseFloat(row[redSampleCol]);
    const redClosed = safeParseFloat(row[redClosedCol]);
    const redScore = safeParseFloat(row[redScoreCol !== -1 ? redScoreCol : redClosedCol + 1]);

    const blueSample = safeParseFloat(row[blueSampleCol]);
    const blueClosed = safeParseFloat(row[blueClosedCol]);
    const blueScore = safeParseFloat(row[blueScoreCol !== -1 ? blueScoreCol : blueClosedCol + 1]);

    const item = {
      name,
      redSample,
      redClosed,
      redScore,
      blueSample,
      blueClosed,
      blueScore
    };

    if (name.toLowerCase().includes('total')) {
      grandTotalRow = item;
      break;
    } else {
      ficRows.push(item);
    }
  }

  let finalRedSample = grandTotalRow ? grandTotalRow.redSample : ficRows.reduce((a, b) => a + b.redSample, 0);
  let finalRedClosed = grandTotalRow ? grandTotalRow.redClosed : ficRows.reduce((a, b) => a + b.redClosed, 0);
  let finalBlueSample = grandTotalRow ? grandTotalRow.blueSample : ficRows.reduce((a, b) => a + b.blueSample, 0);
  let finalBlueClosed = grandTotalRow ? grandTotalRow.blueClosed : ficRows.reduce((a, b) => a + b.blueClosed, 0);

  return {
    redCorner: { target: finalRedSample, actual: finalRedClosed },
    blueCorner: { target: finalBlueSample, actual: finalBlueClosed },
    grandTotal: grandTotalRow,
    ficRows
  };
}

// Parses safety detailed monthly parameters
function parseDetailedSafety(rawRows) {
  const result = {};

  const cornerData = parseCornerTableFromSafetySheet(rawRows);
  if (cornerData) {
    result.redCorner = cornerData.redCorner;
    result.blueCorner = cornerData.blueCorner;
    result.redBlueCornerFic = cornerData.ficRows;
  }

  const parseBlock = (keyword, defaultTarget = 0) => {
    let headerIdx = -1;
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i] || [];
      const joined = row.join(' ').toLowerCase();
      if (joined.includes(keyword.toLowerCase())) {
        headerIdx = i;
        break;
      }
    }
    if (headerIdx === -1) return null;

    let monthRow = null;
    let targetRow = null;
    let actualRow = null;

    for (let offset = 1; offset <= 8; offset++) {
      const rIdx = headerIdx + offset;
      if (rIdx >= rawRows.length) break;
      const row = rawRows[rIdx] || [];
      const col0 = String(row[0] || '').trim().toLowerCase();
      const col1 = String(row[1] || '').trim().toLowerCase();
      const col2 = String(row[2] || '').trim().toLowerCase();
      const label = col0 || col1 || col2;

      if (label.includes('month') || label.includes('fic')) {
        if (!monthRow) monthRow = row;
      } else if (label.includes('plan') || label.includes('target') || label.includes('camera')) {
        if (!targetRow) targetRow = row;
        if (label.includes('camera') && !actualRow) actualRow = row;
      } else if (label.includes('actual') || label.includes('total') || label.includes('session')) {
        if (label.includes('uom') || label.includes('unit')) continue;
        if (!actualRow) actualRow = row;
      }
    }

    if (!targetRow && actualRow) targetRow = actualRow;
    if (!actualRow && targetRow) actualRow = targetRow;
    if (!monthRow || !actualRow) return null;

    const months = [];
    const targets = [];
    const actuals = [];
    let ytdTarget = null;
    let ytdActual = null;

    for (let c = 2; c < monthRow.length; c++) {
      const mHeader = String(monthRow[c] || '').trim();
      if (!mHeader) continue;

      const tgtVal = targetRow ? (safeParseFloat(targetRow[c]) || defaultTarget) : defaultTarget;
      const actVal = actualRow ? safeParseFloat(actualRow[c]) : 0;

      if (mHeader.toLowerCase().includes('ytd')) {
        ytdTarget = tgtVal;
        ytdActual = actVal;
      } else if (isMonthLabel(mHeader)) {
        months.push(mHeader);
        targets.push(tgtVal);
        actuals.push(actVal);
      }
    }

    if (keyword.toLowerCase().includes('s.a.f.e')) {
      ytdTarget = targets.reduce((a, b) => a + b, 0);
      ytdActual = actuals.reduce((a, b) => a + b, 0);
    } else if (ytdTarget === null || ytdTarget === 0) {
      ytdTarget = targets.length > 0 ? targets[targets.length - 1] : defaultTarget;
      ytdActual = actuals.length > 0 ? actuals[actuals.length - 1] : 0;
    }

    if (keyword.toLowerCase().includes('smt')) {
      targets.fill(1.0);
      ytdTarget = 1.0;
    }
    if (keyword.toLowerCase().includes('sdt')) {
      targets.fill(1.0);
      ytdTarget = 1.0;
    }

    return { months, targets, actuals, ytdTarget, ytdActual };
  };

  result.safe_session = parseBlock('s.a.f.e', 2);
  result.floor_leadership = parseBlock('leadership on floor', 5);
  result.visilens = parseBlock('healthy cameras', 104);
  result.smt_coverage = parseBlock("smt's coverage", 1.0);
  result.sdt_coverage = parseBlock("sdt's coverage", 1.0);

  // Safety Training
  let stIdx = -1;
  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    if (row.join(' ').toLowerCase().includes('safety training')) {
      stIdx = i;
      break;
    }
  }
  let stAct = 4.21;
  if (stIdx !== -1) {
    for (let offset = 1; offset <= 10; offset++) {
      const row = rawRows[stIdx + offset] || [];
      const label = String(row[1] || '').trim().toLowerCase();
      if (label === 'total') {
        stAct = safeParseFloat(row[2]) || 4.21;
        break;
      }
    }
  }
  result.safety_training = {
    months: ["Aug'26"], targets: [0.6], actuals: [stAct], ytdTarget: 0.6, ytdActual: stAct
  };

  // SIF Derisking Phase 2 & Phase 3
  let sifIdx = -1;
  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    if (row.join(' ').toLowerCase().includes('sif') && row.join(' ').toLowerCase().includes('derisking')) {
      sifIdx = i;
      break;
    }
  }
  if (sifIdx !== -1) {
    const monthRow = rawRows[sifIdx + 1] || [];
    const p2TargetRow = rawRows[sifIdx + 2] || [];
    const p2ActualRow = rawRows[sifIdx + 3] || [];
    const p3TargetRow = rawRows[sifIdx + 4] || [];
    const p3ActualRow = rawRows[sifIdx + 5] || [];

    const p2Months = [], p2Tgt = [], p2Act = [];
    const p3Months = [], p3Tgt = [], p3Act = [];
    let p2YtdTgt = 197, p2YtdAct = 197, p3YtdTgt = 51, p3YtdAct = 51;

    for (let c = 3; c < monthRow.length; c++) {
      const m = String(monthRow[c] || '').trim();
      if (!m) continue;
      if (m.toLowerCase().includes('ytd')) {
        p2YtdTgt = safeParseFloat(p2TargetRow[c]) || 197;
        p2YtdAct = safeParseFloat(p2ActualRow[c]) || 197;
        p3YtdTgt = safeParseFloat(p3TargetRow[c]) || 51;
        p3YtdAct = safeParseFloat(p3ActualRow[c]) || 51;
      } else if (isMonthLabel(m)) {
        p2Months.push(m); p2Tgt.push(safeParseFloat(p2TargetRow[c]) || 197); p2Act.push(safeParseFloat(p2ActualRow[c]));
        p3Months.push(m); p3Tgt.push(safeParseFloat(p3TargetRow[c]) || 51); p3Act.push(safeParseFloat(p3ActualRow[c]));
      }
    }

    result.phase_2 = { months: p2Months, targets: p2Tgt, actuals: p2Act, ytdTarget: p2YtdTgt, ytdActual: p2YtdAct };
    result.phase_3 = { months: p3Months, targets: p3Tgt, actuals: p3Act, ytdTarget: p3YtdTgt, ytdActual: p3YtdAct };
  }

  // PSI I, PSI II, TRCFR
  let psiHeaderRow = null;
  for (let i = 0; i < rawRows.length; i++) {
    const joined = (rawRows[i] || []).join(' ').toLowerCase();
    if (joined.includes('fy 24') || joined.includes('fy24')) {
      psiHeaderRow = rawRows[i];
      break;
    }
  }

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const col1 = String(row[1] || row[2] || '').trim().toLowerCase();

    if (col1 === 'psi ii') {
      const actRow = rawRows[i + 2] || [];
      let ytdVal = 56.28, months = [], actuals = [];
      if (psiHeaderRow) {
        for (let c = 3; c < psiHeaderRow.length; c++) {
          const m = String(psiHeaderRow[c] || '').trim();
          if (m.toLowerCase().includes('ytd')) ytdVal = safeParseFloat(actRow[c]);
          else if (m && isMonthLabel(m)) { months.push(m); actuals.push(safeParseFloat(actRow[c])); }
        }
      }
      const fyData = extractFyDataFromRow(psiHeaderRow, actRow, actuals);
      result.psi2 = actuals;
      result.psi2Obj = { actuals, targets: months.map(() => 100), ytdTarget: 100, ytdActual: ytdVal, fyData };
      result.psi2Targets = months.map(() => 100);
      result.psi2Ytd = ytdVal;
    } else if (col1 === 'psi i') {
      const actRow = rawRows[i + 2] || [];
      let ytdVal = 97.3, months = [], actuals = [];
      if (psiHeaderRow) {
        for (let c = 3; c < psiHeaderRow.length; c++) {
          const m = String(psiHeaderRow[c] || '').trim();
          if (m.toLowerCase().includes('ytd')) ytdVal = safeParseFloat(actRow[c]);
          else if (m && isMonthLabel(m)) { months.push(m); actuals.push(safeParseFloat(actRow[c])); }
        }
      }
      const fyData = extractFyDataFromRow(psiHeaderRow, actRow, actuals);
      result.psi1 = actuals;
      result.psi1Obj = { actuals, targets: months.map(() => 95), ytdTarget: 95, ytdActual: ytdVal, fyData };
      result.psi1Targets = months.map(() => 95);
      result.psi1Ytd = ytdVal;
    } else if (col1 === 'trcfr') {
      const actRow = rawRows[i + 2] || [];
      let ytdVal = 2.06, months = [], actuals = [];
      if (psiHeaderRow) {
        for (let c = 3; c < psiHeaderRow.length; c++) {
          const m = String(psiHeaderRow[c] || '').trim();
          if (m.toLowerCase().includes('ytd')) ytdVal = safeParseFloat(actRow[c]);
          else if (m && isMonthLabel(m)) { months.push(m); actuals.push(safeParseFloat(actRow[c])); }
        }
      }
      const fyData = extractFyDataFromRow(psiHeaderRow, actRow, actuals);
      result.trcfr = actuals;
      result.trcfrObj = { actuals, targets: months.map(() => 0.31), ytdTarget: 0.31, ytdActual: ytdVal, fyData };
      result.trcfrTargets = months.map(() => 0.31);
      result.trcfrYtd = ytdVal;
    }
  }

  // BPMS Rating
  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    if (String(row[1] || '').toLowerCase().includes('star rating')) {
      const valRow = rawRows[i + 2] || [];
      const tgt = safeParseFloat(valRow[4]);
      const act = safeParseFloat(valRow[5]);
      result.bpms_rating = { target: tgt || 19, actual: act || 2, ytdTarget: tgt || 19, ytdActual: act || 2 };
      break;
    }
  }

  // Extract Injury FY history from bottom table (Row 125 onwards) if present
  let fyHeaderIdx = -1;
  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const joined = row.join(' ').toLowerCase();
    if (joined.includes('fy24') && joined.includes('fy25') && joined.includes('fy26')) {
      fyHeaderIdx = i;
      break;
    }
  }

  const getInjFyData = (labelNames, fallbackYtd = 0) => {
    const labels = Array.isArray(labelNames) ? labelNames : [labelNames];
    if (fyHeaderIdx !== -1) {
      for (let offset = 1; offset <= 6; offset++) {
        const r = rawRows[fyHeaderIdx + offset] || [];
        const label = String(r[0] || r[1] || '').trim().toLowerCase();
        if (labels.includes(label)) {
          return {
            fy24: safeParseFloat(r[1]),
            fy25: safeParseFloat(r[2]),
            fy26: safeParseFloat(r[3]),
            ytd: safeParseFloat(r[4]) || fallbackYtd
          };
        }
      }
    }
    return { fy24: 0, fy25: 0, fy26: 0, ytd: fallbackYtd };
  };

  // Injuries
  let trendHeaderIdx = -1;
  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const hasMonthOrYtd = row.some(c => isMonthLabel(c) || String(c).toLowerCase().includes('ytd'));
    if (hasMonthOrYtd) {
      for (let offset = 1; offset <= 5; offset++) {
        const nextRow = rawRows[i + offset] || [];
        const label = String(nextRow[1] || nextRow[0] || '').trim().toLowerCase();
        if (['fac', 'mtc', 'rwc', 'lti', 'lta'].includes(label)) {
          trendHeaderIdx = i;
          break;
        }
      }
      if (trendHeaderIdx !== -1) break;
    }
  }

  if (trendHeaderIdx !== -1) {
    const mRow = rawRows[trendHeaderIdx] || [];
    let ytdCol = -1;
    const monthCols = [];
    const months = [];
    for (let c = 0; c < mRow.length; c++) {
      const m = String(mRow[c] || '').trim();
      if (m.toLowerCase().includes('ytd')) ytdCol = c;
      else if (m && isMonthLabel(m)) {
        monthCols.push(c);
        months.push(m);
      }
    }

    const getInjObj = (labelNames) => {
      const labels = Array.isArray(labelNames) ? labelNames : [labelNames];
      for (let offset = 1; offset <= 5; offset++) {
        const row = rawRows[trendHeaderIdx + offset] || [];
        const colLabel = String(row[1] || row[0] || '').trim().toLowerCase();
        if (labels.includes(colLabel)) {
          const actuals = monthCols.map(c => safeParseFloat(row[c]));
          const ftm = actuals.length > 0 ? actuals[actuals.length - 1] : 0;
          const ytd = ytdCol !== -1 ? safeParseFloat(row[ytdCol]) : actuals.reduce((a, b) => a + b, 0);
          const fyData = getInjFyData(labels, ytd);
          return { months, actuals, ftm, ytd, fyData };
        }
      }
      return { months: [], actuals: [], ftm: 0, ytd: 0, fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: 0 } };
    };

    const facObj = getInjObj('fac');
    const mtcObj = getInjObj('mtc');
    const rwcObj = getInjObj('rwc');
    const ltaObj = getInjObj(['lti', 'lta']);

    result.fac = facObj.actuals;
    result.mtc = mtcObj.actuals;
    result.rwc = rwcObj.actuals;
    result.lta = ltaObj.actuals;
    result.facObj = facObj;
    result.mtcObj = mtcObj;
    result.rwcObj = rwcObj;
    result.ltaObj = ltaObj;
    if (facObj.months && facObj.months.length > 0) {
      result.labels = facObj.months;
    }
  }

  if (!result.labels && result.psi1Obj && result.psi1Obj.actuals) {
    result.labels = result.psi1Obj.months || ["Apr'26", "May'26", "June'26", "July'26", "Aug'26"];
  }

  // FIC Wise Injuries (FTM & YTD) Universal Parsing
  let ficHeaderIdx = -1;
  let subheaderIdx = -1;

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const joined = row.join(' ').toLowerCase();

    // Skip Near Miss and Camera tables
    if (joined.includes('near miss') || joined.includes('unhealthy camera')) continue;

    // Check if next row contains FAC, MTC, RWC, LTI subheaders
    const nextRow = rawRows[i + 1] || [];
    const nextJoined = nextRow.join(' ').toLowerCase();
    
    if (joined.includes('fic') && (nextJoined.includes('fac') && (nextJoined.includes('mtc') || nextJoined.includes('lti') || nextJoined.includes('rwc')))) {
      ficHeaderIdx = i;
      subheaderIdx = i + 1;
      break;
    }
  }

  if (ficHeaderIdx !== -1) {
    const hRow1 = rawRows[ficHeaderIdx] || [];
    const hRow2 = rawRows[subheaderIdx] || [];

    const facCols = [], mtcCols = [], rwcCols = [], ltiCols = [];

    for (let c = 0; c < hRow2.length; c++) {
      const label = String(hRow2[c] || '').trim().toLowerCase();
      if (label === 'fac') facCols.push(c);
      else if (label === 'mtc') mtcCols.push(c);
      else if (label === 'rwc') rwcCols.push(c);
      else if (label === 'lti' || label === 'lta') ltiCols.push(c);
    }

    let ftmFacCol = -1, ftmMtcCol = -1, ftmRwcCol = -1, ftmLtiCol = -1;
    let ytdFacCol = -1, ytdMtcCol = -1, ytdRwcCol = -1, ytdLtiCol = -1;

    if (facCols.length >= 2) {
      ftmFacCol = facCols[0];
      ftmMtcCol = mtcCols[0] !== undefined ? mtcCols[0] : -1;
      ftmRwcCol = rwcCols[0] !== undefined ? rwcCols[0] : -1;
      ftmLtiCol = ltiCols[0] !== undefined ? ltiCols[0] : -1;

      ytdFacCol = facCols[1];
      ytdMtcCol = mtcCols[1] !== undefined ? mtcCols[1] : -1;
      ytdRwcCol = rwcCols[1] !== undefined ? rwcCols[1] : -1;
      ytdLtiCol = ltiCols[1] !== undefined ? ltiCols[1] : -1;
    } else if (facCols.length === 1) {
      ytdFacCol = facCols[0];
      ytdMtcCol = mtcCols[0] !== undefined ? mtcCols[0] : -1;
      ytdRwcCol = rwcCols[0] !== undefined ? rwcCols[0] : -1;
      ytdLtiCol = ltiCols[0] !== undefined ? ltiCols[0] : -1;
    }

    const monthlyList = [];
    const ytdList = [];

    for (let offset = 2; offset <= 15; offset++) {
      const rIdx = ficHeaderIdx + offset;
      if (rIdx >= rawRows.length) break;
      const row = rawRows[rIdx] || [];
      
      let name = '';
      for (let c = 0; c <= 3; c++) {
        const cellVal = String(row[c] || '').trim();
        if (cellVal && !cellVal.toLowerCase().includes('daily') && !cellVal.toLowerCase().includes('fic') && isNaN(parseFloat(cellVal))) {
          name = cellVal;
          break;
        }
      }

      if (!name) continue;

      const mFac = ftmFacCol !== -1 ? safeParseFloat(row[ftmFacCol]) : (ytdFacCol !== -1 ? safeParseFloat(row[ytdFacCol]) : 0);
      const mMtc = ftmMtcCol !== -1 ? safeParseFloat(row[ftmMtcCol]) : (ytdMtcCol !== -1 ? safeParseFloat(row[ytdMtcCol]) : 0);
      const mRwc = ftmRwcCol !== -1 ? safeParseFloat(row[ftmRwcCol]) : (ytdRwcCol !== -1 ? safeParseFloat(row[ytdRwcCol]) : 0);
      const mLti = ftmLtiCol !== -1 ? safeParseFloat(row[ftmLtiCol]) : (ytdLtiCol !== -1 ? safeParseFloat(row[ytdLtiCol]) : 0);

      const yFac = ytdFacCol !== -1 ? safeParseFloat(row[ytdFacCol]) : 0;
      const yMtc = ytdMtcCol !== -1 ? safeParseFloat(row[ytdMtcCol]) : 0;
      const yRwc = ytdRwcCol !== -1 ? safeParseFloat(row[ytdRwcCol]) : 0;
      const yLti = ytdLtiCol !== -1 ? safeParseFloat(row[ytdLtiCol]) : 0;

      monthlyList.push({ name, fac: mFac, mtc: mMtc, rwc: mRwc, lti: mLti });
      ytdList.push({ name, fac: yFac, mtc: yMtc, rwc: yRwc, lti: yLti });

      if (name.toLowerCase() === 'total') break;
    }

    if (monthlyList.length > 0) result.ficWiseInjuries = monthlyList;
    if (ytdList.length > 0) result.ficWiseInjuriesYtd = ytdList;
  }

  return result;
}

// Imports monthly safety values into state
function importSafetyMonthlyData(parsed) {
  if (!parsed) return;

  if (parsed.labels && parsed.labels.length > 0) {
    state.safetyMonthlyData.labels = parsed.labels;
  }

  const keys = ['safe_session', 'floor_leadership', 'visilens', 'phase_2', 'phase_3', 'smt_coverage', 'sdt_coverage', 'safety_training', 'bpms_rating', 'psi1Obj', 'psi2Obj', 'trcfrObj', 'facObj', 'mtcObj', 'rwcObj', 'ltaObj'];
  keys.forEach(key => {
    if (parsed[key]) {
      state.safetyMonthlyData[key] = parsed[key];
    }
  });

  if (Array.isArray(parsed.psi1)) state.safetyMonthlyData.psi1 = parsed.psi1;
  if (Array.isArray(parsed.psi2)) state.safetyMonthlyData.psi2 = parsed.psi2;
  if (Array.isArray(parsed.trcfr)) state.safetyMonthlyData.trcfr = parsed.trcfr;
  if (Array.isArray(parsed.fac)) state.safetyMonthlyData.fac = parsed.fac;
  if (Array.isArray(parsed.lta)) state.safetyMonthlyData.lta = parsed.lta;
  if (Array.isArray(parsed.mtc)) state.safetyMonthlyData.mtc = parsed.mtc;
  if (Array.isArray(parsed.rwc)) state.safetyMonthlyData.rwc = parsed.rwc;

  if (parsed.psi1Ytd !== undefined) state.safetyMonthlyData.psi1Ytd = parsed.psi1Ytd;
  if (parsed.psi2Ytd !== undefined) state.safetyMonthlyData.psi2Ytd = parsed.psi2Ytd;
  if (parsed.trcfrYtd !== undefined) state.safetyMonthlyData.trcfrYtd = parsed.trcfrYtd;

  state.safetyMonthlyData.fyData = {
    psi1: parsed.psi1Obj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.psi1Ytd ?? parsed.psi1Obj?.ytdActual },
    psi2: parsed.psi2Obj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.psi2Ytd ?? parsed.psi2Obj?.ytdActual },
    trcfr: parsed.trcfrObj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.trcfrYtd ?? parsed.trcfrObj?.ytdActual },
    fac: parsed.facObj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.facObj?.ytd },
    lta: parsed.ltaObj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.ltaObj?.ytd },
    mtc: parsed.mtcObj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.mtcObj?.ytd },
    rwc: parsed.rwcObj?.fyData || { fy24: 0, fy25: 0, fy26: 0, ytd: parsed.rwcObj?.ytd }
  };

  if (parsed.meetings) {
    state.safetyMonthlyData.meetings = parsed.meetings;
  }

  if (parsed.ficWiseInjuries && parsed.ficWiseInjuries.length > 0) {
    state.ficWiseInjuries = parsed.ficWiseInjuries;
  }
  if (parsed.ficWiseInjuriesYtd && parsed.ficWiseInjuriesYtd.length > 0) {
    state.ficWiseInjuriesYtd = parsed.ficWiseInjuriesYtd;
  }

  if (parsed.redCorner) {
    state.safetyMonthlyData.redCorner = parsed.redCorner;
    const redKpi = state.kpis.find(k => k.id === 'red_corner');
    if (redKpi) {
      redKpi.target = parsed.redCorner.target;
      redKpi.actual = parsed.redCorner.actual;
    }
  }
  if (parsed.blueCorner) {
    state.safetyMonthlyData.blueCorner = parsed.blueCorner;
    const blueKpi = state.kpis.find(k => k.id === 'blue_corner');
    if (blueKpi) {
      blueKpi.target = parsed.blueCorner.target;
      blueKpi.actual = parsed.blueCorner.actual;
    }
  }
  if (parsed.redBlueCornerFic && parsed.redBlueCornerFic.length > 0) {
    state.safetyMonthlyData.redBlueCornerFic = parsed.redBlueCornerFic;
  }
}

// Helper to identify if a label is an actual monthly/timeline metric column (excluding days/weeks/etc.)
function isMonthLabel(m) {
  if (!m) return false;
  const str = String(m).trim().toLowerCase();
  if (!str) return false;
  
  let cleanStr = str;
  if (str.startsWith('mtd')) {
    cleanStr = str.replace('mtd', '').trim();
  }
  
  const months = ['apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec', 'jan', 'feb', 'mar'];
  return months.some(month => cleanStr.startsWith(month));
}

// Extracts FY24, FY25, FY26 and YTD values dynamically from detailed worksheet rows
function extractFyDataFromRow(monthsRow, dataRow, actuals, tcRow) {
  const fyData = { fy24: 0, fy25: 0, fy26: 0, ytd: 0, ytdTarget: 0 };
  if (!monthsRow || !dataRow) return fyData;
  for (let c = 1; c < monthsRow.length; c++) {
    const val = monthsRow[c] ? String(monthsRow[c]).trim().toLowerCase().replace(/\s+/g, '') : '';
    const num = safeParseFloat(dataRow[c]) || 0;
    const tcNum = tcRow ? (safeParseFloat(tcRow[c]) || 0) : 0;
    if (val === 'fy24' || val === 'fy24actual' || val === 'fy24avg' || val === 'fy24total' || val === 'fy24actuals' || val === 'fy24ytd' || val === 'fy24score') {
      fyData.fy24 = num;
    } else if (val === 'fy25' || val === 'fy25actual' || val === 'fy25avg' || val === 'fy25total' || val === 'fy25actuals' || val === 'fy25ytd' || val === 'fy25score') {
      fyData.fy25 = num;
    } else if (val === 'fy26' || val === 'fy26actual' || val === 'fy26avg' || val === 'fy26total' || val === 'fy26actuals' || val === 'fy26ytd' || val === 'fy26score') {
      fyData.fy26 = num;
    } else if (val.includes('ytd') || val.includes('fy27ytd') || val.includes('ytdfy27') || val === 'fy27') {
      fyData.ytd = num;
      if (tcNum) fyData.ytdTarget = tcNum;
    }
  }
  if (!fyData.ytd && actuals && actuals.length > 0) {
    fyData.ytd = actuals[actuals.length - 1];
  }
  return fyData;
}

// Parses productivity detailed monthly parameters
function parseDetailedProductivity(rawRows) {
  let hpev3Data = null;
  let hpev4Data = null;
  let cpevData = null;

  for (let i = 0; i < rawRows.length; i++) {
    if (!rawRows[i] || !rawRows[i][0]) continue;
    const clean0 = String(rawRows[i][0]).trim().replace(/\s+/g, '');
    
    if (clean0 === 'HPeV(L3)' || clean0 === 'HPeV(L4)' || clean0 === 'CPeV') {
      const monthsRow = rawRows[i + 1] || [];
      let tcRow = [];
      let scRow = [];
      let actualRow = [];
      
      const nextLabel = rawRows[i + 3] && rawRows[i + 3][0] ? String(rawRows[i + 3][0]).trim().toLowerCase() : '';
      if (nextLabel === 'sc' || nextLabel === 'sc target') {
        tcRow = rawRows[i + 2] || [];
        scRow = rawRows[i + 3] || [];
        actualRow = rawRows[i + 4] || [];
      } else {
        tcRow = rawRows[i + 2] || [];
        scRow = rawRows[i + 2] || [];
        actualRow = rawRows[i + 3] || [];
      }
      
      const months = [];
      const targets = [];
      const scTargets = [];
      const actuals = [];
      for (let c = 1; c < monthsRow.length; c++) {
        const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
        if (isMonthLabel(m)) {
          months.push(m);
          targets.push(safeParseFloatOrNull(tcRow[c]));
          scTargets.push(safeParseFloatOrNull(scRow[c]));
          actuals.push(safeParseFloatOrNull(actualRow[c]));
        }
      }
      
      const dataset = { months, targets, scTargets, actuals, fyData: extractFyDataFromRow(monthsRow, actualRow, actuals) };
      if (clean0 === 'HPeV(L3)') hpev3Data = dataset;
      else if (clean0 === 'HPeV(L4)') hpev4Data = dataset;
      else if (clean0 === 'CPeV') cpevData = dataset;
    }
  }

  return { hpev3: hpev3Data, hpev4: hpev4Data, cpev: cpevData };
}

// Imports monthly productivity values into state
function importProductivityMonthlyData(parsed) {
  if (parsed.hpev3) {
    state.productivityMonthlyData.hpev3 = parsed.hpev3;
  }
  if (parsed.hpev4) {
    state.productivityMonthlyData.hpev4 = parsed.hpev4;
  }
  if (parsed.cpev) {
    state.productivityMonthlyData.cpev = parsed.cpev;
  }
}

// Fallback Excel JSON parser
function parseExcelJSON(rows) {
  return rows.map(row => {
    const idKey = Object.keys(row).find(k => k.toLowerCase().includes('kpi id') || k.toLowerCase() === 'id');
    const nameKey = Object.keys(row).find(k => k.toLowerCase().includes('kpi name') || k.toLowerCase() === 'name');
    const targetKey = Object.keys(row).find(k => k.toLowerCase().includes('target'));
    const actualKey = Object.keys(row).find(k => k.toLowerCase().includes('actual'));

    return {
      id: idKey ? String(row[idKey]) : null,
      name: nameKey ? String(row[nameKey]) : null,
      target: targetKey ? safeParseFloat(row[targetKey]) || 0 : undefined,
      actual: actualKey ? safeParseFloat(row[actualKey]) || 0 : undefined
    };
  }).filter(item => item.id || item.name);
}

// Simple CSV parser
function parseCSVData(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(l => l);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
  const idIdx = headers.indexOf('kpi id');
  const nameIdx = headers.indexOf('kpi name');
  const targetIdx = headers.indexOf('target');
  const actualIdx = headers.indexOf('actual');

  if (idIdx === -1 && nameIdx === -1) return [];

  const results = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(',').map(c => c.trim().replace(/^"|"$/g, ''));
    if (cols.length < Math.max(idIdx, nameIdx, targetIdx, actualIdx)) continue;

    results.push({
      id: idIdx !== -1 ? cols[idIdx] : null,
      name: nameIdx !== -1 ? cols[nameIdx] : null,
      target: targetIdx !== -1 ? safeParseFloat(cols[targetIdx]) || 0 : undefined,
      actual: actualIdx !== -1 ? safeParseFloat(cols[actualIdx]) || 0 : undefined
    });
  }
  return results;
}

// Bind tabs navigation click events
function setupTabs() {
  const tabs = [
    { id: 'tab-overall', module: 'overall' },
    { id: 'tab-safety', module: 'safety' },
    { id: 'tab-quality', module: 'quality' },
    { id: 'tab-productivity', module: 'productivity' },
    { id: 'tab-delivery', module: 'delivery' },
    { id: 'tab-cost', module: 'cost' },
    { id: 'tab-inventory', module: 'inventory' },
    { id: 'tab-environment', module: 'environment' },
    { id: 'tab-hr', module: 'hr' },
    { id: 'tab-digital', module: 'digital' }
  ];

  tabs.forEach(t => {
    const btn = document.getElementById(t.id);
    if (btn) {
      btn.addEventListener('click', () => {
        tabs.forEach(x => {
          const b = document.getElementById(x.id);
          if (b) b.classList.remove('active');
        });
        btn.classList.add('active');
        state.currentModule = t.module;
        renderAll();
      });
    }
  });
}

// Reset button hook
function setupResetButton() {
  const btn = document.getElementById('btn-reset');
  if (btn) {
    btn.addEventListener('click', () => {
      // Clear base states so it resets to hardcoded default values
      state.baseKpis = null;
      state.baseSafetyMonthlyData = null;
      state.baseProductivityMonthlyData = null;
      state.baseDeliveryMonthlyData = null;
      state.baseCostMonthlyData = null;
      state.baseHrMonthlyData = null;
      state.baseQualityMonthlyData = null;
      state.baseEnvironmentMonthlyData = null;
      state.baseInventoryMonthlyData = null;
      state.baseDigitalMonthlyData = null;

      resetState();
      document.getElementById('filter-date').value = 'All Dates';
      document.getElementById('filter-plant').value = 'All Plants';
      document.getElementById('filter-dept').value = 'All Departments';
      document.getElementById('filter-shift').value = 'All Shifts';
      renderAll();
    });
  }
}

// Template download hook
function setupTemplateButton() {
  const btn = document.getElementById('btn-download-template');
  if (btn) {
    btn.addEventListener('click', downloadCSVTemplate);
  }
}

// Render and update history items list inside drawer
function renderHistoryItems() {
  const container = document.getElementById('history-list-container');
  if (!container) return;

  const logs = loadHistoryLogs();

  if (!logs || logs.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; color: var(--text-muted); font-size: 13px; padding: 30px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 10px;">
        <span style="font-size: 26px; display: block; margin-bottom: 8px;">📂</span>
        <strong>No Uploaded Datasets Found</strong>
        <p style="margin-top: 4px; font-size: 11.5px; color: #64748b;">Uploaded dataset files and data checkpoints will be automatically stored in SQLite database memory and listed here.</p>
      </div>
    `;
    return;
  }

  let html = '';
  logs.forEach(log => {
    const rawTitle = log.title || (log.file_name ? `Dataset: ${log.file_name}` : 'Uploaded Dataset');
    const titleText = String(rawTitle).trim();
    const rawTime = log.timestamp || log.upload_timestamp || new Date().toLocaleString();
    const timeText = typeof rawTime === 'string' ? rawTime.replace('T', ' ').substring(0, 19) : new Date(rawTime).toLocaleString();
    const periodText = log.reporting_period ? `Period: ${log.reporting_period}` : `Module: ${String(log.module || 'overall').toUpperCase()}`;
    const rowCountText = log.valid_rows ? ` • ${log.valid_rows} Records` : (log.total_rows ? ` • ${log.total_rows} Rows` : '');
    const logId = String(log.id || log.upload_id || Date.now());
    const isFileImport = titleText.toLowerCase().includes('imported') || titleText.toLowerCase().includes('upload') || titleText.endsWith('.xlsx') || titleText.endsWith('.csv') || log.file_name;

    html += `
      <div class="history-item-card" style="background: #ffffff; border: 1px solid #cbd5e1; border-radius: 10px; padding: 14px 16px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; gap: 12px; box-shadow: 0 2px 8px rgba(15, 23, 42, 0.05); transition: transform 0.2s, box-shadow 0.2s;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="width: 40px; height: 40px; border-radius: 8px; background: ${isFileImport ? '#eff6ff' : '#f0fdf4'}; border: 1px solid ${isFileImport ? '#bfdbfe' : '#bbf7d0'}; display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0;">
            ${isFileImport ? '📊' : '📝'}
          </div>
          <div style="display: flex; flex-direction: column; gap: 3px;">
            <div style="font-weight: 800; font-size: 13.5px; color: #0f172a; display: flex; align-items: center; gap: 6px;">
              ${titleText}
            </div>
            <div style="font-size: 11px; color: #64748b; font-weight: 500;">
              📅 ${timeText} • <span style="color: #2563eb; font-weight: 700;">${periodText}</span>${rowCountText}
            </div>
          </div>
        </div>
        <div style="display: flex; gap: 8px; flex-shrink: 0;">
          <button class="btn btn-primary btn-restore-history" data-id="${logId}" style="padding: 6px 12px; font-size: 11.5px; font-weight: 700; cursor: pointer; background: #2563eb; border-radius: 6px; border: none; color: white;">Restore</button>
          <button class="btn btn-outline btn-delete-history" data-id="${logId}" style="padding: 6px 12px; font-size: 11.5px; font-weight: 700; color: #ef4444; border: 1px solid #fee2e2; background: #fef2f2; cursor: pointer; border-radius: 6px;">🗑 Delete</button>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;

  // Bind Restore events
  container.querySelectorAll('.btn-restore-history').forEach(btn => {
    btn.addEventListener('click', async () => {
      const logId = btn.getAttribute('data-id');
      const originalText = btn.textContent;
      btn.disabled = true;
      btn.textContent = 'Restoring...';

      try {
        const success = await restoreHistoryLog(logId);
        btn.disabled = false;
        btn.textContent = originalText;

        if (success) {
          // Sync active tab state
          const tabs = ['tab-overall', 'tab-safety', 'tab-quality', 'tab-productivity', 'tab-delivery', 'tab-cost', 'tab-inventory', 'tab-environment', 'tab-hr', 'tab-digital'];
          tabs.forEach(t => {
            const tabBtn = document.getElementById(t);
            if (tabBtn) tabBtn.classList.remove('active');
          });
          const currentTabBtn = document.getElementById(`tab-${state.currentModule}`);
          if (currentTabBtn) currentTabBtn.classList.add('active');

          // Close drawer
          const drawer = document.getElementById('history-drawer');
          if (drawer) drawer.classList.remove('open');
          renderAll();
          alert('Dashboard state successfully restored from history dataset!');
        } else {
          alert('Failed to restore history dataset.');
        }
      } catch (err) {
        btn.disabled = false;
        btn.textContent = originalText;
        alert('Error restoring history dataset: ' + err.message);
      }
    });
  });

  // Bind Delete events
  container.querySelectorAll('.btn-delete-history').forEach(btn => {
    btn.addEventListener('click', () => {
      const logId = btn.getAttribute('data-id');
      deleteHistoryLog(logId);
      renderHistoryItems();
    });
  });
}

// History Drawer Trigger Hooks
function setupHistoryDrawer() {
  const drawer = document.getElementById('history-drawer');
  const openBtn = document.getElementById('btn-open-history');
  const closeBtn = document.getElementById('btn-close-history');
  const closeBtnFooter = document.getElementById('btn-close-history-footer');
  const clearBtn = document.getElementById('btn-clear-history');

  if (!drawer || !openBtn || !closeBtn || !closeBtnFooter || !clearBtn) return;

  // Open drawer
  openBtn.addEventListener('click', () => {
    renderHistoryItems();
    drawer.classList.add('open');
  });

  // Close drawer
  const closeDrawer = () => drawer.classList.remove('open');
  closeBtn.addEventListener('click', closeDrawer);
  closeBtnFooter.addEventListener('click', closeDrawer);

  // Clear all
  clearBtn.addEventListener('click', () => {
    if (confirm('Are you sure you want to clear all dashboard history logs?')) {
      clearHistoryLogs();
      renderHistoryItems();
    }
  });
}

// Render Header User Status Pill & Logout Button
function renderUserHeaderPill() {
  const container = document.getElementById('header-user-section');
  if (!container) return;

  if (state.currentUser) {
    const roleIcons = {
      admin: '👑',
      plant_manager: '🏭',
      quality_officer: '🏅',
      safety_head: '⛑️'
    };
    const icon = roleIcons[state.currentUser.username] || '👤';

    container.innerHTML = `
      <div class="user-status-pill">
        <span class="user-avatar-badge">${icon}</span>
        <div class="user-info-text">
          <span class="user-name">${state.currentUser.full_name || state.currentUser.username}</span>
          <span class="user-role">${state.currentUser.department || 'Operations'} • ${state.currentUser.role || 'User'}</span>
        </div>
        <button id="header-logout-btn" class="header-logout-btn" title="Sign out of session">
          <span>🚪 Logout</span>
        </button>
      </div>
    `;

    const logoutBtn = document.getElementById('header-logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', async () => {
        await clearAuthSession();
        renderUserHeaderPill();
        showAuthModal();
      });
    }
  } else {
    container.innerHTML = `
      <button id="header-login-btn" class="header-login-btn">
        <span>🔒 Sign In</span>
      </button>
    `;
    const loginBtn = document.getElementById('header-login-btn');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        showAuthModal();
      });
    }
  }
}

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  // Initialize Login Modal Component
  initAuthModal(async (user) => {
    renderUserHeaderPill();
    renderAll();
  });

  // Check auth session
  initAuthSession().then(user => {
    renderUserHeaderPill();
    if (!user) {
      showAuthModal();
    }
  });

  // Sync state with SQLite backend on boot
  syncStateWithBackend().then(() => {
    renderAll();
  }).catch(() => {
    renderAll();
  });

  // Load or save initial state log
  loadHistoryLogs();
  ensureAllKpisExist();
  if (state.historyLogs.length === 0) {
    saveHistoryLog('Initial State');
  }

  setupTabs();
  renderAll();
  setupFilters();
  setupFileUploader();
  setupResetButton();
  setupTemplateButton();
  setupHistoryDrawer();
  
  // Update editor save callback to also save checkpoint
  initDataEditor(() => {
    saveHistoryLog('Manual Edit');
    renderAll();
  });
});

// Parses delivery detailed monthly parameters (OTIF, MAPE, SPD, Production, Dispatch, Bus Engines)
function parseDetailedDelivery(rawRows) {
  const result = {};

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const cell0 = String(row[0] || '').trim();
    const cell1 = String(row[1] || '').trim();
    const cell2 = String(row[2] || '').trim();
    const joined = (cell0 + ' ' + cell1 + ' ' + cell2).toLowerCase();

    // 1. Target & Compliance Cards (OTIF, MAPE, SPD)
    const cardMetrics = [
      { key: 'otif_dom', keywords: ['otif', 'domestic'] },
      { key: 'otif_ib', keywords: ['otif', 'ib'] },
      { key: 'otif_spares', keywords: ['otif', 'spares'] },
      { key: 'spd', keywords: ['spd'] },
      { key: 'mape_dom_ilmcv', keywords: ['mape', 'domestic'] },
      { key: 'mape_ib', keywords: ['mape', 'ib'] }
    ];

    for (const item of cardMetrics) {
      if (item.keywords.every(kw => joined.includes(kw)) && !result[item.key]) {
        let monthsRow = rawRows[i + 1] || [];
        if (!monthsRow.some(c => isMonthLabel(String(c).trim()))) {
          for (let mR = i; mR <= i + 4 && mR < rawRows.length; mR++) {
            if ((rawRows[mR] || []).some(c => isMonthLabel(String(c).trim()))) {
              monthsRow = rawRows[mR];
              break;
            }
          }
        }

        let tcRow = null, actualRow = null;
        for (let r = i + 1; r <= i + 8 && r < rawRows.length; r++) {
          const rRow = rawRows[r] || [];
          const label = (String(rRow[0] || '') + ' ' + String(rRow[1] || '')).trim().toLowerCase();
          if ((label.includes('tc') || label.includes('plan') || label.includes('target')) && !label.includes('actual') && !label.includes('sc') && !tcRow) {
            tcRow = rRow;
          } else if ((label.includes('actual') || label.includes('act')) && !actualRow) {
            actualRow = rRow;
          }
        }

        const months = [], targets = [], actuals = [];
        for (let c = 1; c < monthsRow.length; c++) {
          const m = String(monthsRow[c] || '').trim();
          if (isMonthLabel(m)) {
            months.push(m);
            const tVal = safeParseFloatOrNull(tcRow ? tcRow[c] : null);
            const aVal = safeParseFloatOrNull(actualRow ? actualRow[c] : null);
            targets.push(tVal !== null ? (tVal <= 1.0 ? parseFloat((tVal * 100).toFixed(1)) : tVal) : null);
            actuals.push(aVal !== null ? (aVal <= 1.0 ? parseFloat((aVal * 100).toFixed(1)) : aVal) : null);
          }
        }
        const rawFy = extractFyDataFromRow(monthsRow, actualRow, actuals);
        const fyData = {
          fy24: rawFy.fy24 <= 1.0 && rawFy.fy24 > 0 ? parseFloat((rawFy.fy24 * 100).toFixed(1)) : rawFy.fy24,
          fy25: rawFy.fy25 <= 1.0 && rawFy.fy25 > 0 ? parseFloat((rawFy.fy25 * 100).toFixed(1)) : rawFy.fy25,
          fy26: rawFy.fy26 <= 1.0 && rawFy.fy26 > 0 ? parseFloat((rawFy.fy26 * 100).toFixed(1)) : rawFy.fy26,
          ytdActual: rawFy.ytd <= 1.0 && rawFy.ytd > 0 ? parseFloat((rawFy.ytd * 100).toFixed(1)) : rawFy.ytd,
          ytd: rawFy.ytd <= 1.0 && rawFy.ytd > 0 ? parseFloat((rawFy.ytd * 100).toFixed(1)) : rawFy.ytd
        };
        const ytdActual = fyData.ytdActual;
        const validT = targets.filter(v => v !== null && !isNaN(v));
        const ytdTarget = validT.length > 0 ? parseFloat((validT.reduce((a, b) => a + b, 0) / validT.length).toFixed(1)) : 98;
        
        const metricObj = { months, targets, actuals, fyData, ytdTarget, ytdActual };
        result[item.key] = metricObj;
        if (item.key === 'otif_dom') result['otif'] = metricObj;
        if (item.key === 'mape_dom_ilmcv') {
          result['mape_dom_hcv'] = metricObj;
          result['mape_dom_cvp'] = metricObj;
        }
      }
    }

    // 2. Production
    if (joined.includes('production') && !result.prod_l2) {
      let monthsRow = rawRows[i + 1] || [];
      if (!monthsRow.some(c => isMonthLabel(String(c).trim()))) {
        for (let mR = i; mR <= i + 4 && mR < rawRows.length; mR++) {
          if ((rawRows[mR] || []).some(c => isMonthLabel(String(c).trim()))) {
            monthsRow = rawRows[mR];
            break;
          }
        }
      }
      let l2Plan = [], l2Act = [], l3Plan = [], l3Act = [];
      for (let r = i + 1; r <= i + 12 && r < rawRows.length; r++) {
        const rRow = rawRows[r] || [];
        const name = (String(rRow[0] || '') + ' ' + String(rRow[1] || '')).trim().toLowerCase();
        const type = (String(rRow[1] || '') + ' ' + String(rRow[2] || '')).trim().toLowerCase();
        if (name.includes('line 2') || name.includes('l2')) {
          if ((type.includes('plan') || type.includes('target') || type.includes('tc')) && !type.includes('sc')) l2Plan = rRow;
          else if (type.includes('actual') || type.includes('act')) l2Act = rRow;
        } else if (name.includes('line 3') || name.includes('l3')) {
          if ((type.includes('plan') || type.includes('target') || type.includes('tc')) && !type.includes('sc')) l3Plan = rRow;
          else if (type.includes('actual') || type.includes('act')) l3Act = rRow;
        }
      }
      const months = [], l2T = [], l2A = [], l3T = [], l3A = [];
      for (let c = 1; c < monthsRow.length; c++) {
        const m = String(monthsRow[c] || '').trim();
        if (isMonthLabel(m)) {
          months.push(m);
          l2T.push(safeParseFloat(l2Plan[c]) || 0);
          l2A.push(safeParseFloat(l2Act[c]) || 0);
          l3T.push(safeParseFloat(l3Plan[c]) || 0);
          l3A.push(safeParseFloat(l3Act[c]) || 0);
        }
      }
      result.prod_l2 = { months, targets: l2T, actuals: l2A, line2: { months, targets: l2T, actuals: l2A } };
      result.line2 = result.prod_l2;
      result.prod_l3 = { months, targets: l3T, actuals: l3A, line3: { months, targets: l3T, actuals: l3A } };
      result.line3 = result.prod_l3;
      result.prod_tot = {
        months,
        targets: l2T.map((v, idx) => v + l3T[idx]),
        actuals: l2A.map((v, idx) => v + l3A[idx])
      };
    }

    // 3. Dispatch Operations
    if (joined.includes('dispatch') && !result.disp_tmbsl) {
      let monthsRow = rawRows[i + 1] || [];
      if (!monthsRow.some(c => isMonthLabel(String(c).trim()))) {
        for (let mR = i; mR <= i + 4 && mR < rawRows.length; mR++) {
          if ((rawRows[mR] || []).some(c => isMonthLabel(String(c).trim()))) {
            monthsRow = rawRows[mR];
            break;
          }
        }
      }
      const dispMap = [
        { key: 'disp_tmbsl', match: ['tmbsl'] },
        { key: 'disp_acgl', match: ['acgl'] },
        { key: 'disp_imac', match: ['imac'] },
        { key: 'disp_jcbl', match: ['jcbl'] },
        { key: 'disp_otherbb', match: ['other bb', 'otherbb'] },
        { key: 'disp_direct', match: ['direct billing', 'direct'] },
        { key: 'disp_ev', match: ['ev bus', 'ev'] },
        { key: 'disp_tot', match: ['total'] }
      ];

      for (let r = i + 1; r <= i + 35 && r < rawRows.length; r++) {
        const rRow = rawRows[r] || [];
        const rLabel = (String(rRow[0] || '') + ' ' + String(rRow[1] || '') + ' ' + String(rRow[2] || '')).trim().toLowerCase();
        
        for (const item of dispMap) {
          if (item.match.some(m => rLabel.includes(m)) && (rLabel.includes('plan') || rLabel.includes('target') || rLabel.includes('tc')) && !rLabel.includes('actual') && !rLabel.includes('sc') && !result[item.key]) {
            let actRow = null;
            for (let aR = r + 1; aR <= r + 4 && aR < rawRows.length; aR++) {
              const checkRow = rawRows[aR] || [];
              const checkLabel = (String(checkRow[0] || '') + ' ' + String(checkRow[1] || '') + ' ' + String(checkRow[2] || '')).trim().toLowerCase();
              if (checkLabel.includes('actual') || checkLabel.includes('act')) {
                actRow = checkRow;
                break;
              }
            }
            if (!actRow) actRow = rawRows[r + 1] || [];

            const months = [], targets = [], actuals = [];
            for (let c = 1; c < monthsRow.length; c++) {
              const m = String(monthsRow[c] || '').trim();
              if (isMonthLabel(m)) {
                months.push(m);
                targets.push(safeParseFloat(rRow[c]) || 0);
                actuals.push(safeParseFloat(actRow[c]) || 0);
              }
            }
            const ytdTarget = targets.reduce((a, b) => a + b, 0);
            const ytdActual = actuals.reduce((a, b) => a + b, 0);
            result[item.key] = { months, targets, actuals, ytdTarget, ytdActual };
          }
        }
      }
    }

    // 4. Bus Engine Dispatches
    if ((joined.includes('bus engine') || joined.includes('bus dispatches')) && !result.bus_4spcr_nac) {
      let monthsRow = rawRows[i + 1] || [];
      if (!monthsRow.some(c => isMonthLabel(String(c).trim()))) {
        for (let mR = i; mR <= i + 4 && mR < rawRows.length; mR++) {
          if ((rawRows[mR] || []).some(c => isMonthLabel(String(c).trim()))) {
            monthsRow = rawRows[mR];
            break;
          }
        }
      }
      const busMap = [
        { key: 'bus_4spcr_nac', match: ['4 spcr nac', '4spcr nac'] },
        { key: 'bus_4spcr_ac', match: ['4 spcr ac', '4spcr ac'] },
        { key: 'bus_maxicab_nac', match: ['maxicab nac', 'maxicab'] },
        { key: 'bus_cx2_nac', match: ['cx2 nac', 'cx2'] },
        { key: 'bus_10_2_4sp', match: ['10.2 4sp', '10.2'] },
        { key: 'bus_3_3l_nac', match: ['3.3l nac'] },
        { key: 'bus_3_3l_ac', match: ['3.3l ac'] },
        { key: 'bus_ib912_bs3', match: ['ib-912', 'ib912'] },
        { key: 'bus_ib712_bs3', match: ['ib-712 bs3', 'ib712 bs3'] },
        { key: 'bus_ib712_bs4', match: ['ib-712 bs4', 'ib712 bs4'] },
        { key: 'bus_tot', match: ['total'] }
      ];

      for (let r = i + 1; r <= i + 45 && r < rawRows.length; r++) {
        const rRow = rawRows[r] || [];
        const rLabel = (String(rRow[0] || '') + ' ' + String(rRow[1] || '') + ' ' + String(rRow[2] || '')).trim().toLowerCase();
        
        for (const item of busMap) {
          if (item.match.some(m => rLabel.includes(m)) && (rLabel.includes('plan') || rLabel.includes('target') || rLabel.includes('tc')) && !rLabel.includes('actual') && !rLabel.includes('sc') && !result[item.key]) {
            let actRow = null;
            for (let aR = r + 1; aR <= r + 4 && aR < rawRows.length; aR++) {
              const checkRow = rawRows[aR] || [];
              const checkLabel = (String(checkRow[0] || '') + ' ' + String(checkRow[1] || '') + ' ' + String(checkRow[2] || '')).trim().toLowerCase();
              if (checkLabel.includes('actual') || checkLabel.includes('act')) {
                actRow = checkRow;
                break;
              }
            }
            if (!actRow) actRow = rawRows[r + 1] || [];

            const months = [], targets = [], actuals = [];
            for (let c = 1; c < monthsRow.length; c++) {
              const m = String(monthsRow[c] || '').trim();
              if (isMonthLabel(m)) {
                months.push(m);
                targets.push(safeParseFloat(rRow[c]) || 0);
                actuals.push(safeParseFloat(actRow[c]) || 0);
              }
            }
            const ytdTarget = targets.reduce((a, b) => a + b, 0);
            const ytdActual = actuals.reduce((a, b) => a + b, 0);
            result[item.key] = { months, targets, actuals, ytdTarget, ytdActual };
          }
        }
      }
    }
  }

  return result;
}

function importDeliveryMonthlyData(parsed) {
  if (!parsed || !state.deliveryMonthlyData) return;
  const getLatestVal = (arr) => {
    if (!arr || !arr.length) return null;
    for (let i = arr.length - 1; i >= 0; i--) {
      if (arr[i] !== null && arr[i] !== undefined && !isNaN(arr[i])) return arr[i];
    }
    return null;
  };
  Object.keys(parsed).forEach(key => {
    if (parsed[key]) {
      state.deliveryMonthlyData[key] = parsed[key];
      const kpi = state.kpis.find(k => k.id === key);
      if (kpi && parsed[key].actuals && parsed[key].actuals.length > 0) {
        const latestTarget = getLatestVal(parsed[key].targets);
        const latestActual = getLatestVal(parsed[key].actuals);
        if (latestTarget !== null && latestTarget !== undefined) kpi.target = latestTarget;
        if (latestActual !== null && latestActual !== undefined) kpi.actual = latestActual;
      }
    }
  });

  // Re-calculate totals if sub-items were imported
  const updateSumKpi = (totId, subIds) => {
    const totKpi = state.kpis.find(k => k.id === totId);
    if (totKpi) {
      let tSum = 0, aSum = 0;
      subIds.forEach(id => {
        const sub = state.kpis.find(k => k.id === id);
        if (sub) {
          tSum += sub.target;
          aSum += sub.actual;
        }
      });
      totKpi.target = tSum;
      totKpi.actual = aSum;
    }
  };

  updateSumKpi('disp_tot', ['disp_tmbsl', 'disp_acgl', 'disp_imac', 'disp_jcbl', 'disp_otherbb', 'disp_direct', 'disp_ev']);
  updateSumKpi('bus_tot', ['bus_4spcr_nac', 'bus_4spcr_ac', 'bus_maxicab_nac', 'bus_cx2_nac', 'bus_10_2_4sp', 'bus_3_3l_nac', 'bus_3_3l_ac', 'bus_ib912_bs3', 'bus_ib712_bs3', 'bus_ib712_bs4']);
  updateSumKpi('prod_tot', ['prod_l2', 'prod_l3']);

  state.baseDeliveryMonthlyData = JSON.parse(JSON.stringify(state.deliveryMonthlyData));
  state.baseKpis = JSON.parse(JSON.stringify(state.kpis));
}


// Parses cost detailed monthly parameters (DMC, Repro, and VCC)
function parseDetailedCost(rawRows) {
  let dmcData = null;
  let reproData = null;
  let vccData = null;
  let ofeData = null;

  const firstRow = rawRows[0] || [];

  // Find VCC column index dynamically
  let vccColIndex = -1;
  for (let c = 0; c < firstRow.length; c++) {
    if (firstRow[c] && String(firstRow[c]).trim().toUpperCase() === 'VCC') {
      vccColIndex = c;
      break;
    }
  }

  // Find Repro column index dynamically
  let reproColIndex = -1;
  for (let c = 0; c < firstRow.length; c++) {
    if (firstRow[c] && String(firstRow[c]).trim().toLowerCase() === 'repro') {
      reproColIndex = c;
      break;
    }
  }

  // Find OFE column index dynamically
  let ofeColIndex = -1;
  for (let c = 0; c < firstRow.length; c++) {
    if (firstRow[c] && String(firstRow[c]).trim().toUpperCase() === 'OFE') {
      ofeColIndex = c;
      break;
    }
  }

  let ofeMonthsRow = [];
  let ofePlanRow = [];
  let ofeScRow = [];
  let ofeActualRow = [];

  let ofeHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val === 'ofe') {
      ofeHeaderIdx = idx;
      break;
    }
  }

  if (ofeHeaderIdx !== -1) {
    ofeMonthsRow = rawRows[ofeHeaderIdx + 1] || [];
    const nextLabel = rawRows[ofeHeaderIdx + 3] && rawRows[ofeHeaderIdx + 3][0] ? String(rawRows[ofeHeaderIdx + 3][0]).trim().toLowerCase() : '';
    if (nextLabel === 'sc' || nextLabel === 'sc target') {
      ofePlanRow = rawRows[ofeHeaderIdx + 2] || [];
      ofeScRow = rawRows[ofeHeaderIdx + 3] || [];
      ofeActualRow = rawRows[ofeHeaderIdx + 4] || [];
    } else {
      ofePlanRow = rawRows[ofeHeaderIdx + 2] || [];
      ofeScRow = rawRows[ofeHeaderIdx + 2] || [];
      ofeActualRow = rawRows[ofeHeaderIdx + 3] || [];
    }
  }

  if (ofeHeaderIdx !== -1 && ofeMonthsRow.length > 0) {
    const months = [];
    const targets = [];
    const scTargets = [];
    const actuals = [];
    const startCol = 1;
    for (let c = startCol; c < ofeMonthsRow.length; c++) {
      const m = ofeMonthsRow[c] ? String(ofeMonthsRow[c]).trim() : '';
      if (isMonthLabel(m)) {
        months.push(m);
        targets.push(safeParseFloatOrNull(ofePlanRow[c]));
        scTargets.push(safeParseFloatOrNull(ofeScRow[c]));
        actuals.push(safeParseFloatOrNull(ofeActualRow[c]));
      }
    }
    const planFy = extractFyDataFromRow(ofeMonthsRow, ofePlanRow);
    const scFy = extractFyDataFromRow(ofeMonthsRow, ofeScRow);
    const fyData = extractFyDataFromRow(ofeMonthsRow, ofeActualRow, actuals);
    fyData.ytdTarget = planFy.ytd;
    fyData.ytdSc = scFy.ytd;
    ofeData = { months, targets, scTargets, actuals, fyData };
  } else if (ofeColIndex !== -1) {
    // Fallback to older hardcoded layout
    const gtRow = rawRows[4] || [];
    const annualTarget = safeParseFloat(gtRow[14]) || 29.16;
    const ytdTarget = safeParseFloat(gtRow[17]) || 8.63;
    const ytdActual = safeParseFloat(gtRow[19]) || 7.61;
    const ftmTarget = safeParseFloat(gtRow[23]) || 2.05;
    const ftmActual = safeParseFloat(gtRow[25]) || 2.12;

    const months = ["Apr'26", "May'26", "June'26", "July'26"];
    const targets = [2.05, 2.05, 2.05, ftmTarget];
    let actuals = [1.75, 1.80, 1.99, ftmActual];
    if (ftmActual === 1.99) {
      actuals = [1.75, 1.80, 1.99, null];
      targets[3] = null;
    }
    const fyData = { fy24: 24.5, fy25: 25.8, fy26: 26.2, ytd: ytdActual, ytdTarget, ytdSc: ytdTarget };
    ofeData = { months, targets, scTargets: targets, actuals, fyData };
  }

  let dmcHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val.includes('dmc')) {
      dmcHeaderIdx = idx;
      break;
    }
  }

  if (dmcHeaderIdx !== -1) {
    const monthsRow = rawRows[dmcHeaderIdx + 1] || [];
    let planRow = [];
    let scRow = [];
    let actualRow = [];

    const nextLabel = rawRows[dmcHeaderIdx + 3] && rawRows[dmcHeaderIdx + 3][0] ? String(rawRows[dmcHeaderIdx + 3][0]).trim().toLowerCase() : '';
    if (nextLabel === 'sc' || nextLabel === 'sc target') {
      planRow = rawRows[dmcHeaderIdx + 2] || [];
      scRow = rawRows[dmcHeaderIdx + 3] || [];
      actualRow = rawRows[dmcHeaderIdx + 4] || [];
    } else {
      planRow = rawRows[dmcHeaderIdx + 2] || [];
      scRow = rawRows[dmcHeaderIdx + 2] || [];
      actualRow = rawRows[dmcHeaderIdx + 3] || [];
    }

    const months = [];
    const targets = [];
    const scTargets = [];
    const actuals = [];
    for (let c = 1; c < monthsRow.length; c++) {
      const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
      if (isMonthLabel(m)) {
        months.push(m);
        targets.push(safeParseFloatOrNull(planRow[c]));
        scTargets.push(safeParseFloatOrNull(scRow[c]));
        actuals.push(safeParseFloatOrNull(actualRow[c]));
      }
    }
    const planFy = extractFyDataFromRow(monthsRow, planRow);
    const scFy = extractFyDataFromRow(monthsRow, scRow);
    const fyData = extractFyDataFromRow(monthsRow, actualRow, actuals);
    fyData.ytdTarget = planFy.ytd;
    fyData.ytdSc = scFy.ytd;
    dmcData = { months, targets, scTargets, actuals, fyData };
  } else {
    // Old loop fallback
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i] || [];
      const clean1 = row[1] ? String(row[1]).trim().toLowerCase() : '';
      
      if (clean1.includes('dmc')) {
        const monthsRow = rawRows[i + 1] || [];
        const planRow = rawRows[i + 2] || [];
        const actualRow = rawRows[i + 3] || [];
        
        const months = [];
        const targets = [];
        const actuals = [];
        for (let c = 1; c < monthsRow.length; c++) {
          const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
          if (isMonthLabel(m)) {
            months.push(m);
            targets.push(safeParseFloat(planRow[c]) || 0);
            actuals.push(safeParseFloat(actualRow[c]) || 0);
          }
        }
        const planFy = extractFyDataFromRow(monthsRow, planRow);
        const fyData = extractFyDataFromRow(monthsRow, actualRow, actuals);
        fyData.ytdTarget = planFy.ytd;
        fyData.ytdSc = planFy.ytd;
        dmcData = { months, targets, scTargets: targets, actuals, fyData };
      }
    }
  }

  if (reproColIndex !== -1) {
    const monthsRow = rawRows[1] || [];
    const actualRow = rawRows[2] || [];
    
    const months = [];
    const targets = [];
    const actuals = [];
    for (let c = reproColIndex; c < monthsRow.length; c++) {
      if (c > reproColIndex && c < firstRow.length && firstRow[c] !== null && firstRow[c] !== undefined && String(firstRow[c]).trim() !== '') {
        break;
      }
      const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
      if (isMonthLabel(m)) {
        months.push(m);
        targets.push(1.0);
        actuals.push(safeParseFloatOrNull(actualRow[c]));
      }
    }
    const fyData = extractFyDataFromRow(monthsRow, actualRow, actuals);
    fyData.ytdTarget = 1.0;
    fyData.ytdSc = 1.0;
    reproData = { months, targets, scTargets: targets, actuals, fyData };
  }

  let vccMonthsRow = [];
  let vccPlanRow = [];
  let vccScRow = [];
  let vccActualRow = [];

  let vccHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val === 'vcc') {
      vccHeaderIdx = idx;
      break;
    }
  }

  if (vccHeaderIdx !== -1) {
    vccMonthsRow = rawRows[vccHeaderIdx + 1] || [];
    const nextLabel = rawRows[vccHeaderIdx + 3] && rawRows[vccHeaderIdx + 3][0] ? String(rawRows[vccHeaderIdx + 3][0]).trim().toLowerCase() : '';
    if (nextLabel === 'sc' || nextLabel === 'sc target') {
      vccPlanRow = rawRows[vccHeaderIdx + 2] || [];
      vccScRow = rawRows[vccHeaderIdx + 3] || [];
      vccActualRow = rawRows[vccHeaderIdx + 4] || [];
    } else {
      vccPlanRow = rawRows[vccHeaderIdx + 2] || [];
      vccScRow = rawRows[vccHeaderIdx + 2] || [];
      vccActualRow = rawRows[vccHeaderIdx + 3] || [];
    }
  } else if (vccColIndex !== -1) {
    vccMonthsRow = rawRows[1] || [];
    vccPlanRow = rawRows[2] || [];
    vccScRow = rawRows[2] || [];
    vccActualRow = rawRows[3] || [];
  }

  if (vccMonthsRow.length > 0) {
    const months = [];
    const targets = [];
    const scTargets = [];
    const actuals = [];
    const startCol = 1;
    for (let c = startCol; c < vccMonthsRow.length; c++) {
      const m = vccMonthsRow[c] ? String(vccMonthsRow[c]).trim() : '';
      if (isMonthLabel(m)) {
        months.push(m);
        targets.push(safeParseFloatOrNull(vccPlanRow[c]));
        scTargets.push(safeParseFloatOrNull(vccScRow[c]));
        actuals.push(safeParseFloatOrNull(vccActualRow[c]));
      }
    }
    const planFy = extractFyDataFromRow(vccMonthsRow, vccPlanRow);
    const scFy = extractFyDataFromRow(vccMonthsRow, vccScRow);
    const fyData = extractFyDataFromRow(vccMonthsRow, vccActualRow, actuals);
    fyData.ytdTarget = planFy.ytd;
    fyData.ytdSc = scFy.ytd;
    vccData = { months, targets, scTargets, actuals, fyData };
  }

  // Parse CLT / Controllable Ledger Expenses detailed breakdown table
  const ledgerBreakdown = [];
  let table2HeaderIdx = -1;
  let table1HeaderIdx = -1;

  for (let r = 0; r < rawRows.length; r++) {
    const row = rawRows[r] || [];
    const col0 = row[0] ? String(row[0]).trim().toUpperCase() : '';
    const col1 = row[1] ? String(row[1]).trim().toUpperCase() : '';
    const col2 = row[2] ? String(row[2]).trim().toUpperCase() : '';

    if (col0 === 'CLT') {
      if (col1.includes('FY27 TC') || col2.includes('FY27 SC')) {
        table2HeaderIdx = r;
        break; // Found Table 2, stop searching
      } else if (col1.includes('B0') || col1.includes('FY')) {
        if (table1HeaderIdx === -1) {
          table1HeaderIdx = r;
        }
      }
    }
  }

  if (table2HeaderIdx !== -1) {
    // Parse using Table 2 structure (starting at row 31)
    const targetConfigs = [
      { id: 'admin_ew', name: 'Admin & EW', match: ['admin', 'ew'] },
      { id: 'maintenance_services', name: 'Maintenance & Services', match: ['maintenance', 'services'] },
      { id: 'civil', name: 'Civil', match: ['civil'] },
      { id: 'sustainability', name: 'Sustainability', match: ['sustainability'] },
      { id: 'production_contracts', name: 'Production Contracts', match: ['production', 'contracts'] },
      { id: 'utilities', name: 'Utilities', match: ['utilities'] },
      { id: 'vic_machinery', name: 'VIC & Machinery spares', match: ['vic', 'machinery'] },
      { id: 'freight_logistic', name: 'Freight - Logistic', match: ['freight', 'logistic'] },
      { id: 'total', name: 'Total', match: ['total'] }
    ];

    let cltTotalRow = null;
    let vicRowIdx = -1;
    const scanLimit = Math.min(rawRows.length, table2HeaderIdx + 20);
    const matchedRows = {};

    for (let r = table2HeaderIdx + 1; r < scanLimit; r++) {
      const row = rawRows[r] || [];
      const col0 = row[0] ? String(row[0]).trim().toLowerCase() : '';

      targetConfigs.forEach(cfg => {
        const matchesAll = cfg.match.every(keyword => col0.includes(keyword));
        if (matchesAll && !matchedRows[cfg.id]) {
          matchedRows[cfg.id] = row;
          if (cfg.id === 'vic_machinery') {
            vicRowIdx = r;
          }
        }
      });
    }

    if (vicRowIdx !== -1) {
      cltTotalRow = rawRows[vicRowIdx + 1] || [];
    }

    const orderedKeys = [
      { id: 'admin_ew', name: 'Admin & EW' },
      { id: 'maintenance_services', name: 'Maintenance & Services' },
      { id: 'civil', name: 'Civil' },
      { id: 'sustainability', name: 'Sustainability' },
      { id: 'production_contracts', name: 'Production Contracts' },
      { id: 'utilities', name: 'Utilities' },
      { id: 'vic_machinery', name: 'VIC & Machinery spares' },
      { id: 'clt_total', name: 'CLT' },
      { id: 'freight_logistic', name: 'Freight - Logistic' },
      { id: 'total', name: 'Total' }
    ];

    orderedKeys.forEach(k => {
      let row = [];
      if (k.id === 'clt_total') {
        row = cltTotalRow || [];
      } else {
        row = matchedRows[k.id] || [];
      }

      if (row.length > 0) {
        const fy27Tc = safeParseFloat(row[1]) || 0;
        const fy27Sc = safeParseFloat(row[2]) || 0;
        const mtdTarget = safeParseFloat(row[3]) || 0; // TC Month Target (TC Tgt. / Column 4)
        const mtdSc = safeParseFloat(row[4]) || 0;     // SC Month Target (SC / Column 5)
        const mtdActual = safeParseFloat(row[5]) || 0; // Month Actual (Act. / Column 6)
        const ytdTarget = safeParseFloat(row[6]) || 0; // TC YTD Target (TC Tgt. / Column 7)
        const ytdSc = safeParseFloat(row[7]) || 0;     // SC YTD Target (SC / Column 8)
        const ytdActual = safeParseFloat(row[8]) || 0; // YTD Actual (Act. / Column 9)

        ledgerBreakdown.push({
          name: k.name,
          fy27Tc,
          fy27Sc,
          ytdTarget,
          ytdSc,
          ytdActual,
          mtdTarget,
          mtdSc,
          mtdActual
        });
      }
    });
  } else if (table1HeaderIdx !== -1) {
    // Parse using Table 1 structure (fallback)
    const monthHeaderRow = rawRows[table1HeaderIdx - 1] || [];
    let ytdColIdx = 1;
    let ftmColIdx = 8;

    for (let c = 0; c < monthHeaderRow.length; c++) {
      const cellVal = monthHeaderRow[c] ? String(monthHeaderRow[c]).toUpperCase() : '';
      if (cellVal.includes('YTD') && ytdColIdx === 1) {
        ytdColIdx = c;
      }
      if (cellVal.includes('FTM') && ftmColIdx === 8) {
        ftmColIdx = c;
      }
    }

    const targetConfigs = [
      { id: 'admin_ew', name: 'Admin & EW', match: ['admin', 'ew'] },
      { id: 'maintenance_services', name: 'Maintenance & Services', match: ['maintenance', 'services'] },
      { id: 'civil', name: 'Civil', match: ['civil'] },
      { id: 'sustainability', name: 'Sustainability', match: ['sustainability'] },
      { id: 'production_contracts', name: 'Production Contracts', match: ['production', 'contracts'] },
      { id: 'utilities', name: 'Utilities', match: ['utilities'] },
      { id: 'vic_machinery', name: 'VIC & Machinery spares', match: ['vic', 'machinery'] },
      { id: 'freight_logistic', name: 'Freight - Logistic', match: ['freight', 'logistic'] },
      { id: 'total', name: 'Total', match: ['total'] }
    ];

    let cltTotalRow = null;
    let vicRowIdx = -1;
    const scanLimit = Math.min(rawRows.length, table1HeaderIdx + 20);
    const matchedRows = {};

    for (let r = table1HeaderIdx + 1; r < scanLimit; r++) {
      const row = rawRows[r] || [];
      const col0 = row[0] ? String(row[0]).trim().toLowerCase() : '';

      targetConfigs.forEach(cfg => {
        const matchesAll = cfg.match.every(keyword => col0.includes(keyword));
        if (matchesAll && !matchedRows[cfg.id]) {
          matchedRows[cfg.id] = row;
          if (cfg.id === 'vic_machinery') {
            vicRowIdx = r;
          }
        }
      });
    }

    if (vicRowIdx !== -1) {
      cltTotalRow = rawRows[vicRowIdx + 1] || [];
    }

    const orderedKeys = [
      { id: 'admin_ew', name: 'Admin & EW' },
      { id: 'maintenance_services', name: 'Maintenance & Services' },
      { id: 'civil', name: 'Civil' },
      { id: 'sustainability', name: 'Sustainability' },
      { id: 'production_contracts', name: 'Production Contracts' },
      { id: 'utilities', name: 'Utilities' },
      { id: 'vic_machinery', name: 'VIC & Machinery spares' },
      { id: 'clt_total', name: 'CLT' },
      { id: 'freight_logistic', name: 'Freight - Logistic' },
      { id: 'total', name: 'Total' }
    ];

    orderedKeys.forEach(k => {
      let row = [];
      if (k.id === 'clt_total') {
        row = cltTotalRow || [];
      } else {
        row = matchedRows[k.id] || [];
      }

      if (row.length > 0) {
        const annualTarget = safeParseFloat(row[1]) || 0;
        const ytdTarget = safeParseFloat(row[ytdColIdx + 1]) || 0; // TC YTD Target
        const ytdSc = safeParseFloat(row[ytdColIdx + 2]) || 0;     // SC YTD Target
        const ytdActual = safeParseFloat(row[ytdColIdx + 3]) || 0; // YTD Actual
        const mtdTarget = safeParseFloat(row[ftmColIdx]) || 0;     // TC Month Target
        const mtdSc = safeParseFloat(row[ftmColIdx + 1]) || 0;     // SC Month Target
        const mtdActual = safeParseFloat(row[ftmColIdx + 2]) || 0; // Month Actual

        ledgerBreakdown.push({
          name: k.name,
          fy27Tc: annualTarget,
          fy27Sc: annualTarget,
          ytdTarget,
          ytdSc,
          ytdActual,
          mtdTarget,
          mtdSc,
          mtdActual
        });
      }
    });
  }

  let ofeBreakdown = [];
  let cltSummaryHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val0 = row[0] ? String(row[0]).trim().toLowerCase() : '';
    const val1 = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val0.includes('clt summary') || val1.includes('clt summary')) {
      cltSummaryHeaderIdx = idx;
      break;
    }
  }

  if (cltSummaryHeaderIdx !== -1) {
    for (let offset = 1; offset <= 12; offset++) {
      const row = rawRows[cltSummaryHeaderIdx + offset] || [];
      if (row.length > 0) {
        const name = row[1] ? String(row[1]).trim() : '';
        const mtdTarget = safeParseFloat(row[2]) || 0;
        const mtdSc = safeParseFloat(row[3]) || 0;
        const mtdActual = safeParseFloat(row[4]) || 0;
        const ytdTarget = safeParseFloat(row[5]) || 0;
        const ytdSc = safeParseFloat(row[6]) || 0;
        const ytdActual = safeParseFloat(row[7]) || 0;
        if (name) {
          ofeBreakdown.push({
            name,
            mtdTarget,
            mtdSc,
            mtdActual,
            ytdTarget,
            ytdSc,
            ytdActual
          });
        }
      }
    }
  }

  let vccBreakdown = [];
  let vccTableHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val0 = row[0] ? String(row[0]).trim().toLowerCase() : '';
    const val1 = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val0.includes('particulars') && val1.includes("vcc's")) {
      vccTableHeaderIdx = idx;
      break;
    }
  }

  if (vccTableHeaderIdx !== -1) {
    for (let offset = 1; offset <= 18; offset++) {
      const row = rawRows[vccTableHeaderIdx + offset] || [];
      if (row.length > 0) {
        const name = row[0] ? String(row[0]).trim() : '';
        const group = row[1] ? String(row[1]).trim() : '';
        if (name || group) {
          vccBreakdown.push({
            name,
            group,
            apr: {
              tc: safeParseFloat(row[3]) || 0,
              sc: safeParseFloat(row[4]) || 0,
              act: safeParseFloat(row[5]) || 0
            },
            may: {
              tc: safeParseFloat(row[6]) || 0,
              sc: safeParseFloat(row[7]) || 0,
              act: safeParseFloat(row[8]) || 0
            },
            jun: {
              tc: safeParseFloat(row[9]) || 0,
              sc: safeParseFloat(row[10]) || 0,
              act: safeParseFloat(row[11]) || 0
            },
            jul: {
              tc: safeParseFloat(row[12]) || 0,
              sc: safeParseFloat(row[13]) || 0,
              act: safeParseFloat(row[14]) || 0
            },
            ytdJuly27: {
              tc: safeParseFloat(row[15]) || 0,
              sc: safeParseFloat(row[16]) || 0,
              act: safeParseFloat(row[17]) || 0
            },
            ytdMar27: {
              savingTc: safeParseFloat(row[18]) || 0,
              savingSc: safeParseFloat(row[19]) || 0
            }
          });
        }
      }
    }
  }

  let cltBreakdown = [];
  let cltTableHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val0 = row[0] ? String(row[0]).trim().toLowerCase() : '';
    const val1 = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val0 === 'clt' && val1.includes('vertical lead')) {
      cltTableHeaderIdx = idx;
      break;
    }
  }

  if (cltTableHeaderIdx !== -1) {
    for (let offset = 2; offset <= 11; offset++) {
      const row = rawRows[cltTableHeaderIdx + offset] || [];
      if (row.length > 0) {
        const name = row[0] ? String(row[0]).trim() : '';
        const lead = row[1] ? String(row[1]).trim() : '';
        const mtdTarget = safeParseFloat(row[2]) || 0;
        const mtdSc = safeParseFloat(row[3]) || 0;
        const mtdActual = safeParseFloat(row[4]) || 0;
        const mtdSavingTc = safeParseFloat(row[5]) || 0;
        const mtdSavingSc = safeParseFloat(row[6]) || 0;
        const ytdTarget = safeParseFloat(row[7]) || 0;
        const ytdSc = safeParseFloat(row[8]) || 0;
        const ytdActual = safeParseFloat(row[9]) || 0;
        const ytdSavingTc = safeParseFloat(row[10]) || 0;
        const ytdSavingSc = safeParseFloat(row[11]) || 0;
        if (name || lead) {
          cltBreakdown.push({
            name,
            lead,
            mtdTarget,
            mtdSc,
            mtdActual,
            mtdSavingTc,
            mtdSavingSc,
            ytdTarget,
            ytdSc,
            ytdActual,
            ytdSavingTc,
            ytdSavingSc
          });
        }
      }
    }
  }
  let plantBreakdown = [];
  let plantTableHeaderIdx = -1;
  for (let idx = 0; idx < rawRows.length; idx++) {
    const row = rawRows[idx] || [];
    const val1 = row[1] ? String(row[1]).trim().toLowerCase() : '';
    if (val1.includes('group heads') && val1.includes('plant controllable')) {
      plantTableHeaderIdx = idx;
      break;
    }
  }

  if (plantTableHeaderIdx !== -1) {
    const targetNorms = [
      "repairs & renovation & maintenance",
      "employee welfare,recruitment etc",
      "municipal chgs & water chgs",
      "others",
      "total controllable",
      "treasury exps",
      "insurance",
      "it opex exps",
      "it dpds exps",
      "total non controllable",
      "grand total (controllable + non controllable)",
      "grand total (controllable + treasury + insurance)"
    ];

    for (let offset = 1; offset <= 60; offset++) {
      const row = rawRows[plantTableHeaderIdx + offset] || [];
      if (row.length > 0) {
        const rawName = row[1] ? String(row[1]).trim() : '';
        const nameNorm = rawName.toLowerCase().replace(/\s+/g, ' ');
        if (targetNorms.includes(nameNorm)) {
          const mtdTarget = safeParseFloat(row[16]) || 0;
          const mtdSc = safeParseFloat(row[17]) || 0;
          const mtdActual = safeParseFloat(row[18]) || 0;
          
          const ytdTarget = safeParseFloat(row[22]) || 0;
          const ytdSc = safeParseFloat(row[23]) || 0;
          const ytdActual = safeParseFloat(row[24]) || 0;
          const ytdSavingTc = safeParseFloat(row[25]) || 0;
          const ytdSavingSc = safeParseFloat(row[26]) || 0;

          plantBreakdown.push({
            name: rawName,
            mtdTarget,
            mtdSc,
            mtdActual,
            mtdSavingTc: mtdTarget - mtdActual,
            mtdSavingSc: mtdSc - mtdActual,
            ytdTarget,
            ytdSc,
            ytdActual,
            ytdSavingTc,
            ytdSavingSc
          });
        }
      }
    }
  }

  return { dmc: dmcData, repro: reproData, vcc: vccData, ofe: ofeData, ledgerBreakdown, ofeBreakdown, vccBreakdown, cltBreakdown, plantBreakdown };
}

function importCostMonthlyData(parsed) {
  if (parsed.dmc) state.costMonthlyData.dmc = parsed.dmc;
  if (parsed.repro) state.costMonthlyData.repro = parsed.repro;
  if (parsed.vcc) state.costMonthlyData.vcc = parsed.vcc;
  if (parsed.ofe) state.costMonthlyData.ofe = parsed.ofe;
  if (parsed.ledgerBreakdown) state.costLedgerBreakdown = parsed.ledgerBreakdown;
  if (parsed.ofeBreakdown && parsed.ofeBreakdown.length > 0) {
    state.costOfeBreakdown = parsed.ofeBreakdown;
  }
  if (parsed.vccBreakdown && parsed.vccBreakdown.length > 0) {
    state.costVccBreakdown = parsed.vccBreakdown;
  }
  if (parsed.cltBreakdown && parsed.cltBreakdown.length > 0) {
    state.costCltBreakdown = parsed.cltBreakdown;
  }
  if (parsed.plantBreakdown && parsed.plantBreakdown.length > 0) {
    state.costPlantBreakdown = parsed.plantBreakdown;
  }
}

// Parses Environment detailed monthly parameters (Water, Fuel, GHG, Power)
function parseDetailedEnvironment(rawRows) {
  let waterData = null;
  let fuelData = null;
  let ghgData = null;
  let powerData = null;

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    
    let cleanVal = '';
    for (let c = 1; c < row.length; c++) {
      if (row[c]) {
        const val = String(row[c]).trim().toLowerCase();
        if (val.startsWith('water positive') || val === 'water positive' ||
            val.startsWith('fuel (') || val === 'fuel' ||
            val.startsWith('ghg (') || val === 'ghg' ||
            val.startsWith('power (') || val === 'power') {
          cleanVal = val;
          break;
        }
      }
    }
    
    if (cleanVal) {
      const monthsRow = rawRows[i + 1] || [];
      const planRow = rawRows[i + 2] || [];
      const actualRow = rawRows[i + 4] || [];
      
      const months = [];
      const targets = [];
      const actuals = [];
      for (let c = 1; c < planRow.length; c++) {
        const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
        if (isMonthLabel(m)) {
          months.push(m);
          targets.push(safeParseFloat(planRow[c]) || 0);
          actuals.push(safeParseFloat(actualRow[c]) || 0);
        }
      }
      
      const dataset = { months, targets, actuals, fyData: extractFyDataFromRow(monthsRow, actualRow, actuals) };
      if (cleanVal.startsWith('water positive') || cleanVal === 'water positive') waterData = dataset;
      else if (cleanVal.startsWith('fuel (') || cleanVal === 'fuel') fuelData = dataset;
      else if (cleanVal.startsWith('ghg (') || cleanVal === 'ghg') ghgData = dataset;
      else if (cleanVal.startsWith('power (') || cleanVal === 'power') powerData = dataset;
    }
  }

  return { water: waterData, fuel: fuelData, ghg: ghgData, power: powerData };
}

function importEnvironmentMonthlyData(parsed) {
  if (parsed.water) state.environmentMonthlyData.water = parsed.water;
  if (parsed.fuel) state.environmentMonthlyData.fuel = parsed.fuel;
  if (parsed.ghg) state.environmentMonthlyData.ghg = parsed.ghg;
  if (parsed.power) state.environmentMonthlyData.power = parsed.power;
}

// Parses HR detailed monthly parameters (IVDP and CSR Lives Touched)
function parseDetailedHr(rawRows) {
  let csrData = null;
  let ivdpData = null;
  let envData = null;
  let healthData = null;
  let eduData = null;
  let empData = null;

  const findTargetCol = (monthsRow, subHeaderRow, c) => {
    for (let idx = c; idx < subHeaderRow.length; idx++) {
      const sub = subHeaderRow[idx] ? String(subHeaderRow[idx]).trim().toLowerCase() : '';
      if (sub.includes('target')) {
        return idx;
      }
    }
    return c;
  };

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const clean0 = row[0] ? String(row[0]).trim().toLowerCase() : '';

    if (clean0 === 'ivdp') {
      const valRow = rawRows[i + 2] || [];
      const monthsRow = rawRows[i] || [];
      const subHeaderRow = rawRows[i + 1] || [];

      const months = [];
      const targets = [];
      const actuals = [];
      
      for (let c = 0; c < monthsRow.length; c++) {
        const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
        if (m && isMonthLabel(m)) {
          const tCol = findTargetCol(monthsRow, subHeaderRow, c);
          months.push(m);
          targets.push(safeParseFloat(valRow[tCol]) || 0);
          actuals.push(safeParseFloat(valRow[tCol + 1]) || 0);
        }
      }
      
      let ytdTarget = 0;
      let ytdActual = 0;
      for (let c = 0; c < monthsRow.length; c++) {
        const val = monthsRow[c] ? String(monthsRow[c]).trim().toLowerCase() : '';
        if (val === 'ytd') {
          const yCol = findTargetCol(monthsRow, subHeaderRow, c);
          ytdTarget = safeParseFloat(valRow[yCol]) || 0;
          ytdActual = safeParseFloat(valRow[yCol + 1]) || 0;
          break;
        }
      }
      
      ivdpData = { 
        months, 
        targets, 
        actuals, 
        ytdTarget,
        ytdActual,
        fyData: { 
          fy24: safeParseFloat(valRow[1]) || 0, 
          fy25: safeParseFloat(valRow[2]) || 0, 
          fy26: safeParseFloat(valRow[3]) || 0, 
          ytd: ytdActual 
        } 
      };
    }

    if (clean0 === 'no. of lives touched' && i < 12) {
      const monthsRow = rawRows[i - 2] || [];
      const subHeaderRow = rawRows[i - 1] || [];

      const helperParse = (targetRow) => {
        const months = [];
        const targets = [];
        const actuals = [];
        
        for (let c = 0; c < monthsRow.length; c++) {
          const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
          if (m && isMonthLabel(m)) {
            const tCol = findTargetCol(monthsRow, subHeaderRow, c);
            months.push(m);
            targets.push(safeParseFloat(targetRow[tCol]) || 0);
            actuals.push(safeParseFloat(targetRow[tCol + 1]) || 0);
          }
        }
        
        let ytdTarget = 0;
        let ytdActual = 0;
        for (let c = 0; c < monthsRow.length; c++) {
          const val = monthsRow[c] ? String(monthsRow[c]).trim().toLowerCase() : '';
          if (val === 'ytd') {
            const yCol = findTargetCol(monthsRow, subHeaderRow, c);
            ytdTarget = safeParseFloat(targetRow[yCol]) || 0;
            ytdActual = safeParseFloat(targetRow[yCol + 1]) || 0;
            break;
          }
        }
        
        return { 
          months, 
          targets, 
          actuals, 
          ytdTarget,
          ytdActual,
          fyData: { 
            fy24: safeParseFloat(targetRow[1]) || 0, 
            fy25: safeParseFloat(targetRow[2]) || 0, 
            fy26: safeParseFloat(targetRow[3]) || 0, 
            ytd: ytdActual 
          } 
        };
      };

      csrData = helperParse(row);

      for (let offset = 1; offset <= 4; offset++) {
        const nextRow = rawRows[i + offset] || [];
        const name = nextRow[0] ? String(nextRow[0]).trim().toLowerCase() : '';
        if (name === 'environment') envData = helperParse(nextRow);
        if (name === 'health') healthData = helperParse(nextRow);
        if (name === 'education') eduData = helperParse(nextRow);
        if (name === 'employability') empData = helperParse(nextRow);
      }
    }
  }
  return {
    csr: csrData,
    ivdp: ivdpData,
    environment: envData,
    health: healthData,
    education: eduData,
    employability: empData
  };
}

function importHrMonthlyData(parsed) {
  if (parsed.csr) state.hrMonthlyData.csr = parsed.csr;
  if (parsed.ivdp) state.hrMonthlyData.ivdp = parsed.ivdp;
  if (parsed.environment) state.hrMonthlyData.environment = parsed.environment;
  if (parsed.health) state.hrMonthlyData.health = parsed.health;
  if (parsed.education) state.hrMonthlyData.education = parsed.education;
  if (parsed.employability) state.hrMonthlyData.employability = parsed.employability;
}

// Parses Quality detailed sheet for Line-wise DRR actual rates calculated from daily columns
function parseDetailedQuality(rawRows) {
  const results = [];
  
  let headerRowIdx = -1;
  for (let i = 140; i <= 145; i++) {
    const row = rawRows[i] || [];
    if (row.some(cell => String(cell).toLowerCase().includes("jul'26") || String(cell).toLowerCase().includes("july'26"))) {
      headerRowIdx = i;
      break;
    }
  }
  
  if (headerRowIdx === -1) {
    for (let i = 0; i < rawRows.length; i++) {
      const row = rawRows[i] || [];
      if (row.some(cell => String(cell).toLowerCase().includes("apr'26")) &&
          row.some(cell => String(cell).toLowerCase().includes("july'26"))) {
        headerRowIdx = i;
        break;
      }
    }
  }

  if (headerRowIdx !== -1) {
    const headerRow = rawRows[headerRowIdx];
    let colIdx = -1;
    for (let c = 2; c < headerRow.length; c++) {
      const cellVal = String(headerRow[c]).toLowerCase();
      if (cellVal.includes("jul")) {
        colIdx = c;
        break;
      }
    }
    
    if (colIdx !== -1) {
      for (let i = headerRowIdx + 1; i < Math.min(rawRows.length, headerRowIdx + 30); i++) {
        const row = rawRows[i] || [];
        const label = row[0] ? String(row[0]).trim() : '';
        const cleanLabel = label.toLowerCase();
        
        if (cleanLabel.startsWith('drr ') || cleanLabel.startsWith('line ')) {
          const actualRow = rawRows[i + 1] || [];
          let targetVal = safeParseFloat(row[colIdx]) || 0;
          let actualVal = safeParseFloat(actualRow[colIdx]) || 0;
          
          if (targetVal > 0 && targetVal <= 1.0) targetVal *= 100;
          if (actualVal > 0 && actualVal <= 1.0) actualVal *= 100;
          
          let key = '';
          if (cleanLabel.startsWith('drr 1')) {
            key = 'drr_1_l1';
            results.push({ id: 'drr_1', target: targetVal, actual: actualVal });
          } else if (cleanLabel.startsWith('drr 2')) {
            key = 'drr_2_l1';
            results.push({ id: 'drr_2', target: targetVal, actual: actualVal });
          } else if (cleanLabel.startsWith('drr 4')) {
            key = 'drr_4_l1';
            results.push({ id: 'drr_4', target: targetVal, actual: actualVal });
          } else if (cleanLabel.startsWith('line 2')) {
            let parentDrr = 1;
            for (let r = i - 1; r >= headerRowIdx; r--) {
              const pLabel = String(rawRows[r][0] || '').toLowerCase();
              if (pLabel.startsWith('drr 1')) { parentDrr = 1; break; }
              if (pLabel.startsWith('drr 2')) { parentDrr = 2; break; }
              if (pLabel.startsWith('drr 4')) { parentDrr = 4; break; }
            }
            key = `drr_${parentDrr}_l2`;
          } else if (cleanLabel.startsWith('line 3')) {
            let parentDrr = 1;
            for (let r = i - 1; r >= headerRowIdx; r--) {
              const pLabel = String(rawRows[r][0] || '').toLowerCase();
              if (pLabel.startsWith('drr 1')) { parentDrr = 1; break; }
              if (pLabel.startsWith('drr 2')) { parentDrr = 2; break; }
              if (pLabel.startsWith('drr 4')) { parentDrr = 4; break; }
            }
            key = `drr_${parentDrr}_l3`;
          }
          
          if (key) {
            results.push({ id: key, target: targetVal, actual: actualVal });
          }
          i++; // Skip actual row
        }
      }
    }
  }
  
  return results;
}

// Kept for backward compatibility
function getQualityActual(actualRow) {
  return 0;
}

// Parses Quality detailed sheet for monthly trend metrics (9 new metrics)
function parseDetailedQualityMonthly(rawRows) {
  const result = {};

  const targetConfigs = [
    { key: 'vc_charter', match: 'vc charter ( c2)' },
    { key: 'comp_quality_iptv', match: 'comp iptv' },
    { key: 'comp_quality_epv', match: 'epv (expense per vehicle)' },
    { key: 'comp_quality_visits', match: 'unscheduled visits per vehicle' },
    { key: 'comp_quality_notouch', match: 'no touch drr' },
    { key: 'launch_quality', match: 'launch quality' },
    { key: 'launch_3mis', match: '3 mis' },
    { key: 'launch_3_6mis', match: '3-6 mis' },
    { key: 'launch_6_12mis', match: '6-12 mis' },
    { key: 'launch_uvpv', match: 'launch uvpv' },
    { key: 'layer_audit', match: 'layer audit' },
    { key: 'cimple_project', match: 'cimple project' },
    { key: 'warranty_payout', match: 'warranty net payout' },
    { key: 'cpa_score', match: 'cpa score' },
    { key: 'visit_24', match: 'unscheduled visit 24 mis' },
    { key: 'visit_12', match: 'unscheduled visit 12 mis' },
    { key: 'iptv_3', match: '3 mis iptv' }
  ];

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const rowStr = row.map(v => v ? String(v).trim().toLowerCase() : '').join(' ');

    for (const cfg of targetConfigs) {
      if (result[cfg.key]) {
        continue; // Skip if this metric was already successfully parsed
      }
      if (rowStr.includes(cfg.match)) {
        if (cfg.key === 'launch_3mis' && (rowStr.includes('iptv') || rowStr.includes('launch quality'))) {
          continue;
        }
        if (cfg.key === 'comp_quality_iptv' && rowStr.includes('3 mis')) {
          continue;
        }
        const monthsRow = rawRows[i + 1] || [];
        let tcRow = [];
        let scRow = [];
        let actualRow = [];

        const nextLabel = rawRows[i + 3] && rawRows[i + 3][1] ? String(rawRows[i + 3][1]).trim().toLowerCase() : '';
        if (nextLabel === 'sc' || nextLabel === 'sc target') {
          tcRow = rawRows[i + 2] || [];
          scRow = rawRows[i + 3] || [];
          actualRow = rawRows[i + 4] || [];
        } else {
          tcRow = rawRows[i + 2] || [];
          scRow = rawRows[i + 2] || [];
          actualRow = rawRows[i + 3] || [];
        }

        const months = [];
        const targets = [];
        const scTargets = [];
        const actuals = [];

        for (let c = 2; c < monthsRow.length; c++) {
          const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
          if (isMonthLabel(m)) {
            const cleanedM = m.replace(/^MTD\s+/, '');
            months.push(cleanedM);
            
            let tVal = safeParseFloatOrNull(tcRow[c]);
            let scVal = safeParseFloatOrNull(scRow[c]);
            let aVal = safeParseFloatOrNull(actualRow[c]);

            const isPctMetric = ['vc_charter', 'product_charter', 'comp_quality_notouch', 'launch_quality', 'layer_audit'].includes(cfg.key);
            if (isPctMetric) {
              if (tVal !== null && tVal > 0 && tVal <= 1.0) tVal = tVal * 100;
              if (scVal !== null && scVal > 0 && scVal <= 1.0) scVal = scVal * 100;
              if (aVal !== null && aVal > 0 && aVal <= 1.0) aVal = aVal * 100;
            }

            targets.push(tVal);
            scTargets.push(scVal);
            actuals.push(aVal);
          }
        }

        const fyData = extractFyDataFromRow(monthsRow, actualRow, actuals, tcRow);
        const isPctMetric = ['vc_charter', 'product_charter', 'comp_quality_notouch', 'launch_quality', 'layer_audit'].includes(cfg.key);
        if (isPctMetric && fyData) {
          if (fyData.fy24 > 0 && fyData.fy24 <= 1.0) fyData.fy24 = fyData.fy24 * 100;
          if (fyData.fy25 > 0 && fyData.fy25 <= 1.0) fyData.fy25 = fyData.fy25 * 100;
          if (fyData.fy26 > 0 && fyData.fy26 <= 1.0) fyData.fy26 = fyData.fy26 * 100;
          if (fyData.ytd > 0 && fyData.ytd <= 1.0) fyData.ytd = fyData.ytd * 100;
        }

        result[cfg.key] = { months, targets, scTargets, actuals, fyData };
        if (cfg.key === 'comp_quality_iptv') {
          result['comp_iptv'] = { months, targets, scTargets, actuals, fyData };
        }
        if (cfg.key === 'comp_quality_visits') {
          result['visit_24'] = { months, targets, scTargets, actuals, fyData };
        }
        break; // Match found, break targetConfigs loop
      }
    }

    // Check for DRR monthly trend tables (typically in rows 133-150)
    const col0 = row[0] ? String(row[0]).trim().toLowerCase() : '';
    if (col0.startsWith('drr ')) {
      const match = col0.match(/drr\s+(\d+)/);
      if (match) {
        const drrNum = parseInt(match[1]);
        
        // Scan upwards to find the nearest row containing month labels
        let monthsRow = [];
        for (let r = i - 1; r >= 0; r--) {
          const checkRow = rawRows[r] || [];
          const hasMonth = checkRow.some(cell => isMonthLabel(String(cell).trim()));
          if (hasMonth) {
            monthsRow = checkRow;
            break;
          }
        }
        
        const parseLineData = (targetRowIdx, actualRowIdx, key) => {
          const tRow = rawRows[targetRowIdx] || [];
          const aRow = rawRows[actualRowIdx] || [];
          const months = [];
          const targets = [];
          const actuals = [];
          
          for (let c = 2; c < monthsRow.length; c++) {
            const m = monthsRow[c] ? String(monthsRow[c]).trim() : '';
            if (isMonthLabel(m)) {
              months.push(m);
              let tVal = safeParseFloat(tRow[c]);
              let aVal = safeParseFloat(aRow[c]);
              
              if (isNaN(tVal)) tVal = 0.9;
              if (isNaN(aVal)) aVal = 0;
              
              if (tVal > 0 && tVal <= 1.0) tVal = tVal * 100;
              if (aVal > 0 && aVal <= 1.0) aVal = aVal * 100;
              
              targets.push(tVal);
              actuals.push(aVal);
            }
          }
          
          // Compute YTD average of monthly actuals
          const validActuals = actuals.filter(v => v !== null && v !== undefined && !isNaN(v));
          const ytdActual = validActuals.length > 0 ? (validActuals.reduce((sum, val) => sum + val, 0) / validActuals.length) : 0;
          const ytdTarget = targets[targets.length - 1] || 90;
          
          result[key] = { 
            months, 
            targets, 
            actuals, 
            ytdTarget,
            ytdActual,
            fyData: { fy24: 0, fy25: 0, fy26: 0, ytd: ytdActual } 
          };
        };

        // DRR Line 1 is rows i and i+1
        parseLineData(i, i + 1, `drr_${drrNum}_l1`);
        // DRR Line 2 is rows i+2 and i+3
        parseLineData(i + 2, i + 3, `drr_${drrNum}_l2`);
        // DRR Line 3 is rows i+4 and i+5
        parseLineData(i + 4, i + 5, `drr_${drrNum}_l3`);
        // Main DRR KPI uses DRR Line 1
        parseLineData(i, i + 1, `drr_${drrNum}`);
      }
    }
  }

  return result;
}

function importQualityMonthlyData(parsed) {
  const keys = [
    'vc_charter', 'product_charter', 'comp_quality_iptv', 'comp_quality_epv',
    'comp_quality_visits', 'comp_quality_notouch', 'launch_quality',
    'launch_3mis', 'launch_3_6mis', 'launch_6_12mis',
    'launch_uvpv', 'layer_audit', 'cimple_project',
    'drr_1', 'drr_1_l1', 'drr_1_l2', 'drr_1_l3',
    'drr_2', 'drr_2_l1', 'drr_2_l2', 'drr_2_l3',
    'drr_4', 'drr_4_l1', 'drr_4_l2', 'drr_4_l3',
    'warranty_payout', 'cpa_score', 'visit_24', 'visit_12', 'iptv_3', 'comp_iptv'
  ];
  keys.forEach(k => {
    if (parsed[k]) {
      state.qualityMonthlyData[k] = parsed[k];
      
      const kpi = state.kpis.find(item => item.id === k);
      if (kpi) {
        const monthly = parsed[k];
        if (monthly && monthly.actuals && monthly.actuals.length > 0 && (kpi.actual === undefined || kpi.actual === 0 || kpi.actual === null)) {
          const target = monthly.targets[monthly.targets.length - 1] ?? kpi.target;
          let actual = kpi.actual;
          for (let idx = monthly.actuals.length - 1; idx >= 0; idx--) {
            const val = monthly.actuals[idx];
            if (val !== undefined && val !== null && !isNaN(val)) {
              actual = val;
              break;
            }
          }
          if (target) kpi.target = target;
          if (actual) kpi.actual = actual;
        }
      }
    }
  });
}

// Parses Inventory detailed sheet for monthly trend metrics
function parseDetailedInventory(rawRows) {
  let opsDaysData = null;
  let invWoData = null;
  let invWithData = null;
  let gt180Data = null;
  let gt90Data = null;
  let machData = null;
  let toolsData = null;
  let ageTotalData = null;
  let invOverallData = null;
  let invNoOfDaysData = null;
  let tmlData = null;
  let tmbslData = null;

  // Parse TML and TMBSL monthly trend columns (columns 16 to 23 of rows 6/7)
  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const col12 = row[12] ? String(row[12]).trim().toLowerCase() : '';

    if (col12 === 'tml' || col12 === 'tmbsl') {
      const targets = [];
      const actuals = [];
      const colIndices = [15, 17, 19, 21];
      colIndices.forEach(c => {
        const tVal = safeParseFloat(row[c]);
        const aVal = safeParseFloat(row[c + 1]);
        targets.push(isNaN(tVal) ? null : tVal);
        actuals.push(isNaN(aVal) ? null : aVal);
      });

      const fy26Val = safeParseFloat(row[14]) || 0;
      const fyData = { fy24: 0, fy25: 0, fy26: fy26Val };

      const itemData = {
        months: ["Apr'26", "May'26", "June'26", "July'26"],
        targets,
        actuals,
        fyData
      };

      if (col12 === 'tml') tmlData = itemData;
      if (col12 === 'tmbsl') tmbslData = itemData;
    }
  }

  const firstRow = rawRows[0] || [];
  
  const months = [];
  const monthCols = [];
  for (let c = 1; c < firstRow.length; c++) {
    const cellVal = firstRow[c];
    if (cellVal) {
      const m = String(cellVal).trim();
      if (m && isMonthLabel(m)) {
        months.push(m);
        monthCols.push(c);
      }
    }
  }

  // Find overall inventory indices (Row 15)
  let row14Header = null;
  let row15TcTarget = null;
  let row16ScTarget = null;
  let row17Actual = null;
  
  let row19Header = null;
  let row20TcTarget = null;
  let row21ScTarget = null;
  let row22Actual = null;

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    if (!row[0]) continue;
    const clean0 = String(row[0]).trim().toLowerCase().replace(/\s+/g, ' ');

    if (clean0.startsWith('inventory rs in cr')) {
      row14Header = row;
      row15TcTarget = rawRows[i + 1] || [];
      row16ScTarget = rawRows[i + 2] || [];
      row17Actual = rawRows[i + 3] || [];
    }
    if (clean0.startsWith('inventory no of days')) {
      row19Header = row;
      row20TcTarget = rawRows[i + 1] || [];
      row21ScTarget = rawRows[i + 2] || [];
      row22Actual = rawRows[i + 3] || [];
    }
  }

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    if (!row[0]) continue;
    const clean0 = String(row[0]).trim().toLowerCase().replace(/\s+/g, ' ');

    const parseRow = () => {
      const targets = [];
      const actuals = [];
      monthCols.forEach(c => {
        const tVal = safeParseFloat(row[c]);
        const aVal = safeParseFloat(row[c + 1]);
        targets.push(isNaN(tVal) ? null : tVal);
        actuals.push(isNaN(aVal) ? null : aVal);
      });
      return { months, targets, actuals };
    };

    if (clean0.includes('operations inventory no') || clean0.includes('no: of days') || clean0.includes('operations inventory')) {
      opsDaysData = parseRow();
    } else if (clean0.includes('(w/o iflt)')) {
      invWoData = parseRow();
    } else if (clean0.includes('(with iflt)')) {
      invWithData = parseRow();
    } else if (clean0.includes('>180 days') || clean0 === '>180') {
      gt180Data = parseRow();
    } else if (clean0.includes('>90 days') || clean0 === '>90') {
      gt90Data = parseRow();
    } else if (clean0.includes('machinery')) {
      machData = parseRow();
    } else if (clean0.includes('tools') && clean0.includes('idm')) {
      toolsData = parseRow();
    } else if (clean0 === 'total' && i < 10) {
      ageTotalData = parseRow();
    }
  }

  // Parse overall inventory metrics from rows 15-23
  if (row14Header && row15TcTarget && row16ScTarget && row17Actual) {
    const overallMonths = [];
    const overallTargets = [];
    const overallScTargets = [];
    const overallActuals = [];
    for (let c = 5; c < row14Header.length; c++) {
      const m = row14Header[c] ? String(row14Header[c]).trim() : '';
      if (m && isMonthLabel(m)) {
        overallMonths.push(m);
        overallTargets.push(safeParseFloat(row15TcTarget[c]) || 0);
        overallScTargets.push(safeParseFloat(row16ScTarget[c]) || 0);
        overallActuals.push(safeParseFloat(row17Actual[c]) || 0);
      }
    }
    invOverallData = {
      months: overallMonths,
      targets: overallTargets,
      scTargets: overallScTargets,
      actuals: overallActuals,
      fyData: extractFyDataFromRow(row14Header, row17Actual, overallActuals)
    };
  }

  if (row19Header && row20TcTarget && row21ScTarget && row22Actual) {
    const daysMonths = [];
    const daysTargets = [];
    const daysScTargets = [];
    const daysActuals = [];
    for (let c = 5; c < row19Header.length; c++) {
      const m = row19Header[c] ? String(row19Header[c]).trim() : '';
      if (m && isMonthLabel(m)) {
        daysMonths.push(m);
        daysTargets.push(safeParseFloat(row20TcTarget[c]) || 0);
        daysScTargets.push(safeParseFloat(row21ScTarget[c]) || 0);
        daysActuals.push(safeParseFloat(row22Actual[c]) || 0);
      }
    }
    invNoOfDaysData = {
      months: daysMonths,
      targets: daysTargets,
      scTargets: daysScTargets,
      actuals: daysActuals,
      fyData: extractFyDataFromRow(row19Header, row22Actual, daysActuals)
    };
  }

  if (invOverallData && invOverallData.fyData) {
    if (invWoData) invWoData.fyData = JSON.parse(JSON.stringify(invOverallData.fyData));
    if (invWithData) invWithData.fyData = JSON.parse(JSON.stringify(invOverallData.fyData));
  }
  if (invNoOfDaysData && invNoOfDaysData.fyData) {
    if (opsDaysData) opsDaysData.fyData = JSON.parse(JSON.stringify(invNoOfDaysData.fyData));
  }

  return {
    opsDays: opsDaysData,
    invWo: invWoData,
    invWith: invWithData,
    gt180: gt180Data,
    gt90: gt90Data,
    mach: machData,
    tools: toolsData,
    ageTotal: ageTotalData,
    invOverall: invOverallData,
    invNoOfDays: invNoOfDaysData,
    tml: tmlData,
    tmbsl: tmbslData
  };
}

function importInventoryMonthlyData(parsed) {
  const getLatestActual = (item) => {
    if (!item || !item.actuals) return 0;
    for (let idx = item.actuals.length - 1; idx >= 0; idx--) {
      const val = item.actuals[idx];
      if (val !== undefined && val !== null && val !== 0 && !isNaN(val)) {
        return val;
      }
    }
    return item.actuals[0] || 0;
  };

  if (parsed.invOverall) {
    state.inventoryMonthlyData.invOverall = parsed.invOverall;
    state.inventoryMonthlyData.invOverall.fyData.ytd = getLatestActual(parsed.invOverall);
  }
  if (parsed.invNoOfDays) {
    state.inventoryMonthlyData.invNoOfDays = parsed.invNoOfDays;
    state.inventoryMonthlyData.invNoOfDays.fyData.ytd = getLatestActual(parsed.invNoOfDays);
  }

  const finalOpsDays = parsed.opsDays || parsed.invNoOfDays;
  if (finalOpsDays) {
    state.inventoryMonthlyData.opsDays = finalOpsDays;
    const hist = parsed.invNoOfDays ? parsed.invNoOfDays.fyData : { fy24: 0, fy25: 0, fy26: 0 };
    state.inventoryMonthlyData.opsDays.fyData = {
      fy24: hist.fy24 || 0,
      fy25: hist.fy25 || 0,
      fy26: hist.fy26 || 0,
      ytd: getLatestActual(finalOpsDays)
    };
  }

  if (parsed.invWo) {
    state.inventoryMonthlyData.invWo = parsed.invWo;
    state.inventoryMonthlyData.invWo.fyData = {
      fy24: 0,
      fy25: 0,
      fy26: 0,
      ytd: getLatestActual(parsed.invWo)
    };
  }

  if (parsed.invWith) {
    state.inventoryMonthlyData.invWith = parsed.invWith;
    const hist = parsed.invOverall ? parsed.invOverall.fyData : { fy24: 0, fy25: 0, fy26: 0 };
    state.inventoryMonthlyData.invWith.fyData = {
      fy24: hist.fy24 || 0,
      fy25: hist.fy25 || 0,
      fy26: hist.fy26 || 0,
      ytd: getLatestActual(parsed.invWith)
    };
  }

  if (parsed.tml) {
    state.inventoryMonthlyData.tml = parsed.tml;
    state.inventoryMonthlyData.tml.fyData.ytd = getLatestActual(parsed.tml);
  }

  if (parsed.tmbsl) {
    state.inventoryMonthlyData.tmbsl = parsed.tmbsl;
    state.inventoryMonthlyData.tmbsl.fyData.ytd = getLatestActual(parsed.tmbsl);
  }

  if (parsed.gt180) state.inventoryMonthlyData.gt180 = parsed.gt180;
  if (parsed.gt90) state.inventoryMonthlyData.gt90 = parsed.gt90;
  if (parsed.mach) state.inventoryMonthlyData.mach = parsed.mach;
  if (parsed.tools) state.inventoryMonthlyData.tools = parsed.tools;
}

function parsePercent(val) {
  if (val === undefined || val === null) return 0;
  const str = String(val).toLowerCase();
  let num = safeParseFloat(val) || 0;
  if (str.includes('%')) {
    return num; // already in percent e.g. "13%" -> 13
  }
  if (num > 0 && num <= 1.0) {
    return num * 100;
  }
  return num;
}

function parsePercentOrNull(val) {
  if (val === undefined || val === null || String(val).trim() === '') return null;
  return parsePercent(val);
}

function safeParseFloatOrNull(val) {
  if (val === undefined || val === null || String(val).trim() === '') return null;
  const parsed = safeParseFloat(val);
  return isNaN(parsed) ? null : parsed;
}

function getLatestActualFromList(actuals) {
  if (!actuals || actuals.length === 0) return 0;
  for (let idx = actuals.length - 1; idx >= 0; idx--) {
    const val = actuals[idx];
    if (val !== undefined && val !== null && val !== 0 && !isNaN(val)) {
      return val;
    }
  }
  return actuals[0] || 0;
}

// Parses Digital detailed sheet for monthly trend metrics
function parseDetailedDigital(rawRows) {
  let budgetRfqData = null;
  let qualixIqmsData = null;

  const firstRow = rawRows[0] || [];
  
  const months = [];
  const monthCols = [];
  // Month columns start at Column J (index 9)
  for (let c = 9; c < firstRow.length; c++) {
    const cellVal = firstRow[c];
    if (cellVal) {
      const m = formatCellDate(cellVal);
      if (m && isMonthLabel(m)) {
        months.push(m);
        monthCols.push(c);
      }
    }
  }

  for (let i = 0; i < rawRows.length; i++) {
    const row = rawRows[i] || [];
    const clean3 = row[3] ? String(row[3]).trim().toLowerCase().replace(/\s+/g, ' ') : '';
    const clean2 = row[2] ? String(row[2]).trim().toLowerCase().replace(/\s+/g, ' ') : '';

    if (clean3.includes('request for quotation') || clean3 === 'request for quotation') {
      const targets = [];
      const actuals = [];
      monthCols.forEach(c => {
        targets.push(parsePercentOrNull(row[c]));
        actuals.push(parsePercentOrNull(row[c + 1]));
      });
      const ytdVal = getLatestActualFromList(actuals);
      const fyData = { fy24: 0, fy25: 0, fy26: 0, ytd: ytdVal };
      budgetRfqData = { months, targets, actuals, fyData };
    }
    
    if (clean2.includes('qualix iqms across all') || clean2 === 'qualix') {
      const targets = [];
      const actuals = [];
      monthCols.forEach(c => {
        targets.push(safeParseFloatOrNull(row[c]));
        actuals.push(safeParseFloatOrNull(row[c + 1]));
      });
      const ytdVal = getLatestActualFromList(actuals);
      const fyData = { fy24: 0, fy25: 0, fy26: 0, ytd: ytdVal };
      qualixIqmsData = { months, targets, actuals, fyData };
    }
  }

  return { budgetRfq: budgetRfqData, qualixIqms: qualixIqmsData };
}

function importDigitalMonthlyData(parsed) {
  if (parsed.budgetRfq) {
    state.digitalMonthlyData.budgetRfq = parsed.budgetRfq;
    state.digitalMonthlyData.labels = parsed.budgetRfq.months;
  }
  if (parsed.qualixIqms) {
    state.digitalMonthlyData.qualixIqms = parsed.qualixIqms;
    if (!state.digitalMonthlyData.labels) {
      state.digitalMonthlyData.labels = parsed.qualixIqms.months;
    }
  }
}

function formatCellDate(cellVal) {
  if (!cellVal) return '';
  if (cellVal instanceof Date) {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const mName = months[cellVal.getMonth()];
    const yr = String(cellVal.getFullYear()).slice(-2);
    return `${mName}'${yr}`;
  }
  const str = String(cellVal).trim();
  const num = Number(str);
  if (!isNaN(num) && num > 40000 && num < 60000) {
    const d = new Date((num - 25569) * 86400 * 1000);
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const mName = months[d.getMonth()];
    const yr = String(d.getFullYear()).slice(-2);
    return `${mName}'${yr}`;
  }
  return str;
}

// Helper to parse strings to floats robustly, removing non-breaking spaces, commas, and percentage signs
function safeParseFloat(val) {
  if (val === undefined || val === null) return NaN;
  if (typeof val === 'number') return val;
  let str = String(val).trim();
  str = str.replace(/[\u00A0\u2007\u202F\u2000-\u200A\s]+/g, '');
  str = str.replace(/,/g, '');
  str = str.replace(/%/g, '');
  const parsed = Number.parseFloat(str);
  return isNaN(parsed) ? NaN : parsed;
}

// Render Overall dashboard page dynamically
function renderOverallDashboard() {
  const container = document.getElementById('overall-dashboard-wrapper');
  if (!container) return;

  const modules = [
    { id: 'safety', name: 'Safety', icon: '🦺', color: '#ef4444' },
    { id: 'quality', name: 'Quality', icon: '⭐', color: '#f59e0b' },
    { id: 'productivity', name: 'Productivity', icon: '⚙', color: '#10b981' },
    { id: 'delivery', name: 'Delivery', icon: '🚚', color: '#3b82f6' },
    { id: 'cost', name: 'Cost', icon: '💰', color: '#6366f1' },
    { id: 'inventory', name: 'Inventory', icon: '📦', color: '#8b5cf6' },
    { id: 'environment', name: 'Environment', icon: '🌱', color: '#14b8a6' },
    { id: 'hr', name: 'HR', icon: '👥', color: '#ec4899' },
    { id: 'digital', name: 'Digital', icon: '💻', color: '#64748b' }
  ];

  const calculateModuleMetrics = (moduleName) => {
    const allModuleKpis = state.kpis.filter(k => k.module === moduleName);
    if (allModuleKpis.length === 0) return { score: 100, greenCount: 0, redCount: 0, kpis: [] };
    
    let sum = 0;
    let count = 0;
    let greenCount = 0;
    let redCount = 0;
    const trackedKpis = [];
    
    allModuleKpis.forEach(k => {
      if (k.id.includes('_l1') || k.id.includes('_l2') || k.id.includes('_l3')) {
        return;
      }
      
      const achMonthly = getAchievement(k, 'monthly');
      const achYtd = getAchievement(k, 'ytd');
      const safeM = (isNaN(achMonthly) || achMonthly === null || achMonthly === undefined) ? 0 : Number(achMonthly);
      const safeY = (isNaN(achYtd) || achYtd === null || achYtd === undefined) ? 0 : Number(achYtd);
      const ach = parseFloat(((safeM + safeY) / 2).toFixed(1));
      const safeAch = isNaN(ach) ? 0 : ach;
      
      const stMonthly = getStatus(k, 'monthly');
      const stYtd = getStatus(k, 'ytd');
      const st = (stMonthly === 'Green' || stYtd === 'Green') ? (stMonthly === 'Green' && stYtd === 'Green' ? 'Green' : 'Yellow') : 'Red';
      const resolvedKpi = getKpiForMode(k, 'ytd');

      sum += safeAch;
      count++;
      if (st === 'Green' || st === 'Yellow') greenCount++;
      else redCount++;
      trackedKpis.push(resolvedKpi);
    });
    
    const rawScore = count > 0 ? parseFloat((sum / count).toFixed(1)) : 100;
    const score = isNaN(rawScore) ? 100 : Math.min(100, Math.max(0, rawScore));
    return { score, greenCount, redCount, kpis: trackedKpis };
  };

  let plantSum = 0;
  let totalPlantKpis = 0;
  let totalPlantGreen = 0;
  let totalPlantRed = 0;
  
  const moduleMetrics = {};
  let topPillar = modules[0];
  let topPillarScore = -1;
  let focusPillar = modules[0];
  let focusPillarScore = 999;

  modules.forEach(m => {
    const metrics = calculateModuleMetrics(m.id);
    moduleMetrics[m.id] = metrics;

    plantSum += metrics.score;
    totalPlantKpis += metrics.kpis.length;
    totalPlantGreen += metrics.greenCount;
    totalPlantRed += metrics.redCount;

    if (metrics.score > topPillarScore) {
      topPillarScore = metrics.score;
      topPillar = m;
    }
    if (metrics.score < focusPillarScore) {
      focusPillarScore = metrics.score;
      focusPillar = m;
    }
  });
  
  const rawPlantScore = (modules.length > 0 && !isNaN(plantSum)) ? parseFloat((plantSum / modules.length).toFixed(1)) : 100;
  const activePlantScore = isNaN(rawPlantScore) ? 100 : Math.min(100, Math.max(0, rawPlantScore));

  // Determine Plant Status Tier
  let tierClass = 'tier-excellent';
  let tierLabel = 'Tier 1: High Performance 🏆';
  if (activePlantScore < 70) {
    tierClass = 'tier-critical';
    tierLabel = 'Tier 4: Critical Review ⚠️';
  } else if (activePlantScore < 80) {
    tierClass = 'tier-warning';
    tierLabel = 'Tier 3: Action Needed ⚡';
  } else if (activePlantScore < 90) {
    tierClass = 'tier-good';
    tierLabel = 'Tier 2: Good Standard ⭐';
  }

  let html = `
    <!-- Executive Industrial Command Center Banner Artifact -->
    <div class="overall-hero-banner">
      <div class="overall-hero-content">
        <!-- SVG Concentric Radial Score Gauge -->
        <div class="overall-hero-gauge-box">
          <div style="position: relative; width: 120px; height: 120px;">
            <svg width="120" height="120" viewBox="0 0 120 120" style="transform: rotate(-90deg);">
              <circle cx="60" cy="60" r="48" fill="transparent" stroke="rgba(255, 255, 255, 0.15)" stroke-width="12"></circle>
              <circle cx="60" cy="60" r="48" fill="transparent" stroke="${activePlantScore >= 85 ? '#10b981' : activePlantScore >= 75 ? '#3b82f6' : '#ef4444'}" stroke-width="12"
                stroke-dasharray="${2 * Math.PI * 48}" stroke-dashoffset="${(2 * Math.PI * 48) - (activePlantScore / 100) * (2 * Math.PI * 48)}" stroke-linecap="round"
                style="transition: stroke-dashoffset 0.8s ease-out; filter: drop-shadow(0 0 8px ${activePlantScore >= 85 ? 'rgba(16, 185, 129, 0.6)' : 'rgba(59, 130, 246, 0.6)'});"></circle>
            </svg>
            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
              <div style="font-size: 26px; font-weight: 900; color: #ffffff; line-height: 1;">${activePlantScore}%</div>
              <div style="font-size: 9px; color: #94a3b8; font-weight: 800; text-transform: uppercase; margin-top: 3px; letter-spacing: 0.5px;">HEALTH INDEX</div>
            </div>
          </div>
          <span class="tier-badge ${tierClass}" style="margin-top: 10px; font-size: 10px; font-weight: 900; padding: 4px 10px;">${tierLabel}</span>
        </div>

        <!-- Hero Header Info & Badges -->
        <div class="overall-hero-info">
          <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; margin-bottom: 6px;">
            <span style="font-size: 11px; background: rgba(59, 130, 246, 0.3); border: 1px solid rgba(147, 197, 253, 0.4); padding: 3px 10px; border-radius: 20px; color: #93c5fd; font-weight: 800;">
              📍 TATA MOTORS — DHARWAD COMMERCIAL VEHICLE PLANT
            </span>
            <span style="font-size: 11px; background: rgba(16, 185, 129, 0.25); border: 1px solid rgba(52, 211, 153, 0.4); padding: 3px 10px; border-radius: 20px; color: #6ee7b7; font-weight: 800; display: flex; align-items: center;">
              <span class="pulse-live-dot"></span> LIVE OPERATIONAL TELEMETRY
            </span>
          </div>

          <h2 style="margin: 0; font-size: 25px; font-weight: 900; letter-spacing: -0.5px; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">
            🏭 Dharwad Plant Executive Command Center
          </h2>

          <p style="margin-top: 6px; color: #e2e8f0; font-size: 13.5px; line-height: 1.5;">
            Real-time executive performance telemetry parsing overall operational health, productivity, safety, and financial parameters across all 9 plant pillars.
          </p>
          
          <!-- 4 Metallic Stat Cards -->
          <div class="overall-stat-cards-grid">
            <div class="overall-stat-card">
              <span class="stat-label">📈 Overall Score</span>
              <span class="stat-val" style="color: #38bdf8;">${activePlantScore}%</span>
            </div>
            <div class="overall-stat-card">
              <span class="stat-label">🛡️ Plant Pillars</span>
              <span class="stat-val" style="color: #a7f3d0;">9 Pillars</span>
            </div>
            <div class="overall-stat-card">
              <span class="stat-label">⚙️ Tracked KPIs</span>
              <span class="stat-val" style="color: #f1f5f9;">${totalPlantKpis} KPIs</span>
            </div>
            <div class="overall-stat-card">
              <span class="stat-label">🎯 Target Rate</span>
              <span class="stat-val" style="color: #4ade80;">${totalPlantGreen} (${Math.round((totalPlantGreen/totalPlantKpis)*100)}%)</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 3x3 Operational Pillar Grid Artifact -->
    <div class="overall-grid">
  `;

  modules.forEach(m => {
    const { score, greenCount, redCount, kpis } = moduleMetrics[m.id];
    
    let tierBadgeText = 'Tier 1 Excellent 🏆';
    let scoreColor = '#10b981';
    if (score < 70) {
      tierBadgeText = 'Tier 4 Critical ⚠️';
      scoreColor = '#ef4444';
    } else if (score < 80) {
      tierBadgeText = 'Tier 3 Action ⚡';
      scoreColor = '#f59e0b';
    } else if (score < 90) {
      tierBadgeText = 'Tier 2 Good ⭐';
      scoreColor = '#3b82f6';
    }

    let cardVisualHtml = '';

    if (m.id === 'safety') {
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="font-size: 11px; font-weight: 800; color: #64748b; margin-bottom: 6px;">Safety Incident Telemetry</div>
          <div style="display: flex; justify-content: space-around; width: 100%; text-align: center;">
            <div style="background: #fee2e2; padding: 6px 12px; border-radius: 8px;"><div style="font-size: 18px; font-weight: 900; color: #ef4444;">${(kpis.find(k => k.id === 'lti') || {}).actual || 0}</div><div style="font-size: 10px; font-weight: 800; color: #991b1b;">LTI</div></div>
            <div style="background: #fef3c7; padding: 6px 12px; border-radius: 8px;"><div style="font-size: 18px; font-weight: 900; color: #d97706;">${(kpis.find(k => k.id === 'mtc') || {}).actual || 0}</div><div style="font-size: 10px; font-weight: 800; color: #92400e;">MTC</div></div>
            <div style="background: #e0f2fe; padding: 6px 12px; border-radius: 8px;"><div style="font-size: 18px; font-weight: 900; color: #0284c7;">${(kpis.find(k => k.id === 'fac') || {}).actual || 0}</div><div style="font-size: 10px; font-weight: 800; color: #075985;">FAC</div></div>
          </div>
        </div>
      `;
    } else if (m.id === 'quality') {
      const drr1 = (kpis.find(k => k.id === 'drr_1') || {}).actual || 95;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>DRR 1 Performance</span>
            <span style="color: #10b981; font-weight: 900;">${drr1}% Met</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: ${Math.min(100, drr1)}%; background: #10b981; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'productivity') {
      const hpev = (kpis.find(k => k.id === 'hpev_3') || {}).actual || 42.34;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>HPeV 3 Labor Hours</span>
            <span style="color: #3b82f6; font-weight: 900;">${hpev} Hrs</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: 85%; background: #3b82f6; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'delivery') {
      const otif = (kpis.find(k => k.id === 'otif_dom') || {}).actual || 98.4;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>Domestic OTIF Delivery</span>
            <span style="color: #10b981; font-weight: 900;">${otif}% On Time</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: ${Math.min(100, otif)}%; background: #10b981; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'cost') {
      const dmc = (kpis.find(k => k.id === 'dmc') || {}).actual || 4632;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>Direct Material Cost (DMC)</span>
            <span style="color: #6366f1; font-weight: 900;">Rs. ${Number(dmc).toLocaleString()}</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: 78%; background: #6366f1; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'inventory') {
      const opsDays = (kpis.find(k => k.id === 'ops_inv_days') || {}).actual || 18;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>Operations Inventory Coverage</span>
            <span style="color: #8b5cf6; font-weight: 900;">${opsDays} Days</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: 70%; background: #8b5cf6; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'environment') {
      const ghg = (kpis.find(k => k.id === 'ghg_emission') || {}).actual || 412;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>GHG Carbon Emissions</span>
            <span style="color: #14b8a6; font-weight: 900;">${ghg} tCO2e</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: 82%; background: #14b8a6; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'hr') {
      const lives = (kpis.find(k => k.id === 'lives_touched') || {}).actual || 1250;
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>CSR Lives Touched</span>
            <span style="color: #ec4899; font-weight: 900;">${Number(lives).toLocaleString()}</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: 90%; background: #ec4899; height: 100%;"></div>
          </div>
        </div>
      `;
    } else if (m.id === 'digital') {
      cardVisualHtml = `
        <div class="overall-mini-visual-box">
          <div style="display: flex; justify-content: space-between; font-size: 11.5px; font-weight: 800; color: #0f172a; margin-bottom: 6px;">
            <span>Smart Factory Automation</span>
            <span style="color: #64748b; font-weight: 900;">100% Adherence</span>
          </div>
          <div style="width: 100%; background: #e2e8f0; height: 8px; border-radius: 4px; overflow: hidden;">
            <div style="width: 100%; background: #64748b; height: 100%;"></div>
          </div>
        </div>
      `;
    }

    html += `
      <div class="overall-summary-card" data-module="${m.id}" style="border-top: 4px solid ${m.color} !important;">
        <div class="overall-card-header-accent" style="background: linear-gradient(135deg, ${m.color} 0%, var(--primary-navy) 100%);">
          <span style="display: flex; align-items: center; gap: 8px; font-weight: 900;">
            <span class="pillar-icon-badge">${m.icon}</span> ${m.name} Dashboard
          </span>
          <span style="font-size: 11px; background: rgba(255, 255, 255, 0.25); padding: 3px 8px; border-radius: 6px; font-weight: 900; color: #ffffff; backdrop-filter: blur(4px);">${tierBadgeText}</span>
        </div>
        
        <div style="padding: 20px 20px 15px 20px; display: flex; flex-direction: column; gap: 14px; background: #ffffff;">
          <!-- Main Overall Score Hero Section -->
          <div>
            <div style="display: flex; justify-content: space-between; align-items: baseline;">
              <span style="font-size: 11px; font-weight: 800; text-transform: uppercase; color: #64748b; letter-spacing: 0.5px;">Overall Module Score</span>
              <span style="font-size: 28px; font-weight: 900; color: ${scoreColor}; line-height: 1;">${score}%</span>
            </div>
            <div class="overall-mini-progress-track" style="height: 10px; margin-top: 8px;">
              <div class="overall-mini-progress-fill" style="width: ${Math.min(100, score)}%; background: ${scoreColor};"></div>
            </div>
          </div>

          <!-- Module Feature Visual Box -->
          ${cardVisualHtml}
        </div>
        
        <div class="overall-card-stats-footer">
          <div class="overall-pill-counts">
            <span class="count-badge-green">🟢 ${greenCount} On Target</span>
            <span class="count-badge-red">🔴 ${redCount} Attention</span>
          </div>
          <span class="explore-btn">
            Explore ${m.name} →
          </span>
        </div>
      </div>
    `;
  });

  html += `
    </div>

    <!-- Executive Pillar Performance Analytics Dual Chart Artifact -->
    <div class="overall-analytics-card">
      <div>
        <div class="overall-analytics-title">
          <span>📊 Dharwad Plant Operational Pillar Performance Comparison</span>
        </div>
        <div style="position: relative; height: 260px; width: 100%;">
          <canvas id="overall-pillar-bar-chart"></canvas>
        </div>
      </div>

      <div class="overall-insights-panel">
        <div style="font-size: 14.5px; font-weight: 900; color: var(--primary-navy); border-bottom: 1px solid #cbd5e1; padding-bottom: 8px; display: flex; align-items: center; gap: 6px;">
          💡 Executive Operational Highlights
        </div>
        
        <div class="insight-badge-row">
          <span class="insight-badge-title">🏆 Top Performing Pillar</span>
          <span class="insight-badge-val" style="background: #d1fae5; color: #047857;">${topPillar.icon} ${topPillar.name} (${topPillarScore}%)</span>
        </div>

        <div class="insight-badge-row">
          <span class="insight-badge-title">⚠️ Priority Focus Pillar</span>
          <span class="insight-badge-val" style="background: #fee2e2; color: #b91c1c;">${focusPillar.icon} ${focusPillar.name} (${focusPillarScore}%)</span>
        </div>

        <div class="insight-badge-row">
          <span class="insight-badge-title">🎯 Plant Target Benchmark</span>
          <span class="insight-badge-val" style="background: #e0f2fe; color: #0369a1;">85.0% Standard</span>
        </div>

        <div class="insight-badge-row">
          <span class="insight-badge-title">⚡ Digital Automation</span>
          <span class="insight-badge-val" style="background: #f1f5f9; color: #475569;">100% Smart Factory</span>
        </div>
      </div>
    </div>
  `;

  container.innerHTML = html;

  // Render Chart.js Bar Chart Artifact for Pillar Performance
  setTimeout(() => {
    const canvas = document.getElementById('overall-pillar-bar-chart');
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (window.overallPillarChartInstance) {
        window.overallPillarChartInstance.destroy();
      }
      
      const labels = modules.map(m => `${m.icon} ${m.name}`);
      const dataScores = modules.map(m => moduleMetrics[m.id].score);
      const bgColors = modules.map(m => m.color);

      window.overallPillarChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Overall Performance Score (%)',
              data: dataScores,
              backgroundColor: bgColors,
              borderRadius: 8,
              barThickness: 26
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: (context) => ` Score: ${context.raw}%`
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              max: 100,
              grid: { color: '#e2e8f0' },
              ticks: { font: { weight: 'bold' } }
            },
            x: {
              grid: { display: false },
              ticks: { font: { weight: 'bold', size: 11 } }
            }
          }
        }
      });
    }
  }, 50);

  // Bind click navigation events to summary cards and matrix buttons
  container.querySelectorAll('.overall-summary-card, .matrix-nav-btn').forEach(el => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      const moduleName = el.getAttribute('data-module');
      if (moduleName) {
        const tabBtn = document.getElementById(`tab-${moduleName}`);
        if (tabBtn) tabBtn.click();
      }
    });
  });
}
